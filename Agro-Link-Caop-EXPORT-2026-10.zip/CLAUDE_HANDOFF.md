# AgroLink Caop — Handoff técnico específico para Claude

Data: 2026-09-15

## 1. Objetivo

Este pacote contém o workspace atual do AgroLink Caop. O objetivo imediato é obter uma **validação real do projeto**, sobretudo instalação das dependências e `npm run build`, num ambiente com acesso funcional ao npm.

O projeto NÃO deve ser recriado do zero.

## 2. Estado arquitetural REAL

Runtime ativo:
- Frontend: React 18 + TypeScript + Vite + PWA.
- Offline/local: Dexie/IndexedDB.
- Backend: Node.js (`server/index.mjs`).
- Base de dados ativa: SQLite interno via `node:sqlite` (`server/db.mjs`).
- API: `/api/*`, servida pelo backend.
- Uploads: `server/uploads/`.
- O antigo código Supabase está em `legacy/supabase/` e é apenas histórico.
- Não trate os documentos antigos que descrevem Supabase como descrição da arquitetura ativa.

Papéis ativos:
- agricultor
- tecnico
- transportador
- admin
- auditor
- admin_chefe

`admin_chefe` é um papel protegido. O email reservado padrão é `sebastiaoissenguel27@gmail.com`, configurável por `ADMIN_CHEFE_EMAIL`. O bootstrap usa `AGROLINK_ADMIN_CHEFE_PASSWORD`.

## 3. Trabalho já implementado antes deste handoff

Já foram implementados e/ou auditados no workspace:

- migração para DB interna SQLite;
- autenticação e sessões;
- recuperação de password com token de uso único e expiração;
- gestão de utilizadores e papéis;
- proteção do `admin_chefe`;
- suspensão/reactivação de contas;
- denúncias e respetivo histórico;
- Security & Trust Layer;
- incidentes de segurança persistentes;
- ações de segurança auditáveis;
- bloqueio temporário defensivo de IP;
- rate limiting HTTP;
- validação de Origin;
- limites de payload;
- headers de segurança/CSP;
- modo de emergência/kill switch limitado e auditável;
- backups SQLite com `VACUUM INTO` + integrity check;
- scheduler de backup/segurança;
- escalada autónoma defensiva limitada quando o `admin_chefe` está operacionalmente indisponível;
- smoke tests de staging e testes de segurança autónomos;
- relatórios de validação.

Nada disso deve ser removido ou substituído sem uma razão técnica forte e documentada.

## 4. Regra crítica sobre testes

O ambiente anterior NÃO conseguiu instalar dependências porque o DNS/rede para o npm estava indisponível. Foram observados erros como:

`EAI_AGAIN registry.npmjs.org`

Portanto:

- auditorias estáticas anteriores não equivalem a um build real;
- não afirmar que `npm run build` passou até o comando ser realmente executado;
- não confundir `node_modules` parcial com instalação válida;
- se `npm ci` falhar por rede, registar exatamente o erro e não mascará-lo como erro de código.

## 5. PRIMEIRA FASE — instalação e build REAL

Executar na raiz do projeto:

```bash
node --version
npm --version
npm config get registry
npm cache verify
npm ping
npm ci
npm run build
```

Se `npm ci` falhar:

1. identificar se é rede/DNS/registry ou dependência;
2. não alterar package.json/package-lock.json apenas para contornar um problema de rede;
3. tentar novamente apenas se houver uma correção legítima do ambiente;
4. se o ambiente tiver um registry corporativo configurado, verificar o registry efetivo antes de modificar qualquer configuração.

Se `npm ci` completar, executar obrigatoriamente:

```bash
npm run build
```

Se o build falhar por TypeScript/Vite/código, corrigir a causa real e executar novamente até obter um resultado verificável.

## 6. SEGUNDA FASE — validação do backend

Depois do build:

```bash
node --check server/index.mjs
node --check server/db.mjs
node --check server/securityTrust.mjs
node --check server/backup.mjs
node scripts/build-preflight.mjs
node scripts/staging-smoke.mjs
node scripts/security-autonomous-smoke.mjs
```

Se algum script tiver pré-requisitos específicos, ler o script antes de executar e documentar o resultado.

## 7. TERCEIRA FASE — auditoria do frontend

Procurar:

- imports quebrados;
- rotas sem destino;
- páginas inacessíveis;
- chamadas para endpoints inexistentes;
- referências Supabase fora de `legacy/`;
- APIs incompatíveis entre frontend/backend;
- problemas de PWA/manifest/service worker;
- ausência de ícones reais do PWA;
- falhas de autenticação/autorização;
- operações administrativas que possam escapar do controle do `admin_chefe`.

Comandos úteis:

```bash
grep -RIn "supabase" src server --exclude-dir=node_modules || true
grep -RIn "TODO\|FIXME" src server || true
```

Não tratar referências históricas em `legacy/` como runtime ativo.

## 8. QUARTA FASE — auditoria de segurança

Verificar especificamente:

### Auth
- login/logout;
- sessões;
- reset de password;
- revogação de sessões após reset;
- bootstrap do `admin_chefe`;
- impossibilidade de signup público usando o email reservado do chief.

### Autorização
- agricultor não pode executar operações de admin;
- admin não pode alterar o `admin_chefe`;
- outro admin não pode suspender/demover o `admin_chefe`;
- `admin_chefe` não pode auto-suspender ou auto-demover;
- somente `admin_chefe` pode promover para `admin`/`auditor`;
- contas não são eliminadas.

### Segurança de rede/API
- rate limiting;
- bloqueio temporário de IP;
- Origin validation;
- payload limits;
- CSP/security headers;
- tratamento de `X-Forwarded-For` sem confiar cegamente em cabeçalhos controláveis pelo cliente.

### Security Trust
- incidentes persistentes;
- ações auditadas;
- escalada high/critical;
- contenção defensiva limitada;
- não existência de qualquer contra-ataque ou ação ofensiva;
- modo de emergência limitado e reversível.

### Backup
- `VACUUM INTO`;
- integrity check;
- caminho de backup não deve expor caminho absoluto do servidor ao cliente;
- produção deve usar armazenamento persistente (`AGROLINK_DATA_DIR`).

## 9. QUINTA FASE — correções

Se forem encontrados bugs:

1. determinar a causa raiz;
2. corrigir no código;
3. executar novamente os testes afetados;
4. executar o build completo novamente;
5. atualizar documentação de estado;
6. criar um checkpoint/pacote antes de alterações de grande porte.

Não fazer uma grande refatoração só porque é possível.

## 10. O que NÃO fazer

- Não recriar o projeto.
- Não trocar SQLite por Supabase.
- Não remover o `legacy/supabase/` sem autorização.
- Não apagar funcionalidades existentes.
- Não alterar GitHub/main/branches remotos sem autorização explícita do proprietário.
- Não aplicar migrations externas em produção sem autorização.
- Não inventar credenciais, tokens ou chaves.
- Não declarar testes como passados sem execução real.
- Não substituir o sistema de segurança por uma implementação mais simples apenas para o build passar.

## 11. Segurança de segredos

Este pacote deliberadamente NÃO contém:
- `.env` real;
- tokens;
- passwords reais;
- chaves API;
- banco SQLite de runtime;
- uploads privados;
- `node_modules`.

Usar `.env.example` para identificar variáveis necessárias.

## 12. Resultado esperado de Claude

No final, produzir um relatório curto com:

1. `npm ci`: PASS/FAIL + motivo;
2. `npm run build`: PASS/FAIL + erros reais, se houver;
3. backend smoke: PASS/FAIL;
4. security smoke: PASS/FAIL;
5. principais bugs encontrados e corrigidos;
6. ficheiros alterados;
7. qualquer bloqueio externo que impeça validação;
8. recomendação objetiva do próximo passo.

Se o build passar, isso deve ser explicitamente distinguido de uma auditoria de produção: **build verde não significa que todas as funcionalidades de produção foram validadas**.

## 13. Ordem de prioridade

1. Instalar dependências.
2. Build real.
3. Corrigir erros reais do build.
4. Smoke tests backend.
5. Smoke tests de segurança.
6. Auditoria de integração frontend ↔ backend.
7. Auditoria PWA/offline.
8. Só depois considerar novas funcionalidades.

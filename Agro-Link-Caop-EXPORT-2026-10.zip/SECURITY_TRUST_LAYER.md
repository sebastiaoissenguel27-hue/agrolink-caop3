# AgroLink Caop — Security & Trust Layer

## Objetivo
Criar uma camada de segurança defensiva que deteta sinais anormais, analisa risco, alerta a administração e mantém um protocolo autónomo de contenção quando o administrador-chefe estiver indisponível.

## Regra de disponibilidade do administrador-chefe
- Se existir uma sessão ativa do `admin_chefe`, incidentes relevantes permanecem pendentes e o sistema envia uma notificação a pedir orientação.
- Se não existir uma sessão ativa e o incidente for `alto`/`critico`, o protocolo autónomo pode aplicar contenção defensiva reversível.
- A indisponibilidade é inferida pela ausência de sessão ativa; isto não significa que a pessoa esteja literalmente offline.

## O que a IA pode fazer
- classificar/analisar sinais de segurança;
- explicar o risco;
- recomendar contenção;
- ajudar a priorizar incidentes;
- produzir relatórios mensais.

## O que a IA não pode fazer
- atacar a origem;
- explorar sistemas externos;
- apagar contas ou dados;
- promover privilégios;
- alterar a própria política de segurança;
- executar ações irreversíveis por conta própria.

## Protocolo autónomo
1. Registar o sinal em `logs_seguranca`.
2. Criar um incidente em `security_incidents` quando o risco ultrapassar o limiar.
3. Fazer análise IA quando `OPENAI_API_KEY` estiver disponível; caso contrário, usar o motor determinístico.
4. Se o administrador-chefe estiver disponível: notificar e aguardar decisão.
5. Se estiver indisponível: para risco alto/crítico, bloquear temporariamente a origem por 15 minutos, registar a ação e marcar o incidente como `contido`.
6. Quando o administrador-chefe voltar, poderá manter, libertar ou encerrar a contenção através do painel.

## Relatórios
O backend verifica diariamente se já existe o relatório do mês anterior. Se não existir, gera-o, guarda-o em `security_monthly_reports` e cria uma notificação para o administrador-chefe. Assim o relatório não depende de uma ação manual.

## Limitações atuais
- O alerta é atualmente uma notificação interna persistente. Push web/email externo ainda depende de configurar um provedor de entrega.
- A análise IA externa é opcional; o sistema continua protegido sem ela.
- A contenção por IP depende de o servidor conhecer corretamente a origem real; em produção, `X-Forwarded-For` deve ser confiável apenas quando preenchido pelo proxy/reverse proxy controlado pela plataforma.

## Operação e alertas
- O painel do administrador-chefe faz polling periódico de incidentes e pode mostrar notificações do navegador quando autorizado.
- `AGROLINK_SECURITY_ALERT_WEBHOOK_URL` permite integrar um canal externo de alerta controlado pela organização.
- O backend aplica cabeçalhos de segurança, valida a origem dos pedidos mutáveis e possui limitação global de pedidos por origem.
- Incidentes alto/crítico aguardam decisão humana enquanto o administrador-chefe estiver disponível; se não houver disponibilidade, o protocolo autónomo pode aplicar apenas contenção reversível.
- Se um incidente alto/crítico ficar aberto por 5 minutos sem decisão e o administrador-chefe estiver indisponível, o scheduler aplica a contenção autónoma e regista o motivo.
- A ausência de sessão não prova que a pessoa esteja fisicamente indisponível; é apenas o sinal operacional usado pelo sistema.

## Identidades fixas de administrador-chefe — 25/09/2026

| Identidade | Papel | Visibilidade |
| --- | --- | --- |
| `sebastiaoissenguel27@gmail.com` | `admin_chefe` | Perfil público da equipa oficial |
| `celcioissenguel@gmail.com` | `admin_chefe` | Perfil completamente oculto para utilizadores comuns |

- A migração `server/migrations/006_admin_chief_identities.sql` promove contas existentes sem as apagar, define a visibilidade, impõe unicidade normalizada (`trim` + minúsculas) e impede alterações aos e-mails, papéis e visibilidade reservados.
- O bootstrap do backend cria cada conta ausente apenas quando a respetiva password é fornecida no ambiente do servidor. Contas existentes mantêm a password e o estado de suspensão; pedidos públicos de registo não podem reclamar nenhum dos endereços.
- `GET /api/public/team` apresenta somente o administrador público e devolve campos de perfil aprovados, sem e-mail ou telefone. Pesquisas comuns de utilizadores excluem a identidade oculta; endpoints administrativos continuam a listar e administrar ambas.
- `AGROLINK_ADMIN_CHEFE_HIDDEN_PASSWORD` configura o bootstrap da conta oculta. `AGROLINK_ADMIN_CHEFE_PUBLIC_PASSWORD` permite configurar a conta pública quando `AGROLINK_ADMIN_CHEFE_EMAIL` está definido para uma identidade legada personalizada. `AGROLINK_ADMIN_CHEFE_PASSWORD` mantém compatibilidade com o bootstrap legado. Estas variáveis não devem conter valores no repositório.

## Modo de Emergência e continuidade

O protocolo possui três estados operacionais:
1. `normal` — funcionalidades normais;
2. `alerta` — monitorização reforçada sem bloqueio automático de funcionalidades;
3. `emergencia` — funcionalidades de risco selecionadas podem ser temporariamente desativadas.

O administrador-chefe pode alterar o estado e selecionar as funcionalidades protegidas. Um incidente crítico, quando o administrador-chefe está indisponível, pode elevar automaticamente o estado para `emergencia`. A reversão é administrativa e auditada.

### Recuperação de palavra-passe

A recuperação não depende de Supabase. O backend gera token aleatório, armazena apenas o hash, limita solicitações, expira em 60 minutos, marca o token como usado e encerra sessões existentes depois da alteração. A entrega é abstraída por webhook HTTPS para que possa ser ligado a um provedor de email/SMS sem colocar credenciais do provedor no frontend.

### Backup e integridade

Existe verificação de integridade antes e depois do backup. O scheduler cria no máximo um backup diário e aplica retenção. O backup local não substitui uma cópia externa/off-site; para produção, a pasta de backups deve ser persistida e, idealmente, replicada por infraestrutura controlada.

## Hardening adicional — 15/09/2026

- Um IP contido pelo Security & Trust Layer não recebe bypass automático por possuir uma sessão administrativa. Isto reduz o risco de uma sessão administrativa comprometida escapar da contenção baseada na origem.
- Em produção, a plataforma exige explicitamente `AGROLINK_DATA_DIR`, evitando implantação acidental com SQLite num filesystem efémero.
- SQLite foi configurado com WAL e `busy_timeout=5000`.
- O endpoint administrativo de listagem de backups não expõe o caminho absoluto do filesystem.

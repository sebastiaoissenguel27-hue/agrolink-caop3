# AgroLink Caop — inventário do workspace atual

> Exportado em: 2026-09-14T13:30:59.160604+00:00
> Raiz auditada: `/home/runner/workspace`

## Escopo e preservação

Este inventário foi gerado a partir da árvore presente no workspace no momento da exportação. Nenhum código funcional, migration, configuração ativa ou dependência foi alterado para produzir o snapshot.

- Repositório Git: **não disponível** neste workspace; não foi possível criar branch ou checkpoint Git.
- O checkpoint auditável produzido é `AGROLINK_CURRENT_WORKSPACE.zip`.
- `node_modules/`, `dist/`, `.cache/`, `.local/`, `.agents/` e `tsconfig.tsbuildinfo` ficaram fora por serem dependências, artefactos gerados ou metadados do ambiente.
- `.env`, `.env.local`, tokens, chaves privadas e credenciais ficaram fora; `.env.example` foi incluído por ser um modelo sem segredo.
- Os anexos Recovery/Pacotes foram incluídos em `audit-materials/` como contexto de auditoria, separados do código ativo.

## Resumo

- Ficheiros no ZIP: **170** (inclui este inventário).
- Ficheiros de aplicação ativos analisados: **155**.
- Migrations SQL: **27**.
- Edge Functions: **3**.
- Rotas declaradas em `src/app/App.tsx`: **28**.

## Estrutura de diretórios exportada

```text
audit-materials/
audit-materials/package-docs/agrolink-caop-pacote1-fundacao-visual_1788799034296/
audit-materials/package-docs/agrolink-caop-pacote1-fundacao-visual_1788799350880/
audit-materials/package-docs/agrolink-caop-pacotes2-9_1788799034452/
audit-materials/package-docs/agrolink-caop-pacotes2-9_1788799337110/
audit-materials/source-attachments/
docs/
public/
public/icons/
src/
src/app/
src/app/components/
src/app/pages/
src/features/academia/api/
src/features/academia/components/
src/features/academia/pages/
src/features/admin/api/
src/features/admin/components/
src/features/admin/pages/
src/features/agricultor/pages/
src/features/alertas/api/
src/features/alertas/pages/
src/features/auth/api/
src/features/auth/components/
src/features/auth/context/
src/features/auth/pages/
src/features/biblioteca/api/
src/features/biblioteca/pages/
src/features/configuracoes/api/
src/features/configuracoes/pages/
src/features/ferramentas/api/
src/features/ferramentas/pages/
src/features/ia-agricola/api/
src/features/ia-agricola/lib/
src/features/ia-agricola/pages/
src/features/manual/pages/
src/features/noticias/api/
src/features/noticias/pages/
src/features/pais/pages/
src/features/recursos/api/
src/features/recursos/pages/
src/features/relatos/api/
src/features/relatos/components/
src/features/relatos/lib/
src/features/relatos/pages/
src/features/tecnico/components/
src/features/tecnico/pages/
src/features/visitante/pages/
src/offline/
src/shared/api/
src/shared/assets/
src/shared/components/
src/shared/i18n/
src/shared/i18n/locales/
src/shared/lib/
src/shared/styles/
src/shared/types/
supabase/functions/ia-agricola-proxy/
supabase/functions/ia-resumo-mensal/
supabase/functions/sync-noticias/
supabase/migrations/
```

## Raiz e configuração

| Ficheiro | Observação |
|---|---|
| `package.json` | configuração ativa |
| `package-lock.json` | configuração ativa |
| `vite.config.ts` | configuração ativa |
| `tsconfig.json` | configuração ativa |
| `index.html` | configuração ativa |
| `.env.example` | configuração ativa |
| `.gitignore` | configuração ativa |
| `.replit` | configuração ativa |
| `README.md` | documentação |
| `HANDOFF_PROMPT.md` | documentação |
| `HANDOFF_SUMMARY.md` | documentação |
| `PILOT_READINESS.md` | documentação |
| `PILOT_TEST_PLAN.md` | documentação |
| `PROJECT_STATUS.md` | documentação |
| `RECONSTRUCTION_AUDIT.md` | documentação |
| `RECONSTRUCTION_STATUS.md` | documentação |

## `package.json`

### Scripts npm

- `dev`: `vite --host 0.0.0.0 --port 4173`
- `build`: `tsc -b && vite build`
- `preview`: `vite preview --host 0.0.0.0 --port 4173`

### Dependências de produção

- `@supabase/supabase-js`: `^2.45.4`
- `dexie`: `^4.0.8`
- `dexie-react-hooks`: `^1.1.7`
- `react`: `^18.3.1`
- `react-dom`: `^18.3.1`
- `react-router-dom`: `^6.26.2`

### Dependências de desenvolvimento

- `@playwright/test`: `^1.62.1`
- `@types/node`: `^26.5.1`
- `@types/react`: `^18.3.5`
- `@types/react-dom`: `^18.3.0`
- `@vitejs/plugin-react`: `^4.3.1`
- `playwright`: `^1.62.1`
- `typescript`: `^5.5.4`
- `vite`: `^5.4.3`
- `vite-plugin-pwa`: `^0.20.5`

## Rotas reais declaradas

| Rota | Componente/página | Proteção |
|---|---|---|
| `/` | `RootGate` | público |
| `/pais` | `EscolhaPaisPage` | público |
| `/visitante` | `VisitanteLandingPage` | público |
| `/visitante-offline` | `VisitanteOfflinePage` | público |
| `/manual` | `ManualPage` | público |
| `/entrar` | `LoginPage` | público |
| `/registar` | `RegisterPage` | público |
| `/esqueci-password` | `ForgotPasswordPage` | público |
| `/redefinir-password` | `ResetPasswordPage` | público |
| `/relato-anonimo` | `RelatoAnonimoPage` | público |
| `/sobre` | `InstitucionalPage` | público |
| `/acesso-negado` | `AcessoNegadoPage` | público |
| `/conta-pendente` | `ContaPendentePage` | público |
| `/conta-bloqueada` | `ContaBloqueadaPage` | público |
| `/perfil` | `PerfilPage` | autenticado |
| `/noticias` | `NoticiasPage` | autenticado |
| `/alertas` | `AlertasPage` | autenticado |
| `/assistente` | `IAChatPage` | autenticado |
| `/configuracoes` | `ConfiguracoesPage` | autenticado |
| `/ferramentas` | `FerramentasPage` | autenticado |
| `/recursos` | `RecursosPage` | autenticado |
| `/biblioteca` | `BibliotecaPage` | autenticado |
| `/academia` | `AcademiaPage` | autenticado |
| `/academia/:cursoId` | `CursoDetalhePage` | autenticado |
| `/relatos` | `RelatosPage` | autenticado — papel: agricultor |
| `/tecnico` | `TecnicoPage` | autenticado — papel: tecnico |
| `/admin` | `AdminPage` | autenticado — papel: admin |
| `*` | `PaginaNaoEncontradaPage` | público |

As páginas são importadas e declaradas em `src/app/App.tsx`. A rota `/` usa `RootGate` e decide entre sessão autenticada, landing de visitante e escolha de país. A rota `*` usa `PaginaNaoEncontradaPage`.

## Frontend: componentes, hooks, serviços e tipos

### Componentes (36)
- `src/app/components/AppHeader.tsx`
- `src/app/components/AppLayout.tsx`
- `src/app/components/AtualizacaoDisponivel.tsx`
- `src/app/components/BackButton.tsx`
- `src/app/components/Breadcrumbs.tsx`
- `src/app/components/ConfirmDialog.tsx`
- `src/app/components/FeedbackBanner.tsx`
- `src/app/components/InstallAppButton.tsx`
- `src/app/components/NotificationBell.tsx`
- `src/app/components/SyncBadge.tsx`
- `src/app/components/layout.css`
- `src/features/academia/components/QuizLicao.tsx`
- `src/features/admin/components/AdminAcademia.tsx`
- `src/features/admin/components/AdminAlertas.tsx`
- `src/features/admin/components/AdminAuditoria.tsx`
- `src/features/admin/components/AdminBiblioteca.tsx`
- `src/features/admin/components/AdminEstatisticas.tsx`
- `src/features/admin/components/AdminFontesNoticias.tsx`
- `src/features/admin/components/AdminIA.tsx`
- `src/features/admin/components/AdminMensagens.tsx`
- `src/features/admin/components/AdminNoticias.tsx`
- `src/features/admin/components/AdminRecursos.tsx`
- `src/features/admin/components/AdminUtilizadores.tsx`
- `src/features/auth/components/AuthLayout.tsx`
- `src/features/auth/components/auth.css`
- `src/features/relatos/components/NovoRelatoForm.tsx`
- `src/features/tecnico/components/RelatoDetalheTecnico.tsx`
- `src/shared/components/BottomNav.tsx`
- `src/shared/components/Button.tsx`
- `src/shared/components/Card.tsx`
- `src/shared/components/EstadosInterface.tsx`
- `src/shared/components/Logo.tsx`
- `src/shared/components/PageContainer.tsx`
- `src/shared/components/PageHeader.tsx`
- `src/shared/components/StatusBadge.tsx`
- `src/shared/components/ui.css`

### Hooks (0)

### Serviços/API (13)
- `src/features/academia/api/academiaService.ts`
- `src/features/admin/api/adminService.ts`
- `src/features/admin/api/iaAdminService.ts`
- `src/features/alertas/api/alertasService.ts`
- `src/features/auth/api/authService.ts`
- `src/features/biblioteca/api/bibliotecaService.ts`
- `src/features/configuracoes/api/preferenciasService.ts`
- `src/features/ferramentas/api/ferramentasService.ts`
- `src/features/ia-agricola/api/iaService.ts`
- `src/features/noticias/api/noticiasService.ts`
- `src/features/recursos/api/recursosService.ts`
- `src/features/relatos/api/relatosService.ts`
- `src/shared/api/notificacoesService.ts`

### Bibliotecas/utilitários (5)
- `src/features/ia-agricola/lib/mediaValidation.test.ts`
- `src/features/ia-agricola/lib/mediaValidation.ts`
- `src/features/relatos/lib/estadoRelato.ts`
- `src/shared/lib/country.ts`
- `src/shared/lib/supabaseClient.ts`

### Tipos (1)
- `src/shared/types/database.types.ts`

### Páginas/rotas (29)
- `src/app/pages/AcessoNegadoPage.tsx`
- `src/app/pages/ContaBloqueadaPage.tsx`
- `src/app/pages/ContaPendentePage.tsx`
- `src/app/pages/HomePage.tsx`
- `src/app/pages/InstitucionalPage.tsx`
- `src/app/pages/PaginaNaoEncontradaPage.tsx`
- `src/app/pages/PerfilPage.tsx`
- `src/features/academia/pages/AcademiaPage.tsx`
- `src/features/academia/pages/CursoDetalhePage.tsx`
- `src/features/admin/pages/AdminPage.tsx`
- `src/features/agricultor/pages/AgricultorDashboard.tsx`
- `src/features/alertas/pages/AlertasPage.tsx`
- `src/features/auth/pages/ForgotPasswordPage.tsx`
- `src/features/auth/pages/LoginPage.tsx`
- `src/features/auth/pages/RegisterPage.tsx`
- `src/features/auth/pages/ResetPasswordPage.tsx`
- `src/features/biblioteca/pages/BibliotecaPage.tsx`
- `src/features/configuracoes/pages/ConfiguracoesPage.tsx`
- `src/features/ferramentas/pages/FerramentasPage.tsx`
- `src/features/ia-agricola/pages/IAChatPage.tsx`
- `src/features/manual/pages/ManualPage.tsx`
- `src/features/noticias/pages/NoticiasPage.tsx`
- `src/features/pais/pages/EscolhaPaisPage.tsx`
- `src/features/recursos/pages/RecursosPage.tsx`
- `src/features/relatos/pages/RelatoAnonimoPage.tsx`
- `src/features/relatos/pages/RelatosPage.tsx`
- `src/features/tecnico/pages/TecnicoPage.tsx`
- `src/features/visitante/pages/VisitanteLandingPage.tsx`
- `src/features/visitante/pages/VisitanteOfflinePage.tsx`

### Estilos/assets (2)
- `src/shared/assets/agrolink-logo-master.png`
- `src/shared/styles/tokens.css`

## Integrações externas e mecanismos

- **Supabase:** cliente frontend em `src/shared/lib/supabaseClient.ts`; Auth, Database, Storage, RPC e Edge Functions.
- **IA:** Edge Function `supabase/functions/ia-agricola-proxy/index.ts`; o código usa a variável `GEMINI_API_KEY` apenas no ambiente da função.
- **Offline:** Dexie/Dexie React Hooks, filas locais e cache; referências em `src/offline/` e nos serviços de domínio.
- **PWA:** `vite-plugin-pwa`, `vite.config.ts`, `src/main.tsx`, manifest, service worker e `public/icons/`.
- **Autenticação:** Supabase Auth via `AuthContext`, `ProtectedRoute` e páginas de login/registo/recuperação.
- **Storage:** chamadas Supabase Storage em serviços de Relatos e Academia.

## Referências ao Supabase no código

### `supabase` — 38 ficheiro(s)
- `HANDOFF_PROMPT.md`
- `HANDOFF_SUMMARY.md`
- `PILOT_READINESS.md`
- `PILOT_TEST_PLAN.md`
- `PROJECT_STATUS.md`
- `RECONSTRUCTION_AUDIT.md`
- `RECONSTRUCTION_STATUS.md`
- `docs/AGROLINK_PACOTES_INTEGRACAO.md`
- `docs/auditoria-v2.md`
- `docs/handoff-sessao.md`
- `docs/plano-v1-integrada.md`
- `docs/relatorio-fecho-v2-final.md`
- `docs/relatorio-fecho-v2.md`
- `docs/relatorio-tecnico-v2.md`
- `package-lock.json`
- `package.json`
- `src/features/academia/api/academiaService.ts`
- `src/features/admin/api/adminService.ts`
- `src/features/admin/api/iaAdminService.ts`
- `src/features/alertas/api/alertasService.ts`
- `src/features/auth/api/authService.ts`
- `src/features/auth/context/AuthContext.tsx`
- `src/features/biblioteca/api/bibliotecaService.ts`
- `src/features/configuracoes/api/preferenciasService.ts`
- `src/features/ferramentas/api/ferramentasService.ts`
- `src/features/ia-agricola/api/iaService.ts`
- `src/features/noticias/api/noticiasService.ts`
- `src/features/recursos/api/recursosService.ts`
- `src/features/relatos/api/relatosService.ts`
- `src/offline/syncEngine.ts`
- `src/shared/api/notificacoesService.ts`
- `src/shared/lib/supabaseClient.ts`
- `src/shared/types/database.types.ts`
- `supabase/functions/ia-agricola-proxy/index.ts`
- `supabase/functions/ia-resumo-mensal/index.ts`
- `supabase/functions/sync-noticias/index.ts`
- `supabase/migrations/0006_preparacao_futura.sql`
- `supabase/migrations/0025_security_trust_layer_base.sql`

### `createClient` — 4 ficheiro(s)
- `src/shared/lib/supabaseClient.ts`
- `supabase/functions/ia-agricola-proxy/index.ts`
- `supabase/functions/ia-resumo-mensal/index.ts`
- `supabase/functions/sync-noticias/index.ts`

### `auth.` — 22 ficheiro(s)
- `docs/relatorio-fecho-v2.md`
- `docs/relatorio-tecnico-v2.md`
- `src/features/auth/api/authService.ts`
- `src/features/auth/components/AuthLayout.tsx`
- `src/features/auth/context/AuthContext.tsx`
- `src/features/configuracoes/api/preferenciasService.ts`
- `supabase/functions/ia-agricola-proxy/index.ts`
- `supabase/migrations/0001_profiles_and_rls.sql`
- `supabase/migrations/0002_status_verificacao_e_rls_por_papel.sql`
- `supabase/migrations/0003_relatos.sql`
- `supabase/migrations/0004_comunicacao.sql`
- `supabase/migrations/0006_preparacao_futura.sql`
- `supabase/migrations/0008_auditoria_e_notificacoes.sql`
- `supabase/migrations/0009_storage_push_fontes.sql`
- `supabase/migrations/0011_configuracoes_preferencias.sql`
- `supabase/migrations/0012_ferramentas_agricolas.sql`
- `supabase/migrations/0015_academia_agrolink.sql`
- `supabase/migrations/0018_preparacao_logistica.sql`
- `supabase/migrations/0021_ia_analytics.sql`
- `supabase/migrations/0025_security_trust_layer_base.sql`
- `supabase/migrations/0026_denuncias_reputacao.sql`
- `supabase/migrations/0027_recover_profiles_admin.sql`

### `storage.` — 8 ficheiro(s)
- `docs/relatorio-tecnico-v2.md`
- `src/features/academia/api/academiaService.ts`
- `src/features/biblioteca/api/bibliotecaService.ts`
- `supabase/migrations/0003_relatos.sql`
- `supabase/migrations/0009_storage_push_fontes.sql`
- `supabase/migrations/0014_biblioteca_agrolink.sql`
- `supabase/migrations/0015_academia_agrolink.sql`
- `supabase/migrations/0026_denuncias_reputacao.sql`

### `from(` — 18 ficheiro(s)
- `src/features/academia/api/academiaService.ts`
- `src/features/admin/api/adminService.ts`
- `src/features/admin/api/iaAdminService.ts`
- `src/features/alertas/api/alertasService.ts`
- `src/features/auth/api/authService.ts`
- `src/features/biblioteca/api/bibliotecaService.ts`
- `src/features/configuracoes/api/preferenciasService.ts`
- `src/features/ferramentas/api/ferramentasService.ts`
- `src/features/ia-agricola/api/iaService.ts`
- `src/features/noticias/api/noticiasService.ts`
- `src/features/recursos/api/recursosService.ts`
- `src/features/relatos/api/relatosService.ts`
- `src/features/relatos/components/NovoRelatoForm.tsx`
- `src/offline/syncEngine.ts`
- `src/shared/api/notificacoesService.ts`
- `supabase/functions/ia-agricola-proxy/index.ts`
- `supabase/functions/ia-resumo-mensal/index.ts`
- `supabase/functions/sync-noticias/index.ts`

### `rpc(` — 7 ficheiro(s)
- `src/features/academia/api/academiaService.ts`
- `src/features/admin/api/adminService.ts`
- `src/features/admin/api/iaAdminService.ts`
- `src/features/ia-agricola/api/iaService.ts`
- `src/features/relatos/api/relatosService.ts`
- `src/offline/syncEngine.ts`
- `supabase/functions/ia-agricola-proxy/index.ts`

### `functions.invoke` — 3 ficheiro(s)
- `src/features/admin/api/iaAdminService.ts`
- `src/features/ia-agricola/api/iaService.ts`
- `src/features/noticias/api/noticiasService.ts`

## Banco de dados

### Migrations

- `supabase/migrations/0001_profiles_and_rls.sql`
- `supabase/migrations/0002_status_verificacao_e_rls_por_papel.sql`
- `supabase/migrations/0003_relatos.sql`
- `supabase/migrations/0004_comunicacao.sql`
- `supabase/migrations/0005_estatisticas.sql`
- `supabase/migrations/0006_preparacao_futura.sql`
- `supabase/migrations/0007_enum_status_respondido.sql`
- `supabase/migrations/0008_auditoria_e_notificacoes.sql`
- `supabase/migrations/0009_storage_push_fontes.sql`
- `supabase/migrations/0010_noticias_fonte_e_deduplicacao.sql`
- `supabase/migrations/0011_configuracoes_preferencias.sql`
- `supabase/migrations/0012_ferramentas_agricolas.sql`
- `supabase/migrations/0013_centro_de_recursos.sql`
- `supabase/migrations/0014_biblioteca_agrolink.sql`
- `supabase/migrations/0015_academia_agrolink.sql`
- `supabase/migrations/0016_protecao_ultimo_admin.sql`
- `supabase/migrations/0017_fontes_noticias_ambito.sql`
- `supabase/migrations/0018_preparacao_logistica.sql`
- `supabase/migrations/0019_preferencia_idioma.sql`
- `supabase/migrations/0020_notificacoes_inteligentes.sql`
- `supabase/migrations/0021_ia_analytics.sql`
- `supabase/migrations/0022_noticias_agricolas_fontes_oficiais.sql`
- `supabase/migrations/0023_indices_chaves_estrangeiras.sql`
- `supabase/migrations/0024_papel_transportador.sql`
- `supabase/migrations/0025_security_trust_layer_base.sql`
- `supabase/migrations/0026_denuncias_reputacao.sql`
- `supabase/migrations/0027_recover_profiles_admin.sql`

### Tabelas encontradas nas migrations

- `profiles`
- `relatos`
- `relato_midias`
- `relato_respostas`
- `noticias`
- `alertas`
- `ia_conversas`
- `ia_mensagens`
- `sie_indicadores`
- `mercado_produtos`
- `sensores`
- `leituras_sensor`
- `auditoria`
- `notificacoes`
- `dispositivos_push`
- `tecnico_documentos`
- `noticias_fontes`
- `preferencias_utilizador`
- `ferramenta_calculos`
- `recursos_externos`
- `perguntas_frequentes`
- `biblioteca_documentos`
- `academia_cursos`
- `academia_licoes`
- `academia_questionarios`
- `academia_progresso`
- `logistica_transportadoras`
- `logistica_pedidos`
- `ia_perguntas_analytics`
- `ia_resumos_mensais`
- `noticias_sync_logs`
- `logs_seguranca`
- `limite_taxa_eventos`
- `transportadores`
- `denuncias`
- `denuncia_historico`
- `reputacao`
- `avaliacoes`

## Edge Functions

- `supabase/functions/ia-agricola-proxy/index.ts`
- `supabase/functions/ia-resumo-mensal/index.ts`
- `supabase/functions/sync-noticias/index.ts`

## Testes e scripts

- Teste encontrado: `src/features/ia-agricola/lib/mediaValidation.test.ts`
- Teste unitário executável no ambiente atual: `node --experimental-strip-types --test src/features/ia-agricola/lib/mediaValidation.test.ts`.
- Não foi encontrado ficheiro de configuração dedicado do Playwright; a dependência está declarada no `package.json`.

## Documentação e materiais de auditoria

- `docs/AGROLINK_PACOTES_INTEGRACAO.md`
- `docs/auditoria-v2.md`
- `docs/handoff-sessao.md`
- `docs/i18n.md`
- `docs/plano-v1-integrada.md`
- `docs/relatorio-fecho-v2-final.md`
- `docs/relatorio-fecho-v2.md`
- `docs/relatorio-tecnico-v2.md`
- `audit-materials/AGROLINK_RECOVERY.md`
- `audit-materials/README.md`
- `audit-materials/package-docs/agrolink-caop-pacote1-fundacao-visual_1788799034296/LOTE1_RELATORIO.md`
- `audit-materials/package-docs/agrolink-caop-pacote1-fundacao-visual_1788799034296/PACOTE1_RELATORIO_CONSOLIDADO.md`
- `audit-materials/package-docs/agrolink-caop-pacote1-fundacao-visual_1788799350880/LOTE1_RELATORIO.md`
- `audit-materials/package-docs/agrolink-caop-pacote1-fundacao-visual_1788799350880/PACOTE1_RELATORIO_CONSOLIDADO.md`
- `audit-materials/package-docs/agrolink-caop-pacotes2-9_1788799034452/PACOTES_RESTANTES_AGROLINK.md`
- `audit-materials/package-docs/agrolink-caop-pacotes2-9_1788799337110/PACOTES_RESTANTES_AGROLINK.md`
- `audit-materials/source-attachments/AGROLINK_RECOVERY_1788798791935.md`
- `audit-materials/source-attachments/AGROLINK_RECOVERY_1788799350974.md`
- `audit-materials/source-attachments/agrolink-caop-pacote1-fundacao-visual_1788799034296.zip`
- `audit-materials/source-attachments/agrolink-caop-pacote1-fundacao-visual_1788799350880.zip`
- `audit-materials/source-attachments/agrolink-caop-pacotes2-9_1788799034452.zip`
- `audit-materials/source-attachments/agrolink-caop-pacotes2-9_1788799337110.zip`

## Manifesto de ficheiros do ZIP

| Ficheiro | Bytes | SHA-256 |
|---|---:|---|
| `.env.example` | 318 | `701adef583347d8ba241aa3dacadc5bd086fd70a61bd8cbeebc33df1f8e60b9f` |
| `.gitignore` | 60 | `2efe0527a4fd6378a0b0fb087feae3ae4624e765017169e1ac8d1152873c85b4` |
| `.replit` | 44 | `7b6871be97d0ef5657c1d05f16d57dd8a5b8b70525e2e53e0b74bcfd53cc5dc0` |
| `HANDOFF_PROMPT.md` | 3050 | `f553b4f71c7bfe3d9bf75a3421ffb0cbe627a38291864982c47fc075454728a6` |
| `HANDOFF_SUMMARY.md` | 1377 | `27bfe4b858a8a143ab009d4e8ecbd40d06770a8deeada276b014615a09f3c096` |
| `PILOT_READINESS.md` | 7321 | `f4485a96febdbb9531c649b8daea4c05ae3ff3cbd722b885fa96f058b3dca218` |
| `PILOT_TEST_PLAN.md` | 2841 | `80570fae9548eb2d916bd89572fb857328058e556e3c1a6b2e1c9b80c07925d1` |
| `PROJECT_STATUS.md` | 19475 | `84a377c085900287672d089203d11196ac8beb4cdac2f45599ea3662de0c8b0b` |
| `README.md` | 97 | `4bd61fd41ca3804250ff83caebf7eeaaaa44f5deaea8f77d635fa46efd9f02dc` |
| `RECONSTRUCTION_AUDIT.md` | 11310 | `ed4d22dfe55098684e3b2a4e5b1011cee42994ad4372100db176666de87c516c` |
| `RECONSTRUCTION_STATUS.md` | 2428 | `e8796b0185d8c15622f8b690649491ed1ba71b2fc521dd93cca47cf36b2ff81d` |
| `audit-materials/AGROLINK_RECOVERY.md` | 1432388 | `7d03e1259e4fa4ddea6dca9dae7500450382fbdd4d3f8210ceef53162c5c28f1` |
| `audit-materials/README.md` | 247 | `054d2c20fa7d9411e5cd32dba1f1ad21b448fb886364cca2929a29d8c465a921` |
| `audit-materials/package-docs/agrolink-caop-pacote1-fundacao-visual_1788799034296/LOTE1_RELATORIO.md` | 7723 | `19d98c9c20e6c5d81d08806946bbe669c38aa3ff455860ea8461eb083debb8af` |
| `audit-materials/package-docs/agrolink-caop-pacote1-fundacao-visual_1788799034296/PACOTE1_RELATORIO_CONSOLIDADO.md` | 9960 | `8fd72ff47ab5f438b278dfdffed234a9bf23a9c8c57843c631afc4e93ffd0b2d` |
| `audit-materials/package-docs/agrolink-caop-pacote1-fundacao-visual_1788799350880/LOTE1_RELATORIO.md` | 7723 | `19d98c9c20e6c5d81d08806946bbe669c38aa3ff455860ea8461eb083debb8af` |
| `audit-materials/package-docs/agrolink-caop-pacote1-fundacao-visual_1788799350880/PACOTE1_RELATORIO_CONSOLIDADO.md` | 9960 | `8fd72ff47ab5f438b278dfdffed234a9bf23a9c8c57843c631afc4e93ffd0b2d` |
| `audit-materials/package-docs/agrolink-caop-pacotes2-9_1788799034452/PACOTES_RESTANTES_AGROLINK.md` | 12394 | `1947cba51edb66a122a390104237a7133640ff600f091c0e4add9eaf227b2090` |
| `audit-materials/package-docs/agrolink-caop-pacotes2-9_1788799337110/PACOTES_RESTANTES_AGROLINK.md` | 12394 | `1947cba51edb66a122a390104237a7133640ff600f091c0e4add9eaf227b2090` |
| `audit-materials/source-attachments/AGROLINK_RECOVERY_1788798791935.md` | 1432388 | `7d03e1259e4fa4ddea6dca9dae7500450382fbdd4d3f8210ceef53162c5c28f1` |
| `audit-materials/source-attachments/AGROLINK_RECOVERY_1788799350974.md` | 1432388 | `7d03e1259e4fa4ddea6dca9dae7500450382fbdd4d3f8210ceef53162c5c28f1` |
| `audit-materials/source-attachments/agrolink-caop-pacote1-fundacao-visual_1788799034296.zip` | 3478039 | `6b188e61dcea0a0859a6cfd8616ecbc688acab60ef6f3840816e73594245529b` |
| `audit-materials/source-attachments/agrolink-caop-pacote1-fundacao-visual_1788799350880.zip` | 3478039 | `6b188e61dcea0a0859a6cfd8616ecbc688acab60ef6f3840816e73594245529b` |
| `audit-materials/source-attachments/agrolink-caop-pacotes2-9_1788799034452.zip` | 43660 | `b34645feb2feb89bcb8476c0d6cc78bc4b03305a53e1eb20f6bc0bcfd90df856` |
| `audit-materials/source-attachments/agrolink-caop-pacotes2-9_1788799337110.zip` | 43660 | `b34645feb2feb89bcb8476c0d6cc78bc4b03305a53e1eb20f6bc0bcfd90df856` |
| `docs/AGROLINK_PACOTES_INTEGRACAO.md` | 8815 | `a4bd50f8b184a1551ffeda8bcf5caec4d3cef41d4a3700120394c1f89b2c7ad3` |
| `docs/auditoria-v2.md` | 6563 | `ff16392f22ebea27156dd8f59bf9e07dcba3b8f09ee562154b66e8970b464fab` |
| `docs/handoff-sessao.md` | 11506 | `c3c8ff393ea86b40423c4a7a3fd7112801edd964b92a722de8ea858e6395d8f8` |
| `docs/i18n.md` | 1059 | `9ade69c233180b4ab6eae57c9611cd71d68fb77add7489f81040559b5b8d7d28` |
| `docs/plano-v1-integrada.md` | 5743 | `110575ad26ac821d3645bdd1c57c1e7bb5a302e3266b4a738db2f6700b41197a` |
| `docs/relatorio-fecho-v2-final.md` | 6727 | `20c9e7a25cec22534627ee97f9a06b69d50bbf96d64f2aa668966dd670cae1d5` |
| `docs/relatorio-fecho-v2.md` | 4312 | `687fe9356167c79d18b47fe619afd19350665b6ac44191268148afaad74d7a50` |
| `docs/relatorio-tecnico-v2.md` | 10675 | `534638b369b849fddbd30dfccb51f0c571058c486c6ca55faada8ddb9e9b61ff` |
| `index.html` | 579 | `17f405d127488dc312e4084a86eca34ca0afb9d4e8c9aa19f4dfa6a9ba371673` |
| `package-lock.json` | 228169 | `bfc8aff9cae25999935e9327b402d011514e4e031c6517e64f35303f8ddf3a98` |
| `package.json` | 769 | `2464bf0b6045aeea097700c0bfacf187253071a35ff5c69f61d2a86ca365d734` |
| `public/favicon.ico` | 849 | `b65e55ea6c3e48344093fdd75b7c8fe342bb43650c9596ce0f7172d1c162d05e` |
| `public/icons/.gitkeep` | 2 | `75a11da44c802486bc6f65640aa48a730f0f684c5c07a42ba3cd1735eb3fb070` |
| `public/icons/apple-touch-icon.png` | 29082 | `1a169abf91b7a3046b202605fad4eeb5d3ecc311e3bb519a1a56c7a331dc32ee` |
| `public/icons/icon-192.png` | 35539 | `d267ad03a862dac7c3946394b16f577fde1aece358fb829076472ab38f57460c` |
| `public/icons/icon-512-maskable.png` | 120827 | `75c1b059b439b713258101a1bda9594ab3953b45b676bd0ceb105d04d97d7205` |
| `public/icons/icon-512.png` | 227006 | `8e537ca7ee23df25f64e94d5910e5ef67a798803a2e466eea013ac49cfd7a201` |
| `src/app/App.tsx` | 8407 | `c0fceb838d809c1d5cabd19196280b1522eff2406d54d8d9de3193e89da91e4b` |
| `src/app/ProtectedRoute.tsx` | 947 | `8dd60c6141f9dc65574fd85765ef6ede84ed202b08d42ccdb5c828fb0a4c5e12` |
| `src/app/components/AppHeader.tsx` | 1245 | `c81d6410c0011981112ad18381419a6722fd88504c8690669f977ca726e34abb` |
| `src/app/components/AppLayout.tsx` | 2533 | `167439f04a5b91eda84a4a5fdc6e1f9790e53d68839e57c15a4b35daffaa2733` |
| `src/app/components/AtualizacaoDisponivel.tsx` | 854 | `d246f25822b690823c16b38dcb51b5cc8e273f4669623bb9a3c418943bfdda7d` |
| `src/app/components/BackButton.tsx` | 549 | `5dd928f75d5db3dc463eaf3cf8e67762cf57db011fac22c20b4ac13390125408` |
| `src/app/components/Breadcrumbs.tsx` | 541 | `354857077790ad3d3d644e0839d4933a2b968eb1d19b3d5e608cf7372e773e48` |
| `src/app/components/ConfirmDialog.tsx` | 1039 | `02030b60f5a7df6df1f377b73699a92f0fd00617e922027b761ccd2577a79619` |
| `src/app/components/FeedbackBanner.tsx` | 685 | `9afcd9f50fbf540c5ff8a0b3eaeb242ce7bb30fe3efdc851ca46ddda5e4b415d` |
| `src/app/components/InstallAppButton.tsx` | 1604 | `28bb8c7c9b891a2b7314609c48ac9a18f67fdea8cfc0ea0cd1a90416193bb6cb` |
| `src/app/components/NotificationBell.tsx` | 2289 | `59a76e24c7c04aa592f4e121e59f22976f77c34deacdb7dabd1cacc3da826bc6` |
| `src/app/components/SyncBadge.tsx` | 617 | `5a65a6a0c86779d5f6888ecb657171de7c2b9dbb964fb8a3978f527bf5f34052` |
| `src/app/components/layout.css` | 3756 | `6b8a1bc861592887a114b47923a4fa5dffdd543c5609cb073712a6a9e406e9e0` |
| `src/app/pages/AcessoNegadoPage.tsx` | 203 | `f7d11cb59e22cc933fbaddf7cfa3e900340cb95569e89455218bcb78696e288c` |
| `src/app/pages/ContaBloqueadaPage.tsx` | 295 | `2c49a500d3502932f30b390704602db278666be8b6d63197c0466822e4279db4` |
| `src/app/pages/ContaPendentePage.tsx` | 357 | `ec50b09ef9a9cd0d96e0881ffe82897f32689f4dd2404750e2de5e590ec25632` |
| `src/app/pages/HomePage.tsx` | 715 | `acffb9755279fefaf7aa8271ff9c9ccee3d5ef998ff71b44011ba4e23c332d11` |
| `src/app/pages/InstitucionalPage.tsx` | 1317 | `9a9b85d43000c9fe4a7ff452b166fc7ad8afcc274605260283aeb184abd63730` |
| `src/app/pages/PaginaNaoEncontradaPage.tsx` | 470 | `28902bc48a95b07f19cef4262fb5e5257f154765b6a4d7895c448c31e31bde99` |
| `src/app/pages/PerfilPage.tsx` | 2703 | `aa00f92ebead2a9a769ed53b98df6adfbae451b7eb8ab7f04b6c6cdb35cf88f7` |
| `src/features/academia/api/academiaService.ts` | 5633 | `1c63f898cdcf2d30f404a91cdb63195d7fdd154606fe2a938ced3ebd3b66ac15` |
| `src/features/academia/components/QuizLicao.tsx` | 2454 | `726df948d0656e561d71597f7c9dccadee5a86ce432a11557fdb774de6f46118` |
| `src/features/academia/pages/AcademiaPage.tsx` | 1531 | `da8b3c1588104d3efef54e6c0367aef475e2bdd3ac9b5298b8ce4830f48630b6` |
| `src/features/academia/pages/CursoDetalhePage.tsx` | 4485 | `53237601e490a46eea315212f05cc7be2a12d53ea85242ee1b2d3731bf97fb4a` |
| `src/features/admin/api/adminService.ts` | 2204 | `4f7f60ff78155d5dd685e70bb1b075fa27c981e31d9279589335ebeb1abd7040` |
| `src/features/admin/api/iaAdminService.ts` | 1278 | `ea212404aeddb0e7ce0231b3c59e79e3e2199d50ba4ca858098337c1b693cf66` |
| `src/features/admin/components/AdminAcademia.tsx` | 7191 | `7bb76e22b082b56052f022185a949fcf18ed64a94035ea90a40fa0b8166d4216` |
| `src/features/admin/components/AdminAlertas.tsx` | 2629 | `605d7285b6554dec69c65842acdf7c1f2ebaeb1425dad55d7be66a0f49372694` |
| `src/features/admin/components/AdminAuditoria.tsx` | 1393 | `6f0662ae66a330bd588e8453814a3fc2c81b1bc3c6e900e9f40fbd7d8007d846` |
| `src/features/admin/components/AdminBiblioteca.tsx` | 3582 | `6c497064f25b2e2c4dc307a81fc5d6de6549754661b04228669cd64dd578ed6e` |
| `src/features/admin/components/AdminEstatisticas.tsx` | 1676 | `6237dcac949af10cb146ccf82b62c279ea022408a16deb6f972039078604f85c` |
| `src/features/admin/components/AdminFontesNoticias.tsx` | 5571 | `2bd5daff62b37c86be6f429728c4489a56586bb7e50ae34ea2b66a76386dd001` |
| `src/features/admin/components/AdminIA.tsx` | 3993 | `3b07551a9a1776fa9e47e60eb2dc3bd84e9aefa8265391c1a0106ec890e43180` |
| `src/features/admin/components/AdminMensagens.tsx` | 1966 | `577cfa32e87843ee03490071a18a9c3128e69ac71076560506e88336ac290d71` |
| `src/features/admin/components/AdminNoticias.tsx` | 2046 | `c5b182c3d9c8e91a056aa869bf4e2ac65b8d73e79cc864a1f6c34d5fc2080b7c` |
| `src/features/admin/components/AdminRecursos.tsx` | 3386 | `987c3274e4754343d30f35c7cfb3365f1bae9bd62c1a81656cf76b183c4fcba0` |
| `src/features/admin/components/AdminUtilizadores.tsx` | 4160 | `e58302fda45d8a3221323b8dbd3a8fcb5873256688b11268a72cfb270c8e6bad` |
| `src/features/admin/pages/AdminPage.tsx` | 2542 | `0707ad93acfcf26a4299bfb503c5fc7149e67637aa7a061339418560c198195a` |
| `src/features/agricultor/pages/AgricultorDashboard.tsx` | 4943 | `f0514a0872f2bfdd139d8b8fda9863bd6e0fc48549900bbb42c54f14e433ee67` |
| `src/features/alertas/api/alertasService.ts` | 1238 | `bb6089b45b52b0854dfc0b649314aa7e6ff8184ec6fdf87ba94e5d4a86d61b78` |
| `src/features/alertas/pages/AlertasPage.tsx` | 1751 | `6964c771c93dabbc00c544c69eb9fcefeb137a4f7b054a8d89cc45235e8e17fe` |
| `src/features/auth/api/authService.ts` | 5564 | `5989b97fe40053e76c0038c1add3f020555483f37e0a86b839306e6c554c11ea` |
| `src/features/auth/components/AuthLayout.tsx` | 434 | `78a02621924da6fdc73dd97bea1c02213974cacb2d261fa2e31c58b917f8afb3` |
| `src/features/auth/components/auth.css` | 2354 | `e71fd7c0464ac589fd757fadc8c129e7a557451ac786de7fa9040fb112fa9df2` |
| `src/features/auth/context/AuthContext.tsx` | 2299 | `c15d8803c7b6585f73614894b2ea582a03c8662dcb3ca2a791421fc650175e2b` |
| `src/features/auth/pages/ForgotPasswordPage.tsx` | 1778 | `37e70a650c8be02cebafec6c67bff4266eb81fc048f30056a77cfd0c1fbfa46a` |
| `src/features/auth/pages/LoginPage.tsx` | 3343 | `893d3d8f5fda2b51625aa360e48ee68ea996a27f6320bb3acc43c119cee13b84` |
| `src/features/auth/pages/RegisterPage.tsx` | 4989 | `9f027718b84b5ba508fe94dcc1a0ef0c8a85e7c5df4446ed630577640c040224` |
| `src/features/auth/pages/ResetPasswordPage.tsx` | 2182 | `081640b269e60f0d7090b6e715be7eae8e8b5dd98225646165d58da6556c5b57` |
| `src/features/biblioteca/api/bibliotecaService.ts` | 2384 | `d35dc773e277ae786f674d8dc40b30dd5b5a60a12ede4be9d24030890acd60c1` |
| `src/features/biblioteca/pages/BibliotecaPage.tsx` | 2856 | `c77d5b9f430cdfbe9c5ef44485c5cabc9e4df8cf83c80e0acb23ef1bf45d218d` |
| `src/features/configuracoes/api/preferenciasService.ts` | 1144 | `9e73f37f0f23bbbbc5a81afc98361adfcf83852f8f8618b722e55948b5f30f86` |
| `src/features/configuracoes/pages/ConfiguracoesPage.tsx` | 7236 | `f1f65cc6a10e85f4714deea4e1e08e431cb8cd582b7dde5d2784f7ebaf67df6e` |
| `src/features/ferramentas/api/ferramentasService.ts` | 1031 | `8e6d44ee758b382cef3d050f5bfab185f1678bf7873781ea3ad9d8d13f08c9b1` |
| `src/features/ferramentas/pages/FerramentasPage.tsx` | 5263 | `3e80ca2908dee5f3bf6b374bc4f29adbd05acad656ee4e5a38082d45fbe0a03c` |
| `src/features/ia-agricola/api/iaService.ts` | 4068 | `8608d7235d89b7e9af06dd27b26fc3f0cca01ebf91f4cb2bcc855f59aec26752` |
| `src/features/ia-agricola/lib/mediaValidation.test.ts` | 3607 | `d62997c9d1daf30e807c1c55cc762cf411e0907548d461a6e1f3accc01d02c62` |
| `src/features/ia-agricola/lib/mediaValidation.ts` | 4761 | `a2514306a65a54943061c6af7708c7d7d1831df68dc6e5b23bfe615cf638a482` |
| `src/features/ia-agricola/pages/IAChatPage.tsx` | 28641 | `496cb16f2ef74558dc45d8fb9e0b4d64ee5f9cfe1ce065ea446187e6f3e3e2ba` |
| `src/features/manual/pages/ManualPage.tsx` | 2527 | `769871536b4bb0f715de3482b9d5f55f7700c371c0ffd4f94541318a9f3653ec` |
| `src/features/noticias/api/noticiasService.ts` | 3660 | `a4cdb5312b4f40b63336d47374c6edb41e8089337bdeca9fd67b12d568829752` |
| `src/features/noticias/pages/NoticiasPage.tsx` | 2815 | `74ba58bcda116904257d0ec80d5049c75b5055c94eb3fe2389db1163bf72f164` |
| `src/features/pais/pages/EscolhaPaisPage.tsx` | 4371 | `37ed23145a5281f58f3770ed07ffdb733ad76d5400ac1cd348b3e45b8468a6a2` |
| `src/features/recursos/api/recursosService.ts` | 1760 | `9995380cba558f9364cba0afc513b258d87dcc604f06bc165f29a945535b171e` |
| `src/features/recursos/pages/RecursosPage.tsx` | 2409 | `06901e435a62952f86aa01a48400feb820ce0c47933e1452a03c9fcecf35878b` |
| `src/features/relatos/api/relatosService.ts` | 3295 | `671772aa786094817f2c76f3912119fb31c1e0d157705eca6e3cf8b98f06f59b` |
| `src/features/relatos/components/NovoRelatoForm.tsx` | 9176 | `6ff97b6669acad1b3835fc4dc7b917fb967a81361df1b88ac3bb312c81fdfaa8` |
| `src/features/relatos/lib/estadoRelato.ts` | 1190 | `5b016431e71c14f225c7fb75b6663e53a17b547245804539d61e163bf52d1016` |
| `src/features/relatos/pages/RelatoAnonimoPage.tsx` | 4855 | `a214b0ae048afbbdad1ae9d535dbb5711fa1d7431b36a760ceff5b3595810a84` |
| `src/features/relatos/pages/RelatosPage.tsx` | 3498 | `3460e9f437ec6eaf0d667b81607882d95388168f3a40ec9fc3496cf526242f45` |
| `src/features/tecnico/components/RelatoDetalheTecnico.tsx` | 3412 | `e8bd46749582ce82f2c61b11241c71435cebc5a44e3509ff85c93d166fd7d8e2` |
| `src/features/tecnico/pages/TecnicoPage.tsx` | 2861 | `a91da51aae1cb699376c614d3241555f46b02ecd9c08484b6f2c1d6e98232f47` |
| `src/features/visitante/pages/VisitanteLandingPage.tsx` | 3411 | `396e24248b677e9173cb50e330c906f81544b65949f50b4112f792ac1ebf449c` |
| `src/features/visitante/pages/VisitanteOfflinePage.tsx` | 1964 | `94c7e4a84c375350027f251fc005ba623dbb7b886352618dab61c6ba6bc43688` |
| `src/main.tsx` | 1976 | `5e9feceffad9d8f0a1a5e5444d030b308a037bba1a22b1404f837289dfe0b82d` |
| `src/offline/db.ts` | 6773 | `681398d5f6d55d6b9baa2f76e9a1562ecf8194ad886b68ad4322a6219154b0b9` |
| `src/offline/syncEngine.ts` | 4399 | `6c6adfa7413cbb4b971a19376bcb5146e07d1baecd646bdd90209e792e5d756d` |
| `src/shared/api/notificacoesService.ts` | 2002 | `b7a7ed32b881e2a3986913f7ff3ee2a2a8af1a22a095bb6e47bbf09c8468924a` |
| `src/shared/assets/agrolink-logo-master.png` | 920418 | `d9be75bd444f350c57ae84994f58a5c32a032c7e2031dd805b5b6cefb628cda1` |
| `src/shared/components/BottomNav.tsx` | 641 | `cfac55b570e8254ddbed97726ae0b2a8c53d26d156eb90300dc82020d28caae4` |
| `src/shared/components/Button.tsx` | 486 | `e77d80f5f20440fec61375c8f32e0292accae8025039391678ae53673515bb80` |
| `src/shared/components/Card.tsx` | 931 | `dd3702d4b3e86048951412a9408e739e7d8c73d04db1ca4d2b171f53fdfd8ab4` |
| `src/shared/components/EstadosInterface.tsx` | 988 | `ebe6239d7bc10d88e5413f9587c3f8b0609bbddf4d9f583cbeb4c2153654b6f2` |
| `src/shared/components/Logo.tsx` | 684 | `da2e1b8e633cf4f164f6a86be806a077f050a3a7f27f9b310757a86ca1f19566` |
| `src/shared/components/PageContainer.tsx` | 233 | `e68f50ed20de24ae2dfe5f6a8d55da70fe9bdf49f31fe8bed1660c516991a82a` |
| `src/shared/components/PageHeader.tsx` | 822 | `d991717611776725eeb43bdeb2ef70a2f77e03ca4bcc1ca02557c4a0e30392e0` |
| `src/shared/components/StatusBadge.tsx` | 852 | `8dde1ab60cc6a005556c4e71412fa369f3ae1943358b53a6211863f728b5236f` |
| `src/shared/components/ui.css` | 3985 | `7ef005e610f034d3091763287236c0d6353eeab88aa27223db5e8680a43ebf35` |
| `src/shared/i18n/LanguageContext.tsx` | 2240 | `2cbdd5dd681c1f08d72b2973352539dc3104798250e7bbe6c97a17d5fe784432` |
| `src/shared/i18n/locales/pt.ts` | 1282 | `aee0a58eee30c902107115d772f0b7b9b858c8e1236e1f1d4402bf986547aa33` |
| `src/shared/lib/country.ts` | 2290 | `147eb44111fc98fa4330bfe178ef10383f3a7343c374c51ebc4cf7330d6cf9f3` |
| `src/shared/lib/supabaseClient.ts` | 747 | `870c9a8048088a2642b02ab21e5daee25697a2231ac1ea53cf13c1fcad79c505` |
| `src/shared/styles/tokens.css` | 834 | `f29ef9f07a0e24847804a8e45b928c36237ca1bc30e985e4a59f633e27be72ec` |
| `src/shared/types/database.types.ts` | 18106 | `4988e44c1d5789cb511001a16ad7b25ee5790bbad77bcf1a0d98fe6ed31351b6` |
| `src/vite-env.d.ts` | 324 | `a55eb9d3c2be74987f3e450b2c33b3bdee23d0cf52aea0afa03e372f7d9a93d7` |
| `supabase/functions/ia-agricola-proxy/index.ts` | 10303 | `c6328e29e477553aaefd7edd93300827cf930a3677b362d4f0de2b572dbaafee` |
| `supabase/functions/ia-resumo-mensal/index.ts` | 4240 | `a8521006ba3d97a5fa0e92adfc88d23827f6043915cc0efd2f369fc311344b55` |
| `supabase/functions/sync-noticias/index.ts` | 6904 | `c6f0f8acf3532fcad0e82f10aaca7562523e47d49c49ab738459d1b287f6d544` |
| `supabase/migrations/0001_profiles_and_rls.sql` | 2237 | `49e4fc06029fe9af4abc6b3c79c89ab25605bb6cb442102b1baa3caed8d85a87` |
| `supabase/migrations/0002_status_verificacao_e_rls_por_papel.sql` | 5040 | `e5a6941e869a395165792d4ef6915a1a54894d7885e8b87794b62ba73cc4af51` |
| `supabase/migrations/0003_relatos.sql` | 7170 | `7375a03e378729aa73a84e764121d8d7e74c8343faab025c7a6105baf289fb98` |
| `supabase/migrations/0004_comunicacao.sql` | 2815 | `be5d6521d94076745cbdcf2de58871f53ba7161cec45a46bc26546291a41e3a7` |
| `supabase/migrations/0005_estatisticas.sql` | 1274 | `1d57659c2c7c2f3b56db8beacd855f9e5f2e8d7c8f2c58b5d3aa130a92464e7a` |
| `supabase/migrations/0006_preparacao_futura.sql` | 3138 | `353e9567739bf4de6302b576d101b4d0445a95079c3d7b2c03c86b143ceba3b8` |
| `supabase/migrations/0007_enum_status_respondido.sql` | 250 | `3da3cff2eea057e080963e2957902d93d1eac34d58b4e1db072c74d0b7c452ec` |
| `supabase/migrations/0008_auditoria_e_notificacoes.sql` | 5282 | `76fdc17dfb7bf71702a565f40f800547412e320274f54a6626bc30a8ebd47d32` |
| `supabase/migrations/0009_storage_push_fontes.sql` | 3380 | `80990917d6c14bffd4f3e92a2913c6ce6a6d725127839a18cf921f0aa444488b` |
| `supabase/migrations/0010_noticias_fonte_e_deduplicacao.sql` | 602 | `7087dc84d5e9aa70d1a7d364d363182b19acb727b498df85cfe1b9b57ffc8cc6` |
| `supabase/migrations/0011_configuracoes_preferencias.sql` | 2700 | `4954e8ad2af9610909dc8b2f7d793e237ddfcf7b83f6b6233438f4f9a5c1ccd1` |
| `supabase/migrations/0012_ferramentas_agricolas.sql` | 887 | `b9ecde6250368e05d9f78e2ba6a99910705ca328c675b8e07789dfff8199d6f7` |
| `supabase/migrations/0013_centro_de_recursos.sql` | 1519 | `02dba8258e14b7dae8b4bf44967521cf2e3915ae2f3acd3e3f31724abed3e491` |
| `supabase/migrations/0014_biblioteca_agrolink.sql` | 1946 | `b443f822de51c25b01b92b54b1cb14beee3303ab992f4b75f409eab2ebc67bae` |
| `supabase/migrations/0015_academia_agrolink.sql` | 6513 | `b349c3590df13699729d060740394f21334db13d6ff122d42598ecc39759eab1` |
| `supabase/migrations/0016_protecao_ultimo_admin.sql` | 693 | `e423c3bf68fe7b4a850b746c7105bfcdd89f190b7c5392230c47b0a897f32d6b` |
| `supabase/migrations/0017_fontes_noticias_ambito.sql` | 419 | `a01c7b1f750402e51a6115fd82dc79d52e0af3e7a28c44885de4e93f15b64d23` |
| `supabase/migrations/0018_preparacao_logistica.sql` | 1881 | `26a9fb73a1ff3f8d66d1faf7d74977a8fb87a1a2348c21c738e9a0f8f9133796` |
| `supabase/migrations/0019_preferencia_idioma.sql` | 765 | `5d697f8be3e71ee59ffd9f63abc1caa6440913ff3d2487dca27885ddb25463ad` |
| `supabase/migrations/0020_notificacoes_inteligentes.sql` | 4060 | `d3a79319629a1c96825016d93e701d2d0868d004c72305ff6846039851f9ee35` |
| `supabase/migrations/0021_ia_analytics.sql` | 5700 | `905e69f0a88311ecb397bbbac3195628d7c757fc873ba3d09c7afd3ba1134ef0` |
| `supabase/migrations/0022_noticias_agricolas_fontes_oficiais.sql` | 4990 | `d28d56672f7115770d69e087eb5ef3848b7a5ffdff26974731d4166eeb7baa19` |
| `supabase/migrations/0023_indices_chaves_estrangeiras.sql` | 3374 | `dfd73ed9aad6e23634d5d81693f62da54e45ecd75f0046f2be9bee4f5da5f70a` |
| `supabase/migrations/0024_papel_transportador.sql` | 280 | `9a1f3c80feb66fed0b3022c75cfdf3c5258d85e54103f95cd9fe17371e1374c2` |
| `supabase/migrations/0025_security_trust_layer_base.sql` | 7201 | `05df8a1e378c89380486c7f3eb427799a4a5c1d7322515def7c835fe42a30323` |
| `supabase/migrations/0026_denuncias_reputacao.sql` | 10319 | `f530887bf96a221f08a8a480d9a51862f1a40459ca41c2de25b58f267fa31d60` |
| `supabase/migrations/0027_recover_profiles_admin.sql` | 5005 | `c17ec15f6dd8dfe7811f15b84a4178bdbfde2c295bbaa3c168b3ec1984940d19` |
| `tsconfig.json` | 702 | `654bc523ce983fe2acb22e12ae86f2fe5c58dee9430c3f566f0d79ebbf3238fe` |
| `vite.config.ts` | 2131 | `46fcbcfb819c9cf60e1ad335d2b3574acaf5b4f10e1d34178e78b0a46bb6ef8c` |
| `AGROLINK_WORKSPACE_INVENTORY.md` | gerado neste inventário | calculado após a escrita |

## Verificação de exclusão de segredos

- Não foram incluídos `.env` ou `.env.local`.
- Não foram incluídas chaves privadas, tokens ou credenciais.
- `AGROLINK_WORKSPACE_INVENTORY.md` lista caminhos e metadados, não valores secretos.

### Redactions applied to exported copies

- `audit-materials/AGROLINK_RECOVERY.md`
- `audit-materials/source-attachments/AGROLINK_RECOVERY_1788798791935.md`
- `audit-materials/source-attachments/AGROLINK_RECOVERY_1788799350974.md`

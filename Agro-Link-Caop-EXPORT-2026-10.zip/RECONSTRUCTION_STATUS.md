
> **Estado arquitetural atualizado (15/09/2026):** o runtime ativo foi migrado de Supabase para a base de dados interna do AgroLink (`server/db.mjs` + `server/migrations/001_platform.sql`). As referências a Supabase nestes documentos podem ser históricas.

# AgroLink Caop — Reconstruction Status

Data: 2026-08-28
Branch de trabalho: `pilot/ai-for-sdgs-2026`
Checkpoint: `checkpoint/pre-restore`

## Restaurado

- Configuração React/TypeScript/Vite/PWA.
- `src/` completo do handoff, incluindo autenticação, relatos, notícias, alertas, IA, administração, academia, biblioteca, recursos, ferramentas e notificações.
- `src/offline/db.ts` e `src/offline/syncEngine.ts`.
- `docs/` do handoff.
- Migrations `supabase/migrations/0001` até `0028`, sem renomear ou reordenar.
- Edge Functions `ia-agricola-proxy`, `sync-noticias` e `ia-resumo-mensal`.
- `.env.example` com placeholders; nenhum `.env` real foi criado.

Ficheiros adicionais existentes e o `README.md` divergente foram preservados. Não foram eliminados ficheiros.

## Corrigido

- Adicionados os aliases `@/offline/*` em `tsconfig.json` e `vite.config.ts`.
- Restaurado o wrapper `Deno.serve(async (req) => {` ausente no `ia-agricola-proxy`.
- Completado o contrato local `Database` com `Relationships`, `Views` e as RPCs utilizadas pelo frontend, permitindo a verificação TypeScript.
- Corrigidos incompatibilidades tipadas concretas em serviços de academia, notícias, relatos, alertas, biblioteca e recursos.

## Validação

- `npm install`: PASSOU; gerou `package-lock.json` sem alterar `package.json`.
- `npx tsc -b --force`: PASSOU.
- `npm run build`: PASSOU.
- Verificação de imports locais: PASSOU; nenhum destino local ausente encontrado.
- Integridade/contagem: 28 migrations e 3 Edge Functions presentes.
- Scan de credenciais reais: nenhum resultado encontrado.
- `npm run lint`: FALHOU porque `eslint` não está instalado/declarado no handoff (`eslint: not found`). Não foi adicionada uma dependência arbitrária.

## Ainda pendente

- Validar autenticação, RLS, schema e RPCs num ambiente Supabase de teste.
- Configurar e testar secrets das Edge Functions sem os commitar.
- Executar testes funcionais em browser e dispositivo móvel.
- Adicionar os três ícones PWA originais quando os assets forem disponibilizados.
- Resolver o lint com uma configuração/dependência aprovada.
- Avaliar o aviso de bundle Vite superior a 500 kB; não bloqueia o build atual.
- Deployment e link público do piloto.

## Restrições respeitadas

Não houve push, merge, deploy, execução de migrations, alteração no Supabase remoto, alteração de secrets ou modificação destrutiva em `main`.

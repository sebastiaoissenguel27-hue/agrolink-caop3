import fs from 'node:fs';
import path from 'node:path';
import ts from 'typescript';

const root = process.cwd();
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const lock = JSON.parse(fs.readFileSync(path.join(root, 'package-lock.json'), 'utf8'));
const failures = [];

for (const group of ['dependencies', 'devDependencies']) {
  for (const name of Object.keys(pkg[group] ?? {})) {
    if (!lock.packages?.[`node_modules/${name}`]) failures.push(`package-lock missing ${name}`);
  }
}

const sourceFiles = [];
function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(p);
    else if (/\.(ts|tsx)$/.test(entry.name)) sourceFiles.push(p);
  }
}
walk(path.join(root, 'src'));
let syntaxErrors = [];
for (const file of sourceFiles) {
  if (file.endsWith('.d.ts')) continue;
  try {
    const result = ts.transpileModule(fs.readFileSync(file, 'utf8'), {
      compilerOptions: { target: ts.ScriptTarget.ES2020, module: ts.ModuleKind.ESNext, jsx: ts.JsxEmit.ReactJSX, isolatedModules: true },
      fileName: file,
      reportDiagnostics: true,
    });
    if (result.diagnostics?.length) syntaxErrors.push(`${path.relative(root, file)}: ${result.diagnostics.map(d => ts.flattenDiagnosticMessageText(d.messageText, ' ')).join('; ')}`);
  } catch (error) {
    syntaxErrors.push(`${path.relative(root, file)}: ${error.message}`);
  }
}

function resolveLocal(from, spec) {
  let base;
  if (spec.startsWith('@/')) base = path.join(root, 'src', spec.slice(2));
  else if (spec.startsWith('.')) base = path.resolve(path.dirname(from), spec);
  else return true;
  const candidates = [base];
  if (!['.ts','.tsx','.js','.jsx','.json'].includes(path.extname(base))) {
    for (const ext of ['.ts', '.tsx', '.js', '.jsx', '.json']) candidates.push(base + ext);
    for (const ext of ['.ts', '.tsx', '.js', '.jsx']) candidates.push(path.join(base, 'index' + ext));
  }
  return candidates.some(fs.existsSync);
}
const importRe = /(?:import|export)\s+(?:[^'"`]*?\s+from\s+)?['"]([^'"]+)['"]|import\(\s*['"]([^'"]+)['"]\s*\)/g;
let missingImports = [];
for (const file of sourceFiles) {
  const text = fs.readFileSync(file, 'utf8');
  let match;
  while ((match = importRe.exec(text))) {
    const spec = match[1] ?? match[2];
    if ((spec.startsWith('.') || spec.startsWith('@/')) && !resolveLocal(file, spec)) missingImports.push(`${path.relative(root, file)} -> ${spec}`);
  }
}

function containsSupabase(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const file = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (containsSupabase(file)) return true;
    } else if (fs.readFileSync(file, 'utf8').toLowerCase().includes('supabase')) {
      return true;
    }
  }
  return false;
}
const activeFiles = ['src', 'server', 'package.json', 'vite.config.ts', '.replit'];
if (activeFiles.some((entry) => {
  const file = path.join(root, entry);
  return fs.statSync(file).isDirectory() ? containsSupabase(file) : fs.readFileSync(file, 'utf8').toLowerCase().includes('supabase');
})) failures.push('active Supabase references found');

const report = {
  generatedAt: new Date().toISOString(),
  packageLockRootDependencies: 'checked',
  packageLockFailures: failures,
  sourceFiles: sourceFiles.length,
  syntaxErrors,
  missingLocalImports: missingImports,
  nodeVersion: process.version,
  typescriptVersion: ts.version,
  note: 'Full npm build remains blocked when registry dependencies are unavailable. This preflight validates syntax/imports/lock consistency without pretending to be vite build output.'
};
fs.writeFileSync(path.join(root, 'reports', 'BUILD_PREFLIGHT_2026-09-15.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({
  sourceFiles: report.sourceFiles,
  syntaxErrors: syntaxErrors.length,
  missingLocalImports: missingImports.length,
  packageLockFailures: failures.length,
  typescriptVersion: ts.version,
}, null, 2));
process.exit(failures.length || syntaxErrors.length || missingImports.length ? 1 : 0);

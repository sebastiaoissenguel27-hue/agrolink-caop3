const endpoint = String(process.env.AGROLINK_AGRI_AI_URL || 'http://127.0.0.1:8080/v1/chat/completions');
const response = await fetch(endpoint, {
  method: 'POST',
  headers: { 'content-type': 'application/json' },
  body: JSON.stringify({
    model: process.env.AGROLINK_AGRI_AI_MODEL || 'qwen3-1.7b',
    messages: [
      { role: 'system', content: 'Responde em português claro e pede dados adicionais quando faltarem.' },
      { role: 'user', content: 'Responde em uma frase: qual é uma verificação inicial para folhas amareladas de tomate?' },
    ],
    max_tokens: 96,
    temperature: 0.2,
    chat_template_kwargs: { enable_thinking: false },
  }),
});
if (!response.ok) throw new Error(`llama-server respondeu HTTP ${response.status}`);
const data = await response.json();
const answer = data?.choices?.[0]?.message?.content?.trim();
if (!answer) throw new Error('llama-server não devolveu conteúdo.');
console.log(answer);
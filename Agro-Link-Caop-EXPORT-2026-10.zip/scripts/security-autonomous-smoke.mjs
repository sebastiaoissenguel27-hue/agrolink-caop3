import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'agrolink-security-'));
process.env.AGROLINK_DATA_DIR=tmp;
process.env.AGROLINK_ADMIN_CHEFE_EMAIL='chief@example.com';
const { db } = await import('../server/db.mjs');
const { evaluateSecuritySignal, getSecurityState, isIpBlocked, setSecurityState } = await import('../server/securityTrust.mjs');
const { randomUUID } = await import('node:crypto');
try {
  const id=randomUUID();
  db.prepare("INSERT INTO users(id,email,password_hash,password_salt) VALUES(?,?,?,?)").run(id,'chief@example.com','x','x');
  db.prepare("INSERT INTO profiles(id,nome,papel,status,criado_em) VALUES(?,?,?,?,?)").run(id,'Chief','admin_chefe','ativo',new Date().toISOString());
  setSecurityState({modo:'normal',funcionalidadesDesativadas:[]});
  const result=await evaluateSecuritySignal({type:'rate_limit_excedido',ip:'203.0.113.55',details:{critical:true}});
  if(result?.estado!=='contido') throw new Error('critical incident was not autonomously contained');
  const duplicate=await evaluateSecuritySignal({type:'rate_limit_excedido',ip:'203.0.113.55',details:{critical:true,endpoint:'/api/test'}});
  if(duplicate?.id!==result.id || duplicate?.duplicado!==true) throw new Error('duplicate security signal did not safely update the existing incident');
  if(!isIpBlocked('203.0.113.55')) throw new Error('source IP was not temporarily blocked');
  if(getSecurityState().modo!=='emergencia') throw new Error('critical autonomous incident did not activate emergency mode');
  console.log(JSON.stringify({ok:true,incident:result,mode:getSecurityState().modo,ipBlocked:true},null,2));
} finally { db.close(); fs.rmSync(tmp,{recursive:true,force:true}); }

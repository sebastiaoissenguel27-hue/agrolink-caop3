const configured = String(process.env.AGROLINK_AGRI_AI_URL || 'http://127.0.0.1:8080/v1/chat/completions');
const healthUrl = new URL(configured);
healthUrl.pathname = '/health';
healthUrl.search = '';
try {
  const response = await fetch(healthUrl);
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  console.log(`llama-server saudável em ${healthUrl}`);
} catch (error) {
  console.error(`llama-server indisponível em ${healthUrl}: ${error.message}`);
  process.exitCode = 1;
}
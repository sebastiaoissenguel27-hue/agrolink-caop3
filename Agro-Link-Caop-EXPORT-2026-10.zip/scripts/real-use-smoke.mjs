import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';

const port = 8898;
const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'agrolink-real-use-'));
const env = {
  ...process.env,
  NODE_ENV: 'production',
  PORT: String(port),
  AGROLINK_DATA_DIR: dataDir,
  AGROLINK_UPLOADS_DIR: path.join(dataDir, 'uploads'),
  AGROLINK_ADMIN_CHEFE_EMAIL: 'chief-real-use@example.com',
  AGROLINK_ADMIN_CHEFE_PASSWORD: 'ChiefRealUse123!',
  AGROLINK_ALLOW_DEV_RECOVERY_LINK: 'true',
  AGROLINK_TRUST_PROXY: 'true',
};
const base = `http://127.0.0.1:${port}`;
let server;
let serverOutput = '';

const sleep = (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds));
function assert(condition, message) {
  if (!condition) throw new Error(message);
}

async function request(pathname, options = {}) {
  for (let attempt = 0; attempt < 40; attempt += 1) {
    try {
      const response = await fetch(`${base}${pathname}`, {
        ...options,
        headers: { 'content-type': 'application/json', ...(options.headers || {}) },
      });
      const text = await response.text();
      let body = null;
      try { body = text ? JSON.parse(text) : null; } catch { body = text; }
      return {
        status: response.status,
        body,
        headers: response.headers,
        cookie: response.headers.get('set-cookie')?.split(';')[0] || null,
      };
    } catch {
      await sleep(50);
    }
  }
  throw new Error(`Servidor indisponível: ${pathname}`);
}

function cookie(response) {
  assert(response.cookie, 'Cookie de sessão ausente.');
  return response.cookie;
}

async function startServer() {
  server = spawn(process.execPath, ['server/index.mjs'], { cwd: process.cwd(), env, stdio: ['ignore', 'pipe', 'pipe'] });
  server.stdout.on('data', (chunk) => { serverOutput += chunk; });
  server.stderr.on('data', (chunk) => { serverOutput += chunk; });
  const health = await request('/api/health');
  assert(health.status === 200 && health.body.database === 'internal', `Health inválido: ${serverOutput}`);
  assert(health.headers.get('x-frame-options') === 'DENY' && health.headers.get('x-content-type-options') === 'nosniff', 'Headers de segurança da API ausentes.');
  const html = await request('/');
  assert(html.status === 200 && typeof html.body === 'string' && html.body.includes('<div id="root">') && html.body.includes('manifest.webmanifest'), 'HTML de produção ou referência do manifest inválida.');
  assert(html.headers.get('x-frame-options') === 'DENY' && html.headers.get('content-security-policy')?.includes("script-src 'self'"), 'Headers CSP de produção ausentes no HTML.');
  const route = await request('/login');
  assert(route.status === 200 && typeof route.body === 'string' && route.body.includes('<div id="root">'), 'Fallback SPA de produção falhou.');
  const manifest = await request('/manifest.webmanifest');
  assert(manifest.status === 200 && manifest.body?.name === 'AgroLink Caop', 'Manifest PWA inválido.');
  for (const asset of ['/favicon.ico', '/icons/apple-touch-icon.png', '/icons/icon-192.png', '/icons/icon-512.png', '/icons/icon-512-maskable.png']) {
    const response = await request(asset);
    assert(response.status === 200, `Asset oficial/PWA indisponível em produção: ${asset}.`);
  }
  assert(manifest.body.icons?.some((icon) => icon.src === 'icons/icon-192.png') && manifest.body.icons?.some((icon) => icon.src === 'icons/icon-512-maskable.png'), 'Manifest não referencia os ícones oficiais do app.');
  const serviceWorker = await request('/sw.js');
  assert(serviceWorker.status === 200 && typeof serviceWorker.body === 'string' && serviceWorker.body.length > 100, 'Service worker PWA indisponível.');
}

async function stopServer() {
  if (!server) return;
  server.kill('SIGTERM');
  await sleep(100);
  server = null;
}

try {
  await startServer();

  const paginationDb = new DatabaseSync(path.join(dataDir, 'agrolink.sqlite'));
  const insertFaq = paginationDb.prepare('INSERT INTO perguntas_frequentes(id,pergunta,resposta,ordem) VALUES(?,?,?,?)');
  for (let index = 0; index < 501; index += 1) insertFaq.run(crypto.randomUUID(), `Pergunta de limite ${index}`, 'Resposta de teste.', index);
  paginationDb.close();
  const negativeLimit = await request('/api/data/perguntas_frequentes?limit=-1');
  assert(negativeLimit.status === 200 && negativeLimit.body.length === 100, 'Limite negativo ignorou o padrão de paginação.');
  const excessiveLimit = await request('/api/data/perguntas_frequentes?limit=9999');
  assert(excessiveLimit.status === 200 && excessiveLimit.body.length === 500, 'Limite da API excedeu o teto de 500 linhas.');

  const suffix = Date.now();
  const farmerEmail = `farmer-${suffix}@example.com`;
  const secondFarmerEmail = `second-farmer-${suffix}@example.com`;
  const technicianEmail = `technician-${suffix}@example.com`;
  const carrierEmail = `carrier-${suffix}@example.com`;
  const adminEmail = `admin-${suffix}@example.com`;

  const chiefLogin = await request('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email: env.AGROLINK_ADMIN_CHEFE_EMAIL, password: env.AGROLINK_ADMIN_CHEFE_PASSWORD }),
  });
  assert(chiefLogin.status === 200 && chiefLogin.body.profile.papel === 'admin_chefe', 'Login do admin_chefe falhou.');
  const chiefCookie = cookie(chiefLogin);
  const newsSync = await request('/api/admin/sync-noticias', { method: 'POST', headers: { cookie: chiefCookie }, body: '{}' });
  assert(newsSync.status === 200 && newsSync.body.fontes_processadas === 0 && newsSync.body.erros.length === 0, 'Sincronização de notícias sem fontes configuradas falhou.');

  const farmerRegister = await request('/api/auth/register', {
    method: 'POST',
    body: JSON.stringify({ email: farmerEmail, password: 'FarmerReal123!', nome: 'Agricultor Piloto', tipo_perfil: 'agricultor', provincia: 'Luanda' }),
  });
  assert(farmerRegister.status === 201, 'Registo do agricultor falhou.');
  const duplicateRegister = await request('/api/auth/register', {
    method: 'POST',
    body: JSON.stringify({ email: farmerEmail.toUpperCase(), password: 'FarmerReal123!', nome: 'Duplicado', tipo_perfil: 'agricultor' }),
  });
  assert(duplicateRegister.status === 409, 'Registo duplicado não foi recusado.');
  const invalidRegister = await request('/api/auth/register', {
    method: 'POST',
    body: JSON.stringify({ email: `invalid-${suffix}@example.com`, password: 'short', nome: 'Inválido', tipo_perfil: 'agricultor' }),
  });
  assert(invalidRegister.status === 400, 'Dados de registo inválidos não foram recusados.');
  const invalidLogin = await request('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email: farmerEmail, password: 'WrongPassword123!' }),
  });
  assert(invalidLogin.status === 401, 'Login com palavra-passe incorreta não foi recusado.');
  const farmerLogin = await request('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email: farmerEmail, password: 'FarmerReal123!' }),
  });
  assert(farmerLogin.status === 200, 'Login do agricultor falhou.');
  assert(farmerLogin.headers.get('set-cookie')?.includes('HttpOnly') && farmerLogin.headers.get('set-cookie')?.includes('SameSite=Lax') && farmerLogin.headers.get('set-cookie')?.includes('Secure'), 'Production session cookie flags are incomplete.');
  const farmerCookie = cookie(farmerLogin);
  const farmerId = farmerLogin.body.profile.id;
  const pendingFarmerWrite = await request('/api/data/relatos', { method: 'POST', headers: { cookie: farmerCookie }, body: JSON.stringify({ tipo: 'praga', descricao: 'Ainda pendente.', provincia: 'Luanda' }) });
  assert(pendingFarmerWrite.status === 403, 'Conta pendente conseguiu escrever antes da aprovação.');
  const approveFarmer = await request('/api/admin/users/approve-account', { method: 'POST', headers: { cookie: chiefCookie }, body: JSON.stringify({ id: farmerId }) });
  assert(approveFarmer.status === 200 && approveFarmer.body.status === 'ativo', 'Admin Chefe não aprovou o agricultor.');
  const secondFarmerRegister = await request('/api/auth/register', {
    method: 'POST',
    body: JSON.stringify({ email: secondFarmerEmail, password: 'SecondFarmer123!', nome: 'Segundo Agricultor', tipo_perfil: 'agricultor', provincia: 'Luanda' }),
  });
  assert(secondFarmerRegister.status === 201, 'Registo do segundo agricultor falhou.');
  const secondFarmerLogin = await request('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email: secondFarmerEmail, password: 'SecondFarmer123!' }),
  });
  assert(secondFarmerLogin.status === 200, 'Login do segundo agricultor falhou.');
  const secondFarmerCookie = cookie(secondFarmerLogin);
  const approveSecondFarmer = await request('/api/admin/users/approve-account', { method: 'POST', headers: { cookie: chiefCookie }, body: JSON.stringify({ id: secondFarmerLogin.body.profile.id }) });
  assert(approveSecondFarmer.status === 200, 'Admin Chefe não aprovou o segundo agricultor.');
  const profileUpdate = await request('/api/profile', { method: 'PATCH', headers: { cookie: farmerCookie }, body: JSON.stringify({ municipio: 'Viana', papel: 'admin' }) });
  assert(profileUpdate.status === 200 && profileUpdate.body.municipio === 'Viana' && profileUpdate.body.papel === 'utilizador' && profileUpdate.body.tipo_perfil === 'agricultor', 'Perfil não persistiu ou permitiu escalada de papel.');
  const crossOriginMutation = await request('/api/profile', { method: 'PATCH', headers: { cookie: farmerCookie, origin: 'https://attacker.example' }, body: JSON.stringify({ municipio: 'Origem não autorizada' }) });
  assert(crossOriginMutation.status === 403, 'Mutação cross-origin não foi recusada.');

  const relatoPayload = {
    id: crypto.randomUUID(),
    autor_id: secondFarmerLogin.body.profile.id,
    codigo_publico: 'AL-FORGED-CODE',
    tipo: 'praga',
    descricao: 'Relato funcional para validação do piloto.',
    provincia: 'Luanda',
    criado_em: new Date().toISOString(),
  };
  const relato = await request('/api/data/relatos', { method: 'POST', headers: { cookie: farmerCookie }, body: JSON.stringify(relatoPayload) });
  assert(relato.status === 201 && relato.body.codigo_publico, 'Criação do relato falhou.');
  assert(relato.body.autor_id === farmerId && relato.body.codigo_publico !== 'AL-FORGED-CODE' && relato.body.codigo_publico.length >= 35, 'O servidor aceitou autoria/código público forjado ou emitiu código fraco.');
  const duplicateRelato = await request('/api/data/relatos', { method: 'POST', headers: { cookie: farmerCookie }, body: JSON.stringify(relatoPayload) });
  assert(duplicateRelato.status === 200 && duplicateRelato.body.codigo_publico === relato.body.codigo_publico, 'Retry do relato não foi idempotente.');
  const consulta = await request(`/api/relatos/codigo?codigo=${encodeURIComponent(relato.body.codigo_publico)}`);
  assert(consulta.status === 200, 'Consulta pública do relato falhou.');
  const consultaRepetida = await request(`/api/relatos/codigo?codigo=${encodeURIComponent(relato.body.codigo_publico)}`);
  assert(consultaRepetida.status === 200 && consultaRepetida.body.id === relato.body.id, 'Código público de relato não pôde ser reutilizado pelo titular.');
  const ownReports = await request('/api/data/relatos?limit=50', { headers: { cookie: farmerCookie } });
  const otherReports = await request('/api/data/relatos?limit=50', { headers: { cookie: secondFarmerCookie } });
  assert(ownReports.status === 200 && ownReports.body.some((item) => item.id === relato.body.id), 'O agricultor perdeu acesso ao próprio relato.');
  assert(otherReports.status === 200 && !otherReports.body.some((item) => item.id === relato.body.id), 'Outro agricultor conseguiu consultar o relato alheio.');
  const reportMediaId = crypto.randomUUID();
  const uploadBody = { uploadId: reportMediaId, filename: 'folha.png', mimeType: 'image/png', data: Buffer.from('agrolink-media-smoke').toString('base64') };
  const uploadMedia = await request('/api/media/upload/relatos', { method: 'POST', headers: { cookie: farmerCookie }, body: JSON.stringify(uploadBody) });
  assert(uploadMedia.status === 201, `Upload de anexo do relato falhou: HTTP ${uploadMedia.status}`);
  const invalidBase64 = await request('/api/media/upload/relatos', { method: 'POST', headers: { cookie: farmerCookie }, body: JSON.stringify({ filename: 'bad.png', data: '%%%not-base64%%%' }) });
  assert(invalidBase64.status === 400, 'Upload aceitou conteúdo Base64 inválido.');
  const retryUpload = await request('/api/media/upload/relatos', { method: 'POST', headers: { cookie: farmerCookie }, body: JSON.stringify(uploadBody) });
  assert(retryUpload.status === 201 && retryUpload.body.caminho === uploadMedia.body.caminho, 'Retry do upload não foi idempotente.');
  const conflictingUpload = await request('/api/media/upload/relatos', { method: 'POST', headers: { cookie: farmerCookie }, body: JSON.stringify({ ...uploadBody, data: Buffer.from('different media').toString('base64') }) });
  assert(conflictingUpload.status === 409, 'Upload reutilizou o mesmo ID com conteúdo diferente.');
  const mediaLinkBody = { id: reportMediaId, relato_id: relato.body.id, tipo: 'imagem', caminho_storage: uploadMedia.body.caminho };
  const mediaLink = await request('/api/data/relato_midias', { method: 'POST', headers: { cookie: farmerCookie }, body: JSON.stringify(mediaLinkBody) });
  assert(mediaLink.status === 201, `Associação de mídia ao relato falhou: HTTP ${mediaLink.status}`);
  const mediaLinkRetry = await request('/api/data/relato_midias', { method: 'POST', headers: { cookie: farmerCookie }, body: JSON.stringify(mediaLinkBody) });
  assert(mediaLinkRetry.status === 200, 'Retry da associação de mídia não foi idempotente.');
  const mediaUrl = `/api/media/${uploadMedia.body.caminho.split('/').map(encodeURIComponent).join('/')}`;
  const anonymousMedia = await request(mediaUrl);
  assert(anonymousMedia.status === 401, 'Mídia privada ficou disponível sem sessão.');
  const ownerMedia = await request(mediaUrl, { headers: { cookie: farmerCookie } });
  assert(ownerMedia.status === 200 && ownerMedia.body === 'agrolink-media-smoke', 'O proprietário não conseguiu ler o próprio anexo.');
  const crossOwnerMedia = await request(mediaUrl, { headers: { cookie: secondFarmerCookie } });
  assert(crossOwnerMedia.status === 404, 'Outro agricultor conseguiu ler anexo privado.');
  const crossOwnerLink = await request('/api/data/relato_midias', { method: 'POST', headers: { cookie: secondFarmerCookie }, body: JSON.stringify({ ...mediaLinkBody, id: crypto.randomUUID() }) });
  assert(crossOwnerLink.status === 403, 'Outro agricultor conseguiu associar mídia a relato alheio.');
  const outsideRegionReport = await request('/api/data/relatos', { method: 'POST', headers: { cookie: secondFarmerCookie }, body: JSON.stringify({ id: crypto.randomUUID(), tipo: 'clima', descricao: 'Relato de outra província.', provincia: 'Benguela', criado_em: new Date().toISOString() }) });
  assert(outsideRegionReport.status === 201, 'Criação de relato para teste de âmbito provincial falhou.');
  const crossOwnerIdCollision = await request('/api/data/relatos', { method: 'POST', headers: { cookie: secondFarmerCookie }, body: JSON.stringify({ ...relatoPayload, descricao: 'Tentativa de colisão entre contas.' }) });
  assert(crossOwnerIdCollision.status === 409 && !JSON.stringify(crossOwnerIdCollision.body).includes(relato.body.descricao), 'Colisão com ID de relato alheio não foi recusada de forma privada.');
  for (let attempt = 0; attempt < 30; attempt += 1) {
    const deniedLookup = await request(`/api/relatos/codigo?codigo=${encodeURIComponent(`AL-UNKNOWN-${attempt}`)}`, { headers: { 'x-forwarded-for': '198.51.100.71' } });
    assert(deniedLookup.status === 404, `Consulta de código inexistente teve resposta inesperada antes do limite: HTTP ${deniedLookup.status}.`);
  }
  const limitedLookup = await request(`/api/relatos/codigo?codigo=${encodeURIComponent(relato.body.codigo_publico)}`, { headers: { 'x-forwarded-for': '198.51.100.71' } });
  assert(limitedLookup.status === 429, 'A enumeração de códigos públicos não foi limitada.');

  const technicianRegister = await request('/api/auth/register', {
    method: 'POST',
    body: JSON.stringify({ email: technicianEmail, password: 'Technician123!', nome: 'Técnico Piloto', tipo_perfil: 'tecnico', provincia: 'Luanda' }),
  });
  assert(technicianRegister.status === 201, 'Registo do técnico falhou.');
  const technicianLogin = await request('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email: technicianEmail, password: 'Technician123!' }),
  });
  assert(technicianLogin.status === 200, 'Login do técnico falhou.');
  const technicianCookie = cookie(technicianLogin);
  const technicianId = technicianLogin.body.profile.id;
  const approveTechnicianAccount = await request('/api/admin/users/approve-account', { method: 'POST', headers: { cookie: chiefCookie }, body: JSON.stringify({ id: technicianId }) });
  assert(approveTechnicianAccount.status === 200, 'Admin Chefe não aprovou a conta do técnico.');
  const approveTechnician = await request(`/api/data/profiles?id=${encodeURIComponent(technicianId)}`, {
    method: 'PATCH',
    headers: { cookie: chiefCookie },
    body: JSON.stringify({ verification_status: 'aprovado' }),
  });
  assert(approveTechnician.status === 200, 'Aprovação do técnico falhou.');
  const technicianSession = await request('/api/auth/session', { headers: { cookie: technicianCookie } });
  assert(technicianSession.body.profile.verification_status === 'aprovado', 'Sessão do técnico não refletiu aprovação.');
  const technicianRelatos = await request('/api/data/relatos?limit=50', { headers: { cookie: technicianCookie } });
  assert(technicianRelatos.status === 200 && technicianRelatos.body.some((item) => item.id === relato.body.id), 'Técnico não recebeu o relato da sua zona.');
  assert(technicianRelatos.body.some((item) => item.id === outsideRegionReport.body.id), 'Técnico não recebeu relato de outra província.');
  const outsideRegionUpdate = await request(`/api/data/relatos?id=${encodeURIComponent(outsideRegionReport.body.id)}`, { method: 'PATCH', headers: { cookie: technicianCookie }, body: JSON.stringify({ status: 'respondido' }) });
  assert(outsideRegionUpdate.status === 200 && outsideRegionUpdate.body.status === 'respondido', 'Técnico não conseguiu atualizar relato de outra província.');
  const forgedReportEdit = await request(`/api/data/relatos?id=${encodeURIComponent(relato.body.id)}`, { method: 'PATCH', headers: { cookie: technicianCookie }, body: JSON.stringify({ status: 'respondido', descricao: 'Descrição alterada sem autorização.' }) });
  assert(forgedReportEdit.status === 403, 'Técnico conseguiu alterar campos não permitidos do relato.');
  const technicianMedia = await request(mediaUrl, { headers: { cookie: technicianCookie } });
  assert(technicianMedia.status === 200 && technicianMedia.body === 'agrolink-media-smoke', 'Técnico aprovado não recebeu mídia do relato da sua zona.');
  const technicianMediaRows = await request(`/api/data/relato_midias?relato_id=${encodeURIComponent(relato.body.id)}`, { headers: { cookie: technicianCookie } });
  assert(technicianMediaRows.status === 200 && technicianMediaRows.body.some((item) => item.id === reportMediaId), 'Técnico aprovado não recebeu metadados de mídia da sua zona.');
  const resposta = await request('/api/data/relato_respostas', {
    method: 'POST',
    headers: { cookie: technicianCookie },
    body: JSON.stringify({ relato_id: relato.body.id, tecnico_id: farmerId, comentario: 'Resposta técnica do piloto.' }),
  });
  assert(resposta.status === 201, 'Resposta técnica falhou.');
  assert(resposta.body.tecnico_id === technicianId, 'O servidor aceitou identidade técnica forjada.');
  const outsideRegionReply = await request('/api/data/relato_respostas', { method: 'POST', headers: { cookie: technicianCookie }, body: JSON.stringify({ relato_id: outsideRegionReport.body.id, tecnico_id: technicianId, comentario: 'Resposta fora da zona.' }) });
  assert(outsideRegionReply.status === 201 && outsideRegionReply.body.tecnico_id === technicianId, 'Técnico não conseguiu responder relato de outra província.');
  const crossProvinceHistory = await request(`/api/data/relato_respostas?relato_id=${encodeURIComponent(outsideRegionReport.body.id)}`, { headers: { cookie: technicianCookie } });
  assert(crossProvinceHistory.status === 200 && crossProvinceHistory.body.some((item) => item.id === outsideRegionReply.body.id), 'Técnico não conseguiu consultar o histórico da resposta cross-provincial.');
  const estado = await request(`/api/data/relatos?id=${encodeURIComponent(relato.body.id)}`, {
    method: 'PATCH',
    headers: { cookie: technicianCookie },
    body: JSON.stringify({ status: 'respondido' }),
  });
  assert(estado.status === 200, 'Atualização do estado do relato falhou.');
  const respostas = await request(`/api/data/relato_respostas?relato_id=${encodeURIComponent(relato.body.id)}`, { headers: { cookie: farmerCookie } });
  assert(respostas.status === 200 && respostas.body.length === 1, 'Agricultor não recebeu a resposta técnica.');
  const technicianResponses = await request(`/api/data/relato_respostas?relato_id=${encodeURIComponent(relato.body.id)}`, { headers: { cookie: technicianCookie } });
  assert(technicianResponses.status === 200 && technicianResponses.body.length === 1, 'Técnico não recebeu as próprias respostas da sua zona.');

  const product = await request('/api/data/mercado_produtos', {
    method: 'POST',
    headers: { cookie: farmerCookie },
    body: JSON.stringify({ nome: 'Milho seco', categoria: 'Cereais', preco: 250, unidade: 'kg', quantidade_disponivel: 80, provincia: 'Luanda' }),
  });
  assert(product.status === 201 && product.body.vendedor_id === farmerId, `Publicação de produto falhou ou não ficou associada ao agricultor: HTTP ${product.status} ${JSON.stringify(product.body)}`);
  const publicProducts = await request('/api/data/mercado_produtos?limit=20', { headers: { cookie: technicianCookie } });
  assert(publicProducts.status === 200 && publicProducts.body.some((item) => item.id === product.body.id), 'Produto ativo não ficou visível no mercado.');
  const crossEdit = await request(`/api/data/mercado_produtos?id=${encodeURIComponent(product.body.id)}`, {
    method: 'PATCH', headers: { cookie: technicianCookie }, body: JSON.stringify({ preco: 1 }),
  });
  assert(crossEdit.status === 403, 'Outro utilizador conseguiu alterar produto alheio.');
  const productUpdate = await request(`/api/data/mercado_produtos?id=${encodeURIComponent(product.body.id)}`, {
    method: 'PATCH', headers: { cookie: farmerCookie }, body: JSON.stringify({ preco: 275 }),
  });
  assert(productUpdate.status === 200 && productUpdate.body.preco === 275, 'Atualização do produto próprio falhou.');
  const pauseProduct = await request(`/api/data/mercado_produtos?id=${encodeURIComponent(product.body.id)}`, {
    method: 'PATCH', headers: { cookie: farmerCookie }, body: JSON.stringify({ ativo: false }),
  });
  assert(pauseProduct.status === 200 && !pauseProduct.body.ativo, 'Agricultor não conseguiu pausar a própria oferta.');
  const hiddenPausedProduct = await request('/api/data/mercado_produtos?limit=20', { headers: { cookie: technicianCookie } });
  assert(hiddenPausedProduct.status === 200 && !hiddenPausedProduct.body.some((item) => item.id === product.body.id), 'Oferta pausada continuou pública.');
  const adminPausedProduct = await request('/api/data/mercado_produtos?limit=20', { headers: { cookie: chiefCookie } });
  assert(adminPausedProduct.status === 200 && adminPausedProduct.body.some((item) => item.id === product.body.id), 'Administrador não conseguiu ver oferta pausada.');
  const crossDelete = await request(`/api/data/mercado_produtos?id=${encodeURIComponent(product.body.id)}`, { method: 'DELETE', headers: { cookie: technicianCookie } });
  assert(crossDelete.status === 403, 'Outro utilizador conseguiu remover produto alheio.');

  const freight = await request('/api/data/logistica_pedidos', {
    method: 'POST', headers: { cookie: farmerCookie },
    body: JSON.stringify({ origem_provincia: 'Luanda', destino_provincia: 'Benguela', produto_descricao: 'Transporte de milho', quantidade_kg: 500 }),
  });
  assert(freight.status === 201 && freight.body.solicitante_id === farmerId && freight.body.status === 'pedido', 'Criação de pedido logístico falhou.');
  const hiddenFreight = await request('/api/data/logistica_pedidos?limit=50', { headers: { cookie: technicianCookie } });
  assert(hiddenFreight.status === 403, 'Papel não envolvido deveria ser recusado na área logística.');

  const carrierRegister = await request('/api/auth/register', {
    method: 'POST',
    body: JSON.stringify({ email: carrierEmail, password: 'CarrierReal123!', nome: 'Transportador Piloto', tipo_perfil: 'agricultor', provincia: 'Luanda' }),
  });
  assert(carrierRegister.status === 201, 'Registo do transportador falhou.');
  const carrierLogin = await request('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email: carrierEmail, password: 'CarrierReal123!' }),
  });
  assert(carrierLogin.status === 200, 'Login do transportador falhou.');
  const carrierCookie = cookie(carrierLogin);
  const approveCarrierAccount = await request('/api/admin/users/approve-account', { method: 'POST', headers: { cookie: chiefCookie }, body: JSON.stringify({ id: carrierLogin.body.profile.id }) });
  assert(approveCarrierAccount.status === 200, 'Admin Chefe não aprovou a conta do transportador.');
  const carrierProfile = await request('/api/data/transportadores', {
    method: 'POST',
    headers: { cookie: carrierCookie },
    body: JSON.stringify({ matricula: 'LD-00-00-AA', tipo_veiculo: 'Camião', capacidade_kg: 1000 }),
  });
  assert(carrierProfile.status === 201, 'Perfil do transportador não foi persistido.');
  const pendingOrders = await request('/api/data/logistica_pedidos?limit=50', { headers: { cookie: carrierCookie } });
  assert(pendingOrders.status === 200 && pendingOrders.body.length === 0, 'Transportador pendente recebeu pedidos.');
  const prematureAccept = await request(`/api/data/logistica_pedidos?id=${encodeURIComponent(freight.body.id)}`, {
    method: 'PATCH', headers: { cookie: carrierCookie }, body: JSON.stringify({ status: 'aceite' }),
  });
  assert(prematureAccept.status === 403, 'Transportador pendente conseguiu aceitar pedido.');
  const approveCarrier = await request('/api/data/transportadores', {
    method: 'POST', headers: { cookie: chiefCookie }, body: JSON.stringify({ utilizador_id: carrierLogin.body.profile.id, estado_verificacao: 'aprovado' }),
  });
  assert(approveCarrier.status === 200 && approveCarrier.body.estado_verificacao === 'aprovado', 'Aprovação administrativa do transportador falhou.');
  const availableFreight = await request('/api/data/logistica_pedidos?limit=50', { headers: { cookie: carrierCookie } });
  assert(availableFreight.status === 200 && availableFreight.body.some((item) => item.id === freight.body.id), 'Transportador não recebeu pedidos disponíveis.');
  const acceptFreight = await request(`/api/data/logistica_pedidos?id=${encodeURIComponent(freight.body.id)}`, {
    method: 'PATCH', headers: { cookie: carrierCookie }, body: JSON.stringify({ status: 'aceite' }),
  });
  assert(acceptFreight.status === 200 && acceptFreight.body.status === 'aceite', 'Transportador não conseguiu aceitar pedido.');
  const advanceFreight = await request(`/api/data/logistica_pedidos?id=${encodeURIComponent(freight.body.id)}`, {
    method: 'PATCH', headers: { cookie: carrierCookie }, body: JSON.stringify({ status: 'em_transito' }),
  });
  assert(advanceFreight.status === 200 && advanceFreight.body.status === 'em_transito', 'Transição para transporte em curso falhou.');
  const deliverFreight = await request(`/api/data/logistica_pedidos?id=${encodeURIComponent(freight.body.id)}`, {
    method: 'PATCH', headers: { cookie: carrierCookie }, body: JSON.stringify({ status: 'entregue' }),
  });
  assert(deliverFreight.status === 200 && deliverFreight.body.status === 'entregue', 'Conclusão do transporte falhou.');
  const privateFreight = await request('/api/data/logistica_pedidos?limit=50', { headers: { cookie: farmerCookie } });
  assert(privateFreight.status === 200 && privateFreight.body.some((item) => item.id === freight.body.id), 'Solicitante perdeu acesso ao próprio pedido.');

  const adminRegister = await request('/api/auth/register', {
    method: 'POST',
    body: JSON.stringify({ email: adminEmail, password: 'AdminReal123!', nome: 'Admin Piloto', tipo_perfil: 'administrador', papel: 'admin_chefe' }),
  });
  assert(adminRegister.status === 201, 'Registo do admin de teste falhou.');
  const adminLogin = await request('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email: adminEmail, password: 'AdminReal123!' }),
  });
  const adminId = adminLogin.body.profile.id;
  assert(adminLogin.body.profile.papel === 'utilizador' && adminLogin.body.profile.tipo_perfil === 'administrador' && adminLogin.body.profile.status === 'pendente', 'O payload de registro do admin alterou privilégios ou ativou a conta.');
  const invalidUploadArea = await request('/api/media/upload/outro', { method: 'POST', headers: { cookie: chiefCookie }, body: JSON.stringify({ filename: 'bad.txt', data: Buffer.from('file').toString('base64') }) });
  assert(invalidUploadArea.status === 400, 'Servidor aceitou uma área de upload não definida.');
  const promote = await request('/api/admin/users/approve', { method: 'POST', headers: { cookie: chiefCookie }, body: JSON.stringify({ id: adminId, papel: 'admin_chefe' }) });
  assert(promote.status === 200 && promote.body.papel === 'admin' && promote.body.status === 'ativo', 'Aprovação de administrador falhou.');
  const users = await request('/api/admin/users', { headers: { cookie: chiefCookie } });
  assert(users.status === 200 && users.body.some((item) => item.id === farmerId), 'Admin não conseguiu listar utilizadores.');
  const denuncia = await request('/api/denuncias', {
    method: 'POST',
    headers: { cookie: farmerCookie },
    body: JSON.stringify({ denunciado_id: technicianId, categoria: 'Conduta', descricao: 'Denúncia funcional para teste controlado.', prioridade: 'media' }),
  });
  assert(denuncia.status === 201, 'Criação de denúncia falhou.');
  const denuncias = await request('/api/admin/denuncias', { headers: { cookie: chiefCookie } });
  assert(denuncias.status === 200 && denuncias.body.some((item) => item.id === denuncia.body.id), 'Admin não conseguiu consultar denúncias.');
  const adminNotifications = await request('/api/data/notificacoes?limit=100', { headers: { cookie: chiefCookie } });
  const complaintNotification = adminNotifications.body.find((item) => item.relacionado_id === denuncia.body.id);
  assert(adminNotifications.status === 200 && complaintNotification, 'Notificação de denúncia não foi entregue ao administrador.');
  const notificationRead = await request(`/api/data/notificacoes?id=${encodeURIComponent(complaintNotification.id)}`, {
    method: 'PATCH', headers: { cookie: chiefCookie }, body: JSON.stringify({ lida: true }),
  });
  assert(notificationRead.status === 200 && notificationRead.body.lida, 'Estado de leitura da notificação não persistiu.');

  const course = await request('/api/data/academia_cursos', {
    method: 'POST', headers: { cookie: chiefCookie }, body: JSON.stringify({ titulo: 'Curso de teste', descricao: 'Conteúdo de validação.', categoria: 'Agricultura' }),
  });
  assert(course.status === 201, 'Criação do curso falhou.');
  const academyUpload = await request('/api/media/upload/academia', { method: 'POST', headers: { cookie: chiefCookie }, body: JSON.stringify({ filename: 'lesson.txt', mimeType: 'text/plain', data: Buffer.from('conteúdo de aula').toString('base64') }) });
  assert(academyUpload.status === 201, `Upload de ficheiro da Academia falhou: HTTP ${academyUpload.status}`);
  const lesson = await request('/api/data/academia_licoes', {
    method: 'POST', headers: { cookie: chiefCookie }, body: JSON.stringify({ curso_id: course.body.id, titulo: 'Lição de teste', conteudo_texto: 'Conteúdo persistente.', caminho_storage: academyUpload.body.caminho, ordem: 1 }),
  });
  assert(lesson.status === 201, 'Criação da lição falhou.');
  const academyMediaUrl = `/api/media/${encodeURIComponent(academyUpload.body.caminho)}`;
  const academyMedia = await request(academyMediaUrl, { headers: { cookie: farmerCookie } });
  assert(academyMedia.status === 200 && academyMedia.body === 'conteúdo de aula', 'Ficheiro associado à lição não ficou disponível para o agricultor.');
  const libraryUpload = await request('/api/media/upload/biblioteca', { method: 'POST', headers: { cookie: chiefCookie }, body: JSON.stringify({ filename: 'library.txt', mimeType: 'text/plain', data: Buffer.from('documento da biblioteca').toString('base64') }) });
  assert(libraryUpload.status === 201, `Upload da Biblioteca falhou: HTTP ${libraryUpload.status}`);
  const libraryDocument = await request('/api/data/biblioteca_documentos', { method: 'POST', headers: { cookie: chiefCookie }, body: JSON.stringify({ titulo: 'Documento de teste', tipo: 'pdf', caminho_storage: libraryUpload.body.caminho }) });
  assert(libraryDocument.status === 201, 'Registo do documento da Biblioteca falhou.');
  const libraryMedia = await request(`/api/media/${encodeURIComponent(libraryUpload.body.caminho)}`, { headers: { cookie: farmerCookie } });
  assert(libraryMedia.status === 200 && libraryMedia.body === 'documento da biblioteca', 'Ficheiro associado à Biblioteca não ficou disponível para o agricultor.');
  const quiz = await request('/api/data/academia_questionarios', {
    method: 'POST', headers: { cookie: chiefCookie }, body: JSON.stringify({ licao_id: lesson.body.id, pergunta: 'Qual cultura foi usada?', opcoes: ['Milho', 'Café'], resposta_correta: 0, ordem: 1 }),
  });
  assert(quiz.status === 201, `Criação do questionário falhou: HTTP ${quiz.status} ${JSON.stringify(quiz.body)}`);
  const publicQuiz = await request(`/api/academia/quiz/${encodeURIComponent(lesson.body.id)}`, { headers: { cookie: farmerCookie } });
  assert(publicQuiz.status === 200 && publicQuiz.body.length === 1 && !('resposta_correta' in publicQuiz.body[0]), 'Questionário expôs a resposta correta.');
  const answerQuiz = await request('/api/academia/quiz/answer', { method: 'POST', headers: { cookie: farmerCookie }, body: JSON.stringify({ questionarioId: quiz.body.id, resposta: 0 }) });
  assert(answerQuiz.status === 200 && answerQuiz.body.correto, 'Correção do questionário falhou.');
  const progress = await request(`/api/data/academia_progresso?licao_id=${encodeURIComponent(lesson.body.id)}`, { headers: { cookie: farmerCookie } });
  assert(progress.status === 200 && progress.body[0]?.concluida, 'Progresso de aprendizagem não persistiu.');

  const ai = await request('/api/ia/chat', { method: 'POST', headers: { cookie: farmerCookie }, body: JSON.stringify({ message: 'Como observar uma praga no milho?' }) });
  assert(ai.status === 200 && ai.body.resposta, 'Fallback de IA falhou.');
  const editorialNews = await request('/api/data/noticias', {
    method: 'POST', headers: { cookie: chiefCookie },
    body: JSON.stringify({ titulo: 'Teste de classificação editorial', conteudo: 'Notícia para teste.', categoria: 'Culturas', categoria_ia: 'Clima', publicado_em: new Date().toISOString() }),
  });
  assert(editorialNews.status === 201, 'Criação controlada de notícia falhou.');
  const categoryFilteredNews = await request('/api/data/noticias?categoria=Clima', { headers: { cookie: farmerCookie } });
  assert(categoryFilteredNews.status === 200 && categoryFilteredNews.body.some((item) => item.id === editorialNews.body.id), 'Filtro de Notícias ignorou categoria IA.');
  const noticias = await request('/api/data/noticias?limit=5', { headers: { cookie: farmerCookie } });
  const alertas = await request('/api/data/alertas?limit=5', { headers: { cookie: farmerCookie } });
  assert(noticias.status === 200 && alertas.status === 200, 'Notícias ou alertas falharam.');

  const forgot = await request('/api/auth/password/forgot', { method: 'POST', body: JSON.stringify({ email: farmerEmail }) });
  assert(forgot.status === 200 && forgot.body.recoveryUrl, 'Recuperação de palavra-passe falhou.');
  const supersededToken = new URL(forgot.body.recoveryUrl).searchParams.get('token');
  const newerForgot = await request('/api/auth/password/forgot', { method: 'POST', body: JSON.stringify({ email: farmerEmail }) });
  assert(newerForgot.status === 200 && newerForgot.body.recoveryUrl, 'Novo pedido de recuperação de conta falhou.');
  const supersededReset = await request('/api/auth/password/reset', { method: 'POST', body: JSON.stringify({ token: supersededToken, password: 'FarmerReset123!' }) });
  assert(supersededReset.status === 400, 'Token substituído continuou válido.');
  const token = new URL(newerForgot.body.recoveryUrl).searchParams.get('token');
  const reset = await request('/api/auth/password/reset', { method: 'POST', body: JSON.stringify({ token, password: 'FarmerReset123!' }) });
  assert(reset.status === 200, 'Reset de palavra-passe falhou.');
  const reusedReset = await request('/api/auth/password/reset', { method: 'POST', body: JSON.stringify({ token, password: 'FarmerReused123!' }) });
  assert(reusedReset.status === 400, 'Token de recuperação de conta foi reutilizado.');
  const oldSession = await request('/api/auth/session', { headers: { cookie: farmerCookie } });
  assert(oldSession.body.session === null, 'Sessão antiga não foi revogada após reset.');

  const newFarmerLogin = await request('/api/auth/login', { method: 'POST', body: JSON.stringify({ email: farmerEmail, password: 'FarmerReset123!' }) });
  const newFarmerCookie = cookie(newFarmerLogin);
  const expiredForgot = await request('/api/auth/password/forgot', { method: 'POST', body: JSON.stringify({ email: secondFarmerEmail }) });
  assert(expiredForgot.status === 200 && expiredForgot.body.recoveryUrl, 'Pedido de token para teste de expiração falhou.');
  const expiredToken = new URL(expiredForgot.body.recoveryUrl).searchParams.get('token');
  const recoveryDb = new DatabaseSync(path.join(dataDir, 'agrolink.sqlite'));
  const expiredAt = new Date(Date.now() - 60_000).toISOString();
  recoveryDb.prepare('UPDATE password_reset_tokens SET expira_em=? WHERE token_hash=?').run(expiredAt, crypto.createHash('sha256').update(expiredToken).digest('hex'));
  recoveryDb.prepare('UPDATE password_reset_outbox SET expira_em=? WHERE token_hash=?').run(expiredAt, crypto.createHash('sha256').update(expiredToken).digest('hex'));
  const sessionToken = decodeURIComponent(newFarmerCookie.split('=')[1]);
  recoveryDb.prepare('UPDATE sessoes SET expira_em=? WHERE token_hash=?').run(expiredAt, crypto.createHash('sha256').update(sessionToken).digest('hex'));
  recoveryDb.close();
  const expiredReset = await request('/api/auth/password/reset', { method: 'POST', body: JSON.stringify({ token: expiredToken, password: 'SecondFarmerReset123!' }) });
  assert(expiredReset.status === 400, 'Token de recuperação de conta expirado continuou válido.');
  const expiredSession = await request('/api/auth/session', { headers: { cookie: newFarmerCookie } });
  assert(expiredSession.body.session === null, 'Sessão expirada continuou autenticada.');
  const emergency = await request('/api/admin/security/state', { method: 'PATCH', headers: { cookie: chiefCookie }, body: JSON.stringify({ modo: 'emergencia', funcionalidades_desativadas: ['registos'], motivo: 'Teste funcional controlado.' }) });
  assert(emergency.status === 200, 'Ativação de emergência falhou.');
  const blockedRegistration = await request('/api/auth/register', { method: 'POST', body: JSON.stringify({ email: `blocked-${suffix}@example.com`, password: 'Blocked123!', nome: 'Bloqueado', tipo_perfil: 'agricultor' }) });
  assert(blockedRegistration.status === 503, 'Modo de emergência não bloqueou registos.');
  const normal = await request('/api/admin/security/state', { method: 'PATCH', headers: { cookie: chiefCookie }, body: JSON.stringify({ modo: 'normal', funcionalidades_desativadas: [], motivo: 'Teste funcional concluído.' }) });
  assert(normal.status === 200, 'Desativação de emergência falhou.');
  const backup = await request('/api/admin/security/backup', { method: 'POST', headers: { cookie: chiefCookie }, body: '{}' });
  assert(backup.status === 201 && backup.body.integrity === 'ok', 'Backup/integridade falhou.');

  await stopServer();
  await startServer();
  const persisted = await request(`/api/relatos/codigo?codigo=${encodeURIComponent(relato.body.codigo_publico)}`);
  assert(persisted.status === 200 && persisted.body.status === 'respondido', 'Dados não sobreviveram ao restart.');
  const logout = await request('/api/auth/logout', { method: 'POST', headers: { cookie: newFarmerCookie } });
  assert(logout.status === 200, 'Logout falhou.');
  const loggedOut = await request('/api/auth/session', { headers: { cookie: newFarmerCookie } });
  assert(loggedOut.body.session === null, 'Sessão não terminou após logout.');

  console.log(JSON.stringify({
    ok: true,
    checks: [
      'registration-validation-duplicates-login-failure', 'farmer-register-login-session', 'report-owner-and-code-forgery-protection', 'report-code-reuse-and-enumeration-limit', 'cross-user-report-isolation', 'relato-idempotent-retry',
      'profile-self-edit-role-protection', 'academy-course-quiz-progress', 'notifications-delivery-read-state',
      'technician-approval-list-response-status', 'carrier-profile-persistence', 'admin-users-denuncias',
      'market-product-create-public-read-owner-write', 'logistics-private-pending-approval-state-transitions', 'news-category-ia-filter',
      'news-sync-without-sources', 'news-alerts', 'ia-fallback', 'password-reset-supersession-expiration-reuse-session-revocation', 'emergency-mode',
      'backup-integrity', 'sqlite-restart-persistence', 'logout',
    ],
  }, null, 2));
} catch (error) {
  console.error(JSON.stringify({ ok: false, error: error instanceof Error ? error.message : String(error), serverOutput }, null, 2));
  process.exitCode = 1;
} finally {
  await stopServer();
  fs.rmSync(dataDir, { recursive: true, force: true });
}

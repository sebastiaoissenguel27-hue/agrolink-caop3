import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { chromium } from 'playwright';

const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'agrolink-browser-audit-'));
const probe = createServer();
await new Promise((resolve) => probe.listen(0, '127.0.0.1', resolve));
const port = probe.address().port;
await new Promise((resolve) => probe.close(resolve));
const chiefEmail = 'browser-chief@example.com';
const chiefPassword = 'BrowserChief123!';
const env = {
  ...process.env,
  NODE_ENV: 'test',
  PORT: String(port),
  AGROLINK_DATA_DIR: dataDir,
  AGROLINK_UPLOADS_DIR: path.join(dataDir, 'uploads'),
  AGROLINK_ADMIN_CHEFE_EMAIL: chiefEmail,
  AGROLINK_ADMIN_CHEFE_PASSWORD: chiefPassword,
  AGROLINK_PASSWORD_RESET_WEBHOOK_URL: '',
  AGROLINK_TRUST_PROXY: 'true',
};
const server = spawn(process.execPath, ['server/index.mjs'], { cwd: process.cwd(), env, stdio: ['ignore', 'pipe', 'pipe'] });
let serverOutput = '';
server.stdout.on('data', (chunk) => { serverOutput += chunk; });
server.stderr.on('data', (chunk) => { serverOutput += chunk; });
let browser;
const checks = [];
const results = [];
const runtimeErrors = [];
const deniedResponses = [];
let expectedRoleForgery = false;
let approvedIds = {};
let browserRequestIp = 1;
const assert = (condition, message) => { if (!condition) throw new Error(message); };

async function waitForServer() {
  for (let attempt = 0; attempt < 60; attempt += 1) {
    try {
      const response = await fetch(`http://127.0.0.1:${port}/api/health`);
      if (response.ok) return;
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  throw new Error(`Server did not become ready: ${serverOutput}`);
}

async function assertLayout(page, viewport, route) {
  const response = await page.goto(`http://127.0.0.1:${port}${route}`, { waitUntil: 'networkidle' });
  const metrics = await page.evaluate(() => ({
    viewport: innerWidth,
    document: document.documentElement.scrollWidth,
    body: document.body.scrollWidth,
    heading: document.querySelector('h1, h2')?.textContent?.trim() || '',
  }));
  assert(response?.status() === 200, `${route} returned HTTP ${response?.status()}`);
  assert(metrics.document <= metrics.viewport + 1 && metrics.body <= metrics.viewport + 1, `${route} overflowed horizontally: ${JSON.stringify(metrics)}`);
  assert(metrics.heading.length > 0, `${route} rendered no primary heading`);
  return metrics;
}

async function register(page, { email, name, type, password = 'BrowserTest123!' }) {
  await page.goto(`http://127.0.0.1:${port}/registar`, { waitUntil: 'networkidle' });
  await page.locator('#nome').fill(name);
  await page.locator('#email').fill(email);
  await page.locator('#password').fill(password);
  await page.locator('#tipo-perfil').selectOption(type);
  await page.getByRole('button', { name: 'Criar conta' }).click();
  if (email === 'sebastiaoissenguel27@gmail.com' || email === 'celcioissenguel@gmail.com') {
    await page.waitForURL('**/');
    const profile = await page.evaluate(async () => (await (await fetch('/api/auth/session')).json()).profile);
    assert(profile?.papel === 'admin_chefe' && profile.status === 'ativo' && profile.tipo_perfil === type, `${email} was not auto-approved with its selected profile`);
    await page.goto(`http://127.0.0.1:${port}/perfil`, { waitUntil: 'networkidle' });
    await page.getByText('Administrador Chefe').waitFor();
    await page.getByText(type === 'tecnico' ? 'Técnico' : 'Agricultor', { exact: true }).waitFor();
    checks.push(`reserved-chief-register-${type}`);
    return profile;
  }
  await page.getByRole('status').filter({ hasText: 'Aguarda aprovação' }).waitFor();
  checks.push(`register-${type}-pending`);
  return null;
}

async function login(page, email, password, destination = '/admin') {
  await page.goto(`http://127.0.0.1:${port}/entrar`, { waitUntil: 'networkidle' });
  await page.locator('#email').fill(email);
  await page.locator('#password').fill(password);
  await page.getByRole('button', { name: 'Entrar', exact: true }).click();
  await page.waitForURL(destination === '/' ? `http://127.0.0.1:${port}/` : '**/admin');
}

try {
  await waitForServer();
  browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  const suffix = Date.now();
  const farmer = { email: `browser-farmer-${suffix}@example.com`, name: 'Browser Farmer', type: 'agricultor' };
  const technician = { email: `browser-technician-${suffix}@example.com`, name: 'Browser Technician', type: 'tecnico' };
  const administrator = { email: `browser-admin-${suffix}@example.com`, name: 'Browser Administrator', type: 'administrador' };
  for (const viewport of [
    { name: 'android', width: 360, height: 800, mobile: true, scale: 2 },
    { name: 'desktop', width: 1365, height: 900, mobile: false, scale: 1 },
  ]) {
    const context = await browser.newContext({
      viewport: { width: viewport.width, height: viewport.height },
      isMobile: viewport.mobile,
      hasTouch: viewport.mobile,
      deviceScaleFactor: viewport.scale,
    });
    const page = await context.newPage();
    await page.route('**/api/**', (route) => {
      const headers = { ...route.request().headers(), 'x-forwarded-for': `198.51.100.${browserRequestIp++}` };
      return route.continue({ headers });
    });
    page.on('pageerror', (error) => runtimeErrors.push(`${viewport.name}: ${error.message}`));
    page.on('console', (message) => {
      if (message.type() === 'error' && !(expectedRoleForgery && /403|Forbidden/.test(message.text()))) {
        runtimeErrors.push(`${viewport.name}: ${message.location().url}: ${message.text()}`);
      }
    });
    page.on('response', (response) => { if (response.status() === 403) deniedResponses.push(`${viewport.name}: ${response.request().method()} ${response.url()}`); });
    page.on('dialog', (dialog) => void dialog.accept());

    const entryRoutes = ['/registar', '/entrar', '/visitante-offline'];
    const layout = [];
    for (const route of entryRoutes) layout.push({ route, ...await assertLayout(page, viewport, route) });
    if (viewport.mobile) {
      await register(page, farmer);
      await register(page, technician);
      await register(page, administrator);

      await login(page, chiefEmail, chiefPassword);
      assert(new URL(page.url()).pathname === '/admin', 'Admin Chefe did not reach admin panel');
      layout.push({ route: '/admin', ...await assertLayout(page, viewport, '/admin') });
      const adminRow = page.getByRole('row').filter({ hasText: administrator.name });
      await adminRow.getByRole('button', { name: 'Aprovar administrador' }).click();
      await adminRow.getByText('Ativa').waitFor();
      const farmerRow = page.getByRole('row').filter({ hasText: farmer.name });
      await farmerRow.getByRole('button', { name: 'Aprovar conta' }).click();
      await farmerRow.getByText('Ativa').waitFor();
      const technicianRow = page.getByRole('row').filter({ hasText: technician.name });
      await technicianRow.getByRole('button', { name: 'Aprovar conta' }).click();
      await technicianRow.getByText('Ativa').waitFor();
      checks.push('chief-approves-pending-admin-farmer-technician-in-ui');

      approvedIds = await page.evaluate(async ({ farmerName, technicianName }) => {
        const users = await (await fetch('/api/admin/users?status=ativo')).json();
        return {
          farmerId: users.find((user) => user.nome === farmerName)?.id,
          technicianId: users.find((user) => user.nome === technicianName)?.id,
        };
      }, { farmerName: farmer.name, technicianName: technician.name });
      assert(approvedIds.farmerId && approvedIds.technicianId, 'Approved account IDs unavailable to chief');

      expectedRoleForgery = true;
      const forbiddenMutation = await page.evaluate(async (farmerId) => {
        const response = await fetch('/api/data/profiles?id=' + encodeURIComponent(farmerId), {
          method: 'PATCH', credentials: 'include', headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ papel: 'admin_chefe' }),
        });
        return response.status;
      }, approvedIds.farmerId);
      expectedRoleForgery = false;
      assert(forbiddenMutation === 403, 'Frontend role-forgery request was not rejected');
      checks.push('authenticated-role-forgery-rejected');

      await page.getByRole('button', { name: 'Sair' }).click();
      await page.waitForURL('**/entrar');
      await login(page, farmer.email, 'BrowserTest123!', '/');
      await page.goto(`http://127.0.0.1:${port}/relatos`, { waitUntil: 'networkidle' });
      await context.setOffline(true);
      await page.getByPlaceholder('Descreva o que está a observar…').fill('Fila offline do agricultor.');
      await page.getByRole('button', { name: 'Enviar relato' }).click();
      await page.getByRole('status').filter({ hasText: 'Relato guardado no dispositivo' }).waitFor();
      const ownedReportId = await page.evaluate(async () => {
        const db = await new Promise((resolve, reject) => {
          const request = indexedDB.open('agrolink-caop');
          request.onsuccess = () => resolve(request.result);
          request.onerror = () => reject(request.error);
        });
        const rows = await new Promise((resolve, reject) => {
          const request = db.transaction('relatosPendentes').objectStore('relatosPendentes').getAll();
          request.onsuccess = () => resolve(request.result);
          request.onerror = () => reject(request.error);
        });
        db.close();
        return rows.find((row) => row.descricao === 'Fila offline do agricultor.')?.localId;
      });
      assert(ownedReportId, 'Authenticated farmer report was not saved locally while offline');
      await page.evaluate(async ({ technicianId }) => {
        const db = await new Promise((resolve, reject) => {
          const request = indexedDB.open('agrolink-caop');
          request.onsuccess = () => resolve(request.result);
          request.onerror = () => reject(request.error);
        });
        const store = db.transaction('relatosPendentes', 'readwrite').objectStore('relatosPendentes');
        const created = new Date().toISOString();
        store.put({ localId: 'offline-other-test', autorId: technicianId, tipo: 'praga', descricao: 'Fila offline de outra conta.', provincia: 'Benguela', municipio: null, comuna: null, criadoEm: created, sincronizado: false });
        await new Promise((resolve, reject) => { store.transaction.oncomplete = resolve; store.transaction.onerror = () => reject(store.transaction.error); });
        db.close();
      }, { technicianId: approvedIds.technicianId });
      const syncButton = page.getByRole('button', { name: /por sincronizar/ });
      try {
        await syncButton.waitFor({ timeout: 3000 });
      } catch {
        const debug = await page.evaluate(async () => {
          const session = await (await fetch('/api/auth/session')).json();
          const db = await new Promise((resolve, reject) => {
            const request = indexedDB.open('agrolink-caop');
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
          });
          const rows = await new Promise((resolve, reject) => {
            const request = db.transaction('relatosPendentes').objectStore('relatosPendentes').getAll();
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
          });
          db.close();
          return { profile: session.profile, rows: rows.filter((row) => row.localId.startsWith('offline-')) };
        });
        throw new Error(`Sync button missing after app-owned offline save; browser data: ${JSON.stringify(debug)}`);
      }
      await context.setOffline(false);
      await page.waitForFunction(async (ownedReportId) => await new Promise((resolve) => {
        const request = indexedDB.open('agrolink-caop');
        request.onsuccess = () => {
          const db = request.result;
          const read = db.transaction('relatosPendentes').objectStore('relatosPendentes');
          const owned = read.get(ownedReportId);
          const other = read.get('offline-other-test');
          let ownedRow, otherRow;
          owned.onsuccess = () => { ownedRow = owned.result; if (otherRow) { db.close(); resolve(ownedRow?.sincronizado === true && otherRow?.sincronizado === false); } };
          other.onsuccess = () => { otherRow = other.result; if (ownedRow) { db.close(); resolve(ownedRow?.sincronizado === true && otherRow?.sincronizado === false); } };
        };
        request.onerror = () => resolve(false);
      }), ownedReportId, { timeout: 15000 });
      checks.push('offline-retry-is-user-scoped');
      await page.getByRole('button', { name: 'Sair' }).click();
      await page.waitForURL('**/entrar');
      await login(page, administrator.email, 'BrowserTest123!');
      assert(new URL(page.url()).pathname === '/admin', 'Approved administrator did not reach the admin panel');
      checks.push('approved-admin-login-session');

      await page.getByRole('button', { name: 'Sair' }).click();
      await page.waitForURL('**/entrar');
      await register(page, { email: 'sebastiaoissenguel27@gmail.com', name: 'Sebastião Browser', type: 'tecnico', password: 'ReservedChief123!' });
      const publicTeam = await page.evaluate(async () => (await (await fetch('/api/public/team')).json()).map((member) => member.nome));
      assert(publicTeam.includes('Sebastião Browser'), 'Sebastião reserved account is not publicly visible');
      await page.getByRole('button', { name: 'Sair' }).click();
      await page.waitForURL('**/entrar');
      await register(page, { email: 'celcioissenguel@gmail.com', name: 'Célcio Browser', type: 'agricultor', password: 'ReservedChief456!' });
      const teamAfterHidden = await page.evaluate(async () => (await (await fetch('/api/public/team')).json()).map((member) => member.nome));
      assert(!teamAfterHidden.includes('Célcio Browser'), 'Célcio reserved account leaked into public team');
      checks.push('reserved-email-visibility');
    } else {
      await login(page, chiefEmail, chiefPassword);
      layout.push({ route: '/admin', ...await assertLayout(page, viewport, '/admin') });
      await page.getByRole('button', { name: 'Sair' }).click();
      await page.waitForURL('**/entrar');
      await login(page, administrator.email, 'BrowserTest123!');
      layout.push({ route: '/perfil', ...await assertLayout(page, viewport, '/perfil') });
      checks.push('desktop-chief-and-approved-admin-session');
    }
    results.push({ viewport: viewport.name, routes: layout });
    await context.close();
  }

  assert(runtimeErrors.length === 0, `Browser JavaScript/console errors: ${runtimeErrors.join(' | ')}`);
  console.log(JSON.stringify({ ok: true, checks, viewports: results, runtimeErrors, deniedResponses }, null, 2));
} catch (error) {
  console.error(JSON.stringify({ ok: false, error: error instanceof Error ? error.message : String(error), checks, runtimeErrors, deniedResponses, serverOutput }, null, 2));
  process.exitCode = 1;
} finally {
  if (browser) await browser.close();
  server.kill('SIGTERM');
  await new Promise((resolve) => server.once('exit', resolve));
  fs.rmSync(dataDir, { recursive: true, force: true });
}
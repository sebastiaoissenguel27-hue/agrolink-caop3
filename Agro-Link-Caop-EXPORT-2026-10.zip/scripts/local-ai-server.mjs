import fs from 'node:fs';
import path from 'node:path';
import { spawn, spawnSync } from 'node:child_process';

const ensure = process.argv.includes('--ensure');
const modelPath = path.resolve(String(process.env.AGROLINK_AI_MODEL_PATH || '/opt/agrolink/models/Qwen3-1.7B-Q4_K_M.gguf').trim());
if (!modelPath || modelPath === path.resolve('.')) {
  console.error('Defina AGROLINK_AI_MODEL_PATH para um GGUF fora do repositório.');
  process.exit(ensure ? 0 : 1);
}
if (!fs.existsSync(modelPath) || !fs.statSync(modelPath).isFile()) {
  console.error(`Modelo GGUF não encontrado: ${modelPath}`);
  process.exit(ensure ? 0 : 1);
}

const containerName = process.env.AGROLINK_AI_CONTAINER || 'agrolink-llama-server';
const image = process.env.AGROLINK_LLAMA_CPP_IMAGE || 'ghcr.io/ggml-org/llama.cpp:server';
const port = String(process.env.AGROLINK_AI_PORT || '8080');
const threads = String(process.env.AGROLINK_AI_THREADS || '2');
const context = String(process.env.AGROLINK_AI_CONTEXT || '2048');
const memory = String(process.env.AGROLINK_AI_MEMORY_LIMIT || '7g');

const containerArgs = [
  '--name', containerName,
  '--cpus', threads, '--memory', memory, '--memory-swap', memory,
  '-p', `127.0.0.1:${port}:8080`,
  '-v', `${modelPath}:/models/model.gguf:ro`,
  image, '-m', '/models/model.gguf', '-ngl', '0', '-c', context,
  '-t', threads, '-tb', threads, '-n', '700',
  '--host', '0.0.0.0', '--port', '8080',
];

console.log(`A iniciar llama-server com ${path.basename(modelPath)} em 127.0.0.1:${port}.`);
if (!ensure) {
  const child = spawn('docker', ['run', '--rm', ...containerArgs], { stdio: 'inherit' });
  child.on('error', (error) => {
    console.error(`Não foi possível iniciar Docker: ${error.message}`);
    process.exitCode = 1;
  });
  child.on('exit', (code, signal) => {
    process.exitCode = code ?? (signal ? 1 : 0);
  });
} else {
  function docker(args) {
    const result = spawnSync('docker', args, { encoding: 'utf8' });
    if (result.error) throw result.error;
    if (result.status !== 0) throw new Error(result.stderr.trim() || `docker ${args[0]} falhou`);
    return result.stdout.trim();
  }

  async function waitForHealth() {
    const healthUrl = new URL(process.env.AGROLINK_AGRI_AI_URL || `http://127.0.0.1:${port}/v1/chat/completions`);
    healthUrl.pathname = '/health';
    healthUrl.search = '';
    const deadline = Date.now() + Number(process.env.AGROLINK_AI_STARTUP_TIMEOUT_MS || 180000);
    while (Date.now() < deadline) {
      try {
        const response = await fetch(healthUrl, { signal: AbortSignal.timeout(2000) });
        if (response.ok) {
          console.log(`llama-server saudável em ${healthUrl}`);
          return;
        }
      } catch {}
      await new Promise((resolve) => setTimeout(resolve, 500));
    }
    throw new Error(`health não ficou saudável em ${healthUrl} dentro do tempo limite`);
  }

  try {
    const state = JSON.parse(docker(['inspect', '--format', '{{json .State}}', containerName]));
    docker(['update', '--restart', 'unless-stopped', containerName]);
    if (!state.Running) docker(['start', containerName]);
    console.log(`Container ${containerName} já existe; política de reinício assegurada.`);
  } catch (error) {
    if (String(error.message).includes('No such object')) {
      docker(['run', '--detach', '--restart', 'unless-stopped', ...containerArgs]);
    } else {
      try {
        docker(['run', '--detach', '--restart', 'unless-stopped', ...containerArgs]);
      } catch (startError) {
        console.warn(`Qwen local indisponível; AgroLink seguirá com fallback: ${startError.message}`);
        process.exit(0);
      }
    }
    console.log(`Container ${containerName} iniciado com restart=unless-stopped.`);
  }

  try {
    await waitForHealth();
  } catch (error) {
    console.warn(`Qwen local ainda indisponível; AgroLink seguirá com fallback: ${error.message}`);
  }
}
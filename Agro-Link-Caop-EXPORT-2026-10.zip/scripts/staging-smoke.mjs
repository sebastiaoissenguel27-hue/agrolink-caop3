import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const port = 8897;
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'agrolink-smoke-'));
const env = { ...process.env, PORT: String(port), AGROLINK_DATA_DIR: tmp, AGROLINK_UPLOADS_DIR: path.join(tmp, 'uploads'), AGROLINK_ADMIN_CHEFE_EMAIL: 'chief-smoke@example.com', AGROLINK_ADMIN_CHEFE_PASSWORD: 'ChiefSmoke123!', AGROLINK_ALLOW_DEV_RECOVERY_LINK: 'true' };
const child = spawn(process.execPath, ['server/index.mjs'], { cwd: process.cwd(), env, stdio: ['ignore', 'pipe', 'pipe'] });
let output = '';
child.stdout.on('data', d => output += d);
child.stderr.on('data', d => output += d);

const sleep = ms => new Promise(r => setTimeout(r, ms));
async function request(pathname, options = {}) {
  const r = await fetch(`http://127.0.0.1:${port}${pathname}`, { redirect: 'manual', ...options, headers: { 'content-type': 'application/json', ...(options.headers || {}) } });
  const text = await r.text();
  let body = null; try { body = JSON.parse(text); } catch {}
  return { status: r.status, body, headers: r.headers };
}
function assert(ok, msg) { if (!ok) throw new Error(msg); }

try {
  let health;
  for (let i = 0; i < 30; i++) {
    try { health = await request('/api/health'); if (health.status === 200) break; } catch {}
    await sleep(100);
  }
  assert(health?.status === 200 && health.body?.database === 'internal', 'health failed');
  const sameOriginPreflight = await request('/api/auth/login', { method: 'OPTIONS', headers: { origin: `http://127.0.0.1:${port}` } });
  assert(sameOriginPreflight.status === 204 && sameOriginPreflight.headers.get('access-control-allow-origin') === `http://127.0.0.1:${port}`, 'same-origin preflight failed');
  const hostilePreflight = await request('/api/auth/login', { method: 'OPTIONS', headers: { origin: 'https://attacker.example' } });
  assert(hostilePreflight.status === 403 && !hostilePreflight.headers.get('access-control-allow-origin'), 'hostile preflight origin was reflected');

  const chiefEmail = env.AGROLINK_ADMIN_CHEFE_EMAIL;
  const chiefPassword = 'ChiefSmoke123!';
  const chiefReg = await request('/api/auth/register', { method: 'POST', body: JSON.stringify({ email: chiefEmail, password: chiefPassword, nome: 'Chief Smoke', papel: 'admin' }) });
  assert(chiefReg.status === 409, `bootstrapped chief account should reject duplicate registration, got ${chiefReg.status}`);
  const chiefLogin = await request('/api/auth/login', { method: 'POST', body: JSON.stringify({ email: chiefEmail, password: chiefPassword }) });
  assert(chiefLogin.status === 200, `chief login failed: ${chiefLogin.status}`);
  assert(chiefLogin.body?.profile?.papel === 'admin_chefe', 'bootstrap chief role invalid');
  const chiefCookie = chiefLogin.headers.get('set-cookie');
  assert(chiefCookie, 'chief cookie missing');

  const farmerEmail = 'farmer-smoke@example.com';
  const farmerPassword = 'FarmerSmoke123!';
  const farmerReg = await request('/api/auth/register', { method: 'POST', body: JSON.stringify({ email: farmerEmail, password: farmerPassword, nome: 'Farmer Smoke', papel: 'admin', tipo_perfil: 'agricultor' }) });
  assert(farmerReg.status === 201, `farmer register failed: ${farmerReg.status}`);
  const farmerLogin = await request('/api/auth/login', { method: 'POST', body: JSON.stringify({ email: farmerEmail, password: farmerPassword }) });
  assert(farmerLogin.status === 200, `farmer login failed: ${farmerLogin.status}`);
  let farmerCookie = farmerLogin.headers.get('set-cookie');
  assert(farmerCookie, 'farmer cookie missing');
  const farmerSession = await request('/api/auth/session', { headers: { cookie: farmerCookie } });
  assert(farmerSession.status === 200 && farmerSession.body?.profile?.papel === 'utilizador' && farmerSession.body?.profile?.tipo_perfil === 'agricultor', 'farmer session invalid');
  const forgot = await request('/api/auth/password/forgot', { method: 'POST', body: JSON.stringify({ email: farmerEmail }) });
  assert(forgot.status === 200 && forgot.body?.recoveryUrl, 'password recovery link was not generated in dev mode');
  const recoveryToken = new URL(forgot.body.recoveryUrl).searchParams.get('token');
  assert(recoveryToken, 'recovery token missing');
  const reset = await request('/api/auth/password/reset', { method: 'POST', body: JSON.stringify({ token: recoveryToken, password: 'FarmerReset123!' }) });
  assert(reset.status === 200, `password reset failed: ${reset.status}`);
  const farmerRelogin = await request('/api/auth/login', { method: 'POST', body: JSON.stringify({ email: farmerEmail, password: 'FarmerReset123!' }) });
  assert(farmerRelogin.status === 200, `password reset login failed: ${farmerRelogin.status}`);
  farmerCookie = farmerRelogin.headers.get('set-cookie');

  const adminEmail = 'admin-smoke@example.com';
  const adminPassword = 'AdminSmoke123!';
  await request('/api/auth/register', { method: 'POST', body: JSON.stringify({ email: adminEmail, password: adminPassword, nome: 'Admin Smoke', tipo_perfil: 'administrador', papel: 'admin_chefe' }) });
  const adminLogin0 = await request('/api/auth/login', { method: 'POST', body: JSON.stringify({ email: adminEmail, password: adminPassword }) });
  const adminId = adminLogin0.body.profile.id;
  assert(adminLogin0.body.profile.papel === 'utilizador' && adminLogin0.body.profile.tipo_perfil === 'administrador' && adminLogin0.body.profile.status === 'pendente', 'admin registration did not remain pending without frontend privileges');
  const promote = await request('/api/admin/users/approve', { method: 'POST', headers: { cookie: chiefCookie }, body: JSON.stringify({ id: adminId, papel: 'admin_chefe' }) });
  assert(promote.status === 200 && promote.body.papel === 'admin' && promote.body.status === 'ativo', `chief approval failed: ${promote.status}`);

  const pendingComplaint = await request('/api/denuncias', { method: 'POST', headers: { cookie: farmerCookie }, body: JSON.stringify({ denunciado_id: adminId, categoria: 'Conduta', descricao: 'Tentativa enquanto a conta aguarda aprovação.', prioridade: 'media' }) });
  assert(pendingComplaint.status === 403, 'pending account performed a protected mutation');
  const approveFarmer = await request('/api/admin/users/approve-account', { method: 'POST', headers: { cookie: chiefCookie }, body: JSON.stringify({ id: farmerLogin.body.profile.id }) });
  assert(approveFarmer.status === 200 && approveFarmer.body.status === 'ativo', `farmer approval failed: ${approveFarmer.status}`);

  const complaint = await request('/api/denuncias', { method: 'POST', headers: { cookie: farmerCookie }, body: JSON.stringify({ denunciado_id: adminId, categoria: 'Conduta', descricao: 'Teste controlado de denúncia no staging.', prioridade: 'media' }) });
  assert(complaint.status === 201, `complaint failed: ${complaint.status}`);
  const complaints = await request('/api/admin/denuncias', { headers: { cookie: chiefCookie } });
  assert(complaints.status === 200 && complaints.body.some(x => x.id === complaint.body.id), 'complaint not visible to admin');

  const suspend = await request('/api/admin/users/suspender', { method: 'POST', headers: { cookie: chiefCookie }, body: JSON.stringify({ id: adminId, motivo: 'Teste controlado de suspensão.' }) });
  assert(suspend.status === 200, `suspend failed: ${suspend.status}`);
  const blockedLogin = await request('/api/auth/login', { method: 'POST', body: JSON.stringify({ email: adminEmail, password: adminPassword }) });
  assert(blockedLogin.status === 403, `blocked login expected 403, got ${blockedLogin.status}`);
  const reactivate = await request('/api/admin/users/repor-ativa', { method: 'POST', headers: { cookie: chiefCookie }, body: JSON.stringify({ id: adminId }) });
  assert(reactivate.status === 200, `reactivate failed: ${reactivate.status}`);

  const emergency = await request('/api/admin/security/state', { method: 'PATCH', headers: { cookie: chiefCookie }, body: JSON.stringify({ modo: 'emergencia', funcionalidades_desativadas: ['registos'], motivo: 'Smoke test controlado.' }) });
  assert(emergency.status === 200 && emergency.body.modo === 'emergencia', `emergency enable failed: ${emergency.status}`);
  const blockedRegister = await request('/api/auth/register', { method: 'POST', body: JSON.stringify({ email: 'blocked-smoke@example.com', password: 'BlockedSmoke123!', nome: 'Blocked Smoke', papel: 'agricultor' }) });
  assert(blockedRegister.status === 503, `emergency register expected 503, got ${blockedRegister.status}`);
  const normal = await request('/api/admin/security/state', { method: 'PATCH', headers: { cookie: chiefCookie }, body: JSON.stringify({ modo: 'normal', funcionalidades_desativadas: [], motivo: 'Smoke test concluído.' }) });
  assert(normal.status === 200 && normal.body.modo === 'normal', 'emergency disable failed');

  const backup = await request('/api/admin/security/backup', { method: 'POST', headers: { cookie: chiefCookie }, body: '{}' });
  assert(backup.status === 201 && backup.body.integrity === 'ok', `backup failed: ${backup.status}`);

  console.log(JSON.stringify({ ok: true, checks: ['health','chief-auth','farmer-auth','password-recovery','promotion','complaint','suspension','blocked-login','reactivation','emergency-mode','backup-integrity'] }, null, 2));
} catch (error) {
  console.error(JSON.stringify({ ok: false, error: String(error?.message || error), serverOutput: output }, null, 2));
  process.exitCode = 1;
} finally {
  child.kill('SIGTERM');
  await sleep(100);
  fs.rmSync(tmp, { recursive: true, force: true });
}

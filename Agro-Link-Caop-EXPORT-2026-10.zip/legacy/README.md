# Legado Supabase

As migrations e funções que estavam em `supabase/` foram mantidas aqui apenas como histórico/referência de reconstrução.

O runtime atual do AgroLink **não importa nem executa Supabase**. A base ativa está em `server/migrations/001_platform.sql` e é inicializada por `server/db.mjs`.

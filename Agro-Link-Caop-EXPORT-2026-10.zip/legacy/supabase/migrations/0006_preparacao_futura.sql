
-- 0006 — Preparação futura: SIE, Mercado AgroLink, mapas, sensores.
-- Schema pronto, RLS fechada, sem UI de profundidade nesta versão.

-- SIE: indicadores agregados por período/província.
create table public.sie_indicadores (
  id              uuid primary key default gen_random_uuid(),
  tipo_indicador  text not null,
  provincia       text,
  periodo         text,
  valor           numeric,
  calculado_em    timestamptz not null default now()
);

alter table public.sie_indicadores enable row level security;

create policy "sie_select_admin_tecnico"
  on public.sie_indicadores for select to authenticated
  using (public.is_admin() or public.sou_tecnico_aprovado());

-- Mercado AgroLink: schema pronto, módulo inativo (sem política de
-- leitura pública ainda — só o próprio vendedor e admin veem).
create table public.mercado_produtos (
  id                      uuid primary key default gen_random_uuid(),
  vendedor_id             uuid references public.profiles(id),
  nome                    text not null,
  categoria               text,
  preco                   numeric,
  unidade                 text,
  quantidade_disponivel   numeric,
  provincia               text,
  ativo                   boolean not null default false,
  criado_em               timestamptz not null default now()
);

alter table public.mercado_produtos enable row level security;

create policy "mercado_select_proprio_ou_admin"
  on public.mercado_produtos for select to authenticated
  using (vendedor_id = auth.uid() or public.is_admin());

create policy "mercado_gerir_proprio"
  on public.mercado_produtos for all to authenticated
  using (vendedor_id = auth.uid())
  with check (vendedor_id = auth.uid());

-- Mapas: coordenadas geográficas nos relatos (PostGIS).
-- Nota: se o projeto Supabase ainda não tem a extensão PostGIS ativa,
-- pode ser necessário ativá-la primeiro pelo painel (Database > Extensions).
create extension if not exists postgis;
alter table public.relatos add column if not exists localizacao geography(point, 4326);

-- Sensores (IoT): schema pronto para uma futura integração de hardware.
create table public.sensores (
  id                uuid primary key default gen_random_uuid(),
  exploracao_nome   text,
  tipo              text,
  provincia         text,
  instalado_por     uuid references public.profiles(id),
  criado_em         timestamptz not null default now()
);

create table public.leituras_sensor (
  id          uuid primary key default gen_random_uuid(),
  sensor_id   uuid not null references public.sensores(id) on delete cascade,
  valor       numeric,
  unidade     text,
  medido_em   timestamptz not null default now()
);

alter table public.sensores enable row level security;
alter table public.leituras_sensor enable row level security;

create policy "sensores_select_admin_tecnico"
  on public.sensores for select to authenticated
  using (public.is_admin() or public.sou_tecnico_aprovado());

create policy "leituras_select_admin_tecnico"
  on public.leituras_sensor for select to authenticated
  using (public.is_admin() or public.sou_tecnico_aprovado());


-- 0003 — Módulo de relatos agrícolas
create extension if not exists pgcrypto;

create type tipo_relato as enum ('praga', 'doenca', 'clima', 'solo', 'pedido_apoio', 'outro');
create type status_relato as enum ('pendente', 'em_analise', 'resolvido');
create type tipo_midia as enum ('foto', 'audio');

create table public.relatos (
  id                    uuid primary key default gen_random_uuid(),
  autor_id              uuid references public.profiles(id) on delete set null,
  codigo_publico        text unique,
  tipo                  tipo_relato not null,
  descricao             text not null,
  provincia             text,
  municipio             text,
  comuna                text,
  status                status_relato not null default 'pendente',
  tecnico_atribuido_id  uuid references public.profiles(id) on delete set null,
  criado_em             timestamptz not null default now(),
  constraint relato_tem_autor_ou_codigo check (autor_id is not null or codigo_publico is not null)
);

comment on column public.relatos.codigo_publico is
  'Preenchido só quando autor_id é nulo (relato sem cadastro); é o único meio de o autor anónimo consultar depois o estado do seu relato.';

-- Gera um código público de 8 caracteres, único, só quando não há autor.
-- Fica no servidor de propósito: o cliente nunca decide o próprio código.
create or replace function public.gerar_codigo_publico()
returns trigger
language plpgsql
as $$
declare
  tentativa text;
begin
  if new.autor_id is null and new.codigo_publico is null then
    loop
      tentativa := upper(substr(md5(random()::text || clock_timestamp()::text), 1, 8));
      exit when not exists (select 1 from public.relatos where codigo_publico = tentativa);
    end loop;
    new.codigo_publico := tentativa;
  end if;
  return new;
end;
$$;

create trigger trg_gerar_codigo_publico
  before insert on public.relatos
  for each row
  execute function public.gerar_codigo_publico();

create table public.relato_midias (
  id              uuid primary key default gen_random_uuid(),
  relato_id       uuid not null references public.relatos(id) on delete cascade,
  tipo            tipo_midia not null,
  caminho_storage text not null,
  criado_em       timestamptz not null default now()
);

create table public.relato_respostas (
  id          uuid primary key default gen_random_uuid(),
  relato_id   uuid not null references public.relatos(id) on delete cascade,
  tecnico_id  uuid not null references public.profiles(id),
  comentario  text not null,
  criado_em   timestamptz not null default now()
);

alter table public.relatos enable row level security;
alter table public.relato_midias enable row level security;
alter table public.relato_respostas enable row level security;

-- Auxiliares reutilizados pelas políticas abaixo.
create or replace function public.minha_provincia()
returns text
language sql security definer stable
as $$ select provincia from public.profiles where id = auth.uid(); $$;

create or replace function public.sou_tecnico_aprovado()
returns boolean
language sql security definer stable
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and papel = 'tecnico' and verification_status = 'aprovado'
  );
$$;

-- SELECT relatos: autor vê o seu; técnico aprovado vê os da sua província;
-- admin vê todos. Relatos sem cadastro só se consultam via RPC por código.
create policy "relatos_select_proprio"
  on public.relatos for select to authenticated
  using (autor_id = auth.uid());

create policy "relatos_select_tecnico_da_provincia"
  on public.relatos for select to authenticated
  using (public.sou_tecnico_aprovado() and provincia = public.minha_provincia());

create policy "relatos_select_admin"
  on public.relatos for select to authenticated
  using (public.is_admin());

-- INSERT: autenticado só em nome próprio; anónimo só sem autor_id.
create policy "relatos_insert_autenticado"
  on public.relatos for insert to authenticated
  with check (autor_id = auth.uid());

create policy "relatos_insert_anonimo"
  on public.relatos for insert to anon
  with check (autor_id is null);

-- UPDATE (mudar status/atribuição): só técnico aprovado ou admin.
create policy "relatos_update_tecnico_ou_admin"
  on public.relatos for update to authenticated
  using (public.sou_tecnico_aprovado() or public.is_admin());

-- Mídias: visibilidade herda a do relato-pai.
create policy "midias_select_via_relato"
  on public.relato_midias for select to authenticated
  using (
    exists (
      select 1 from public.relatos r where r.id = relato_id
        and (r.autor_id = auth.uid() or public.is_admin()
             or (public.sou_tecnico_aprovado() and r.provincia = public.minha_provincia()))
    )
  );

create policy "midias_insert_autenticado"
  on public.relato_midias for insert to authenticated
  with check (exists (select 1 from public.relatos r where r.id = relato_id and r.autor_id = auth.uid()));

create policy "midias_insert_anonimo"
  on public.relato_midias for insert to anon
  with check (exists (select 1 from public.relatos r where r.id = relato_id and r.autor_id is null));

-- Respostas técnicas
create policy "respostas_select_via_relato"
  on public.relato_respostas for select to authenticated
  using (
    exists (
      select 1 from public.relatos r where r.id = relato_id
        and (r.autor_id = auth.uid() or public.is_admin()
             or (public.sou_tecnico_aprovado() and r.provincia = public.minha_provincia()))
    )
  );

create policy "respostas_insert_tecnico"
  on public.relato_respostas for insert to authenticated
  with check (tecnico_id = auth.uid() and public.sou_tecnico_aprovado());

-- Consulta pública por código (relatos sem cadastro), via RPC —
-- devolve só o relato correspondente, nunca uma lista navegável.
create or replace function public.consultar_relato_por_codigo(p_codigo text)
returns jsonb
language sql security definer stable
as $$
  select jsonb_build_object(
    'id', r.id,
    'tipo', r.tipo,
    'descricao', r.descricao,
    'status', r.status,
    'criado_em', r.criado_em,
    'respostas', coalesce(
      (select jsonb_agg(jsonb_build_object('comentario', rr.comentario, 'criado_em', rr.criado_em) order by rr.criado_em)
       from public.relato_respostas rr where rr.relato_id = r.id),
      '[]'::jsonb
    )
  )
  from public.relatos r
  where r.codigo_publico = upper(p_codigo);
$$;

grant execute on function public.consultar_relato_por_codigo(text) to anon, authenticated;

-- Storage: bucket privado para fotos/áudios dos relatos.
insert into storage.buckets (id, name, public)
values ('relatos', 'relatos', false)
on conflict (id) do nothing;

-- v1: qualquer autenticado ou anónimo pode enviar para o bucket "relatos";
-- a leitura fica restrita a autenticados. Refinar por path (pasta por
-- relato_id) fica marcado para um ciclo de melhoria de segurança.
create policy "storage_relatos_insert"
  on storage.objects for insert to authenticated, anon
  with check (bucket_id = 'relatos');

create policy "storage_relatos_select"
  on storage.objects for select to authenticated
  using (bucket_id = 'relatos');

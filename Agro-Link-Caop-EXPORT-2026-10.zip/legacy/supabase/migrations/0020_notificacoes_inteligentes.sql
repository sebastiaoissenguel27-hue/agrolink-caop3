
-- 0020 — Notificações inteligentes: mais tipos de evento + mensagens da administração.

alter table public.preferencias_utilizador
  add column if not exists notif_novos_cursos boolean not null default true,
  add column if not exists notif_progresso_academia boolean not null default true,
  add column if not exists notif_calendario_agricola boolean not null default true;

-- Mudança de estado do relato (fora do fluxo de resposta, já coberto por
-- trg_ao_responder_relato — aqui cobrimos só em_analise/resolvido, para
-- não duplicar notificação quando o estado muda para "respondido").
create or replace function public.ao_mudar_estado_relato()
returns trigger
language plpgsql security definer
as $$
declare v_notificar boolean;
begin
  if new.status is distinct from old.status
     and new.status in ('em_analise', 'resolvido')
     and new.autor_id is not null then
    select notif_respostas_relato into v_notificar
      from public.preferencias_utilizador where utilizador_id = new.autor_id;
    if coalesce(v_notificar, true) then
      perform public.criar_notificacao(
        new.autor_id, 'O estado do seu relato mudou',
        'Novo estado: ' || new.status, 'relato_estado', 'relato', new.id
      );
    end if;
  end if;
  return new;
end;
$$;

create trigger trg_ao_mudar_estado_relato
  after update on public.relatos
  for each row
  execute function public.ao_mudar_estado_relato();

-- Novo alerta: notifica utilizadores da(s) província(s) alvo (ou todos,
-- se for nacional) que tenham a preferência ativa. Inserção em lote —
-- não usa criar_notificacao() (pensada para um destinatário de cada vez)
-- por razões de desempenho com muitos destinatários.
create or replace function public.ao_criar_alerta()
returns trigger
language plpgsql security definer
as $$
begin
  insert into public.notificacoes (destinatario_id, titulo, corpo, tipo, relacionado_tipo, relacionado_id)
  select p.id, 'Novo alerta: ' || new.titulo, new.descricao, 'novo_alerta', 'alerta', new.id
  from public.profiles p
  join public.preferencias_utilizador pu on pu.utilizador_id = p.id
  where p.status = 'ativo'
    and coalesce(pu.notif_alertas, true)
    and (array_length(new.provincias_alvo, 1) is null or p.provincia = any (new.provincias_alvo));
  return new;
end;
$$;

create trigger trg_ao_criar_alerta
  after insert on public.alertas
  for each row
  execute function public.ao_criar_alerta();

-- Novo curso na Academia.
create or replace function public.ao_criar_curso()
returns trigger
language plpgsql security definer
as $$
begin
  insert into public.notificacoes (destinatario_id, titulo, corpo, tipo, relacionado_tipo, relacionado_id)
  select p.id, 'Novo curso na Academia', new.titulo, 'novo_curso', 'curso', new.id
  from public.profiles p
  join public.preferencias_utilizador pu on pu.utilizador_id = p.id
  where p.status = 'ativo' and coalesce(pu.notif_novos_cursos, true);
  return new;
end;
$$;

create trigger trg_ao_criar_curso
  after insert on public.academia_cursos
  for each row
  execute function public.ao_criar_curso();

-- Mensagens gerais da administração ("broadcast"), com filtro opcional por papel.
create or replace function public.enviar_mensagem_admin(p_titulo text, p_corpo text, p_papel papel_utilizador default null)
returns integer
language plpgsql security definer
as $$
declare v_count integer;
begin
  if not public.is_admin() then
    raise exception 'Só administradores podem enviar mensagens gerais.';
  end if;

  insert into public.notificacoes (destinatario_id, titulo, corpo, tipo)
  select id, p_titulo, p_corpo, 'mensagem_admin'
  from public.profiles
  where status = 'ativo' and (p_papel is null or papel = p_papel);

  get diagnostics v_count = row_count;
  perform public.registar_auditoria('enviar_mensagem_admin', 'notificacoes', null,
    jsonb_build_object('titulo', p_titulo, 'papel_alvo', p_papel, 'destinatarios', v_count));
  return v_count;
end;
$$;

grant execute on function public.enviar_mensagem_admin(text, text, papel_utilizador) to authenticated;

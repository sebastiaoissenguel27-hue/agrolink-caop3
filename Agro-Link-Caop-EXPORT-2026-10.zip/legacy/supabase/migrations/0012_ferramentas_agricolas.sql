
-- 0012 — Módulo Ferramentas Agrícolas: histórico de cálculos por utilizador.
-- As próprias calculadoras correm no cliente (sem custo de servidor);
-- só o histórico de resultados é persistido, para consulta posterior
-- em qualquer dispositivo.

create table public.ferramenta_calculos (
  id             uuid primary key default gen_random_uuid(),
  utilizador_id  uuid not null references public.profiles(id) on delete cascade,
  ferramenta     text not null,   -- 'dose_insumo' | 'calendario_plantio'
  entradas       jsonb not null,
  resultado      jsonb not null,
  criado_em      timestamptz not null default now()
);

alter table public.ferramenta_calculos enable row level security;

create policy "ferramenta_calculos_proprio"
  on public.ferramenta_calculos for all to authenticated
  using (utilizador_id = auth.uid())
  with check (utilizador_id = auth.uid());

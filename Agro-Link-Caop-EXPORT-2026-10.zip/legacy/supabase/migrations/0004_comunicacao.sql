
-- 0004 — Notícias, alertas e assistente IA agrícola

create table public.noticias (
  id            uuid primary key default gen_random_uuid(),
  titulo        text not null,
  resumo        text,
  conteudo      text not null,
  imagem_url    text,
  autor_id      uuid references public.profiles(id),
  categoria     text,
  publicado_em  timestamptz not null default now()
);

alter table public.noticias enable row level security;

create policy "noticias_select_publico"
  on public.noticias for select to authenticated, anon
  using (true);

create policy "noticias_gerir_admin"
  on public.noticias for all to authenticated
  using (public.is_admin())
  with check (public.is_admin());

create type nivel_alerta as enum ('info', 'atencao', 'urgente');

create table public.alertas (
  id                uuid primary key default gen_random_uuid(),
  titulo            text not null,
  descricao         text not null,
  tipo              text,
  provincias_alvo   text[] not null default '{}',
  nivel             nivel_alerta not null default 'info',
  criado_por        uuid references public.profiles(id),
  criado_em         timestamptz not null default now(),
  expira_em         timestamptz
);

alter table public.alertas enable row level security;

create policy "alertas_select_publico"
  on public.alertas for select to authenticated, anon
  using (expira_em is null or expira_em > now());

create policy "alertas_gerir_admin"
  on public.alertas for all to authenticated
  using (public.is_admin())
  with check (public.is_admin());

-- Assistente IA agrícola: histórico de conversas, sempre isolado por dono.
create table public.ia_conversas (
  id              uuid primary key default gen_random_uuid(),
  utilizador_id   uuid not null references public.profiles(id) on delete cascade,
  criado_em       timestamptz not null default now()
);

create table public.ia_mensagens (
  id            uuid primary key default gen_random_uuid(),
  conversa_id   uuid not null references public.ia_conversas(id) on delete cascade,
  role          text not null check (role in ('user', 'assistant')),
  conteudo      text not null,
  criado_em     timestamptz not null default now()
);

alter table public.ia_conversas enable row level security;
alter table public.ia_mensagens enable row level security;

create policy "ia_conversas_proprio"
  on public.ia_conversas for all to authenticated
  using (utilizador_id = auth.uid())
  with check (utilizador_id = auth.uid());

create policy "ia_mensagens_via_conversa"
  on public.ia_mensagens for all to authenticated
  using (exists (select 1 from public.ia_conversas c where c.id = conversa_id and c.utilizador_id = auth.uid()))
  with check (exists (select 1 from public.ia_conversas c where c.id = conversa_id and c.utilizador_id = auth.uid()));

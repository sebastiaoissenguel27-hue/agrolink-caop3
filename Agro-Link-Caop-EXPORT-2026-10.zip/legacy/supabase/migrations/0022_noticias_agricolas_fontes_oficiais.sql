
-- 0022 — Notícias exclusivamente agrícolas: categorias fixas, país,
-- prioridade de fontes, logs de sincronização, e catálogo de fontes
-- oficiais (só as que consegui confirmar têm URL; as restantes ficam
-- por completar pelo admin — não inventamos feeds RSS).

create type categoria_noticia as enum (
  'Culturas', 'Pecuária', 'Clima', 'Mercados', 'Tecnologia',
  'Investigação', 'Políticas Públicas', 'Pragas e Doenças', 'Formação', 'Ambiente'
);

alter table public.noticias
  add column if not exists categoria_ia categoria_noticia,
  add column if not exists pais text,
  add column if not exists relevante boolean not null default true;

comment on column public.noticias.categoria_ia is
  'Categoria atribuída automaticamente pela IA na ingestão (ver Edge Function sync-noticias). "categoria" (texto livre) continua a existir para notícias manuais do admin.';
comment on column public.noticias.relevante is
  'false = passou no feed mas o filtro de relevância agrícola teve dúvidas; fica visível ao admin para revisão manual, não é apagada automaticamente.';

alter table public.noticias_fontes
  add column if not exists pais text,
  add column if not exists prioridade int not null default 0;

comment on column public.noticias_fontes.prioridade is
  'Fontes com prioridade mais alta são sincronizadas primeiro (útil quando há muitas fontes e a janela de execução da Edge Function é limitada).';

-- Torna url_rss opcional: permite pré-registar fontes conhecidas cujo
-- feed ainda não foi confirmado, sem bloquear a sincronização das outras.
alter table public.noticias_fontes alter column url_rss drop not null;
alter table public.noticias_fontes
  add constraint fonte_ativa_precisa_de_url check (not ativo or url_rss is not null);

-- Histórico de sincronizações, por fonte e por execução — para o admin
-- ver o que falhou sem interromper as restantes fontes.
create table public.noticias_sync_logs (
  id                uuid primary key default gen_random_uuid(),
  fonte_id          uuid references public.noticias_fontes(id) on delete cascade,
  sucesso           boolean not null,
  itens_inseridos   int not null default 0,
  itens_ignorados   int not null default 0,
  mensagem_erro     text,
  executado_em      timestamptz not null default now()
);

alter table public.noticias_sync_logs enable row level security;

create policy "sync_logs_select_admin"
  on public.noticias_sync_logs for select to authenticated
  using (public.is_admin());

-- Sem política de INSERT: só a Edge Function (service role) escreve aqui.

-- ── Catálogo de fontes oficiais ──────────────────────────────────────
-- Nacionais confirmadas (URL verificada nesta sessão):
insert into public.noticias_fontes (nome, url_rss, categoria, ambito, pais, prioridade, ativo)
values
  ('ANGOP — Agricultura', 'https://www.angop.ao/rss/agricultura/', 'Agricultura', 'nacional', 'Angola', 10, true)
on conflict do nothing;

-- Internacionais confirmadas:
insert into public.noticias_fontes (nome, url_rss, categoria, ambito, pais, prioridade, ativo)
values
  ('FAO Newsroom', 'https://www.fao.org/feeds/fao-newsroom-rss', 'Agricultura', 'internacional', 'Internacional', 10, true)
on conflict do nothing;

-- Nacionais e internacionais pedidas mas sem URL de feed confirmada
-- nesta sessão — inativas de propósito (a constraint acima impede
-- ativá-las sem primeiro preencher url_rss). O admin completa e ativa
-- pelo painel quando tiver o feed real.
insert into public.noticias_fontes (nome, url_rss, categoria, ambito, pais, ativo)
values
  ('Ministério da Agricultura e Florestas de Angola (MINAGRIF)', null, 'Políticas Públicas', 'nacional', 'Angola', false),
  ('Instituto de Desenvolvimento Agrário (IDA)', null, 'Culturas', 'nacional', 'Angola', false),
  ('Instituto de Investigação Agronómica (IIA)', null, 'Investigação', 'nacional', 'Angola', false),
  ('Instituto dos Serviços de Veterinária (ISV)', null, 'Pecuária', 'nacional', 'Angola', false),
  ('FAO Angola', null, 'Agricultura', 'nacional', 'Angola', false),
  ('Jornal de Angola — Agricultura', null, 'Culturas', 'nacional', 'Angola', false),
  ('IFAD', null, 'Investigação', 'internacional', 'Internacional', false),
  ('CGIAR', null, 'Investigação', 'internacional', 'Internacional', false),
  ('CABI', null, 'Pragas e Doenças', 'internacional', 'Internacional', false),
  ('CIMMYT', null, 'Investigação', 'internacional', 'Internacional', false),
  ('IITA', null, 'Investigação', 'internacional', 'Internacional', false),
  ('World Bank — Agriculture', null, 'Políticas Públicas', 'internacional', 'Internacional', false),
  ('African Development Bank — Agriculture', null, 'Políticas Públicas', 'internacional', 'Internacional', false),
  ('Reuters — Agriculture', null, 'Mercados', 'internacional', 'Internacional', false)
on conflict do nothing;


-- 0005 — Estatísticas iniciais (agregações simples, sem tabela dedicada
-- ainda; o SIE, na preparação futura, é que vai persistir séries no tempo)

create or replace function public.obter_estatisticas()
returns jsonb
language plpgsql
security definer
stable
as $$
begin
  if not (public.is_admin() or public.sou_tecnico_aprovado()) then
    raise exception 'Sem permissão para consultar estatísticas.';
  end if;

  return jsonb_build_object(
    'total_relatos', (select count(*) from public.relatos),
    'relatos_pendentes', (select count(*) from public.relatos where status = 'pendente'),
    'relatos_em_analise', (select count(*) from public.relatos where status = 'em_analise'),
    'relatos_resolvidos', (select count(*) from public.relatos where status = 'resolvido'),
    'total_agricultores', (select count(*) from public.profiles where papel = 'agricultor'),
    'total_tecnicos', (select count(*) from public.profiles where papel = 'tecnico'),
    'tecnicos_aprovados', (select count(*) from public.profiles where papel = 'tecnico' and verification_status = 'aprovado'),
    'contas_pendentes', (select count(*) from public.profiles where status = 'pendente')
  );
end;
$$;

grant execute on function public.obter_estatisticas() to authenticated;

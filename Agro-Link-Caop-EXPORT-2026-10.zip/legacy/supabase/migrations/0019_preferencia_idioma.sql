
-- 0019 — Preferência de idioma (infraestrutura de internacionalização).
-- O valor é guardado mesmo antes de existirem traduções completas para
-- todas as línguas, para não perder a escolha do utilizador quando as
-- traduções chegarem.

create type idioma_app as enum ('pt', 'kmb', 'umb', 'kon', 'cok');
-- pt = Português · kmb = Kimbundu · umb = Umbundu · kon = Kikongo · cok = Cokwe

alter table public.preferencias_utilizador
  add column if not exists idioma idioma_app not null default 'pt';

comment on column public.preferencias_utilizador.idioma is
  'Preferência de idioma da interface. Só "pt" tem tradução completa nesta versão — as restantes ficam guardadas para quando as traduções estiverem prontas (ver docs/i18n.md).';

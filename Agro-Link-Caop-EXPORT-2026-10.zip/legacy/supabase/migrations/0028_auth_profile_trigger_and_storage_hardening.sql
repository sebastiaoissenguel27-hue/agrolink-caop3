-- 0028 — Perfil automático após registo + endurecimento do Storage.
--
-- Corrige dois problemas operacionais do fluxo real:
-- 1) quando a confirmação de email está ativa, o cliente não tem sessão logo
--    após signUp e o perfil não podia ser criado pelo frontend;
-- 2) o bucket privado "relatos" aceitava uploads anónimos/autenticados sem
--    verificar se o caminho pertencia ao relato correspondente.
--
-- Esta migration não cria admins. O papel recebido do frontend é limitado a
-- agricultor/técnico e o trigger força qualquer valor desconhecido para agricultor.

create or replace function public.criar_perfil_apos_registo()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_papel public.papel_utilizador := 'agricultor';
  v_nome text;
  v_provincia text;
  v_municipio text;
  v_comuna text;
  v_telefone text;
begin
  -- Nunca aceitar admin/transportador a partir de metadata pública.
  if coalesce(new.raw_user_meta_data ->> 'papel', '') = 'tecnico' then
    v_papel := 'tecnico';
  end if;

  v_nome := nullif(trim(coalesce(new.raw_user_meta_data ->> 'nome', '')), '');
  if v_nome is null then
    v_nome := coalesce(nullif(split_part(coalesce(new.email, ''), '@', 1), ''), 'Utilizador AgroLink');
  end if;

  v_provincia := nullif(trim(coalesce(new.raw_user_meta_data ->> 'provincia', '')), '');
  v_municipio := nullif(trim(coalesce(new.raw_user_meta_data ->> 'municipio', '')), '');
  v_comuna := nullif(trim(coalesce(new.raw_user_meta_data ->> 'comuna', '')), '');
  v_telefone := nullif(trim(coalesce(new.raw_user_meta_data ->> 'telefone', '')), '');

  insert into public.profiles (
    id, nome, papel, provincia, municipio, comuna, telefone,
    status, verification_status
  ) values (
    new.id, v_nome, v_papel, v_provincia, v_municipio, v_comuna, v_telefone,
    'pendente', case when v_papel = 'tecnico' then 'pendente'::public.status_verificacao_tecnico else null end
  )
  on conflict (id) do nothing;

  return new;
end;
$$;

revoke all on function public.criar_perfil_apos_registo() from public;

drop trigger if exists on_auth_user_created_agrolink on auth.users;
create trigger on_auth_user_created_agrolink
after insert on auth.users
for each row
execute function public.criar_perfil_apos_registo();

-- Substitui a política ampla por regras que ligam o primeiro segmento do
-- caminho ao relato e ao respetivo proprietário. O frontend usa
-- <relato_id>/<media_id>-<nome>.
drop policy if exists "storage_relatos_insert" on storage.objects;
drop policy if exists "storage_relatos_select" on storage.objects;
drop policy if exists "storage_relatos_insert_autenticado" on storage.objects;
drop policy if exists "storage_relatos_insert_anonimo" on storage.objects;
drop policy if exists "storage_relatos_select_autenticado" on storage.objects;

create policy "storage_relatos_insert_autenticado"
  on storage.objects for insert
  to authenticated
  with check (
    bucket_id = 'relatos'
    and exists (
      select 1
      from public.relatos r
      where r.id::text = (storage.foldername(name))[1]
        and r.autor_id = auth.uid()
    )
  );

create policy "storage_relatos_insert_anonimo"
  on storage.objects for insert
  to anon
  with check (
    bucket_id = 'relatos'
    and exists (
      select 1
      from public.relatos r
      where r.id::text = (storage.foldername(name))[1]
        and r.autor_id is null
    )
  );

create policy "storage_relatos_select_autenticado"
  on storage.objects for select
  to authenticated
  using (
    bucket_id = 'relatos'
    and exists (
      select 1
      from public.relatos r
      where r.id::text = (storage.foldername(name))[1]
        and (
          r.autor_id = auth.uid()
          or public.is_admin()
          or (public.sou_tecnico_aprovado() and r.provincia = public.minha_provincia())
        )
    )
  );

-- Chave idempotente usada pelo syncEngine para impedir mídias duplicadas.
create unique index if not exists uq_relato_midias_relato_caminho
  on public.relato_midias (relato_id, caminho_storage);

-- Endurece também as funções SECURITY DEFINER existentes contra alterações
-- do search_path. As assinaturas abaixo correspondem às migrations anteriores.
alter function public.is_admin() set search_path = public;
alter function public.meu_papel() set search_path = public;
alter function public.minha_provincia() set search_path = public;
alter function public.sou_tecnico_aprovado() set search_path = public;
alter function public.consultar_relato_por_codigo(text) set search_path = public;
alter function public.obter_estatisticas() set search_path = public;
alter function public.registar_auditoria(text, text, uuid, jsonb) set search_path = public;
alter function public.criar_notificacao(uuid, text, text, text, text, uuid) set search_path = public;
alter function public.ao_responder_relato() set search_path = public;
alter function public.ao_alterar_perfil_sensivel() set search_path = public;
alter function public.criar_preferencias_padrao() set search_path = public;
alter function public.obter_questionario_licao(uuid) set search_path = public;
alter function public.submeter_resposta_questionario(uuid, int) set search_path = public;
alter function public.marcar_licao_concluida(uuid) set search_path = public;
alter function public.ao_mudar_estado_relato() set search_path = public;
alter function public.ao_criar_alerta() set search_path = public;
alter function public.ao_criar_curso() set search_path = public;
alter function public.enviar_mensagem_admin(text, text, public.papel_utilizador) set search_path = public;
alter function public.registar_pergunta_ia(text, text[], text[], text) set search_path = public;
alter function public.marcar_pergunta_encaminhada(uuid) set search_path = public;
alter function public.obter_estatisticas_ia() set search_path = public;
alter function public.registar_log_seguranca(text, public.nivel_risco, jsonb) set search_path = public;
alter function public.verificar_limite_taxa(text, int, int) set search_path = public;
alter function public.limpar_limite_taxa_antigo() set search_path = public;
alter function public.proteger_estado_transportador() set search_path = public;
alter function public.registar_historico_denuncia() set search_path = public;
alter function public.ao_resolver_denuncia() set search_path = public;
alter function public.garantir_linha_reputacao(uuid) set search_path = public;
alter function public.ao_criar_avaliacao() set search_path = public;
alter function public.confirmar_denuncia(uuid, text) set search_path = public;
alter function public.preparar_perfil_no_insert() set search_path = public;
alter function public.proteger_campos_sensiveis() set search_path = public;
alter function public.criar_perfil_apos_registo() set search_path = public;

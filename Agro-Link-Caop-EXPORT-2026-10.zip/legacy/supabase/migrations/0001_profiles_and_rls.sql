
-- Fase 1 — Fundação
-- Tabela de perfis + políticas RLS básicas por papel.

create type papel_utilizador as enum ('agricultor', 'tecnico', 'admin');

create table if not exists public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  nome        text not null,
  papel       papel_utilizador not null default 'agricultor',
  provincia   text,
  municipio   text,
  telefone    text,
  criado_em   timestamptz not null default now()
);

alter table public.profiles enable row level security;

-- Qualquer utilizador autenticado pode ver perfis (nome/papel/província),
-- necessário para técnicos identificarem agricultores e vice-versa.
-- Dados mais sensíveis (telefone, coordenadas de exploração) migram para
-- tabelas próprias com políticas mais restritas nas fases seguintes.
create policy "profiles_select_autenticados"
  on public.profiles for select
  to authenticated
  using (true);

-- Um utilizador só pode criar o seu próprio perfil (id = auth.uid()).
create policy "profiles_insert_proprio"
  on public.profiles for insert
  to authenticated
  with check (id = auth.uid());

-- Um utilizador só pode atualizar o seu próprio perfil, e nunca o
-- próprio campo "papel" (isso exige uma função de administração à parte).
create policy "profiles_update_proprio"
  on public.profiles for update
  to authenticated
  using (id = auth.uid())
  with check (id = auth.uid() and papel = (select papel from public.profiles where id = auth.uid()));

-- Função auxiliar: verifica se o utilizador atual é admin.
-- Usada aqui e reutilizada pelas políticas dos módulos seguintes
-- (relatos, alertas, SIE, etc.) para evitar duplicar esta lógica.
create or replace function public.is_admin()
returns boolean
language sql
security definer
stable
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and papel = 'admin'
  );
$$;

-- Um admin pode atualizar qualquer perfil, incluindo o papel de outros.
create policy "profiles_update_admin"
  on public.profiles for update
  to authenticated
  using (public.is_admin());

comment on table public.profiles is
  'Perfil de cada utilizador autenticado: agricultor, técnico ou administrador.';


-- 0007 — Novo estado "respondido" para relatos.
-- Fica isolado num ficheiro próprio: o Postgres não permite usar um
-- valor de enum recém-criado na mesma transação que o cria.
alter type status_relato add value if not exists 'respondido';

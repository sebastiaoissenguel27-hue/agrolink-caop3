
-- 0015 — Módulo Academia AgroLink: cursos, lições, questionários e progresso.
-- "video" já existe no enum de tipo de lição — schema preparado para o
-- futuro, mas a interface desta versão mostra "em breve" para esse tipo
-- (pedido explícito: não implementar reprodução de vídeo agora).

create type tipo_licao as enum ('texto', 'imagem', 'pdf', 'video');

create table public.academia_cursos (
  id            uuid primary key default gen_random_uuid(),
  titulo        text not null,
  descricao     text,
  categoria     text,
  autor_id      uuid references public.profiles(id),
  publicado_em  timestamptz not null default now()
);

alter table public.academia_cursos enable row level security;

create policy "cursos_select_publico"
  on public.academia_cursos for select to authenticated, anon
  using (true);

create policy "cursos_gerir_admin"
  on public.academia_cursos for all to authenticated
  using (public.is_admin())
  with check (public.is_admin());

create table public.academia_licoes (
  id                uuid primary key default gen_random_uuid(),
  curso_id          uuid not null references public.academia_cursos(id) on delete cascade,
  titulo            text not null,
  tipo              tipo_licao not null default 'texto',
  conteudo_texto    text,
  caminho_storage   text,  -- imagem ou pdf da lição
  ordem             int not null default 0,
  criado_em         timestamptz not null default now()
);

alter table public.academia_licoes enable row level security;

create policy "licoes_select_publico"
  on public.academia_licoes for select to authenticated, anon
  using (true);

create policy "licoes_gerir_admin"
  on public.academia_licoes for all to authenticated
  using (public.is_admin())
  with check (public.is_admin());

comment on column public.academia_licoes.tipo is
  'texto/imagem/pdf têm renderização completa nesta versão; video fica preparado no enum, mas a interface mostra "em breve" — suporte adiado a pedido explícito.';

-- Questionários: a resposta certa NUNCA é exposta por SELECT direto —
-- só admins geststionam a tabela; agricultores/técnicos só acedem via
-- as duas funções abaixo, que escondem "resposta_correta".
create table public.academia_questionarios (
  id                  uuid primary key default gen_random_uuid(),
  licao_id            uuid not null references public.academia_licoes(id) on delete cascade,
  pergunta            text not null,
  opcoes              jsonb not null,
  resposta_correta    int not null,
  ordem               int not null default 0
);

alter table public.academia_questionarios enable row level security;

create policy "questionarios_gerir_admin"
  on public.academia_questionarios for all to authenticated
  using (public.is_admin())
  with check (public.is_admin());

-- Progresso do utilizador (lições concluídas / pontuação de questionários).
create table public.academia_progresso (
  utilizador_id           uuid not null references public.profiles(id) on delete cascade,
  licao_id                uuid not null references public.academia_licoes(id) on delete cascade,
  concluida               boolean not null default true,
  pontuacao_questionario  int,
  atualizado_em           timestamptz not null default now(),
  primary key (utilizador_id, licao_id)
);

alter table public.academia_progresso enable row level security;

create policy "progresso_proprio"
  on public.academia_progresso for all to authenticated
  using (utilizador_id = auth.uid())
  with check (utilizador_id = auth.uid());

-- RPC: devolve as perguntas de uma lição SEM a resposta certa.
create or replace function public.obter_questionario_licao(p_licao_id uuid)
returns jsonb
language sql security definer stable
as $$
  select coalesce(
    jsonb_agg(jsonb_build_object('id', id, 'pergunta', pergunta, 'opcoes', opcoes) order by ordem),
    '[]'::jsonb
  )
  from public.academia_questionarios where licao_id = p_licao_id;
$$;

grant execute on function public.obter_questionario_licao(uuid) to anon, authenticated;

-- RPC: corrige a resposta no servidor e regista o progresso — o
-- cliente nunca sabe a resposta certa antes de submeter a sua.
create or replace function public.submeter_resposta_questionario(p_questionario_id uuid, p_resposta int)
returns jsonb
language plpgsql security definer
as $$
declare
  v_correta int;
  v_licao uuid;
  v_correto boolean;
begin
  select resposta_correta, licao_id into v_correta, v_licao
    from public.academia_questionarios where id = p_questionario_id;

  if v_licao is null then
    raise exception 'Questionário não encontrado.';
  end if;

  v_correto := (v_correta = p_resposta);

  if auth.uid() is not null then
    insert into public.academia_progresso (utilizador_id, licao_id, concluida, pontuacao_questionario)
    values (auth.uid(), v_licao, true, case when v_correto then 100 else 0 end)
    on conflict (utilizador_id, licao_id) do update
      set pontuacao_questionario = greatest(
            coalesce(public.academia_progresso.pontuacao_questionario, 0),
            excluded.pontuacao_questionario
          ),
          concluida = true,
          atualizado_em = now();
  end if;

  return jsonb_build_object('correto', v_correto);
end;
$$;

grant execute on function public.submeter_resposta_questionario(uuid, int) to authenticated;

-- RPC: marca uma lição sem questionário como concluída.
create or replace function public.marcar_licao_concluida(p_licao_id uuid)
returns void
language plpgsql security definer
as $$
begin
  if auth.uid() is null then
    return;
  end if;

  insert into public.academia_progresso (utilizador_id, licao_id, concluida)
  values (auth.uid(), p_licao_id, true)
  on conflict (utilizador_id, licao_id) do update
    set concluida = true, atualizado_em = now();
end;
$$;

grant execute on function public.marcar_licao_concluida(uuid) to authenticated;

-- Storage: bucket privado para imagens/PDFs das lições.
insert into storage.buckets (id, name, public)
values ('academia', 'academia', false)
on conflict (id) do nothing;

create policy "storage_academia_select"
  on storage.objects for select to authenticated
  using (bucket_id = 'academia');

create policy "storage_academia_admin_insert"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'academia' and public.is_admin());

create policy "storage_academia_admin_delete"
  on storage.objects for delete to authenticated
  using (bucket_id = 'academia' and public.is_admin());

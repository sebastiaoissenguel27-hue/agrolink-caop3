
-- Fase 1 — Ajustes finais antes da Fase 2
-- 1) Restringe a visualização de perfis conforme o papel
-- 2) Acrescenta status geral da conta (ativo/pendente/bloqueado)
-- 3) Acrescenta verification_status, só para técnicos
-- 4) Acrescenta "comuna" à localização (província/município já existiam)
-- 5) Reforça ao nível da BD que ninguém se autorregista como admin

-- ── 2) Estado geral da conta ─────────────────────────────────────────
create type status_conta as enum ('ativo', 'pendente', 'bloqueado');

-- ── 3) Verificação profissional de técnicos ──────────────────────────
create type status_verificacao_tecnico as enum ('pendente', 'aprovado', 'rejeitado');

alter table public.profiles
  add column status status_conta not null default 'pendente',
  add column verification_status status_verificacao_tecnico,
  add column comuna text;

-- Garante, ao nível da BD, que só técnicos têm verification_status.
alter table public.profiles
  add constraint verification_status_so_tecnico
  check (
    (papel = 'tecnico' and verification_status is not null)
    or (papel <> 'tecnico' and verification_status is null)
  );

comment on column public.profiles.status is
  'Estado geral da conta: ativo, pendente (aguarda aprovação do admin) ou bloqueado.';
comment on column public.profiles.verification_status is
  'Só aplicável a papel=tecnico: validação das credenciais profissionais pelo admin. NULL para os restantes papéis.';
comment on column public.profiles.comuna is
  'Localização de terceiro nível, dentro do município.';

-- Preenche verification_status automaticamente ao criar o perfil,
-- e garante que fica sempre NULL para quem não é técnico —
-- mesmo que o cliente tente enviar outro valor.
create or replace function public.preparar_perfil_no_insert()
returns trigger
language plpgsql
as $$
begin
  if new.papel = 'tecnico' then
    new.verification_status := coalesce(new.verification_status, 'pendente');
  else
    new.verification_status := null;
  end if;
  return new;
end;
$$;

create trigger trg_preparar_perfil_no_insert
  before insert on public.profiles
  for each row
  execute function public.preparar_perfil_no_insert();

-- Impede qualquer utilizador (exceto admin) de mudar papel, status ou
-- verification_status através de um UPDATE ao seu próprio perfil —
-- reforço feito por trigger, não só pela política RLS, porque é mais
-- difícil de contornar do que uma cláusula "with check".
create or replace function public.proteger_campos_sensiveis()
returns trigger
language plpgsql
as $$
begin
  if not public.is_admin() then
    new.papel := old.papel;
    new.status := old.status;
    new.verification_status := old.verification_status;
  end if;
  return new;
end;
$$;

create trigger trg_proteger_campos_sensiveis
  before update on public.profiles
  for each row
  execute function public.proteger_campos_sensiveis();

-- Como a proteção fina agora vive no trigger acima, simplificamos a
-- política de update: só precisa de garantir que cada um mexe no seu.
drop policy if exists "profiles_update_proprio" on public.profiles;
create policy "profiles_update_proprio"
  on public.profiles for update
  to authenticated
  using (id = auth.uid())
  with check (id = auth.uid());

-- ── 5) Ninguém se autorregista como admin (agora também na BD) ──────
drop policy if exists "profiles_insert_proprio" on public.profiles;
create policy "profiles_insert_proprio"
  on public.profiles for insert
  to authenticated
  with check (id = auth.uid() and papel <> 'admin');

-- ── 1) Visualização de perfis restrita por papel ─────────────────────
-- Função auxiliar (security definer) para consultar o papel do
-- utilizador autenticado sem recursão direta dentro das políticas.
create or replace function public.meu_papel()
returns papel_utilizador
language sql
security definer
stable
as $$
  select papel from public.profiles where id = auth.uid();
$$;

drop policy if exists "profiles_select_autenticados" on public.profiles;

-- Todos veem sempre o próprio perfil.
create policy "profiles_select_proprio"
  on public.profiles for select
  to authenticated
  using (id = auth.uid());

-- Técnicos veem agricultores (precisam de identificar quem reporta).
create policy "profiles_select_tecnico_ve_agricultores"
  on public.profiles for select
  to authenticated
  using (papel = 'agricultor' and public.meu_papel() = 'tecnico');

-- Agricultores veem técnicos (para saber quem os pode apoiar).
create policy "profiles_select_agricultor_ve_tecnicos"
  on public.profiles for select
  to authenticated
  using (papel = 'tecnico' and public.meu_papel() = 'agricultor');

-- Administradores veem todos os perfis.
create policy "profiles_select_admin_ve_todos"
  on public.profiles for select
  to authenticated
  using (public.is_admin());

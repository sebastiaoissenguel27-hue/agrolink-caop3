
-- 0026 — Security & Trust Layer (parte 2): denúncias, reputação, avaliações.

create type categoria_denuncia as enum (
  'comportamento_inadequado', 'tentativa_fraude', 'incumprimento_acordo',
  'atraso_injustificado', 'problema_carga', 'cobranca_diferente',
  'informacao_falsa', 'alteracao_injustificada_acordo', 'outro'
);

create type estado_denuncia as enum ('pendente', 'em_analise', 'resolvida', 'rejeitada', 'escalada');
create type prioridade_denuncia as enum ('baixa', 'media', 'alta', 'urgente');

create table public.denuncias (
  id                    uuid primary key default gen_random_uuid(),
  autor_id              uuid not null references public.profiles(id),
  denunciado_id         uuid not null references public.profiles(id),
  transporte_id         uuid references public.logistica_pedidos(id) on delete set null,
  categoria             categoria_denuncia not null,
  descricao             text not null,
  evidencias            jsonb not null default '[]', -- caminhos no bucket "denuncias-evidencias"
  estado                estado_denuncia not null default 'pendente',
  prioridade            prioridade_denuncia not null default 'media',
  admin_responsavel_id  uuid references public.profiles(id),
  decisao               text,
  sugestao_ia           jsonb, -- classificação/prioridade sugerida pela IA — nunca decide sozinha
  data_resolucao        timestamptz,
  criado_em             timestamptz not null default now(),
  constraint denuncia_nao_e_sobre_si_proprio check (autor_id <> denunciado_id)
);

alter table public.denuncias enable row level security;

-- O autor só vê as suas próprias denúncias (nunca a lista completa).
create policy "denuncias_select_autor"
  on public.denuncias for select to authenticated
  using (autor_id = auth.uid());

create policy "denuncias_select_admin"
  on public.denuncias for select to authenticated
  using (public.is_admin());

create policy "denuncias_insert_autor"
  on public.denuncias for insert to authenticated
  with check (autor_id = auth.uid());

-- Só admin pode atualizar (mudar estado/prioridade/decisão) — o autor
-- nunca pode alterar ou apagar depois de submetida, tal como pedido.
-- Não existe política de DELETE para ninguém: denúncias são permanentes.
create policy "denuncias_update_admin"
  on public.denuncias for update to authenticated
  using (public.is_admin())
  with check (public.is_admin());

create index if not exists idx_denuncias_autor on public.denuncias (autor_id);
create index if not exists idx_denuncias_denunciado on public.denuncias (denunciado_id);
create index if not exists idx_denuncias_estado on public.denuncias (estado);
create index if not exists idx_denuncias_prioridade on public.denuncias (prioridade);

-- Histórico de alterações — regista toda a mudança de estado/prioridade/
-- decisão, para auditoria completa do processo.
create table public.denuncia_historico (
  id              uuid primary key default gen_random_uuid(),
  denuncia_id     uuid not null references public.denuncias(id) on delete cascade,
  campo_alterado  text not null,
  valor_anterior  text,
  valor_novo      text,
  alterado_por    uuid references public.profiles(id),
  alterado_em     timestamptz not null default now()
);

alter table public.denuncia_historico enable row level security;

create policy "denuncia_historico_select_admin"
  on public.denuncia_historico for select to authenticated
  using (public.is_admin());

create index if not exists idx_denuncia_historico_denuncia on public.denuncia_historico (denuncia_id);

create or replace function public.registar_historico_denuncia()
returns trigger
language plpgsql security definer
as $$
begin
  if new.estado is distinct from old.estado then
    insert into public.denuncia_historico (denuncia_id, campo_alterado, valor_anterior, valor_novo, alterado_por)
    values (new.id, 'estado', old.estado::text, new.estado::text, auth.uid());
  end if;
  if new.prioridade is distinct from old.prioridade then
    insert into public.denuncia_historico (denuncia_id, campo_alterado, valor_anterior, valor_novo, alterado_por)
    values (new.id, 'prioridade', old.prioridade::text, new.prioridade::text, auth.uid());
  end if;
  if new.decisao is distinct from old.decisao then
    insert into public.denuncia_historico (denuncia_id, campo_alterado, valor_anterior, valor_novo, alterado_por)
    values (new.id, 'decisao', old.decisao, new.decisao, auth.uid());
  end if;
  return new;
end;
$$;

create trigger trg_registar_historico_denuncia
  after update on public.denuncias
  for each row
  execute function public.registar_historico_denuncia();

-- Notifica o autor quando a denúncia é resolvida/rejeitada/escalada.
create or replace function public.ao_resolver_denuncia()
returns trigger
language plpgsql security definer
as $$
begin
  if new.estado is distinct from old.estado and new.estado in ('resolvida', 'rejeitada', 'escalada') then
    new.data_resolucao := now();
    perform public.criar_notificacao(
      new.autor_id, 'A sua denúncia foi atualizada',
      'Estado atual: ' || new.estado, 'denuncia_atualizada', 'denuncia', new.id
    );
  end if;
  return new;
end;
$$;

create trigger trg_ao_resolver_denuncia
  before update on public.denuncias
  for each row
  execute function public.ao_resolver_denuncia();

-- ── Reputação bilateral ───────────────────────────────────────────────
-- Nunca reduzida automaticamente por uma simples denúncia — só quando
-- o admin marca uma denúncia como "resolvida" com decisão que a
-- confirma (ver função abaixo). Combina sinais mais confiáveis.
create table public.reputacao (
  utilizador_id           uuid primary key references public.profiles(id) on delete cascade,
  transportes_concluidos  int not null default 0,
  media_avaliacao         numeric,
  total_avaliacoes        int not null default 0,
  denuncias_confirmadas   int not null default 0,
  atualizado_em           timestamptz not null default now()
);

alter table public.reputacao enable row level security;

-- Pública para autenticados — a reputação é precisamente para dar
-- confiança visível antes de negociar (ver Centro de Segurança).
create policy "reputacao_select_publico"
  on public.reputacao for select to authenticated
  using (true);

-- Sem política de INSERT/UPDATE para clientes — só as funções abaixo.

create or replace function public.garantir_linha_reputacao(p_utilizador_id uuid)
returns void
language plpgsql security definer
as $$
begin
  insert into public.reputacao (utilizador_id) values (p_utilizador_id)
  on conflict (utilizador_id) do nothing;
end;
$$;

create table public.avaliacoes (
  id            uuid primary key default gen_random_uuid(),
  avaliador_id  uuid not null references public.profiles(id),
  avaliado_id   uuid not null references public.profiles(id),
  transporte_id uuid references public.logistica_pedidos(id) on delete set null,
  nota          int not null check (nota between 1 and 5),
  comentario    text,
  criado_em     timestamptz not null default now(),
  constraint avaliacao_nao_e_sobre_si_proprio check (avaliador_id <> avaliado_id),
  -- Protege contra manipulação: uma avaliação por (avaliador, avaliado,
  -- transporte) — impede inflacionar/destruir reputação com repetição.
  unique (avaliador_id, avaliado_id, transporte_id)
);

alter table public.avaliacoes enable row level security;

create policy "avaliacoes_select_publico"
  on public.avaliacoes for select to authenticated
  using (true);

create policy "avaliacoes_insert_proprio"
  on public.avaliacoes for insert to authenticated
  with check (avaliador_id = auth.uid());

create index if not exists idx_avaliacoes_avaliado on public.avaliacoes (avaliado_id);

create or replace function public.ao_criar_avaliacao()
returns trigger
language plpgsql security definer
as $$
begin
  perform public.garantir_linha_reputacao(new.avaliado_id);
  update public.reputacao
    set total_avaliacoes = total_avaliacoes + 1,
        media_avaliacao = (coalesce(media_avaliacao, 0) * total_avaliacoes + new.nota) / (total_avaliacoes + 1),
        atualizado_em = now()
    where utilizador_id = new.avaliado_id;
  return new;
end;
$$;

create trigger trg_ao_criar_avaliacao
  after insert on public.avaliacoes
  for each row
  execute function public.ao_criar_avaliacao();

-- Só o admin marca uma denúncia como "confirmada" (ao resolvê-la com
-- decisão explícita) — é o único caminho que mexe em denuncias_confirmadas.
create or replace function public.confirmar_denuncia(p_denuncia_id uuid, p_decisao text)
returns void
language plpgsql security definer
as $$
declare v_denunciado uuid;
begin
  if not public.is_admin() then
    raise exception 'Só administradores podem confirmar denúncias.';
  end if;

  select denunciado_id into v_denunciado from public.denuncias where id = p_denuncia_id;
  if v_denunciado is null then
    raise exception 'Denúncia não encontrada.';
  end if;

  update public.denuncias
    set estado = 'resolvida', decisao = p_decisao, admin_responsavel_id = auth.uid()
    where id = p_denuncia_id;

  perform public.garantir_linha_reputacao(v_denunciado);
  update public.reputacao
    set denuncias_confirmadas = denuncias_confirmadas + 1, atualizado_em = now()
    where utilizador_id = v_denunciado;

  perform public.registar_auditoria('confirmar_denuncia', 'denuncia', p_denuncia_id,
    jsonb_build_object('decisao', p_decisao));
end;
$$;

grant execute on function public.confirmar_denuncia(uuid, text) to authenticated;

-- Storage: evidências de denúncias — privado, só autor e admin acedem.
insert into storage.buckets (id, name, public)
values ('denuncias-evidencias', 'denuncias-evidencias', false)
on conflict (id) do nothing;

create policy "storage_denuncias_insert_proprio"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'denuncias-evidencias' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "storage_denuncias_select_proprio_ou_admin"
  on storage.objects for select to authenticated
  using (
    bucket_id = 'denuncias-evidencias'
    and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin())
  );

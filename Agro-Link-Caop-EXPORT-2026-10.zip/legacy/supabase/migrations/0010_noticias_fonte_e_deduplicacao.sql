
-- 0010 — Suporte a ingestão automática de notícias a partir de fontes RSS.

alter table public.noticias add column if not exists url_original text unique;
alter table public.noticias add column if not exists fonte_id uuid references public.noticias_fontes(id);

comment on column public.noticias.url_original is
  'Link do artigo original, quando a notícia vem de uma fonte RSS automática. UNIQUE evita duplicados em sincronizações repetidas.';
comment on column public.noticias.fonte_id is
  'Fonte de origem (public.noticias_fontes), nula para notícias escritas manualmente pelo admin.';


-- 0008 — Sistema de auditoria e notificações internas.

-- ── Auditoria ─────────────────────────────────────────────────────────
-- Só se escreve via função SECURITY DEFINER (registar_auditoria) — não
-- existe política de INSERT para clientes, por isso ninguém escreve
-- diretamente na tabela, só o próprio servidor através das funções/
-- triggers abaixo.
create table public.auditoria (
  id            uuid primary key default gen_random_uuid(),
  ator_id       uuid references public.profiles(id),
  acao          text not null,
  entidade      text not null,
  entidade_id   uuid,
  detalhes      jsonb,
  criado_em     timestamptz not null default now()
);

alter table public.auditoria enable row level security;

create policy "auditoria_select_admin"
  on public.auditoria for select to authenticated
  using (public.is_admin());

create or replace function public.registar_auditoria(
  p_acao text, p_entidade text, p_entidade_id uuid, p_detalhes jsonb default null
)
returns void
language plpgsql security definer
as $$
begin
  insert into public.auditoria (ator_id, acao, entidade, entidade_id, detalhes)
  values (auth.uid(), p_acao, p_entidade, p_entidade_id, p_detalhes);
end;
$$;

-- ── Notificações internas ────────────────────────────────────────────
-- Mesma lógica: sem política de INSERT para clientes — só a função
-- criar_notificacao (SECURITY DEFINER) e os triggers escrevem aqui.
create table public.notificacoes (
  id                uuid primary key default gen_random_uuid(),
  destinatario_id   uuid not null references public.profiles(id) on delete cascade,
  titulo            text not null,
  corpo             text,
  tipo              text not null default 'info',
  lida              boolean not null default false,
  relacionado_tipo  text,
  relacionado_id    uuid,
  criado_em         timestamptz not null default now()
);

alter table public.notificacoes enable row level security;

create policy "notificacoes_select_proprio"
  on public.notificacoes for select to authenticated
  using (destinatario_id = auth.uid());

-- O único UPDATE permitido ao próprio dono é marcar como lida.
create policy "notificacoes_marcar_lida"
  on public.notificacoes for update to authenticated
  using (destinatario_id = auth.uid())
  with check (destinatario_id = auth.uid());

create or replace function public.criar_notificacao(
  p_destinatario uuid, p_titulo text, p_corpo text,
  p_tipo text default 'info', p_relacionado_tipo text default null, p_relacionado_id uuid default null
)
returns void
language plpgsql security definer
as $$
begin
  insert into public.notificacoes (destinatario_id, titulo, corpo, tipo, relacionado_tipo, relacionado_id)
  values (p_destinatario, p_titulo, p_corpo, p_tipo, p_relacionado_tipo, p_relacionado_id);
end;
$$;

-- ── Automação: responder a um relato notifica o autor + regista auditoria ──
create or replace function public.ao_responder_relato()
returns trigger
language plpgsql security definer
as $$
declare
  v_autor uuid;
begin
  select autor_id into v_autor from public.relatos where id = new.relato_id;

  if v_autor is not null then
    perform public.criar_notificacao(
      v_autor,
      'O seu relato tem uma nova resposta',
      new.comentario,
      'relato_respondido',
      'relato',
      new.relato_id
    );
  end if;

  update public.relatos
    set status = 'respondido'
    where id = new.relato_id and status not in ('resolvido');

  perform public.registar_auditoria(
    'responder_relato', 'relato', new.relato_id,
    jsonb_build_object('tecnico_id', new.tecnico_id)
  );

  return new;
end;
$$;

create trigger trg_ao_responder_relato
  after insert on public.relato_respostas
  for each row
  execute function public.ao_responder_relato();

-- ── Automação: mudança de status/verificação de perfil por admin ──────
create or replace function public.ao_alterar_perfil_sensivel()
returns trigger
language plpgsql security definer
as $$
begin
  if new.status is distinct from old.status then
    perform public.criar_notificacao(
      new.id, 'O estado da sua conta mudou',
      'Estado atual: ' || new.status, 'conta_status', 'profile', new.id
    );
    perform public.registar_auditoria(
      'alterar_status_conta', 'profile', new.id,
      jsonb_build_object('de', old.status, 'para', new.status)
    );
  end if;

  if new.verification_status is distinct from old.verification_status then
    perform public.criar_notificacao(
      new.id, 'O estado da sua verificação profissional mudou',
      'Estado atual: ' || coalesce(new.verification_status::text, '—'),
      'verificacao_tecnico', 'profile', new.id
    );
    perform public.registar_auditoria(
      'alterar_verificacao_tecnico', 'profile', new.id,
      jsonb_build_object('de', old.verification_status, 'para', new.verification_status)
    );
  end if;

  return new;
end;
$$;

create trigger trg_ao_alterar_perfil_sensivel
  after update on public.profiles
  for each row
  execute function public.ao_alterar_perfil_sensivel();

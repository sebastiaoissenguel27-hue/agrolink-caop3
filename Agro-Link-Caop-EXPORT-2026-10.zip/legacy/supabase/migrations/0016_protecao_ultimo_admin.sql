
-- 0016 — Salvaguarda: nunca deixar a plataforma sem nenhum admin ativo.

create or replace function public.impedir_bloqueio_ultimo_admin()
returns trigger
language plpgsql
as $$
begin
  if old.papel = 'admin' and new.status = 'bloqueado' and old.status <> 'bloqueado' then
    if (select count(*) from public.profiles where papel = 'admin' and status = 'ativo' and id <> old.id) = 0 then
      raise exception 'Não é permitido bloquear o último administrador ativo da plataforma.';
    end if;
  end if;
  return new;
end;
$$;

create trigger trg_impedir_bloqueio_ultimo_admin
  before update on public.profiles
  for each row
  execute function public.impedir_bloqueio_ultimo_admin();

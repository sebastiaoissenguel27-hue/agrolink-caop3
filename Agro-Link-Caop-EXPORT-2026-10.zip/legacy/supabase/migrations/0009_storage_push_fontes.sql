
-- 0009 — Storage adicional (documentos), dispositivos push, fontes de notícias.

-- Bucket privado para documentos de verificação profissional dos técnicos
-- (ex: diploma, carteira profissional) — só o próprio e admin acedem.
insert into storage.buckets (id, name, public)
values ('documentos', 'documentos', false)
on conflict (id) do nothing;

create policy "storage_documentos_insert_proprio"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'documentos' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "storage_documentos_select_proprio_ou_admin"
  on storage.objects for select to authenticated
  using (
    bucket_id = 'documentos'
    and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin())
  );

-- ── Dispositivos para notificações push ──────────────────────────────
-- Schema pronto; o envio real depende de um serviço externo (FCM/APNs)
-- chamado a partir de uma Edge Function — ver docs/plano-pacote-a-b.md.
create table public.dispositivos_push (
  id            uuid primary key default gen_random_uuid(),
  utilizador_id uuid not null references public.profiles(id) on delete cascade,
  token         text not null unique,
  plataforma    text not null default 'web',
  criado_em     timestamptz not null default now()
);

alter table public.dispositivos_push enable row level security;

create policy "dispositivos_push_gerir_proprio"
  on public.dispositivos_push for all to authenticated
  using (utilizador_id = auth.uid())
  with check (utilizador_id = auth.uid());

-- ── Documentos de verificação profissional dos técnicos ──────────────
create table public.tecnico_documentos (
  id            uuid primary key default gen_random_uuid(),
  tecnico_id    uuid not null references public.profiles(id) on delete cascade,
  caminho_storage text not null,
  descricao     text,
  criado_em     timestamptz not null default now()
);

alter table public.tecnico_documentos enable row level security;

create policy "tecnico_documentos_select_proprio_ou_admin"
  on public.tecnico_documentos for select to authenticated
  using (tecnico_id = auth.uid() or public.is_admin());

create policy "tecnico_documentos_insert_proprio"
  on public.tecnico_documentos for insert to authenticated
  with check (tecnico_id = auth.uid());

-- ── Fontes de notícias agrícolas (para integração automática) ────────
create table public.noticias_fontes (
  id            uuid primary key default gen_random_uuid(),
  nome          text not null,
  url_rss       text not null,
  categoria     text,
  ativo         boolean not null default true,
  criado_em     timestamptz not null default now()
);

alter table public.noticias_fontes enable row level security;

create policy "noticias_fontes_select_publico"
  on public.noticias_fontes for select to authenticated, anon
  using (true);

create policy "noticias_fontes_gerir_admin"
  on public.noticias_fontes for all to authenticated
  using (public.is_admin())
  with check (public.is_admin());

-- Índice de pesquisa full-text sobre título e resumo das notícias.
create index if not exists idx_noticias_pesquisa
  on public.noticias using gin (to_tsvector('portuguese', titulo || ' ' || coalesce(resumo, '')));


-- 0023 — Índices em todas as chaves estrangeiras.
-- O Postgres NUNCA cria índice automático numa coluna "references" —
-- só na própria chave primária do lado "um". Sem isto, qualquer junção
-- ou filtro pelo lado "muitos" (ex: "todos os relatos deste técnico",
-- "todas as respostas deste relato") degrada com o crescimento da tabela.
-- "if not exists" torna esta migração segura de reexecutar.

create index if not exists idx_relatos_autor_id on public.relatos (autor_id);
create index if not exists idx_relatos_tecnico_atribuido_id on public.relatos (tecnico_atribuido_id);
create index if not exists idx_relato_midias_relato_id on public.relato_midias (relato_id);
create index if not exists idx_relato_respostas_relato_id on public.relato_respostas (relato_id);
create index if not exists idx_relato_respostas_tecnico_id on public.relato_respostas (tecnico_id);
create index if not exists idx_noticias_autor_id on public.noticias (autor_id);
create index if not exists idx_alertas_criado_por on public.alertas (criado_por);
create index if not exists idx_ia_conversas_utilizador_id on public.ia_conversas (utilizador_id);
create index if not exists idx_ia_mensagens_conversa_id on public.ia_mensagens (conversa_id);
create index if not exists idx_mercado_produtos_vendedor_id on public.mercado_produtos (vendedor_id);
create index if not exists idx_sensores_instalado_por on public.sensores (instalado_por);
create index if not exists idx_leituras_sensor_sensor_id on public.leituras_sensor (sensor_id);
create index if not exists idx_auditoria_ator_id on public.auditoria (ator_id);
create index if not exists idx_notificacoes_destinatario_id on public.notificacoes (destinatario_id);
create index if not exists idx_dispositivos_push_utilizador_id on public.dispositivos_push (utilizador_id);
create index if not exists idx_tecnico_documentos_tecnico_id on public.tecnico_documentos (tecnico_id);
create index if not exists idx_ferramenta_calculos_utilizador_id on public.ferramenta_calculos (utilizador_id);
create index if not exists idx_biblioteca_documentos_autor_id on public.biblioteca_documentos (autor_id);
create index if not exists idx_academia_cursos_autor_id on public.academia_cursos (autor_id);
create index if not exists idx_academia_licoes_curso_id on public.academia_licoes (curso_id);
create index if not exists idx_academia_questionarios_licao_id on public.academia_questionarios (licao_id);
create index if not exists idx_academia_progresso_licao_id on public.academia_progresso (licao_id);
create index if not exists idx_logistica_pedidos_solicitante_id on public.logistica_pedidos (solicitante_id);
create index if not exists idx_logistica_pedidos_transportadora_id on public.logistica_pedidos (transportadora_id);
create index if not exists idx_ia_perguntas_analytics_utilizador_id on public.ia_perguntas_analytics (utilizador_id);
create index if not exists idx_noticias_sync_logs_fonte_id on public.noticias_sync_logs (fonte_id);

-- Índices adicionais para os padrões de consulta mais comuns do código
-- (filtros por estado/data, muito usados nos painéis técnico e admin).
create index if not exists idx_relatos_status on public.relatos (status);
create index if not exists idx_relatos_provincia on public.relatos (provincia);
create index if not exists idx_profiles_papel_status on public.profiles (papel, status);

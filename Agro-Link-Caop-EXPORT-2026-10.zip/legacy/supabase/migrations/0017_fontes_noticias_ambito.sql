
-- 0017 — Distingue fontes de notícias nacionais e internacionais.

create type ambito_fonte_noticia as enum ('nacional', 'internacional');

alter table public.noticias_fontes
  add column if not exists ambito ambito_fonte_noticia not null default 'nacional';

comment on column public.noticias_fontes.ambito is
  'Permite ao admin distinguir e filtrar fontes nacionais de internacionais na gestão de notícias.';


-- 0025 — Security & Trust Layer (parte 1): logs de segurança, rate
-- limiting aplicacional, e extensão de perfil para transportadores.
--
-- Nota honesta sobre limites deste ambiente: rate limiting real ao
-- nível de rede/gateway (proteção DDoS, WAF) não é algo que se
-- implemente em SQL — depende de infraestrutura fora do controlo desta
-- base de código (Cloudflare, Supabase's próprio rate limit do Auth,
-- etc.). O que aqui se implementa é rate limiting AO NÍVEL DA APLICAÇÃO
-- (contagem de eventos por chave/janela temporal, reutilizável por
-- qualquer Edge Function ou trigger) — uma camada real e útil, mas que
-- não substitui proteção de borda.

-- ── Logs de segurança ─────────────────────────────────────────────────
create type nivel_risco as enum ('baixo', 'medio', 'alto');

create table public.logs_seguranca (
  id            uuid primary key default gen_random_uuid(),
  tipo          text not null, -- 'login_falhado' | 'registo' | 'rate_limit_excedido' | 'denuncia_criada' | ...
  utilizador_id uuid references public.profiles(id) on delete set null,
  nivel_risco   nivel_risco not null default 'baixo',
  detalhes      jsonb,
  criado_em     timestamptz not null default now()
);

alter table public.logs_seguranca enable row level security;

create policy "logs_seguranca_select_admin"
  on public.logs_seguranca for select to authenticated
  using (public.is_admin());

-- Sem política de INSERT para clientes — só a função abaixo (SECURITY
-- DEFINER) e as Edge Functions com service role escrevem aqui.
create or replace function public.registar_log_seguranca(
  p_tipo text, p_nivel nivel_risco default 'baixo', p_detalhes jsonb default null
)
returns void
language plpgsql security definer
as $$
begin
  insert into public.logs_seguranca (tipo, utilizador_id, nivel_risco, detalhes)
  values (p_tipo, auth.uid(), p_nivel, p_detalhes);
end;
$$;

grant execute on function public.registar_log_seguranca(text, nivel_risco, jsonb) to authenticated, anon;

create index if not exists idx_logs_seguranca_criado_em on public.logs_seguranca (criado_em desc);
create index if not exists idx_logs_seguranca_nivel_risco on public.logs_seguranca (nivel_risco);

-- ── Rate limiting aplicacional (reutilizável) ────────────────────────
create table public.limite_taxa_eventos (
  id         uuid primary key default gen_random_uuid(),
  chave      text not null, -- ex: 'ia_pergunta:<uuid>', 'registo:<hash-do-email>'
  criado_em  timestamptz not null default now()
);

create index if not exists idx_limite_taxa_chave_tempo on public.limite_taxa_eventos (chave, criado_em desc);

-- Sem RLS/policies de leitura para clientes — é só um contador interno,
-- gerido inteiramente pela função abaixo.
alter table public.limite_taxa_eventos enable row level security;
-- (nenhuma política = ninguém acede diretamente, nem por engano)

-- Verifica e regista uma tentativa; devolve false se o limite foi
-- excedido na janela indicada (não insere o evento nesse caso).
create or replace function public.verificar_limite_taxa(p_chave text, p_max int, p_janela_segundos int)
returns boolean
language plpgsql security definer
as $$
declare v_contagem int;
begin
  select count(*) into v_contagem
    from public.limite_taxa_eventos
    where chave = p_chave and criado_em > now() - (p_janela_segundos || ' seconds')::interval;

  if v_contagem >= p_max then
    perform public.registar_log_seguranca(
      'rate_limit_excedido', 'medio', jsonb_build_object('chave', p_chave, 'limite', p_max)
    );
    return false;
  end if;

  insert into public.limite_taxa_eventos (chave) values (p_chave);
  return true;
end;
$$;

grant execute on function public.verificar_limite_taxa(text, int, int) to authenticated, anon;

-- Limpeza: eventos com mais de 24h já não interessam para nenhuma janela
-- de rate limit razoável — evita crescimento indefinido da tabela.
create or replace function public.limpar_limite_taxa_antigo()
returns void
language sql security definer
as $$
  delete from public.limite_taxa_eventos where criado_em < now() - interval '24 hours';
$$;

grant execute on function public.limpar_limite_taxa_antigo() to authenticated;

-- ── Preparação para transportadores (AgroLink Logística) ─────────────
create type estado_verificacao_transportador as enum ('pendente', 'aprovado', 'rejeitado', 'suspenso');

create table public.transportadores (
  utilizador_id       uuid primary key references public.profiles(id) on delete cascade,
  foto_url            text,
  foto_camiao_url     text,
  matricula           text,
  tipo_veiculo        text,
  capacidade_kg       numeric,
  documentos          jsonb not null default '[]', -- array de caminhos no bucket "documentos"
  estado_verificacao  estado_verificacao_transportador not null default 'pendente',
  motivo_estado       text, -- preenchido pelo admin ao rejeitar/suspender
  criado_em           timestamptz not null default now(),
  atualizado_em       timestamptz not null default now()
);

alter table public.transportadores enable row level security;

create policy "transportadores_select_proprio_ou_admin"
  on public.transportadores for select to authenticated
  using (utilizador_id = auth.uid() or public.is_admin());

-- Qualquer utilizador autenticado vê transportadores APROVADOS (para o
-- Centro de Segurança e Confiança / futura listagem no Mercado) — sem
-- expor documentos, que só aparecem no SELECT * para o próprio/admin
-- por não existir política extra de coluna (RLS é por linha, não por
-- coluna); o frontend público deve pedir só os campos não sensíveis.
create policy "transportadores_select_aprovados_publico"
  on public.transportadores for select to authenticated
  using (estado_verificacao = 'aprovado');

create policy "transportadores_upsert_proprio"
  on public.transportadores for insert to authenticated
  with check (utilizador_id = auth.uid());

create policy "transportadores_update_proprio_dados"
  on public.transportadores for update to authenticated
  using (utilizador_id = auth.uid());

create policy "transportadores_gerir_admin"
  on public.transportadores for all to authenticated
  using (public.is_admin())
  with check (public.is_admin());

-- Impede o próprio transportador de se auto-aprovar/suspender —
-- só o admin pode mudar estado_verificacao (mesmo padrão já usado
-- para profiles.status/verification_status).
create or replace function public.proteger_estado_transportador()
returns trigger
language plpgsql security definer
as $$
begin
  if not public.is_admin() then
    new.estado_verificacao := old.estado_verificacao;
    new.motivo_estado := old.motivo_estado;
  end if;
  new.atualizado_em := now();
  return new;
end;
$$;

create trigger trg_proteger_estado_transportador
  before update on public.transportadores
  for each row
  execute function public.proteger_estado_transportador();

create index if not exists idx_transportadores_estado on public.transportadores (estado_verificacao);

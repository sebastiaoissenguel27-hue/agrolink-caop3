
-- 0027 — Recuperação segura da estrutura de perfis e admin chefe.
-- Objetivo: restaurar a tabela public.profiles e as funções/políticas
-- essenciais sem criar uma arquitetura paralela.

-- PostgreSQL não suporta `CREATE TYPE IF NOT EXISTS` para tipos ENUM.
-- Os tipos já são criados pelas migrations 0001/0002; estes blocos tornam
-- a migration de recuperação segura para uma base parcialmente restaurada.
do $$
begin
  if to_regtype('public.papel_utilizador') is null then
    create type public.papel_utilizador as enum ('agricultor', 'tecnico', 'admin');
  end if;
end $$;

do $$
begin
  if to_regtype('public.status_conta') is null then
    create type public.status_conta as enum ('ativo', 'pendente', 'bloqueado');
  end if;
end $$;

do $$
begin
  if to_regtype('public.status_verificacao_tecnico') is null then
    create type public.status_verificacao_tecnico as enum ('pendente', 'aprovado', 'rejeitado');
  end if;
end $$;

-- A migration 0024 adiciona este valor no fluxo normal. Se a base foi
-- parcialmente restaurada sem 0024, recupera-o aqui sem substituir o enum.
do $$
begin
  if to_regtype('public.papel_utilizador') is not null
     and not exists (
       select 1
       from pg_enum e
       join pg_type t on t.oid = e.enumtypid
       join pg_namespace n on n.oid = t.typnamespace
       where n.nspname = 'public'
         and t.typname = 'papel_utilizador'
         and e.enumlabel = 'transportador'
     ) then
    alter type public.papel_utilizador add value 'transportador';
  end if;
end $$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nome text not null,
  papel public.papel_utilizador not null default 'agricultor',
  provincia text,
  municipio text,
  comuna text,
  telefone text,
  status public.status_conta not null default 'pendente',
  verification_status public.status_verificacao_tecnico,
  criado_em timestamptz not null default now()
);

alter table public.profiles
  add column if not exists provincia text,
  add column if not exists municipio text,
  add column if not exists comuna text,
  add column if not exists telefone text,
  add column if not exists status public.status_conta,
  add column if not exists verification_status public.status_verificacao_tecnico,
  add column if not exists criado_em timestamptz default now();

alter table public.profiles
  alter column nome set not null,
  alter column papel set default 'agricultor',
  alter column status set default 'pendente';

alter table public.profiles enable row level security;

-- Reforça a regra corporativa: ninguém se regista como admin por conta própria.
do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'verification_status_so_tecnico'
  ) then
    alter table public.profiles
      add constraint verification_status_so_tecnico
      check (
        (papel = 'tecnico' and verification_status is not null)
        or (papel <> 'tecnico' and verification_status is null)
      );
  end if;
end $$;

create or replace function public.is_admin()
returns boolean
language sql
security definer
stable
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and papel = 'admin'
  );
$$;

create or replace function public.meu_papel()
returns public.papel_utilizador
language sql
security definer
stable
as $$
  select papel from public.profiles where id = auth.uid();
$$;

create or replace function public.preparar_perfil_no_insert()
returns trigger
language plpgsql
as $$
begin
  if new.papel = 'tecnico' then
    new.verification_status := coalesce(new.verification_status, 'pendente');
  else
    new.verification_status := null;
  end if;
  if new.status is null then
    new.status := 'pendente';
  end if;
  return new;
end;
$$;

drop trigger if exists trg_preparar_perfil_no_insert on public.profiles;
create trigger trg_preparar_perfil_no_insert
  before insert on public.profiles
  for each row
  execute function public.preparar_perfil_no_insert();

create or replace function public.proteger_campos_sensiveis()
returns trigger
language plpgsql
as $$
begin
  if not public.is_admin() then
    new.papel := old.papel;
    new.status := old.status;
    new.verification_status := old.verification_status;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_proteger_campos_sensiveis on public.profiles;
create trigger trg_proteger_campos_sensiveis
  before update on public.profiles
  for each row
  execute function public.proteger_campos_sensiveis();

drop policy if exists "profiles_select_proprio" on public.profiles;
create policy "profiles_select_proprio"
  on public.profiles for select
  to authenticated
  using (id = auth.uid());

drop policy if exists "profiles_select_tecnico_ve_agricultores" on public.profiles;
create policy "profiles_select_tecnico_ve_agricultores"
  on public.profiles for select
  to authenticated
  using (papel = 'agricultor' and public.meu_papel() = 'tecnico');

drop policy if exists "profiles_select_agricultor_ve_tecnicos" on public.profiles;
create policy "profiles_select_agricultor_ve_tecnicos"
  on public.profiles for select
  to authenticated
  using (papel = 'tecnico' and public.meu_papel() = 'agricultor');

drop policy if exists "profiles_select_admin_ve_todos" on public.profiles;
create policy "profiles_select_admin_ve_todos"
  on public.profiles for select
  to authenticated
  using (public.is_admin());

drop policy if exists "profiles_insert_proprio" on public.profiles;
create policy "profiles_insert_proprio"
  on public.profiles for insert
  to authenticated
  with check (id = auth.uid() and papel <> 'admin');

drop policy if exists "profiles_update_proprio" on public.profiles;
create policy "profiles_update_proprio"
  on public.profiles for update
  to authenticated
  using (id = auth.uid())
  with check (id = auth.uid());

drop policy if exists "profiles_update_admin" on public.profiles;
create policy "profiles_update_admin"
  on public.profiles for update
  to authenticated
  using (public.is_admin());


-- 0011 — Módulo Configurações: preferências de notificação por utilizador.

create table public.preferencias_utilizador (
  utilizador_id           uuid primary key references public.profiles(id) on delete cascade,
  notif_respostas_relato  boolean not null default true,
  notif_noticias          boolean not null default true,
  notif_alertas           boolean not null default true,
  atualizado_em           timestamptz not null default now()
);

alter table public.preferencias_utilizador enable row level security;

create policy "preferencias_gerir_proprio"
  on public.preferencias_utilizador for all to authenticated
  using (utilizador_id = auth.uid())
  with check (utilizador_id = auth.uid());

-- Cria a linha de preferências (todas ativas por omissão) assim que um
-- perfil é criado — assim a página de Configurações nunca encontra um
-- utilizador sem registo de preferências.
create or replace function public.criar_preferencias_padrao()
returns trigger
language plpgsql security definer
as $$
begin
  insert into public.preferencias_utilizador (utilizador_id) values (new.id)
  on conflict (utilizador_id) do nothing;
  return new;
end;
$$;

create trigger trg_criar_preferencias_padrao
  after insert on public.profiles
  for each row
  execute function public.criar_preferencias_padrao();

-- Retroativo: garante preferências também para perfis já existentes
-- antes desta migração.
insert into public.preferencias_utilizador (utilizador_id)
select id from public.profiles
on conflict (utilizador_id) do nothing;

-- Passa a respeitar a preferência "notif_respostas_relato" antes de
-- notificar o autor de um relato — não altera o comportamento de
-- auditoria (isso continua a registar-se sempre).
create or replace function public.ao_responder_relato()
returns trigger
language plpgsql security definer
as $$
declare
  v_autor uuid;
  v_notificar boolean;
begin
  select autor_id into v_autor from public.relatos where id = new.relato_id;

  if v_autor is not null then
    select notif_respostas_relato into v_notificar
      from public.preferencias_utilizador where utilizador_id = v_autor;

    if coalesce(v_notificar, true) then
      perform public.criar_notificacao(
        v_autor,
        'O seu relato tem uma nova resposta',
        new.comentario,
        'relato_respondido',
        'relato',
        new.relato_id
      );
    end if;
  end if;

  update public.relatos
    set status = 'respondido'
    where id = new.relato_id and status not in ('resolvido');

  perform public.registar_auditoria(
    'responder_relato', 'relato', new.relato_id,
    jsonb_build_object('tecnico_id', new.tecnico_id)
  );

  return new;
end;
$$;


-- 0021 — IA AgroLink: analytics de utilização (só admin) e resumos mensais gerados por IA.
-- Nunca guarda o texto da pergunta/resposta aqui — só metadados agregáveis,
-- para os relatórios administrativos nunca exporem conversas individuais.

create table public.ia_perguntas_analytics (
  id           uuid primary key default gen_random_uuid(),
  utilizador_id uuid references public.profiles(id) on delete set null,
  provincia    text,
  tema         text,        -- 'praga' | 'doenca' | 'clima' | 'solo' | 'mercado' | 'plataforma' | 'outro'
  culturas     text[] not null default '{}',
  pragas       text[] not null default '{}',
  confianca    text,        -- 'alta' | 'media' | 'baixa'
  encaminhado  boolean not null default false,
  criado_em    timestamptz not null default now()
);

alter table public.ia_perguntas_analytics enable row level security;

create policy "ia_analytics_select_admin"
  on public.ia_perguntas_analytics for select to authenticated
  using (public.is_admin());

-- Sem política de INSERT/UPDATE para clientes — só as duas funções abaixo.

create or replace function public.registar_pergunta_ia(
  p_tema text, p_culturas text[], p_pragas text[], p_confianca text
)
returns uuid
language plpgsql security definer
as $$
declare
  v_id uuid;
  v_provincia text;
begin
  select provincia into v_provincia from public.profiles where id = auth.uid();

  insert into public.ia_perguntas_analytics (utilizador_id, provincia, tema, culturas, pragas, confianca)
  values (auth.uid(), v_provincia, p_tema, coalesce(p_culturas, '{}'), coalesce(p_pragas, '{}'), p_confianca)
  returning id into v_id;

  return v_id;
end;
$$;

grant execute on function public.registar_pergunta_ia(text, text[], text[], text) to authenticated;

create or replace function public.marcar_pergunta_encaminhada(p_id uuid)
returns void
language plpgsql security definer
as $$
begin
  update public.ia_perguntas_analytics
    set encaminhado = true
    where id = p_id and utilizador_id = auth.uid();
end;
$$;

grant execute on function public.marcar_pergunta_encaminhada(uuid) to authenticated;

-- Estatísticas agregadas para o dashboard admin.
create or replace function public.obter_estatisticas_ia()
returns jsonb
language plpgsql security definer stable
as $$
declare resultado jsonb;
begin
  if not public.is_admin() then
    raise exception 'Sem permissão para consultar estatísticas da IA.';
  end if;

  select jsonb_build_object(
    'total_perguntas', (select count(*) from public.ia_perguntas_analytics),
    'por_dia', (
      select coalesce(jsonb_agg(jsonb_build_object('dia', dia, 'total', total) order by dia), '[]'::jsonb)
      from (
        select date_trunc('day', criado_em)::date as dia, count(*) as total
        from public.ia_perguntas_analytics
        where criado_em > now() - interval '30 days'
        group by 1
      ) s
    ),
    'por_mes', (
      select coalesce(jsonb_agg(jsonb_build_object('mes', mes, 'total', total) order by mes), '[]'::jsonb)
      from (
        select to_char(date_trunc('month', criado_em), 'YYYY-MM') as mes, count(*) as total
        from public.ia_perguntas_analytics
        where criado_em > now() - interval '12 months'
        group by 1
      ) s
    ),
    'por_provincia', (
      select coalesce(jsonb_agg(jsonb_build_object('provincia', provincia, 'total', total) order by total desc), '[]'::jsonb)
      from (
        select coalesce(provincia, '—') as provincia, count(*) as total
        from public.ia_perguntas_analytics group by 1
      ) s
    ),
    'temas_frequentes', (
      select coalesce(jsonb_agg(jsonb_build_object('tema', tema, 'total', total) order by total desc), '[]'::jsonb)
      from (
        select tema, count(*) as total from public.ia_perguntas_analytics
        where tema is not null group by 1 order by 2 desc limit 10
      ) s
    ),
    'culturas_frequentes', (
      select coalesce(jsonb_agg(jsonb_build_object('cultura', cultura, 'total', total) order by total desc), '[]'::jsonb)
      from (
        select unnest(culturas) as cultura, count(*) as total
        from public.ia_perguntas_analytics group by 1 order by 2 desc limit 10
      ) s
    ),
    'pragas_frequentes', (
      select coalesce(jsonb_agg(jsonb_build_object('praga', praga, 'total', total) order by total desc), '[]'::jsonb)
      from (
        select unnest(pragas) as praga, count(*) as total
        from public.ia_perguntas_analytics group by 1 order by 2 desc limit 10
      ) s
    ),
    'confianca_media_pct', (
      select round(avg(case confianca when 'alta' then 100 when 'media' then 60 when 'baixa' then 20 end))
      from public.ia_perguntas_analytics
    ),
    'total_encaminhados', (select count(*) from public.ia_perguntas_analytics where encaminhado),
    'total_resolvidas_so_ia', (select count(*) from public.ia_perguntas_analytics where not encaminhado)
  ) into resultado;

  return resultado;
end;
$$;

grant execute on function public.obter_estatisticas_ia() to authenticated;

-- Resumos mensais gerados por IA (texto narrativo, sem dados pessoais individuais).
create table public.ia_resumos_mensais (
  id         uuid primary key default gen_random_uuid(),
  mes        int not null,
  ano        int not null,
  conteudo   text not null,
  gerado_em  timestamptz not null default now(),
  unique (mes, ano)
);

alter table public.ia_resumos_mensais enable row level security;

create policy "resumos_ia_select_admin"
  on public.ia_resumos_mensais for select to authenticated
  using (public.is_admin());

-- Sem política de INSERT: só a Edge Function "ia-resumo-mensal", com a
-- service role, escreve aqui (a service role ignora RLS por definição).

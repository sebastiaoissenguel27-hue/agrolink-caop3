
-- 0013 — Módulo Centro de Recursos: links/contactos externos + FAQ.
-- Complementa (não substitui) a Biblioteca AgroLink: aqui ficam
-- referências e contactos externos, não documentos próprios da plataforma.

create table public.recursos_externos (
  id          uuid primary key default gen_random_uuid(),
  titulo      text not null,
  descricao   text,
  categoria   text,
  url         text,
  contacto    text,
  criado_em   timestamptz not null default now(),
  constraint recurso_tem_url_ou_contacto check (url is not null or contacto is not null)
);

alter table public.recursos_externos enable row level security;

create policy "recursos_select_publico"
  on public.recursos_externos for select to authenticated, anon
  using (true);

create policy "recursos_gerir_admin"
  on public.recursos_externos for all to authenticated
  using (public.is_admin())
  with check (public.is_admin());

create table public.perguntas_frequentes (
  id          uuid primary key default gen_random_uuid(),
  pergunta    text not null,
  resposta    text not null,
  categoria   text,
  ordem       int not null default 0,
  criado_em   timestamptz not null default now()
);

alter table public.perguntas_frequentes enable row level security;

create policy "faq_select_publico"
  on public.perguntas_frequentes for select to authenticated, anon
  using (true);

create policy "faq_gerir_admin"
  on public.perguntas_frequentes for all to authenticated
  using (public.is_admin())
  with check (public.is_admin());

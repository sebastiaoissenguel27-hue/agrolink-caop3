
-- 0024 — Novo papel "transportador", preparação para o AgroLink Logística.
-- Isolado em ficheiro próprio: o Postgres não permite usar um valor de
-- enum recém-criado na mesma transação que o cria.
alter type papel_utilizador add value if not exists 'transportador';

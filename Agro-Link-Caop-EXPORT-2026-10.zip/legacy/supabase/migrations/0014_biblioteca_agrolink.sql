
-- 0014 — Módulo Biblioteca AgroLink: documentos, guias, manuais e PDFs.

create type tipo_documento_biblioteca as enum ('pdf', 'guia', 'manual', 'outro');

create table public.biblioteca_documentos (
  id                uuid primary key default gen_random_uuid(),
  titulo            text not null,
  descricao         text,
  categoria         text,
  tipo              tipo_documento_biblioteca not null default 'pdf',
  caminho_storage   text,   -- ficheiro carregado no bucket "biblioteca"
  url_externo       text,   -- alternativa: link externo em vez de upload
  autor_id          uuid references public.profiles(id),
  publicado_em      timestamptz not null default now(),
  constraint biblioteca_tem_ficheiro_ou_link check (caminho_storage is not null or url_externo is not null)
);

alter table public.biblioteca_documentos enable row level security;

create policy "biblioteca_select_publico"
  on public.biblioteca_documentos for select to authenticated, anon
  using (true);

create policy "biblioteca_gerir_admin"
  on public.biblioteca_documentos for all to authenticated
  using (public.is_admin())
  with check (public.is_admin());

create index if not exists idx_biblioteca_pesquisa
  on public.biblioteca_documentos using gin (to_tsvector('portuguese', titulo || ' ' || coalesce(descricao, '')));

-- Storage: bucket privado para os ficheiros da biblioteca.
insert into storage.buckets (id, name, public)
values ('biblioteca', 'biblioteca', false)
on conflict (id) do nothing;

create policy "storage_biblioteca_select"
  on storage.objects for select to authenticated
  using (bucket_id = 'biblioteca');

create policy "storage_biblioteca_admin_insert"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'biblioteca' and public.is_admin());

create policy "storage_biblioteca_admin_delete"
  on storage.objects for delete to authenticated
  using (bucket_id = 'biblioteca' and public.is_admin());

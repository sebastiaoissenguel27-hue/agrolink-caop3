
-- 0018 — Preparação futura: AgroLink Logística (transporte/distribuição de produção).
-- Mesmo padrão do SIE/Mercado/Sensores: schema e RLS prontos, sem interface própria.

create table public.logistica_transportadoras (
  id            uuid primary key default gen_random_uuid(),
  nome          text not null,
  provincia     text,
  contacto      text,
  capacidade_kg numeric,
  ativo         boolean not null default true,
  criado_em     timestamptz not null default now()
);

alter table public.logistica_transportadoras enable row level security;

create policy "logistica_transportadoras_select_admin"
  on public.logistica_transportadoras for select to authenticated
  using (public.is_admin());

create table public.logistica_pedidos (
  id                  uuid primary key default gen_random_uuid(),
  solicitante_id      uuid references public.profiles(id),
  transportadora_id   uuid references public.logistica_transportadoras(id),
  origem_provincia    text,
  destino_provincia   text,
  produto_descricao   text,
  quantidade_kg       numeric,
  status              text not null default 'pedido',
  criado_em           timestamptz not null default now()
);

alter table public.logistica_pedidos enable row level security;

create policy "logistica_pedidos_proprio_ou_admin"
  on public.logistica_pedidos for select to authenticated
  using (solicitante_id = auth.uid() or public.is_admin());

create policy "logistica_pedidos_criar_proprio"
  on public.logistica_pedidos for insert to authenticated
  with check (solicitante_id = auth.uid());

comment on table public.logistica_transportadoras is
  'Preparação do futuro módulo AgroLink Logística — sem interface nesta versão.';
comment on table public.logistica_pedidos is
  'Preparação do futuro módulo AgroLink Logística — liga-se ao Mercado AgroLink quando ambos forem ativados.';

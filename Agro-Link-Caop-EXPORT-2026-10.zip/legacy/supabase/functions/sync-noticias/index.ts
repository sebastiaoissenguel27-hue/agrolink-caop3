
// Edge Function (Deno) — ingestão automática de notícias agrícolas.
//
// Percorre "noticias_fontes" ativas (por ordem de prioridade), faz fetch
// do RSS de cada uma, filtra por relevância agrícola (palavras-chave —
// determinístico, sem custo de modelo), classifica por categoria fixa
// usando IA (só para os itens que passam o filtro, para poupar custo), e
// insere os artigos novos em "noticias". Regista sempre um log por fonte
// em "noticias_sync_logs", mesmo quando falha — uma fonte deixar de
// responder nunca interrompe as restantes.
//
// Limitação conhecida: o parser abaixo é uma extração por regex, não um
// parser XML completo — cobre bem RSS 2.0 comum.
//
// Agendamento: Supabase Dashboard → Edge Functions → sync-noticias → Schedule.

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.4';

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const GEMINI_API_KEY = Deno.env.get('GEMINI_API_KEY');
const GEMINI_ENDPOINT = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent';

const CATEGORIAS = [
  'Culturas', 'Pecuária', 'Clima', 'Mercados', 'Tecnologia',
  'Investigação', 'Políticas Públicas', 'Pragas e Doenças', 'Formação', 'Ambiente',
];

// Filtro de relevância agrícola — determinístico, sem custo de modelo.
// Cobre os domínios pedidos: agricultura, pecuária, pescas, florestas,
// ambiente, clima, tecnologia agrícola, mercados agrícolas, políticas
// agrícolas, investigação agrícola, segurança alimentar.
const PALAVRAS_AGRICOLAS = [
  'agricultura', 'agrícola', 'agricultor', 'colheita', 'plantio', 'cultivo',
  'cultura', 'milho', 'mandioca', 'feijão', 'café', 'algodão', 'pecuária',
  'gado', 'pescas', 'pesca', 'aquicultura', 'floresta', 'reflorestamento',
  'ambiente', 'clima', 'seca', 'chuva', 'irrigação', 'fertilizante', 'adubo',
  'praga', 'doença das plantas', 'mercado agrícola', 'exportação agrícola',
  'segurança alimentar', 'fao', 'ministério da agricultura', 'investigação agronómica',
  'agropecuário', 'agroindústria', 'semente', 'solo agrícola',
];

function extrairTag(bloco: string, tag: string): string {
  const m = bloco.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)</${tag}>`, 'i'));
  if (!m) return '';
  return m[1].replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1').replace(/<[^>]+>/g, '').trim();
}

function extrairImagem(bloco: string): string | null {
  const m = bloco.match(/<(?:media:content|enclosure)[^>]*url=["']([^"']+)["']/i);
  return m?.[1] ?? null;
}

function extrairItens(xml: string) {
  const blocos = xml.match(/<item[^>]*>[\s\S]*?<\/item>/gi) ?? [];
  return blocos.map((bloco) => ({
    titulo: extrairTag(bloco, 'title'),
    link: extrairTag(bloco, 'link'),
    resumo: extrairTag(bloco, 'description'),
    imagem: extrairImagem(bloco),
  }));
}

function ePertinenteAgricola(titulo: string, resumo: string): boolean {
  const alvo = (titulo + ' ' + resumo).toLowerCase();
  return PALAVRAS_AGRICOLAS.some((p) => alvo.includes(p));
}

async function classificarCategoria(titulo: string, resumo: string): Promise<string | null> {
  if (!GEMINI_API_KEY) return null;
  try {
    const resposta = await fetch(`${GEMINI_ENDPOINT}?key=${encodeURIComponent(GEMINI_API_KEY)}`, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
      },
      body: JSON.stringify({
        contents: [{ role: 'user', parts: [{ text: `Categoria única para esta notícia agrícola, escolhida exatamente entre: ${CATEGORIAS.join(', ')}.
Responda só com o nome exato da categoria, nada mais.
Título: ${titulo}
Resumo: ${resumo.slice(0, 300)}` }] }],
        generationConfig: { maxOutputTokens: 20 },
      }),
    });
    if (!resposta.ok) return null;
    const dados = await resposta.json();
    const texto = (dados.candidates?.[0]?.content?.parts ?? []).map((b: { text?: string }) => b.text ?? '').join('').trim();
    return CATEGORIAS.includes(texto) ? texto : null;
  } catch {
    return null;
  }
}

Deno.serve(async () => {
  if (!SUPABASE_SERVICE_ROLE_KEY) {
    return new Response(JSON.stringify({ erro: 'Função não configurada no servidor.' }), { status: 500 });
  }

  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

  const { data: fontes, error: erroFontes } = await supabase
    .from('noticias_fontes')
    .select('*')
    .eq('ativo', true)
    .not('url_rss', 'is', null)
    .order('prioridade', { ascending: false });

  if (erroFontes) {
    return new Response(JSON.stringify({ erro: erroFontes.message }), { status: 500 });
  }

  let inseridas = 0;
  let ignoradas = 0;
  const erros: string[] = [];

  for (const fonte of fontes ?? []) {
    let itensInseridosFonte = 0;
    let itensIgnoradosFonte = 0;
    let mensagemErro: string | null = null;

    try {
      const resposta = await fetch(fonte.url_rss);
      if (!resposta.ok) throw new Error(`HTTP ${resposta.status}`);

      const xml = await resposta.text();
      const itens = extrairItens(xml).slice(0, 20);

      for (const item of itens) {
        if (!item.titulo || !item.link) continue;

        if (!ePertinenteAgricola(item.titulo, item.resumo)) {
          itensIgnoradosFonte++;
          continue;
        }

        const categoriaIA = await classificarCategoria(item.titulo, item.resumo);

        const { error: erroInsert } = await supabase.from('noticias').insert({
          titulo: item.titulo,
          resumo: item.resumo.slice(0, 300) || null,
          conteudo: item.resumo || item.titulo,
          imagem_url: item.imagem,
          categoria: fonte.categoria,
          categoria_ia: categoriaIA,
          pais: fonte.pais,
          url_original: item.link,
          fonte_id: fonte.id,
        });

        if (erroInsert) {
          if (erroInsert.code === '23505') itensIgnoradosFonte++; // duplicado (url_original UNIQUE)
          else mensagemErro = erroInsert.message;
        } else {
          itensInseridosFonte++;
        }
      }

      inseridas += itensInseridosFonte;
      ignoradas += itensIgnoradosFonte;
    } catch (e) {
      mensagemErro = e instanceof Error ? e.message : 'erro desconhecido';
      erros.push(`${fonte.nome}: ${mensagemErro}`);
    }

    // Log desta fonte — sempre gravado, mesmo em erro, para o admin
    // ver no painel sem interromper as fontes seguintes.
    await supabase.from('noticias_sync_logs').insert({
      fonte_id: fonte.id,
      sucesso: mensagemErro === null,
      itens_inseridos: itensInseridosFonte,
      itens_ignorados: itensIgnoradosFonte,
      mensagem_erro: mensagemErro,
    });
  }

  return new Response(
    JSON.stringify({ fontes_processadas: (fontes ?? []).length, inseridas, ignoradas, erros }),
    { headers: { 'content-type': 'application/json' } }
  );
});

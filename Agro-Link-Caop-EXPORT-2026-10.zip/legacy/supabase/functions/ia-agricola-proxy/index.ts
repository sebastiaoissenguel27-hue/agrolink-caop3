
// Edge Function (Deno) — proxy seguro para o assistente IA agrícola.
// A chave do provedor de IA vive só aqui (variável de ambiente da função),
// nunca chega ao cliente. Aceita texto + mídia validada em payload único,
// de forma segura e com limites rígidos. Usa apenas a Gemini API no backend.

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.4';

const GEMINI_API_KEY = Deno.env.get('GEMINI_API_KEY');
const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SUPABASE_ANON_KEY = Deno.env.get('SUPABASE_ANON_KEY')!;
const GEMINI_MODEL = 'gemini-2.5-flash';
const GEMINI_ENDPOINT = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;
const MAX_INLINE_VIDEO_BYTES = 20 * 1024 * 1024;
const MAX_MEDIA_ITEMS = 4;
const MAX_TOTAL_MEDIA_BYTES = 16 * 1024 * 1024;
const MAX_MESSAGE_LENGTH = 4_000;

const SYSTEM_PROMPT = `Você é o assistente do AgroLink Caop — tem DUAS especializações:

1. Agricultura angolana: culturas (mandioca, milho, feijão, batata-doce, café, etc.),
   clima tropical/subtropical de Angola, pragas e doenças comuns na região.
2. O funcionamento da própria plataforma AgroLink Caop: como criar um relato (com ou
   sem conta), como consultar um relato pelo código, como funcionam os estados de um
   relato (pendente/em análise/respondido/resolvido), como usar as Ferramentas
   Agrícolas, a Biblioteca, a Academia e o Centro de Recursos, e como contactar um
   técnico. Quando a pergunta for sobre a plataforma, responda com base nestas
   funcionalidades reais — não invente ecrãs ou botões que não existem.

Responda em português, de forma clara e prática para um agricultor, mesmo que
não tenha formação técnica. Se a pergunta envolver um risco sério (praga que
pode destruir a colheita, doença que se espalha rápido, uso incorreto de
químicos), seja direto sobre a gravidade.

No FIM da resposta, numa linha própria, indique o seu nível de confiança
nesta resposta específica, exatamente neste formato:
[confianca: alta|media|baixa]

Use "baixa" sempre que o caso pareça precisar de inspeção presencial por um
técnico (ex: diagnóstico visual duvidoso, sintomas atípicos, risco de perda
total da colheita). Para perguntas sobre a plataforma (não agrícolas), a
confiança é tipicamente "alta" quando a resposta é factual sobre como algo
funciona.`;

const CULTURAS_CONHECIDAS = [
  'mandioca', 'milho', 'feijão', 'batata-doce', 'batata doce', 'café',
  'amendoim', 'arroz', 'sorgo', 'massango', 'massambala', 'banana', 'tomate',
];
const PRAGAS_CONHECIDAS = [
  'lagarta-do-cartucho', 'lagarta do cartucho', 'gafanhoto', 'mosca-branca',
  'mosca branca', 'cochonilha', 'broca', 'pulgão', 'ácaro', 'ferrugem',
  'antracnose', 'míldio', 'podridão',
];

function detetarPalavrasChave(texto: string, lista: string[]): string[] {
  const alvo = texto.toLowerCase();
  return lista.filter((p) => alvo.includes(p));
}

function detetarTema(texto: string): string {
  const alvo = texto.toLowerCase();
  if (/relato|código|sincroniz|painel|ecrã|app|aplicaç|academia|biblioteca/.test(alvo)) return 'plataforma';
  if (/praga|inset|lagarta|gafanhoto/.test(alvo)) return 'praga';
  if (/doença|fungo|podridão|míldio|ferrugem/.test(alvo)) return 'doenca';
  if (/chuva|seca|clima|tempo|temperatura/.test(alvo)) return 'clima';
  if (/solo|adubo|fertiliz|ph do/.test(alvo)) return 'solo';
  if (/preço|vender|mercado|comprador/.test(alvo)) return 'mercado';
  return 'outro';
}

const MAX_BYTES: Record<string, number> = {
  image: 8 * 1024 * 1024,
  audio: 12 * 1024 * 1024,
  video: 25 * 1024 * 1024,
};

const ALLOWED_MIME: Record<string, string[]> = {
  image: ['image/jpeg', 'image/png', 'image/webp'],
  audio: ['audio/webm', 'audio/mp4', 'audio/ogg', 'audio/wav', 'audio/mpeg', 'audio/x-wav'],
  video: ['video/mp4', 'video/webm', 'video/quicktime', 'video/x-matroska'],
};

function parseDataUrl(dataUrl: string): { mimeType: string; data: string } | null {
  const match = dataUrl.match(/^data:([^;,]+);base64,(.*)$/i);
  if (!match) return null;
  return { mimeType: match[1].toLowerCase(), data: match[2] };
}

function estimateBytesFromDataUrl(dataUrl: string): number {
  const parsed = parseDataUrl(dataUrl);
  if (!parsed) return 0;
  return Math.ceil((parsed.data.length * 3) / 4);
}

function normalizeMedia(media: unknown, index: number) {
  if (!media || typeof media !== 'object' || Array.isArray(media)) {
    throw new Error(`Media ${index + 1} inválida.`);
  }

  const item = media as Record<string, unknown>;
  const type = item.type;
  const mimeType = typeof item.mimeType === 'string' ? item.mimeType.toLowerCase() : undefined;
  const data = typeof item.data === 'string' ? item.data : undefined;

  if (type !== 'image' && type !== 'audio' && type !== 'video') {
    throw new Error(`Tipo de media inválido no item ${index + 1}.`);
  }
  if (!data || data.trim().length === 0) {
    throw new Error(`${type === 'image' ? 'Foto' : type === 'audio' ? 'Áudio' : 'Vídeo'} vazio.`);
  }
  if (!mimeType || !ALLOWED_MIME[type].includes(mimeType)) {
    throw new Error(`MIME type inválido para ${type} no item ${index + 1}.`);
  }

  const parsed = parseDataUrl(data);
  const normalizedData = parsed ? `data:${parsed.mimeType};base64,${parsed.data}` : `data:${mimeType};base64,${data}`;
  const size = estimateBytesFromDataUrl(normalizedData);
  if (size <= 0 || size > MAX_BYTES[type]) {
    throw new Error(`Ficheiro ${type} excede o limite permitido no item ${index + 1}.`);
  }

  return { type, mimeType, data: normalizedData, size };
}

function buildGeminiParts(mensagem: string, media: Array<{ type: string; mimeType: string; data: string; size: number }>) {
  const parts: Record<string, unknown>[] = [{ text: mensagem }];
  const hasLargeVideo = media.some((item) => item.type === 'video' && item.size > MAX_INLINE_VIDEO_BYTES);

  if (hasLargeVideo) {
    parts.push({ text: 'O vídeo excede o limite de envio inline; analise as imagens representativas extraídas do vídeo que seguem nesta mensagem. Não afirme ter analisado o ficheiro completo.' });
  }

  for (const item of media) {
    if (item.type === 'video' && item.size > MAX_INLINE_VIDEO_BYTES) continue;
    parts.push({
      inline_data: {
        mime_type: item.mimeType,
        data: item.data.replace(/^data:[^;]+;base64,/, ''),
      },
    });
  }

  return parts;
}

async function gerarRespostaGemini(mensagem: string, media: Array<{ type: string; mimeType: string; data: string; size: number }>): Promise<string> {
  const resposta = await fetch(`${GEMINI_ENDPOINT}?key=${encodeURIComponent(GEMINI_API_KEY!)}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      system_instruction: { parts: [{ text: SYSTEM_PROMPT }] },
      contents: [{ role: 'user', parts: buildGeminiParts(mensagem, media) }],
      generationConfig: { maxOutputTokens: 800 },
    }),
  });

  if (!resposta.ok) throw new Error('Falha ao contactar o assistente IA.');
  const dados = await resposta.json();
  const texto = (dados.candidates?.[0]?.content?.parts ?? [])
    .map((part: { text?: string }) => part.text ?? '')
    .join('\n')
    .trim();
  if (!texto) throw new Error('O assistente IA não devolveu uma resposta válida.');
  return texto;
}

Deno.serve(async (req) => {
  if (req.method !== 'POST') {
    return new Response('Método não permitido', { status: 405 });
  }

  const authHeader = req.headers.get('Authorization') ?? '';
  const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
    global: { headers: { Authorization: authHeader } },
  });
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return new Response(JSON.stringify({ erro: 'Não autenticado.' }), { status: 401 });
  }

  // Limite por utilizador no servidor para evitar abuso/custos inesperados.
  const { data: permitido, error: erroLimite } = await supabase.rpc('verificar_limite_taxa', {
    p_chave: `ia_pergunta:${user.id}`,
    p_max: 20,
    p_janela_segundos: 600,
  });
  if (erroLimite) {
    return new Response(JSON.stringify({ erro: 'Não foi possível validar o limite de utilização da IA.' }), {
      status: 503,
    });
  }
  if (!permitido) {
    return new Response(JSON.stringify({ erro: 'Limite temporário de perguntas atingido. Tente novamente mais tarde.' }), {
      status: 429,
    });
  }

  if (!GEMINI_API_KEY) {
    return new Response(JSON.stringify({ erro: 'Assistente IA temporariamente indisponível.' }), { status: 503 });
  }

  let payload: any;
  try {
    payload = await req.json();
  } catch {
    return new Response(JSON.stringify({ erro: 'Payload inválido.' }), { status: 400 });
  }

  const mensagem = typeof payload?.message === 'string' ? payload.message : payload?.mensagem;
  const conversaId = payload?.conversaId;
  const mediaRaw = Array.isArray(payload?.media) ? payload.media : [];

  if (!mensagem || typeof mensagem !== 'string' || mensagem.trim().length === 0) {
    return new Response(JSON.stringify({ erro: 'Mensagem em falta.' }), { status: 400 });
  }
  if (mensagem.length > MAX_MESSAGE_LENGTH) {
    return new Response(JSON.stringify({ erro: 'Mensagem demasiado longa. Reduza o texto e tente novamente.' }), {
      status: 413,
    });
  }
  if (mediaRaw.length > MAX_MEDIA_ITEMS) {
    return new Response(JSON.stringify({ erro: `Pode enviar no máximo ${MAX_MEDIA_ITEMS} ficheiros por pergunta.` }), {
      status: 413,
    });
  }

  try {
    const media = mediaRaw.map((item, index) => normalizeMedia(item, index));
    const totalMediaBytes = media.reduce((total, item) => total + item.size, 0);
    if (totalMediaBytes > MAX_TOTAL_MEDIA_BYTES) {
      return new Response(JSON.stringify({ erro: 'O conjunto de ficheiros excede o limite permitido.' }), {
        status: 413,
      });
    }

    let idConversa = conversaId as string | undefined;
    if (!idConversa) {
      const { data: novaConversa, error: erroConversa } = await supabase
        .from('ia_conversas')
        .insert({ utilizador_id: user.id })
        .select()
        .single();
      if (erroConversa || !novaConversa) {
        return new Response(JSON.stringify({ erro: 'Não foi possível iniciar a conversa.' }), {
          status: 500,
        });
      }
      idConversa = novaConversa.id;
    }

    await supabase
      .from('ia_mensagens')
      .insert({ conversa_id: idConversa, role: 'user', conteudo: mensagem });

    const textoCompleto = await gerarRespostaGemini(mensagem, media);

    const match = textoCompleto.match(/\[confianca:\s*(alta|media|baixa)\]/i);
    const confianca = (match?.[1]?.toLowerCase() ?? 'media') as 'alta' | 'media' | 'baixa';
    const respostaLimpa = textoCompleto.replace(/\[confianca:\s*(alta|media|baixa)\]/i, '').trim();

    await supabase
      .from('ia_mensagens')
      .insert({ conversa_id: idConversa, role: 'assistant', conteudo: respostaLimpa });

    const { data: analyticsId } = await supabase.rpc('registar_pergunta_ia', {
      p_tema: detetarTema(mensagem),
      p_culturas: detetarPalavrasChave(mensagem, CULTURAS_CONHECIDAS),
      p_pragas: detetarPalavrasChave(mensagem, PRAGAS_CONHECIDAS),
      p_confianca: confianca,
    });

    return new Response(
      JSON.stringify({ conversaId: idConversa, resposta: respostaLimpa, confianca, analyticsId }),
      { headers: { 'content-type': 'application/json' } }
    );
  } catch (erro) {
    const mensagemErro = erro instanceof Error ? erro.message : 'Dados de mídia inválidos.';
    return new Response(JSON.stringify({ erro: mensagemErro }), { status: 400 });
  }
});

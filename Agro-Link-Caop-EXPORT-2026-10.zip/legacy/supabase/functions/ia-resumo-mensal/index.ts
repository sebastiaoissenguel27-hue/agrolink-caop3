
// Edge Function (Deno) — gera o resumo mensal automático da IA AgroLink.
// Só lê agregados de ia_perguntas_analytics (temas/culturas/pragas/contagens),
// nunca o texto de perguntas ou respostas individuais — por desenho, os
// relatórios administrativos não podem expor conversas de utilizadores.
//
// Agendamento sugerido: 1x por mês (Supabase Dashboard → Edge Functions →
// ia-resumo-mensal → Schedule, ex: dia 1 às 03:00). Também pode ser
// chamada manualmente pelo botão "Gerar resumo" no painel admin.

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.4';

const GEMINI_API_KEY = Deno.env.get('GEMINI_API_KEY');
const GEMINI_ENDPOINT = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent';
const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

Deno.serve(async () => {
  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

  const agora = new Date();
  const mesAlvo = agora.getMonth() === 0 ? 12 : agora.getMonth();
  const anoAlvo = agora.getMonth() === 0 ? agora.getFullYear() - 1 : agora.getFullYear();

  const { count: jaExiste } = await supabase
    .from('ia_resumos_mensais')
    .select('*', { count: 'exact', head: true })
    .eq('mes', mesAlvo)
    .eq('ano', anoAlvo);

  if (jaExiste && jaExiste > 0) {
    return new Response(JSON.stringify({ gerado: false, motivo: 'Resumo desse mês já existe.' }), {
      headers: { 'content-type': 'application/json' },
    });
  }

  const inicio = new Date(anoAlvo, mesAlvo - 1, 1).toISOString();
  const fim = new Date(anoAlvo, mesAlvo, 1).toISOString();

  const { data: perguntas } = await supabase
    .from('ia_perguntas_analytics')
    .select('tema, culturas, pragas, confianca, encaminhado, provincia')
    .gte('criado_em', inicio)
    .lt('criado_em', fim);

  if (!perguntas || perguntas.length === 0) {
    return new Response(JSON.stringify({ gerado: false, motivo: 'Sem perguntas nesse mês.' }), {
      headers: { 'content-type': 'application/json' },
    });
  }

  const contar = (arr: (string | null)[]) => {
    const mapa = new Map<string, number>();
    arr.forEach((v) => {
      if (!v) return;
      mapa.set(v, (mapa.get(v) ?? 0) + 1);
    });
    return [...mapa.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8);
  };

  const agregados = {
    total: perguntas.length,
    temas: contar(perguntas.map((p) => p.tema)),
    culturas: contar(perguntas.flatMap((p) => p.culturas ?? [])),
    pragas: contar(perguntas.flatMap((p) => p.pragas ?? [])),
    provincias: contar(perguntas.map((p) => p.provincia)),
    encaminhados: perguntas.filter((p) => p.encaminhado).length,
    confianca_baixa: perguntas.filter((p) => p.confianca === 'baixa').length,
  };

  let conteudo = `Resumo automático — sem acesso ao modelo de IA configurado. Dados agregados: ${JSON.stringify(agregados)}`;

  if (GEMINI_API_KEY) {
    const prompt = `Escreva um resumo mensal, em português, para a equipa técnica do AgroLink Caop,
com base SÓ nestes dados agregados (nunca invente números fora daqui):
${JSON.stringify(agregados, null, 2)}

Estruture com estas secções: Principais temas do mês; Problemas agrícolas mais frequentes;
Culturas mais afetadas; Dúvidas mais comuns; Tendências identificadas; Recomendações para a equipa técnica.
Seja conciso (max. 300 palavras).`;

    const respostaIA = await fetch(`${GEMINI_ENDPOINT}?key=${encodeURIComponent(GEMINI_API_KEY)}`, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
      },
      body: JSON.stringify({
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        generationConfig: { maxOutputTokens: 700 },
      }),
    });

    if (respostaIA.ok) {
      const dadosIA = await respostaIA.json();
      conteudo = (dadosIA.candidates?.[0]?.content?.parts ?? [])
        .map((b: { text?: string }) => b.text ?? '')
        .join('\n');
    }
  }

  await supabase.from('ia_resumos_mensais').insert({ mes: mesAlvo, ano: anoAlvo, conteudo });

  return new Response(JSON.stringify({ gerado: true }), {
    headers: { 'content-type': 'application/json' },
  });
});

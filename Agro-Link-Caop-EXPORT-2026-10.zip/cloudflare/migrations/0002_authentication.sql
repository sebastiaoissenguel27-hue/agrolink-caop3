ALTER TABLE profiles ADD COLUMN tipo_perfil TEXT NOT NULL DEFAULT 'agricultor';
ALTER TABLE profiles ADD COLUMN nivel_admin TEXT NOT NULL DEFAULT 'normal';
ALTER TABLE profiles ADD COLUMN verification_status TEXT;
ALTER TABLE profiles ADD COLUMN visibilidade TEXT NOT NULL DEFAULT 'publico';

UPDATE profiles SET nivel_admin='auditor' WHERE papel='auditor';
UPDATE profiles SET tipo_perfil=CASE papel
  WHEN 'tecnico' THEN 'tecnico'
  WHEN 'transportador' THEN 'agricultor'
  WHEN 'admin' THEN 'administrador'
  WHEN 'admin_chefe' THEN 'administrador'
  WHEN 'auditor' THEN 'administrador'
  ELSE 'agricultor'
END;
UPDATE profiles SET papel=CASE
  WHEN papel IN ('agricultor','tecnico','transportador') THEN 'utilizador'
  WHEN papel='auditor' THEN 'admin'
  ELSE papel
END;

UPDATE users SET email='duplicate-' || lower(hex(CAST(id AS BLOB))) || '@invalid.agrolink.local'
WHERE id IN (
  SELECT id FROM (
    SELECT u.id,
      ROW_NUMBER() OVER (
        PARTITION BY lower(trim(u.email))
        ORDER BY CASE WHEN p.papel='admin_chefe' THEN 0 ELSE 1 END,
                 CASE WHEN p.status='ativo' THEN 0 ELSE 1 END,
                 u.created_at,u.id
      ) AS duplicate_rank
    FROM users u LEFT JOIN profiles p ON p.id=u.id
  ) WHERE duplicate_rank>1
);
UPDATE profiles SET visibilidade='oculto' WHERE id IN (
  SELECT id FROM users WHERE email LIKE 'duplicate-%@invalid.agrolink.local'
);
UPDATE users SET email=lower(trim(email));
CREATE UNIQUE INDEX IF NOT EXISTS idx_users_normalized_email_unique ON users(email);

CREATE TABLE IF NOT EXISTS password_reset_tokens (
  id TEXT PRIMARY KEY,
  utilizador_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  expira_em TEXT NOT NULL,
  usado INTEGER NOT NULL DEFAULT 0,
  criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS password_reset_outbox (
  id TEXT PRIMARY KEY,
  utilizador_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  token_hash TEXT NOT NULL UNIQUE,
  expira_em TEXT NOT NULL,
  estado TEXT NOT NULL DEFAULT 'pendente' CHECK (estado IN ('pendente','enviado','falhou','usado','expirado')),
  criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  enviado_em TEXT,
  erro TEXT
);

CREATE INDEX IF NOT EXISTS idx_password_reset_outbox_email ON password_reset_outbox(email,criado_em);
CREATE INDEX IF NOT EXISTS idx_password_reset_outbox_estado ON password_reset_outbox(estado,criado_em);

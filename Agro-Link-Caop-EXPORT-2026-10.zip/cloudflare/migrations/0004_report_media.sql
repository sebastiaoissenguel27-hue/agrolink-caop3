CREATE TABLE IF NOT EXISTS relato_midias (
  id TEXT PRIMARY KEY,
  relato_id TEXT NOT NULL REFERENCES relatos(id) ON DELETE CASCADE,
  tipo TEXT NOT NULL CHECK (tipo IN ('foto','audio')),
  caminho_storage TEXT NOT NULL,
  criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_relatos_midias ON relato_midias(relato_id,criado_em);
CREATE INDEX IF NOT EXISTS idx_denuncia_historico_denuncia ON denuncia_historico(denuncia_id,alterado_em);

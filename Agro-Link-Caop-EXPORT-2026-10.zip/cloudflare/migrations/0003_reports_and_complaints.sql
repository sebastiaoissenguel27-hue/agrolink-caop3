CREATE TABLE IF NOT EXISTS relatos (
  id TEXT PRIMARY KEY,
  autor_id TEXT REFERENCES profiles(id) ON DELETE SET NULL,
  codigo_publico TEXT UNIQUE,
  tipo TEXT NOT NULL CHECK (tipo IN ('praga','doenca','clima','solo','pedido_apoio','outro')),
  descricao TEXT NOT NULL,
  provincia TEXT,
  municipio TEXT,
  comuna TEXT,
  status TEXT NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente','em_analise','respondido','resolvido')),
  tecnico_atribuido_id TEXT REFERENCES profiles(id) ON DELETE SET NULL,
  criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  localizacao TEXT
);

CREATE TABLE IF NOT EXISTS relato_respostas (
  id TEXT PRIMARY KEY,
  relato_id TEXT NOT NULL REFERENCES relatos(id) ON DELETE CASCADE,
  tecnico_id TEXT NOT NULL REFERENCES profiles(id),
  comentario TEXT NOT NULL,
  criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS denuncias (
  id TEXT PRIMARY KEY,
  autor_id TEXT NOT NULL REFERENCES profiles(id),
  denunciado_id TEXT NOT NULL REFERENCES profiles(id),
  transporte_id TEXT,
  categoria TEXT NOT NULL,
  descricao TEXT NOT NULL,
  evidencias TEXT NOT NULL DEFAULT '[]' CHECK (json_valid(evidencias)),
  estado TEXT NOT NULL DEFAULT 'pendente' CHECK (estado IN ('pendente','em_analise','confirmada','rejeitada','arquivada')),
  prioridade TEXT NOT NULL DEFAULT 'media' CHECK (prioridade IN ('baixa','media','alta','urgente')),
  admin_responsavel_id TEXT REFERENCES profiles(id),
  decisao TEXT,
  sugestao_ia TEXT,
  data_resolucao TEXT,
  criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CHECK (autor_id <> denunciado_id)
);

CREATE TABLE IF NOT EXISTS denuncia_historico (
  id TEXT PRIMARY KEY,
  denuncia_id TEXT NOT NULL REFERENCES denuncias(id) ON DELETE CASCADE,
  campo_alterado TEXT NOT NULL,
  valor_anterior TEXT,
  valor_novo TEXT,
  alterado_por TEXT REFERENCES profiles(id),
  alterado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_relatos_autor_criado ON relatos(autor_id,criado_em);
CREATE INDEX IF NOT EXISTS idx_relatos_status_provincia ON relatos(status,provincia);
CREATE INDEX IF NOT EXISTS idx_relatos_codigo_publico ON relatos(codigo_publico);
CREATE INDEX IF NOT EXISTS idx_relatos_respostas ON relato_respostas(relato_id,criado_em);
CREATE INDEX IF NOT EXISTS idx_denuncias_autor_criado ON denuncias(autor_id,criado_em);
CREATE INDEX IF NOT EXISTS idx_denuncias_estado_prioridade ON denuncias(estado,prioridade,criado_em);

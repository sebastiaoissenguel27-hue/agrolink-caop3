
> **Estado arquitetural atualizado (15/09/2026):** o runtime ativo foi migrado de Supabase para a base de dados interna do AgroLink (`server/db.mjs` + `server/migrations/001_platform.sql`). As referências a Supabase nestes documentos podem ser históricas.

# agrolink-caop
Agro Link Caop — Plataforma de Inovação e Transformação Digital Agrícola


> **Estado arquitetural atualizado (15/09/2026):** o runtime ativo foi migrado de Supabase para a base de dados interna do AgroLink (`server/db.mjs` + `server/migrations/001_platform.sql`). As referências a Supabase nestes documentos podem ser históricas.

# HANDOFF_SUMMARY.md

**Projeto:** AgroLink Caop — plataforma agrícola angolana (React+TS, Supabase, PWA offline-first)

**O que este pacote contém:** código-fonte completo, 28 migrações SQL, 3 Edge Functions,
configuração de projeto (`package.json`, `vite.config.ts`, `tsconfig.json`), `.env.example`
(sem segredos), toda a documentação já existente, mais 3 documentos novos:
`PROJECT_STATUS.md` (estado real e auditado), `HANDOFF_PROMPT.md` (prompt pronto para a
próxima IA), e este ficheiro.

**Estado real, em uma frase:** v2.0 está completa e auditada; da v3.0, só a base de dados
do Security & Trust Layer existe — o frontend desse módulo, e todos os módulos seguintes
(Mercado, Logística, Mapas, Meteorologia, Sensores), ainda não foram começados.

**Nunca executado neste ambiente (limitação confirmada, não hipótese):** `npm install`,
`npm run build`, qualquer ligação a um Supabase real, deploy de Edge Functions. Ver
`PROJECT_STATUS.md` secção 12 para o detalhe completo.

**Próximo passo real, por ordem:** (1) correr o primeiro build real num ambiente com rede;
(2) ligar um Supabase real e aplicar as 28 migrações; (3) terminar o frontend do Security
& Trust Layer; (4) só depois, Mercado AgroLink.

**Para continuar:** ler `PROJECT_STATUS.md` na íntegra, depois usar `HANDOFF_PROMPT.md`
como primeira mensagem à IA seguinte.

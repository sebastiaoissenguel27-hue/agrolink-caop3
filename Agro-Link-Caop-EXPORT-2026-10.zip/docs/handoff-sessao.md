
# AgroLink Caop — Handoff de Sessão (fim da v2.0)

Documento de continuidade. Lido no início da próxima sessão, permite retomar exatamente
daqui, sem repetir análise de arquitetura já feita.

---

## 1. Estado exato do projeto neste momento

Projeto em `/home/claude/agrolink-caop` (última versão empacotada: `agrolink-caop-v2.zip`,
mas essa cópia **não inclui** os ficheiros do Módulo 3 e 4 criados nesta última sessão —
ver secção 4). Migrações SQL vão de `0001` a `0015`. 22 tabelas com RLS + política
verificadas até ao módulo 3; o módulo 4 (Academia) acrescentou mais 4 tabelas
(`academia_cursos`, `academia_licoes`, `academia_questionarios`, `academia_progresso`)
cuja migração está escrita e correta, mas **cujo código de frontend ainda não está ligado**.

---

## 2. Concluído (implementado, ligado e testado estaticamente)

### Plataforma base
- React + TypeScript + Vite, PWA instalável (Android), Supabase (Auth + Postgres + Storage + Edge Functions).
- Autenticação completa: login, registo, recuperação/redefinição de password, sessão persistente.
- Perfis com 3 papéis (agricultor/técnico/admin), `status` de conta, `verification_status` de técnico, localização província/município/comuna.
- RLS restrita por papel em todas as tabelas; auto-registo como admin bloqueado a nível de BD (não só UI).
- Auditoria (`auditoria`) e notificações internas (`notificacoes`) automáticas, geridas só por funções `SECURITY DEFINER`.

### Relatos agrícolas
- Com e sem cadastro (código público único), várias fotos, áudio, offline completo (fila Dexie + `syncEngine`), 6 estados (`pendente/sincronizando/enviado/respondido/resolvido/erro`), respostas técnicas com notificação automática.

### Painéis
- Agricultor (dashboard), Técnico (lista filtrável + mídias + respostas), Admin (8 abas: Utilizadores, Notícias, Fontes de notícias, Alertas, Centro de Recursos, Biblioteca, Estatísticas, Auditoria).

### Comunicação
- Notícias (pesquisa, categoria, cache offline, ingestão automática RSS via Edge Function `sync-noticias`).
- Alertas (nacional/provincial/municipal, cache offline).
- Assistente IA agrícola multimodal (texto+foto), confiança extraída no servidor, encaminhamento a técnico, voz (Web Speech API), Edge Function `ia-agricola-proxy`.

### Módulos novos desta sessão (prioridade definida pelo utilizador)
1. **Configurações** — preferências de notificação (`preferencias_utilizador`), limpeza de cache offline, atalhos de conta. ✅ Completo.
2. **Ferramentas Agrícolas** — calculadora de dose de insumo + planeador de calendário de plantio, histórico offline-first (`ferramenta_calculos`). ✅ Completo.
3. **Centro de Recursos** — recursos externos + FAQ, cache offline, aba admin. ✅ Completo.
4. **Biblioteca AgroLink** — documentos/guias/manuais/PDFs, upload para bucket `biblioteca`, pesquisa full-text, cache offline de metadados, aba admin. ✅ Código completo — **mas sem reteste estático depois de escrito** (ver secção 3).

Motor de sincronização generalizado: `sincronizarTudo()` (chamado ao reconectar) agora
cobre relatos + cálculos de ferramentas + progresso da Academia.

---

## 3. Por concluir

### Imediato — fechar o Módulo 4 (Academia AgroLink)
Já feito: migração `0015` (cursos, lições, questionários com correção segura via RPC —
resposta certa nunca exposta ao cliente —, progresso, bucket `academia`), tipos
TypeScript, cache Dexie (`academiaCursosCache`, `academiaLicoesCache`, fila
`progressoPendente`), `syncEngine.sincronizarProgresso()`, e `academiaService.ts`
completo (`listarCursos`, `obterCurso`, `listarLicoes`, `obterUrlMidiaLicao`,
`obterMeuProgresso`, `marcarLicaoConcluida`, `obterQuestionario`, `submeterResposta`).

**Ficheiros ainda por criar:**
- `src/features/academia/pages/AcademiaPage.tsx` — listagem de cursos (padrão igual a `BibliotecaPage`/`NoticiasPage`).
- `src/features/academia/pages/CursoDetalhePage.tsx` — navegação entre lições de um curso; renderiza `texto`/`imagem`/`pdf`; para `tipo: 'video'` mostrar "Em breve" (não implementar player); no fim de uma lição com questionário, mostrar o quiz (`obterQuestionario` + `submeterResposta`); sem questionário, botão "Marcar como concluída" (`marcarLicaoConcluida`, já offline-first).
- `src/features/admin/components/AdminAcademia.tsx` — CRUD de cursos, lições (com upload para o bucket `academia`) e perguntas de questionário (opções + índice da resposta certa).

**Ficheiros a editar:**
- `src/features/admin/pages/AdminPage.tsx` — nova aba "Academia" (mesmo padrão das outras 7 abas).
- `src/app/App.tsx` — rotas `/academia` (lista) e `/academia/:cursoId` (detalhe) — **primeira rota dinâmica da app**, confirmar que `react-router-dom` já suporta (`useParams`) sem alterações de configuração.
- `src/app/components/AppLayout.tsx` — link de navegação "Academia" para agricultor e técnico (e talvez admin, para pré-visualizar).

### Testes pendentes (nenhum corrido desde o módulo 3)
1. Rerun do script de imports/exports (mesmo script usado nos módulos 1–3).
2. Rerun do script de equilíbrio de chavetas/parênteses.
3. Rerun da verificação de RLS/políticas (esperar 26 tabelas: 22 anteriores + 4 da Academia).
4. Confirmar que a rota dinâmica `/academia/:cursoId` está corretamente registada e que `CursoDetalhePage` lê `cursoId` via `useParams<{ cursoId: string }>()`.
5. Reempacotar (`agrolink-caop-v3-parcial.zip` ou similar) só depois dos testes acima passarem.

### Dívida técnica já conhecida (de sessões anteriores, ainda válida)
- Nunca foi possível correr `npm install`/`npm run build` reais neste ambiente (sem rede) — só auditoria estática. **Recomendação forte**: correr a build real antes de qualquer deploy.
- Push notifications: schema pronto (`dispositivos_push`), sem integração real com FCM/APNs.
- Parser RSS (`sync-noticias`): regex funcional para RSS 2.0 comum, não é parser XML robusto.
- IA: não transcreve áudio (só o técnico ouve o áudio do relato); sem suporte a vídeo.
- Upload de documentos de verificação de técnico: schema/bucket prontos (`tecnico_documentos`), sem UI.
- SIE, Mercado AgroLink, Mapas, Sensores: schema e RLS prontos, sem interface própria.
- Acessibilidade: corrigidos problemas pontuais (aria-label, alt, aria-live); nunca foi feita auditoria formal de contraste de cor nem navegação completa por teclado.

---

## 4. Nota sobre o ficheiro entregável mais recente

O `agrolink-caop-v2.zip` partilhado anteriormente **não contém** os módulos Configurações,
Ferramentas, Centro de Recursos nem Biblioteca (todos criados depois desse zip). O código
existe no filesystem de trabalho desta sessão, mas — por instrução explícita de não
implementar mais nada agora — **não foi reempacotado**. Isto é o primeiro passo prático
da próxima sessão: reempacotar depois de terminar e testar o Módulo 4.

---

## 5. Plano detalhado — Versão 3.0

Ordem sugerida, cada item a tratar com a mesma metodologia usada até aqui (migração →
tipos → serviço → páginas → rotas → offline → testes):

1. **Fechar o Módulo 4** (Academia) — ver secção 3. Pré-requisito de tudo o resto.
2. **Validação de build real** — assim que houver um ambiente com acesso à rede, correr
   `npm install && npm run build` e corrigir o que a auditoria estática não conseguiu apanhar
   (sobretudo erros de tipos mais subtis do `tsc`).
3. **SIE (Sistema de Informação Estratégica)** — primeira interface real sobre
   `sie_indicadores`: dashboards agregados por província/período, alimentados por um job
   periódico (Edge Function agendada, como `sync-noticias`) que calcula indicadores a
   partir de `relatos`.
4. **Mapas** — usar a coluna `relatos.localizacao` (já existe, PostGIS) para uma vista de
   mapa (ex: MapLibre GL) com clustering de relatos por zona; útil sobretudo para o painel
   técnico e admin.
5. **Mercado AgroLink** — ativar o módulo já preparado (`mercado_produtos`): listagem
   pública de produtos ativos, painel do agricultor para publicar/gerir os seus, e (a
   decidir) se há necessidade de um fluxo de transação ou só de contacto direto entre
   partes.
6. **Sensores (IoT)** — interface básica de leitura sobre `sensores`/`leituras_sensor`
   (gráfico de série temporal simples); a integração com hardware real fica fora do
   controlo da aplicação — só o lado de receção/visualização de dados.
7. **Push notifications reais** — integrar Firebase Cloud Messaging (caminho mais direto
   para Android); ligar a `dispositivos_push` (já tem o schema) e aos triggers que já
   criam `notificacoes` internas.
8. **Vídeo** — Academia (`tipo: 'video'` já no enum) e IA (entrada de áudio transcrita).
   Ambos foram propositadamente adiados até agora.
9. **Upload de documentos de verificação de técnico** — UI sobre `tecnico_documentos`
   (schema e bucket já prontos), ligado ao fluxo de aprovação do admin.
10. **Parser RSS robusto** — substituir a extração por regex numa biblioteca XML dedicada,
    só se as fontes reais começarem a ter formatos irregulares.
11. **Testes automatizados** — até agora só houve auditoria estática manual; introduzir
    testes unitários (Vitest) para os serviços e, pelo menos, um teste E2E do fluxo crítico
    (registo → relato offline → sincronização → resposta técnica).
12. **Acessibilidade formal** — auditoria de contraste de cor e navegação completa por
    teclado em todos os painéis (admin especialmente, por ter mais tabelas/formulários).

---

## 6. Sugestões de melhorias futuras (não implementadas — só a registar)

- **Internacionalização**: hoje só português; Angola tem várias línguas nacionais que
  poderiam justificar tradução (ex: Umbundu, Kimbundu) dependendo do público real.
- **Modo escuro**: reduz consumo de bateria em ecrãs OLED, relevante para uso prolongado no campo.
- **Exportação de relatórios em PDF**: para técnicos/admin gerarem relatórios de zona a
  partir de `relatos`/`sie_indicadores` para partilhar com entidades externas.
- **Gamificação da Academia**: certificados/badges por curso concluído, para incentivar
  formação continuada dos agricultores.
- **Integração com WhatsApp**: canal de relato/notificação alternativo, potencialmente
  mais familiar do que uma app dedicada em zonas com menor adoção de apps.
- **Deteção preditiva de pragas**: cruzar o histórico de `relatos` por zona/época para
  sinalizar padrões emergentes antes de se tornarem alertas formais — depende de volume
  de dados real para ser útil, não vale a pena antes de haver utilização em produção.
- **Avaliação de técnicos pelos agricultores**: sinal de qualidade do atendimento, com
  cuidado no desenho para não desincentivar técnicos a aceitar casos difíceis.
- **Modo de baixa largura de banda**: compressão automática de imagens antes do upload
  (hoje o ficheiro original vai tal e qual), relevante dado o contexto de conectividade
  rural já assumido desde a Fase 1.
- **Pipeline de CI/CD**: build/test automático a cada alteração, especialmente importante
  visto que este ambiente de trabalho nunca conseguiu correr a build real.
- **Exportação/backup de dados do agricultor**: extrato pessoal dos seus relatos e
  histórico, tanto por transparência como por portabilidade de dados.


# AgroLink Caop — Relatório Técnico (fecho da v2.0)

## Funcionalidades implementadas neste bloco

**Notificações Inteligentes** — tipos cobertos: resposta a relato, mudança de estado
(em_análise/resolvido), novo alerta (por província), novo curso na Academia, mensagens
gerais da administração (broadcast, com filtro por papel). Sino de notificações em tempo
real (Supabase Realtime), leitura offline via cache Dexie, fila de "marcar como lida"
offline com sincronização automática. Preferências individuais por tipo de notificação em
Configurações.

**IA Analytics** — cada troca com o assistente regista tema/culturas/pragas mencionadas
(deteção por palavras-chave, sem custo de modelo extra) e nível de confiança, nunca o
texto da conversa. Dashboard admin (`obter_estatisticas_ia`, admin-only) com total de
perguntas, evolução diária/mensal, distribuição por província, temas/culturas/pragas mais
frequentes, confiança média, encaminhamentos vs. resolvidas só pela IA. Resumo mensal
narrativo gerado por IA a partir só de agregados (Edge Function `ia-resumo-mensal`),
nunca de conversas individuais.

**Notícias exclusivamente agrícolas** — filtro de relevância por palavras-chave
(determinístico) antes de qualquer inserção; classificação automática nas 10 categorias
fixas pedidas, via IA; catálogo de fontes oficiais pré-registado (FAO e ANGOP com feeds
reais confirmados por pesquisa nesta sessão; as restantes 14 fontes pedidas — MINAGRIF,
IDA, IIA, ISV, FAO Angola, Jornal de Angola, IFAD, CGIAR, CABI, CIMMYT, IITA, World Bank,
AfDB, Reuters — ficam pré-registadas mas inativas, com campo para o admin colar o feed
real quando o confirmar; **não inventei URLs para estas**). Prioridade de fonte, país de
origem, histórico de sincronizações com logs por fonte (sucesso/erro nunca interrompe as
restantes), cache offline, pesquisa e filtro por categoria na página pública.

## Correções feitas durante a auditoria deste bloco
1. `AdminIA.tsx` e a funcionalidade de mensagens gerais existiam mas não estavam ligadas
   a nenhuma aba do painel admin — corrigido (`AdminMensagens.tsx` criado + ambas ligadas).
2. Notificações não tinham cache offline nem fila de sincronização de leituras — corrigido
   (Dexie v7/v8 + `sincronizarLeiturasNotificacoes`, ligada a `sincronizarTudo`).
3. O filtro de categoria em `NoticiasPage` usava a categoria manual do admin, mas o
   seletor mostrava as categorias atribuídas pela IA — eram campos diferentes; corrigido
   para filtrar por ambos.

## Auditoria geral da v2.0 — resultado
- RLS: 31/31 tabelas com RLS ativa e pelo menos uma política.
- As 16 políticas `for all` da base de dados foram revistas uma a uma: todas restritas a
  `is_admin()` ou ao dono (`utilizador_id = auth.uid()` ou equivalente) — nenhuma aberta.
- PWA: `vite-plugin-pwa` configurado, service worker registado.
- Offline: 4 filas (relatos+mídias, cálculos de ferramentas, progresso da Academia,
  leituras de notificações) todas processadas por um único ponto de entrada
  (`sincronizarTudo`), disparado ao reconectar.
- Segurança: nenhuma chave de API (Gemini, service role) referenciada no frontend —
  confirmado por busca no código-fonte.
- Consistência frontend/backend: 0 problemas de imports/exports ou sintaxe (auditoria
  estática automatizada — ver limitação abaixo).

## Limitação que se mantém
Sem acesso à rede neste ambiente, continua a não ser possível correr `npm install`/
`npm run build` reais — toda a validação é auditoria estática (resolução de imports,
sintaxe, cobertura de RLS). Recomendação inalterada: correr a build real antes do deploy.

## Recomendações para a versão 3.0
Mantêm-se as do relatório anterior (SIE, Mapas, Mercado, Sensores, push real, vídeo,
upload de documentos de técnico, parser RSS robusto, testes automatizados, acessibilidade
formal), acrescidas de:
- Completar o catálogo de fontes de notícias com os feeds reais das 14 fontes ainda
  inativas (MINAGRIF, IDA, IIA, ISV, etc.) — o admin só precisa de colar o URL no painel.
- Avaliar se o resumo mensal da IA deve também considerar dados do SIE quando este ganhar
  interface própria, para cruzar tendências de perguntas com indicadores reais de terreno.

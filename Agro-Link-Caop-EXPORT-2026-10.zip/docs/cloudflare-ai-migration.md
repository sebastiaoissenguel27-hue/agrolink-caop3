# Mapa de Migracao de IA para Cloudflare

Estado: `/api/ia/chat` está integrado no Worker através de `env.AI`; Qwen local e o backend Node/Express permanecem ativos. O contrato HTTP não foi alterado. Inferência remota e deployment dependem de uma sessão Wrangler autenticada.

## Superficie atual

| Ponto | Implementacao atual | Alvo/acao futura |
|---|---|---|
| `server/localAi.mjs` | `getLocalAiConfig` le `process.env`; URL default `http://127.0.0.1:8080/v1/chat/completions`; `requestLocalAi` faz health polling antes de cada inferencia, `AbortController`/timeout, limite de concorrencia 1 em variavel de processo e fetch Chat Completions | Tornar um adapter `LocalAiProvider` Node. Worker recebe outro provider, sem URL loopback. |
| `POST /api/ia/chat` em `server/index.mjs` | Auth obrigatoria; mensagem ate 4.000 chars; ate 4 medias/16 MiB; limite 20 perguntas/10 min; cria/consulta conversa, guarda mensagens e chama `generateAgriculturalResponse`; fallback OpenAI so se habilitado/chave presente; fallback final informativo | Manter exatamente a resposta externa `{conversaId,resposta,confianca}` e validacoes/ownership; delegar para use-case + AI provider. |
| Security & Trust, `server/securityTrust.mjs` -> `analyzeSecuritySignal` | Qwen local e analise consultiva de schema restrito; OpenAI opcional; parser valida risco/categoria/confidence/reason/recommendation. O nivel/action/containment e calculado pelo motor deterministico. | `SecurityAnalysisProvider` pode usar Workers AI, com a mesma validacao estrita. Se AI falhar, o motor deterministico continua. Nunca usar output do modelo para executar acoes/permissoes. |
| Fallback agricola em `server/index.mjs` | Outra chamada OpenAI direta e opt-in por `AGROLINK_AI_OPENAI_FALLBACK=true` + `OPENAI_API_KEY`; erro/timeout nao expoe segredo. Sem resposta, devolve mensagem de indisponibilidade e `confianca='baixa'`. | Unificar escolha de provider atras de interface/config; fallback explicito e observavel, sem ativar substituto silenciosamente. |
| Configuracao local | `.env.example`: path GGUF, endpoint, modelo `qwen3-1.7b`, timeout 12s, enabled true; fallback externo false. Launcher Node controla Docker local. | Worker env/bindings: `AI` para Workers AI, secrets/config separados; Qwen remoto apenas por conector/endereco acessivel autenticado se for requisito futuro. |

## Contrato preservado

Pedido continua `POST /api/ia/chat` com cookie de sessao e JSON de mensagem/contexto/medias. Resposta de sucesso normal:

```json
{
  "conversaId": "...",
  "resposta": "...",
  "confianca": "alta | media | baixa"
}
```

A integracao futura deve normalizar o resultado do provider para esse formato; nao expor bindings, modelo, prompts internos, segredos ou erros remotos. Timeout e indisponibilidade devem produzir fallback controlado sem alterar status nem fluxo de autenticacao. O frontend nao precisa conhecer o nome do modelo/provider.

## Provider abstraction

```text
API /api/ia/chat
        |
        v
AgriculturalResponseUseCase (regra/prompt/contexto/historico/limites)
        |
        v
AiProvider.generate(messages, options)
        |                         |
        v                         v
LocalAiProvider (Node)       WorkersAiProvider (Worker env.AI)
                                  |
                                  +-- opcional futuro: AI Gateway/Connector -> Qwen externo
```

- A interface de dominio deve tratar prompt/mensagens e produzir texto estruturado/normalizado; nao importar `process.env`, `fetch` diretamente para host fixo nem tipos de Worker.
- Adapter Node preserva Qwen atual e testes do launcher.
- Adapter Workers AI usa `env.AI.run(model, input)`, com modelo `AI_MODEL` e timeout `AI_TIMEOUT_MS` configuráveis. A configuração inicial usa `@cf/meta/llama-3.1-8b-instruct`; mudar o modelo não altera o contrato HTTP.
- O Worker limita mensagem a 4.000 caracteres, contexto a 8 KiB, histórico a 20 mensagens, saída a 700 tokens e resposta a 12.000 caracteres. Resposta vazia/inválida, falha, binding ausente e timeout resultam no fallback existente com confiança baixa; respostas não validadas não são persistidas.
- Testes isolam o binding com mocks e exercitam D1, ownership, quota, prompt injection, timeout, erro e saída inválida. A execução local não depende de inferência remota.
- A resposta do provider e dado nao confiavel: aplicar limite de tamanho, timeout, parse/normalizacao e remocao de metadados; persistir mensagem do assistente so depois de validada.
- Para operar o Qwen container em Cloudflare, `127.0.0.1` nao e rota do Worker. Exigiria AI Gateway/Connector ou endpoint externo autenticado, rede/firewall, disponibilidade, latencia e segredo; nao se infere que Workers AI execute o GGUF.

## Security & Trust Layer

`evaluateSecuritySignal` calcula deterministicamente tipo/risco inicial, persistencia, disponibilidade do Admin Chefe, bloqueio reversivel de IP e modo de emergencia. `localAi.mjs` e apenas analise consultiva: output parser exige exatamente cinco campos; `buildSecurityAiResult` preserva `nivel: signal.nivel`; nenhuma decisao da IA pode executar bloqueio, apagar dados, promover papel ou alterar permissoes. Essa autoridade fica na logica deterministica em qualquer provider Cloudflare.

Em Worker, persistir incidente/acao/notificacao de forma atomica via repositories/D1; substituir o scheduler `setInterval` por Cron Trigger/Queue; limitar e autenticar o webhook externo. Rate-limit, timeout e indisponibilidade do AI binding nunca podem bloquear a contenção deterministica.

## Dependencias e limites confirmados

- Existem 3 pontos de integracao runtime: config/cliente Qwen em `localAi.mjs`, use-case agricola em `/api/ia/chat` e analise consultiva de sinal no Security & Trust. O fallback OpenAI agricola duplicado esta diretamente em `server/index.mjs`; security possui outro fallback opcional.
- `127.0.0.1:8080` ocorre como endpoint default local; Workers nao compartilha loopback com Docker/container do host.
- `process.env` precisa ser substituido por config Node ou bindings `env`; `setTimeout`, fetch e AbortController existem em Workers, mas timeout/CPU/subrequests/vida util devem respeitar os limites da plataforma.
- O limite `MAX_LOCAL_AI_CONCURRENCY=1` e global apenas por processo Node. Workers escalados nao compartilham esse contador; se backpressure for requisito, usar Rate Limiting/DO ou limite de provider.
- A rota valida `media` mas a chamada `generateAgriculturalResponse` recebe mensagem/contexto/historico, nao os bytes de media. Preservar esse comportamento ou definir suporte multimodal como requisito separado; nao presumir paridade automatica.
- A rota recebe `conversaId` do cliente e a consulta de historico atual deve ser auditada/escopada por `utilizador_id` no use-case/adapters. Antes do cutover, provar que uma conversa de outro utilizador nao pode ser carregada nem usada por ID forjado.
- `api/ia/chat` persiste mensagens via D1 em vez de uma transacao SQLite; garantir ownership, atomicidade de conversa + user message + assistant message e retry sem duplicacao.

## Estado

**Workers AI: IMPLEMENTADO LOCALMENTE.** O Worker usa o binding configurado, mantém D1/ownership/quota e trata a inferência como consultiva. Qwen local permanece ativo no Express. A inferência remota ainda não foi executada: Wrangler não está autenticado neste ambiente.

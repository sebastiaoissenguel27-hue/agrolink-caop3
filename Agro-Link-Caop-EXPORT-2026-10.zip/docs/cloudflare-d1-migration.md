# Mapa de Migracao SQLite para D1

Estado: mapeamento apenas. Nenhum banco D1 foi criado, nenhuma migration foi aplicada e o SQLite local permanece ativo.

## Inventario de schema

- 10 arquivos em `server/migrations/` (`001` a `010`), 356 linhas no total.
- 47 tabelas operacionais finais: 41 criadas em `001`, 4 em `003` e 2 em `004`.
- `009` cria uma tabela TEMP de staging para deduplicacao; `010` cria `profiles_rebuild`, copia dados e renomeia para `profiles` (nao e tabela operacional adicional).
- 21 declaracoes de indices nas migrations; manter filtros, ordenacao, foreign keys e unicidade. Os indices principais cobrem reports por autor/provincia/status, notificacoes, auditoria, sessao/rate limit, denuncias, logisticas e market.
- 5 declaracoes de triggers: `006` cria 3, `007` remove duas protecoes de profile e `010` recria essas duas. Resultado final: 3 triggers ativas (email reservado imutavel + insert/update de profile reservado).
- 55 ocorrencias textuais de `REFERENCES` e 20 `CHECK` no conjunto de migrations; algumas contam referencias redeclaradas pela reconstrucao `010`.
- Tipos dominantes: `TEXT` IDs/timestamps/JSON serializado, `INTEGER` flags/ordem, `REAL` valores/quantidades. Ha PKs compostas em `academia_progresso`, unique constraints e cascades.

## Migracoes existentes

| Migration | Conteudo | Compatibilidade D1 preliminar | Trabalho/risco |
|---|---|---|---|
| `001_platform.sql` | 41 tabelas e indices base; FK, CHECK, defaults, unique, cascades | Alta como schema SQLite, exceto `PRAGMA foreign_keys=ON` | Remover PRAGMA; aplicar em D1 descartavel e verificar FK/cascades/indices. |
| `002_security_admin_denuncias.sql` | 3 `ALTER TABLE profiles ADD COLUMN`; indices de denuncia | Media/Alta | `ADD COLUMN REFERENCES` nullable requer teste no mecanismo D1 e nas migrations encadeadas. |
| `003_security_trust_layer.sql` | 4 tabelas de incidentes, acoes, blocks e relatorios; indices | Alta candidata | Validar cascades, timestamps e atomicidade de criacao incidente/acao/notificacao. |
| `004_emergency_recovery_backup.sql` | estado de seguranca e outbox de password reset; INSERT OR IGNORE | Alta candidata | Manter unicidade do estado e outbox single-use; nao portar backup filesystem. |
| `005_market_logistics.sql` | `ALTER TABLE` com FK nullable e indices market/logistica | Media/Alta | Testar alteracao de coluna referenciada e retencao de index. |
| `006_admin_chief_identities.sql` | `visibilidade`, saneamento de duplicados, indice parcial e 3 triggers | Media | Expression/partial index e triggers dependem de teste na versao D1; `ALTER` e triggers nao devem ser assumidos como drop-in. |
| `007_profile_type_and_reserved_registration.sql` | coluna/check `tipo_perfil`, backfill, DROP TRIGGER | Media | DDL incremental e triggers: ensaiar na copia de schema; nao reordenar historico. |
| `008_reserved_admin_bootstrap.sql` | UPDATE com subquery/CASE/COALESCE e INSERT SELECT com `json_object` | Media/Alta | Funcoes JSON/SQL sao candidatas; validar JSON1, FKs e auditoria antes de aplicar. |
| `009_normalized_unique_emails.sql` | TEMP table, CTE, `ROW_NUMBER`, `lower/trim`, `hex(CAST AS BLOB)`, `randomblob`, `json_object`, unique expression index | Media/Baixa ate provar | Window/JSON podem existir no SQLite D1, mas TEMP table e migracao multi-statement requerem prova. Em tabela grande, impacto de copy/locks. |
| `010_separate_authorization_and_profile.sql` | cria `profiles_rebuild`, self-FK, insert-select, DROP/RENAME, triggers | Baixa como drop-in | `db.mjs` desliga FK por PRAGMA antes da transacao. PRAGMA nao portavel; DROP da tabela referenciada e a troca precisam de desenho D1 especifico e teste integral. |

`server/db.mjs` tambem cria `_agrolink_migrations`, varre arquivos por filesystem, aplica cada arquivo em `BEGIN`/`COMMIT`, faz rollback e tolera duplicate-column em migrations posteriores. O runner D1 deve substituir essa descoberta/execucao por migrations versionadas Wrangler/CI; nao reutilizar o runner Node no Worker.

## SQL runtime e adaptacao

Inventario medido nos modulos runtime `index.mjs`, `db.mjs`, `backup.mjs`, `news.mjs`, `securityTrust.mjs`, `localAi.mjs`: 175 callsites `db.prepare(...)`, 16 `db.exec(...)`. Nao sao 175 queries unicas: o mesmo callsite executa em multiplos requests.

### Candidatos diretos, ainda a validar

- `SELECT/INSERT/UPDATE/DELETE`, joins, subqueries, `CASE`, `COALESCE`, `LOWER`, `TRIM`, `COUNT`, `ORDER BY`, `LIMIT`.
- `CHECK`, `UNIQUE`, PK composta, FK/cascade, defaults, indices B-tree.
- placeholders posicionais `?` (D1 `prepare().bind(...)`), `ON CONFLICT ... DO UPDATE`, `INSERT OR IGNORE`.
- `json_extract`, `json_object`, `strftime`, `randomblob`, CTEs/window functions pertencem ao ecossistema SQLite, mas precisam de smoke com runtime/versao D1 escolhida.

### Incompativeis ou com mudanca de contrato

- `DatabaseSync`/`.get/.all/.run` sao sync; D1 exige await e retorna envelopes (`results`, `meta.changes`, `success`). Adaptar 175 callsites atras de repositories, evitando mudar regras de negocio.
- `db.exec` e transacoes explicitas `BEGIN IMMEDIATE`, `BEGIN`, `COMMIT`, `ROLLBACK`: substituir sequencias atomicas por `env.DB.batch([...])` onde o batch transacional for adequado, ou Durable Object para coordenacao/serializacao. Testar register, bootstrap, upload associacao, relatorio/resposta, denuncia/historico e incidentes/acoes/notificacao. Nao dividir um use-case atomico em awaits independentes.
- `PRAGMA foreign_keys`, `journal_mode=WAL`, `busy_timeout`, `foreign_keys OFF/ON` e `PRAGMA integrity_check`: configuracao SQLite local; nao transportar para D1.
- `VACUUM INTO`, abrir outro `DatabaseSync` para integridade, `rowid=last_insert_rowid()`, `changes` do Statement: rever um a um. O fallback `rowid/last_insert_rowid()` ocorre no insert generico; usar ID explicito ou resultado D1.
- `INSERT OR IGNORE` e `ON CONFLICT` podem ser SQL valido, mas a forma de detectar conflito deve ler `meta.changes`/resultado.
- SQL dinamico de tabela/colunas e montado no generic `/api/data/:table`; as allowlists existentes devem continuar sendo a unica fonte de nomes SQL. Valores permanecem bind parameters.
- `strftime('%m/%Y', ...)` em resumo mensal: preferir limites UTC de intervalo (`>=` e `<`) para portabilidade, indice e timezone previsivel.
- JSON e armazenado como TEXT e convertido por `hydrate/jsonColumn`; preservar a forma de retorno ou planejar migracao separada para colunas JSON/objetos.

### Integridade e concorrencia

As rotinas atuais dependem de transacao SQLite local para consistencia; a API usa updates condicionais em estados de transporte e `BEGIN IMMEDIATE` em bootstrap/registro. Antes de D1: testes de concorrencia de aceitar pedido, email unico normalizado, idempotencia report/media, suspensao+revogacao de sessao, resposta+mudanca de estado e incidente+block/action. Revalidar FKs e `ON DELETE` com `PRAGMA foreign_key_check` local e queries de orphan em D1 de teste; nao copiar WAL/arquivo SQLite como forma de migracao.

Backups atuais dependem de `VACUUM INTO`, `PRAGMA integrity_check` e limpeza de arquivos. D1 requer export/snapshot/backup do mecanismo Cloudflare e validacao independente; o scheduler Node nao e portavel.

## Prototipo futuro (sem executar nesta etapa)

1. Preservar `server/db.mjs` e todos os testes Node.
2. Definir interfaces de repositorio assíncronas e contracts para tabelas/transactions.
3. Implementar adapter SQLite async-compatible ou wrapper de compatibilidade no Node e rodar os mesmos use-cases.
4. Criar database local descartavel D1/Wrangler somente quando houver autorizacao para provisionar localmente; testar cada migration em copia.
5. Reescrever migrations `006-010` para o esquema D1 depois de ensaiar a reconstrucao de `profiles`; export/import e reconciliation antes de qualquer cutover.

**Estado D1: MAPEADO / PROBLEMAS.** SQL central e SQLite-like, mas runner sync, PRAGMAs, transacoes, backups, `rowid`, TEMP table e reconstrucao `010` impedem declarar compatibilidade direta. Nada foi provisionado.


# AgroLink Caop 2.0 — Plano de Implementação v1 (Integrada)

## Mudança de estratégia

Antes: fases isoladas e sequenciais. Agora: **uma primeira versão completa e
funcional de todos os módulos pedidos**, seguida de ciclos de melhoria sobre
essa base. Isto muda uma decisão importante: módulos como SIE, Mercado,
mapas e sensores **não** ficam de fora — ficam com schema de base de dados
pronto e um ponto de entrada na navegação, mas com profundidade mínima
("preparado para iterar", não "ausente"). Cada ciclo seguinte aprofunda um
módulo de cada vez, sobre uma base já coesa.

## Escopo desta entrega

| Módulo | Profundidade nesta v1 |
|---|---|
| Auth + perfis + permissões | **Completo** (herdado da Fase 1, já aprovado) |
| Relatos (com fotos/áudio) | **Completo**: CRUD, upload, offline, sync |
| Relatos sem cadastro (código único) | **Completo**: criação e consulta por código |
| Sincronização offline | **Completo**: fila local + resolução de conflitos simples |
| Respostas dos técnicos | **Completo** |
| Notícias | **Completo**: listagem pública + CRUD admin |
| Alertas | **Completo**: listagem por província + CRUD admin |
| Assistente IA agrícola | **Funcional**: chat com proxy seguro (Edge Function) |
| Painel administrativo | **Funcional**: utilizadores, ativação/bloqueio, verificação de técnicos, moderação de notícias/alertas |
| Painel técnico | **Funcional**: relatos da sua zona, responder, estado |
| Estatísticas iniciais | **Básico**: contagens e agregações simples (view SQL) |
| SIE | **Preparado**: tabela `sie_indicadores` + página placeholder |
| Mercado AgroLink | **Preparado**: tabela `mercado_produtos` + página placeholder |
| Mapas | **Preparado**: coluna `geography` em `exploracoes`/`relatos` + página placeholder |
| Sensores | **Preparado**: tabela `sensores` + `leituras_sensor` + página placeholder |

## Arquitetura

```
PWA (React+TS, offline-first)
 ├─ IndexedDB (Dexie): fila de relatos por sincronizar + cache de leitura
 ├─ Service Worker: assets + navegação offline
 └─ Supabase JS client
        │
        ▼
Supabase
 ├─ Auth (JWT) ─────────────► profiles (papel, status, verification_status)
 ├─ Postgres + RLS ─────────► relatos, relato_midias, relato_respostas,
 │                             noticias, alertas, ia_conversas/mensagens,
 │                             sie_indicadores*, mercado_produtos*, sensores*
 ├─ Storage ────────────────► fotos e áudios de relatos (bucket "relatos")
 └─ Edge Functions (Deno) ──► ia-agricola-proxy (chama o LLM com a chave
                               protegida no servidor), stats-agregadas
```
`*` = tabela criada nesta versão, sem UI de profundidade ainda.

## Base de dados — visão completa (novas tabelas desta entrega)

**`relatos`**
`id, autor_id (nullable), codigo_publico (nullable), tipo, descricao, provincia, municipio, comuna, localizacao (geography, nullable), status [pendente|em_analise|resolvido], tecnico_atribuido_id, criado_em, atualizado_localmente_em`
— `autor_id` nulo + `codigo_publico` preenchido = relato sem cadastro.

**`relato_midias`**
`id, relato_id, tipo [foto|audio], caminho_storage, criado_em`

**`relato_respostas`**
`id, relato_id, tecnico_id, comentario, criado_em`

**`noticias`** / **`alertas`** — como definido no plano original (Fase 0).

**`ia_conversas`** / **`ia_mensagens`** — como definido no plano original.

**`sie_indicadores`**, **`mercado_produtos`**, **`sensores`**, **`leituras_sensor`**
— schema mínimo, RLS fechado a admin/técnico por agora; sem UI de profundidade.

## Sincronização offline — desenho

1. Utilizador cria relato offline → grava em IndexedDB (`fila_relatos`) com um `id` local (UUID) e `sincronizado = false`.
2. Um `syncEngine` corre ao detetar rede (`online` event) e periodicamente: percorre a fila, envia cada relato pendente (incluindo upload de mídias do IndexedDB para o Storage), e marca `sincronizado = true` ao confirmar.
3. Conflito só pode acontecer em **respostas** a um relato já sincronizado por outro dispositivo — resolvido por `last-write-wins` com registo em `relato_respostas` (é um histórico, não um valor único, por isso não há conflito real de escrita).

## Estrutura de pastas (acréscimos à Fase 1)

```
src/
├── features/
│   ├── relatos/         (novo)
│   ├── tecnico/         (novo — painel técnico)
│   ├── admin/           (novo — painel admin)
│   ├── noticias/        (novo)
│   ├── alertas/         (novo)
│   ├── ia-agricola/     (novo)
│   └── auth/            (Fase 1)
├── offline/              (novo — Dexie + syncEngine)
└── shared/
    └── future/           (novo — placeholders SIE, Mercado, Mapas, Sensores)
supabase/
├── migrations/
│   ├── 0001, 0002        (Fase 1)
│   ├── 0003_relatos.sql
│   ├── 0004_comunicacao.sql
│   ├── 0005_estatisticas.sql
│   └── 0006_preparacao_futura.sql
└── functions/
    └── ia-agricola-proxy/
```

## Ordem de construção desta entrega

1. Base de dados completa (todas as migrações 0003–0006).
2. Motor offline (Dexie + syncEngine) — infraestrutura partilhada por relatos.
3. Módulo Relatos (CRUD + fotos/áudio + código público + offline).
4. Painel técnico (responder relatos).
5. Painel admin (utilizadores + moderação + estatísticas).
6. Notícias + Alertas.
7. Assistente IA agrícola (Edge Function + chat).
8. Placeholders preparados: SIE, Mercado, Mapas, Sensores.

Vou seguir esta ordem na implementação.

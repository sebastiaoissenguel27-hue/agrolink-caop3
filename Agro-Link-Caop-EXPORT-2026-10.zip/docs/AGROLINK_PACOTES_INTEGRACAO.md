# AgroLink Caop — auditoria e integração dos Pacotes 1–9

Data da integração: 2026-09-07.

Este documento regista o que foi comparado e integrado a partir de
`AGROLINK_RECOVERY.md`, Pacote 1 e Pacotes 2–9. O Recovery foi tratado como
referência auditável; não foi assumido como autoridade sobre o código real sem
confirmar a árvore restaurada.

## Estado encontrado

O workspace de trabalho não tinha uma árvore de aplicação antes desta sessão:
continha apenas os anexos. A árvore web recuperada foi restaurada do Recovery
para permitir a continuação controlada. A pasta Android/Capacitor não foi
restaurada nesta fase, conforme a restrição do pedido.

O código recuperado é:

- React + TypeScript + Vite;
- React Router, Supabase Auth/Database/Storage/Edge Functions;
- Dexie para filas e caches offline;
- `vite-plugin-pwa`;
- IA já existente em `src/features/ia-agricola`, através de Edge Function com
  Gemini.

Os relatórios dos Pacotes 1–9 descrevem uma outra stack hipotética
(Wouter/Tailwind/Express/Drizzle/JWT/OpenAI) e dizem explicitamente que foram
preparados sem acesso ao projeto real. Por isso, esses componentes não foram
copiados cegamente nem foram introduzidos Wouter, Tailwind, Express, Drizzle,
JWT ou uma segunda implementação de IA.

## Inventário e decisão por pacote

| Pacote | Verificação no código recuperado | Decisão |
|---|---|---|
| 1 — UI/fundação | Havia layout, dashboard, tokens e PWA, mas faltavam componentes UI reutilizáveis e ícones válidos no Recovery | Integrados componentes compatíveis com React Router/CSS existente; dashboard ligado a dados reais; assets oficiais de marca/PWA restaurados |
| 2 — Relatos + alertas | Já existem serviços, páginas, relato anónimo, filas offline, respostas técnicas e alertas | Preservados; não foram duplicados com os componentes “burros” do pacote |
| 3 — Assistente IA | `IAChatPage` e `iaService` já implementam histórico, erro, multimédia, confiança, encaminhamento e TTS | Preservados; não foi criada segunda IA nem trocado o fornecedor |
| 4 — Conteúdo | Notícias, Biblioteca e Academia têm páginas, serviços, cache e área administrativa | Preservados; não foi inventado conteúdo |
| 5 — Ferramentas | Existem calculadoras e calendário agrícola em `features/ferramentas`; não existe integração meteorológica confirmada | Calculadoras/calendário preservados; `WeatherCard` não foi ativado sem fonte de tempo real |
| 6 — Acesso | AuthContext, Supabase Auth, páginas de login/registo e ProtectedRoute já existem | Preservados; formulários JWT/Wouter especulativos não foram copiados |
| 7 — PWA | Service worker e manifest já existiam, mas os ícones do Recovery estavam ausentes/placeholders | Ícones oficiais, favicon, apple-touch-icon, instalação pelo browser e aviso de atualização integrados |
| 8 — UX | Não havia 404 global nem primitives genéricas suficientes | Breadcrumbs, confirmação, feedback e 404 adicionados sem alterar os fluxos de domínio |
| 9 — documentação/testes | Havia documentação de auditoria, mas não a matriz desta integração | Este inventário e a matriz de 20 fluxos foram adicionados |

## Componentes UI integrados

Os componentes ficam em `src/shared/components/` e usam os tokens/CSS já
existentes, em vez de impor Tailwind:

- `Logo`, `Button`, `Card`, `StatusBadge`;
- `PageContainer`, `PageHeader`, `EstadosInterface`;
- `BottomNav`;
- `ui.css`.

`AppHeader` foi extraído para `src/app/components/AppHeader.tsx` e mantém a
lógica existente de sessão, notificações, sincronização, perfil e logout.
`AppLayout` continua a ser o layout único das rotas autenticadas.

## Matriz de integração real

| Área | Implementação atual | Fonte de dados/ação | Estado |
|---|---|---|---|
| Dashboard agricultor | `features/agricultor/pages/AgricultorDashboard.tsx` | serviços de relatos/notícias/alertas + Dexie | integrado |
| Relatos | `features/relatos/pages`, `api`, `components` | Supabase e fila offline | preservado |
| Alertas | `features/alertas/pages` e `api` | Supabase + cache local | preservado |
| Assistente | `features/ia-agricola/pages/IAChatPage.tsx` e `api/iaService.ts` | Edge Function existente | preservado |
| Notícias | `features/noticias` | serviço e cache/Edge Function existentes | preservado |
| Biblioteca | `features/biblioteca` | Supabase Storage/Database | preservado |
| Academia | `features/academia` | Supabase + progresso offline | preservado |
| Calculadoras/calendário | `features/ferramentas` | serviço e fórmulas existentes | preservado |
| Meteorologia | nenhum serviço confirmado | nenhuma fonte inventada | pendente |
| Auth | `features/auth` + `ProtectedRoute` | Supabase Auth | preservado |
| PWA | `vite.config.ts`, `main.tsx`, componentes PWA | browser/service worker | integrado |
| 404 | `PaginaNaoEncontradaPage` + `Route path="*"` | router existente | integrado |

## Matriz dos 20 fluxos de validação

Esta é uma matriz de validação do projeto real, não uma declaração de que os
fluxos remotos já foram executados. “Build” abaixo significa validação local
do bundle; Auth, Supabase e notificações remotas ainda requerem ambiente de
teste configurado.

| # | Fluxo | Código de entrada | Resultado esperado | Estado |
|---:|---|---|---|---|
| 1 | Visitante abre a landing | `/`, `/visitante` | landing ou escolha de país | código presente |
| 2 | Registo válido/inválido | `/registar` | sucesso ou erro seguro | código presente |
| 3 | Login válido/inválido | `/entrar` | sessão ou mensagem segura | código presente |
| 4 | Dashboard agricultor | `/` autenticado | resumo e estados de dados | código + build |
| 5 | Perfil | `/perfil` | consultar/editar perfil | código presente |
| 6 | Assistente | `/assistente` | resposta, loading, erro e multimédia | código presente |
| 7 | Criar relato | `/relato-anonimo` ou fluxo autenticado | confirmação/código e fila offline | código presente |
| 8 | Lista de relatos | `/relatos` | lista, filtros e estados | código presente |
| 9 | Detalhe de relato | fluxo de relatos | histórico e mídia | código presente |
| 10 | Acompanhamento | relato enviado | estados local/servidor | código presente |
| 11 | Resposta técnica | `/tecnico` | resposta visível ao agricultor | código presente |
| 12 | Alertas | `/alertas` | severidade, lista e cache | código presente |
| 13 | Notícias | `/noticias` | pesquisa, categoria e detalhe | código presente |
| 14 | Biblioteca | `/biblioteca` | pesquisa, categoria e documento | código presente |
| 15 | Academia | `/academia` | cursos, lições e progresso | código presente |
| 16 | Calculadoras | `/ferramentas` | fórmulas existentes e histórico | código presente |
| 17 | Calendário agrícola | `/ferramentas` | eventos disponíveis | código presente |
| 18 | Logout | header/perfil | sessão terminada e retorno ao login | código presente |
| 19 | PWA | manifest/service worker | assets válidos e atualização | build + código |
| 20 | Instalação | `InstallAppButton` | prompt Android/desktop e instrução iOS | código; browser real pendente |

Em cada fluxo, a validação completa deve cobrir loading, vazio, erro, offline,
voltar, largura mobile (320–430px) e desktop. A validação real de Auth, RLS,
Edge Functions e Storage exige um Supabase de teste; nenhuma migration ou
deploy remoto foi executado por esta integração.

## Verificações executadas

- `npm install --ignore-scripts --no-audit --no-fund` — concluído; apenas avisos
  de dependências transitivas deprecated.
- `npm run build` — concluído: TypeScript e Vite passaram; manifest/service
  worker gerados.
- As dependências Capacitor do Recovery foram removidas do `package.json` e do
  lockfile porque a árvore Android não foi restaurada nesta fase. O suporte
  Node usado pelo teste TypeScript existente ficou declarado explicitamente em
  `@types/node`.
- O script `lint` do Recovery não foi mantido: não havia ESLint nem configuração
  ESLint no workspace; adicionar uma ferramenta de lint seria uma mudança de
  escopo sem regras verificadas.
- O build emite apenas o aviso existente de bundle JavaScript superior a
  500 kB; não foi feita uma migração de arquitetura só para eliminar esse
  aviso.
- Nenhum segredo foi criado, exposto ou incluído no frontend.

## Pendências honestas

- Testar Auth, RLS, Storage e Edge Functions num Supabase de staging.
- Testar instalação em Chrome Android e fallback Safari iOS.
- Decidir separadamente se o download Android deve voltar numa fase futura.
- Avaliar code splitting do bundle grande sem alterar comportamento.
- Não implementar `WeatherCard` até existir integração de meteorologia e contrato
  de dados confirmado.
# Mapa de Migracao de Uploads para R2

Estado: inventario e desenho. Nenhum objeto foi copiado para R2; os arquivos locais continuam intactos. R2 ainda nao foi provisionado.

## Convencoes atuais

- Diretorio base `UPLOADS = AGROLINK_UPLOADS_DIR || DATA_DIR/uploads`, criado no startup de `server/index.mjs`.
- Areas permitidas: `relatos`, `biblioteca`, `academia`.
- Key relativa: `<area>/<uuid-ou-uploadId>-<nome-sanitizado>`; o caminho relativo e persistido em `caminho_storage` nas tabelas SQL.
- `apiUpload`/`apiUploadBlob` leem `File`/`Blob` inteiro em `arrayBuffer`, convertem para Base64 e enviam JSON. O backend decodifica todo o body em memoria.
- Tamanho: body JSON parser limita 25 MiB; upload decodificado limita 18 MiB (Base64 ate 24 MiB); arquivo vazio/Base64 invalido e rejeitado. Sao limites de aplicacao, nao limites R2.
- `mimeType` e enviado pelo cliente, mas a gravacao atual nao confirma magic bytes nem exige MIME permitido; a resposta GET deriva Content-Type da extensao.

## Operacoes de filesystem/upload

| Arquivo e funcao/rota | Finalidade | Autorizacao atual | Operacao atual | Equivalente futuro R2 |
|---|---|---|---|---|
| `server/index.mjs` startup (`fs.mkdirSync(UPLOADS)`) | Criar raiz de armazenamento | Configuracao de processo, sem usuario | mkdir | Remover; binding `R2Bucket` nao requer diretório. |
| `server/index.mjs`, POST `/api/media/upload/:area` | Receber foto/audio de relatos ou documentos de academia/biblioteca | `requireAuth`; qualquer usuario autenticado em `relatos`; `canWriteAdmin` para `biblioteca` e `academia`; rejeita area fora da allowlist | Base64 decode, valida tamanho e UUID, construi key, `mkdirSync`, `existsSync/readFileSync` para idempotencia/hash, `writeFileSync` novo objeto | Fazer `bucket.put(key, stream/body, {httpMetadata})`; R2 nao tem `existsSync`; para idempotencia ler metadata/ETag ou manter hash/estado de upload no D1. Preferir upload streaming ou URL de upload controlada em vez de Base64. |
| `server/index.mjs`, POST `/api/data/relato_midias` | Associar key a relato depois do upload | Requer sessao; relato tem de existir; owner ou admin; valida prefixo `relatos/`, containment e existencia de arquivo; ID idempotente | Verifica filesystem e insere linha `relato_midias` | `HEAD`/`get` no binding R2 + insert D1; idealmente reconciliar falhas entre put e insert. Manter `UNIQUE(relato_id,caminho_storage)`/idempotencia. |
| `server/index.mjs`, GET `/api/media/:path` | Servir mídia privada/documentos | Requer `currentUser`; em `relatos` permite owner/admin/técnico aprovado; em `biblioteca`/`academia` exige metadata SQL; perfil/status e escopo do curso requerem revisao antes de manter o mesmo contrato | Resolve caminho, containment, `existsSync/statSync`, `createReadStream`; Content-Type por extensao; cache private 600s | Buscar metadata em D1 para autorização, depois `bucket.get(key)` e stream via Response; `private, max-age` apenas após confirmar identidade/ownership. Alternativa: URL assinada curta depois da autorização. |
| `src/offline/syncEngine.ts`, `enviarRelato` | Repetir upload offline com ID estável e depois inserir metadados | Fila scoped por `autorId`; API faz verificacao de owner | `apiUploadBlob` com `uploadId` UUID; em conflito compara SHA-256 dos bytes existentes | Manter idempotency key, hash e outbox/estado D1; operações R2+D1 não são uma transação única, logo retries/reconciliacao sao obrigatorios. |
| `src/features/academia/api/academiaService.ts`, `carregarFicheiroAcademia` | Upload administrativo de arquivo de lição | Endpoint backend limita a admin de escrita | `apiUpload` em Base64 para area `academia`; `caminho_storage` salvo em `academia_licoes` | R2 put + D1 metadata de licao; GET precisa validar licao/curso antes de devolver objeto. |
| `src/features/biblioteca/api/bibliotecaService.ts`, `carregarFicheiroBiblioteca` | Upload administrativo de documento | Admin de escrita | `apiUpload` Base64 para `biblioteca`; key salva em `biblioteca_documentos` | R2 put + D1 metadata; servir via Worker autenticado ou URLs curtas conforme politica de documentos. |
| `server/index.mjs`, GET static `dist/*` e SPA fallback | Servir frontend, SW, manifest, icons | Publico | `existsSync`, `statSync`, `createReadStream` sobre diretório `dist` | Nao e R2 por padrao: Worker Static Assets ou Pages. Separar mídia privada de assets publicos. |
| `server/backup.mjs`, `createDatabaseBackup/listDatabaseBackups/pruneDatabaseBackups` | Backup e retencao do SQLite | Endpoint de backup e exclusivo Admin Chefe; scheduler local diario | `VACUUM INTO`, `statSync`, abre outro `DatabaseSync`, `integrity_check`, `readdirSync`, `rmSync` | Nao mapear para upload media. D1 export/backup e armazenamento externo R2 exigem fluxo proprio, checksums, retencao e restore testado. |
| `server/db.mjs`, loader de migrations | Ler SQL de disco | Runtime | `readdirSync/readFileSync` em `server/migrations` | Pipeline `wrangler d1 migrations`/release fora do request Worker; nao R2. |

## Autorizacao e modelo de objeto

- A tabela `relato_midias` liga `relato_id`, tipo e `caminho_storage`; o relato define owner/visibilidade. Preservar a politica server-side antes de `get` em R2.
- `biblioteca_documentos.caminho_storage` e `academia_licoes.caminho_storage` sao referencias em D1. O objeto sem metadata nao deve ser servico publico.
- A rota de leitura usa `currentUser` e checa as associacoes de tabela; ao portar, centralizar uma funcao de autorizacao por area/objeto. Validar explicitamente status pendente/bloqueado e visibilidade do curso.
- Deletes genericos de linhas metadata nao removem arquivo do filesystem hoje. Isso pode deixar objetos orfaos; manter estado/outbox ou job de reconciliacao R2, sem excluir durante a primeira migracao.
- Keys atuais contêm UUID e nome sanitizado, mas o cliente ainda escolhe nome/extensao. Na arquitetura R2, key opaca UUID, MIME permitido por area, checksum e tamanho devem ser validados no servidor; nao confiar no Content-Type do cliente.

## Sequencia recomendada

1. Extrair `MediaRepository`/`ObjectStore` com contrato `put/get/head/delete` e manter adapter filesystem testado no Node.
2. Fazer os endpoints consumirem esse contrato sem alterar APIs ou ownership.
3. Adicionar testes de upload, retry/idempotencia, acesso cruzado, arquivo orfao e corpo acima do limite.
4. Implementar adapter R2 em ambiente local de teste e verificar streaming/multipart, metadata, CORS e custos.
5. Fazer copia incremental de objetos mantendo IDs/key mapping e reconciliar contagens/hash; nao remover origem ate aprovacao e restore comprovado.

**Estado R2: MAPEADO / PROBLEMAS.** Existem leituras, escritas, verificacoes e backups vinculados diretamente a `fs`; Base64 em memoria, metadata separada e autorizacao por join precisam de adapter e testes de integridade. Nenhum objeto foi movido.

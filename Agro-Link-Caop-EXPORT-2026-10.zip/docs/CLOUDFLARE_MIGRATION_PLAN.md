# Agro Link Caop: Plano de Migração para Cloudflare

## Estado atual
React/PWA + Vite no frontend; API HTTP em Node em `server/index.mjs`; `node:sqlite` persistente e migrations SQL em `server/migrations`; uploads no filesystem local; Security & Trust Layer determinístico; Qwen servido localmente por `localAi.mjs`/llama-server. As sessões usam cookies HttpOnly e a API fornece o contrato consumido pelo frontend.

## Progresso Cloudflare local
O protótipo `worker/index.mjs` usa `D1DatabaseAdapter` e `R2StorageAdapter`. As migrations D1 locais `0001` a `0005` cobrem autenticação/sessões, relatos/denúncias e os módulos de alertas/notificações, logística/mercado, academia, documentos, notícias e restantes tabelas de negócio portadas. Os fluxos de leitura/escrita mantêm os controlos de papel e ownership e são exercitados contra bindings locais do Wrangler.

Relatos e denúncias usam D1 e R2 local; uploads da biblioteca e academia também são guardados no R2 local. A sincronização RSS também está portada: a resolução A/AAAA usa DNS-over-HTTPS através de `fetch`, bloqueia IPs não públicos e IPs literais, usa apenas HTTPS e não segue redirects (revalidando a localização antes de os rejeitar). O parsing partilhado valida XML bem-formado e a persistência/deduplicação e logs usam D1. Não foi feita migração de dados reais nem criado qualquer recurso remoto. Workers AI e Security & Trust continuam fora desta fatia.

## Arquitetura alvo
Frontend React/PWA → Cloudflare Worker/API → D1 + R2 + Workers AI → AI Connector → Qwen Container.

O Worker será a API HTTP; D1 será a base SQL; R2 substituirá os ficheiros locais. Workers AI poderá executar tarefas suportadas diretamente no Worker. Para manter Qwen, o AI Connector ligará o Worker a um Qwen Container externo, em vez de tentar executar llama-server dentro do runtime Workers.

## Adaptações necessárias
| Componente atual | Adaptação necessária | Destino/decisão |
| --- | --- | --- |
| Node HTTP em `server/index.mjs` | Reorganizar rotas sob `fetch(request, env, ctx)`; rever streams, payloads, CORS, cookies, static serving e APIs Node indisponíveis | Cloudflare Workers; definir hosting do frontend Vite |
| `node:sqlite` e `server/migrations/*.sql` | Criar adaptador D1; rever transações, concorrência, prepared statements, funções SQLite, migrations e contratos de linhas | D1, com migração de dados e validação antes do cutover |
| `data/` e filesystem de uploads | Substituir `fs` por bindings R2; guardar chaves e metadados no D1; validar autorização, limites, integridade, retenção e cópia | R2, privado por omissão |
| Cookies HttpOnly e tabela `sessoes` | Preservar HttpOnly/Secure/SameSite e expiração; decidir D1 ou KV/Durable Objects para revogação e concorrência; rever CSRF e CORS nos domínios finais | Workers e armazenamento de sessões a decidir após protótipo |
| Security & Trust Layer, backups e schedulers | Preservar decisões determinísticas; substituir timers/processos persistentes; redesenhar backups e recuperação | Workers, Cron Triggers/Queues ou serviço dedicado |
| `/api/ia/chat`, `localAi.mjs` e llama-server/Qwen | Isolar contrato de IA; usar Workers AI para tarefas suportadas; configurar AI Connector para Qwen Container com autenticação, limites, timeout, retries e fallback | Workers AI e AI Connector → Qwen Container externo |
| Segredos, URLs e configuração | Retirar dependências de `.env`, caminhos locais e variáveis do host; separar credenciais por ambiente | Secrets e bindings do Worker |

## Ordem recomendada
1. Inventariar rotas, contratos, migrations, jobs, uploads e APIs Node; fixar testes e métricas atuais.
2. Prototipar D1, schema e camada de dados; testar constraints, transações, migração e rollback numa cópia da base.
3. Implementar R2; validar autorização, limites, metadados e integridade de todos os fluxos de ficheiros.
4. Adaptar autenticação/sessões e CSRF; testar expiração, logout, revogação e cookies nos domínios finais.
5. Portar a API para Workers em fatias, removendo dependências Node/filesystem e preservando contratos.
6. Adaptar tarefas de IA a Workers AI; testar latência, limites e fallback.
7. Ligar AI Connector ao Qwen Container; testar autenticação de serviço, disponibilidade, custo e timeouts.
8. Executar testes, typecheck, build e smoke/security/real-use em staging; ensaiar migração, observabilidade e rollback.
9. Fazer cutover gradual só depois de aprovar critérios de aceitação e recuperação.

## Riscos principais
Compatibilidade Node/Workers, diferenças SQL/transacionais, migração de dados, uploads grandes, autorização R2, revogação de sessões, jobs agendados, limites de CPU/subrequests, disponibilidade/custo do Qwen e recuperação/rollback.

## Regra
O trabalho Cloudflare descrito acima é apenas um protótipo local. Os bindings declarados servem Wrangler local; não foram criados recursos Cloudflare remotos, feitos deployments ou migrados dados reais. Qualquer cutover requer plano separado de migração, verificação e rollback.

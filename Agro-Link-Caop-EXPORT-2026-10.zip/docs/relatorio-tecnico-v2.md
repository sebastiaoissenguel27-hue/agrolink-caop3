
# AgroLink Caop 2.0 — Relatório Técnico Final

## 1. Funcionalidades implementadas

### Infraestrutura
- Autenticação Supabase completa (login, registo, **recuperação de palavra-passe**, sessão persistente).
- Perfis com 3 papéis (agricultor, técnico, admin), `status` de conta (ativo/pendente/bloqueado) e `verification_status` exclusivo de técnicos.
- RLS restrita por papel em **todas** as tabelas (não só `profiles`): cada política foi desenhada função a função, sem nenhuma tabela "aberta" por omissão.
- Sistema de **auditoria** (tabela `auditoria`, só gravável pelo servidor via `registar_auditoria()`), com registo automático de: respostas a relatos, mudanças de estado de conta, mudanças de verificação de técnico.
- Sistema de **notificações internas** (tabela `notificacoes`), disparadas automaticamente pelos mesmos eventos, com sino em tempo real no cabeçalho (Supabase Realtime).
- Storage: bucket `relatos` (fotos/áudio) e bucket `documentos` (verificação profissional de técnicos, schema pronto).

### Relatos agrícolas
- Com conta e **sem conta** (código público único, gerado só no servidor).
- **Várias fotografias** por relato + gravação de áudio (MediaRecorder).
- Funcionamento **offline completo**: fila local em IndexedDB (Dexie), sincronização automática ao reconectar, e manual por botão.
- 6 estados visíveis: `pendente`, `sincronizando`, `enviado`, `respondido`, `resolvido`, `erro` (os 3 primeiros são estado local; os últimos 3 vêm do servidor).
- Consulta pública por código (RPC dedicada — nunca lista todos os relatos anónimos).
- Respostas técnicas com notificação automática ao autor.

### Painéis
- **Agricultor**: dashboard com resumo de relatos, alertas e notícias recentes, atalho para a IA.
- **Técnico**: lista filtrável (estado/tipo), vê fotos/áudio (URL assinada, bucket privado), responde, muda estado — bloqueado até `verification_status = 'aprovado'`.
- **Administrador**: utilizadores (ativar/bloquear/promover a admin/aprovar-rejeitar técnicos), notícias (CRUD), fontes de notícias RSS, alertas (CRUD), estatísticas (função segura `obter_estatisticas`), auditoria (só leitura).

### Comunicação
- Notícias: pesquisa, categoria, **cache offline automática**, e **ingestão automática via RSS** (Edge Function `sync-noticias`, deduplicada por `url_original` UNIQUE).
- Alertas: nacional/provincial/municipal (`provincias_alvo`), níveis info/atenção/urgente, cache offline.
- Assistente IA agrícola **multimodal** (texto + foto), com nível de confiança extraído no servidor, **botão "Encaminhar para técnico"** quando a confiança é baixa (cria automaticamente um relato `pedido_apoio`), leitura da resposta em voz (Web Speech API), histórico persistente e cache offline.

### Preparado para ciclos futuros (schema pronto, sem UI de profundidade)
SIE (`sie_indicadores`), Mercado AgroLink (`mercado_produtos`), Mapas (`geography` em `relatos`), Sensores IoT (`sensores`, `leituras_sensor`), push notifications (`dispositivos_push` — falta a integração real com FCM/APNs).

## 2. Ficheiros criados nesta última etapa

```
src/app/pages/PerfilPage.tsx
src/features/agricultor/pages/AgricultorDashboard.tsx
src/features/ia-agricola/pages/IAChatPage.tsx
src/features/admin/components/AdminFontesNoticias.tsx
supabase/migrations/0010_noticias_fonte_e_deduplicacao.sql
supabase/functions/sync-noticias/index.ts
```

## 3. Ficheiros alterados nesta última etapa

```
src/app/pages/HomePage.tsx          → agora despacha por papel em vez de placeholder
src/app/App.tsx                     → todas as rotas ligadas ao AppLayout/ProtectedRoute
src/features/auth/api/authService.ts → atualizarPerfilProprio()
src/features/ia-agricola/api/iaService.ts → obterConversaAtual(), encaminharConversaParaTecnico()
src/features/noticias/api/noticiasService.ts → gestão de fontes + sincronização manual
src/features/admin/pages/AdminPage.tsx → nova aba "Fontes de notícias"
src/features/admin/components/AdminUtilizadores.tsx → botão "Promover a admin" (existia a função, faltava o botão)
src/features/relatos/api/relatosService.ts → correção de bug (ver secção 5)
src/shared/types/database.types.ts  → url_original/fonte_id, NoticiaFonteInsert
README.md                           → passos de deploy das Edge Functions e migração 0010
```

## 4. Estrutura final do projeto

```
agrolink-caop/
├── src/
│   ├── app/                 (rotas, layout, páginas de sistema, perfil)
│   ├── features/
│   │   ├── auth/             autenticação e recuperação de password
│   │   ├── relatos/          CRUD + offline + código público
│   │   ├── agricultor/       dashboard
│   │   ├── tecnico/          painel técnico
│   │   ├── admin/            painel administrativo (6 abas)
│   │   ├── noticias/         listagem + fontes RSS
│   │   ├── alertas/          listagem + gestão
│   │   └── ia-agricola/      chat multimodal
│   ├── offline/              Dexie + motor de sincronização
│   └── shared/                cliente Supabase, tipos, notificações
└── supabase/
    ├── migrations/            0001 → 0010
    └── functions/
        ├── ia-agricola-proxy/ (chat multimodal seguro)
        └── sync-noticias/     (ingestão RSS automática)
```

## 5. Testes executados e correções

Sem acesso à rede neste ambiente não foi possível correr `npm install` / `npm run build` reais (confirmado: `npm error 403` ao tentar). Em alternativa, corri uma **auditoria estática automatizada** em cada bloco:
- Resolução de todos os imports `@/...` contra os exports reais de cada ficheiro.
- Equilíbrio de chavetas/parênteses em todos os `.ts`/`.tsx`.
- Ordem de dependência das migrações SQL (tipos/funções usados só depois de criados; políticas com o mesmo nome sempre precedidas de `drop policy if exists`).

**Bugs encontrados e corrigidos:**
1. `relatosService.ts` — a função `obterRespostas` tinha perdido a linha de assinatura numa edição anterior, deixando o corpo órfão (o painel técnico rebentaria ao carregar respostas). Corrigido.
2. `NoticiaFonteInsert` — o tipo exigia sempre `ativo`, mas a base de dados já lhe dá valor por omissão (`true`). Corrigido com um tipo de Insert dedicado.
3. `promoverAAdmin` — a função já existia no serviço admin, mas não estava ligada a nenhum botão (não havia forma real de criar o primeiro admin pela interface). Adicionado o botão com confirmação.

**Recomendação para o próximo ciclo**: correr `npm install && npm run build` num ambiente com rede antes de ir para produção — a auditoria estática apanha erros estruturais, mas não substitui a verificação de tipos completa do `tsc`.

## 6. Melhorias de segurança feitas além do pedido

- Proibição de autorregisto como `admin` reforçada a **dois níveis**: UX (formulário) e RLS (`with check papel <> 'admin'`) — mesmo contornando o frontend, a base de dados recusa.
- Mudança de `papel`/`status`/`verification_status` por um utilizador normal é bloqueada por **trigger** (`proteger_campos_sensiveis`), não só por política — mais difícil de contornar do que uma cláusula `with check`.
- Auditoria e notificações só são graváveis por **funções `SECURITY DEFINER`** — não existe política de `INSERT` direta para nenhum cliente, autenticado ou não.
- Consulta de relatos sem cadastro feita via **RPC dedicada** (`consultar_relato_por_codigo`), nunca por `SELECT` direto — impossível listar todos os relatos anónimos.
- `sync-noticias` usa a **service role só dentro da Edge Function** (nunca exposta ao cliente) para poder escrever em `noticias` sem depender de um utilizador admin autenticado no momento da sincronização automática.
- Bucket `documentos` com política de storage restrita por pasta (`storage.foldername(name)[1] = auth.uid()`) — cada técnico só acede aos seus próprios documentos.

## 7. Melhorias de desempenho feitas além do pedido

- `dexie-react-hooks` (`useLiveQuery`) em vez de *polling* manual para refletir o estado da fila offline — atualização reativa sem re-renderizações desnecessárias.
- Índice `GIN` full-text (`idx_noticias_pesquisa`) para a pesquisa de notícias, em vez de `ILIKE` sequencial em tabelas grandes.
- URLs assinadas do Storage geradas só quando o técnico abre um relato (não pré-carregadas em lote).
- Cache offline (Dexie) para notícias e alertas serve de "cache de leitura" mesmo online — reduz pedidos repetidos ao Supabase em navegação normal, não só quando offline.

## 8. Melhorias de UX feitas além do pedido

- Debounce de 300ms na pesquisa de notícias (evita disparar uma query por tecla).
- Layout partilhado (`AppLayout`) com navegação adaptada ao papel — um agricultor nunca vê um link para `/admin`.
- Confirmação (`window.confirm`) antes de promover alguém a admin — ação sensível e de alto impacto.
- Indicador visível "X por sincronizar" em qualquer ecrã (não só na página de relatos), com clique para forçar sincronização.

## 9. Limitações conhecidas (documentadas, não escondidas)

| Item | Estado real |
|---|---|
| Push notifications | Schema pronto (`dispositivos_push`); falta integração com FCM/APNs |
| Parser RSS | Regex funcional para RSS 2.0 comum; não é um parser XML robusto |
| IA — áudio como entrada | Áudio do relato serve para o técnico ouvir; a IA não transcreve áudio ainda |
| IA — vídeo | Não implementado, sem schema dedicado ainda |
| Upload de documentos de técnico | Schema (`tecnico_documentos`) e bucket prontos; sem UI de upload ainda |
| SIE / Mercado / Mapas / Sensores | Schema e RLS prontos; sem interface própria |
| Build real (`tsc`/`vite build`) | Não executável neste ambiente (sem rede); só auditoria estática |

## 10. Próximos passos recomendados

1. Correr a suite de build real (`npm install && npm run build`) num ambiente com rede antes do deploy.
2. UI de upload de documentos de verificação de técnico (o schema já existe).
3. Integração real de push (Firebase Cloud Messaging é o caminho mais direto para Android).
4. Ecrã de mapa (usar `relatos.localizacao`, já preenchível, com uma biblioteca como MapLibre).
5. Primeira interface do SIE: começar por gráficos simples sobre `sie_indicadores`, alimentados por um job periódico que agrega `relatos`.
6. Trocar o parser RSS por uma biblioteca XML dedicada, se as fontes reais tiverem formatos mais irregulares do que RSS 2.0 padrão.

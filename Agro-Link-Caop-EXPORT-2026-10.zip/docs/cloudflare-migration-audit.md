# Auditoria de Preparacao Cloudflare

Data: 2026-10-01
Escopo: somente compatibilidade e planejamento. Nenhum recurso Cloudflare foi criado; nao houve deploy nem migracao de dados.

## Estado observado

- Frontend: React 18 + TypeScript + Vite + PWA/Workbox; o cliente chama caminhos relativos `/api/...` por `fetch(..., credentials: 'include')`.
- API atual: servidor HTTP Node em `server/index.mjs`, porta padrao 8787.
- Persistencia: `node:sqlite` sincronico, arquivo `AGROLINK_DATA_DIR/agrolink.sqlite`, WAL e migrations locais.
- Uploads e backups: filesystem local, configurados por `AGROLINK_UPLOADS_DIR` e `AGROLINK_BACKUP_DIR`.
- IA: `server/localAi.mjs` chama `llama-server` local em `127.0.0.1:8080`; existe fallback OpenAI opt-in. O Qwen Docker atualmente pode estar ativo neste ambiente, mas loopback nao sera acessivel diretamente do Worker.
- Wrangler: ausente. A verificacao nao instalou pacotes. Node `v24.21.0`; npm `11.19.0`.
- Inventario: 10 migrations SQL; 47 tabelas operacionais finais, 21 declaracoes de indices e 5 declaracoes de triggers (3 ativas no final: email reservado imutavel e protecoes de insert/update de profile). Ha 175 callsites `db.prepare` e 16 `db.exec` nos modulos de runtime/infra examinados, e 24 callsites de filesystem nesses modulos.
- HTTP/API: 36 caminhos literais `/api/...` no dispatcher, mais 4 padroes dinamicos (`/api/data/:table`, `/api/media/upload/:area`, `/api/media/:path`, `/api/academia/quiz/:licaoId`): 40 padroes de rota, sem contar OPTIONS e o fallback 404. O dispatcher inclui ainda `/` para SPA.
- Node-only: 8 imports builtin distintos na superficie backend/runtime: `node:crypto`, `node:dns/promises`, `node:fs`, `node:http`, `node:net`, `node:path`, `node:sqlite` e `node:url`; ha 30 referencias diretas a `process.env` nos seis modulos de runtime avaliados.

## Mapa de migracao

| Componente | Atual | Cloudflare alvo | Complexidade | Observacoes |
|---|---|---|---|---|
| SQLite | `DatabaseSync`, arquivo local, WAL, `busy_timeout`, 175 prepared-statement callsites | D1 via repository adapter | Alta | D1 nao e um filesystem SQLite. Reescrever acesso sincrono para API async D1, adaptar resultados/batches e validar constraints/queries. |
| Migrations | 10 SQL em `server/migrations`, lidas pelo filesystem e registradas em `_agrolink_migrations` | `wrangler d1 migrations` ou pipeline SQL controlado | Alta | Nao executar diretamente sem classificar PRAGMAs, transacoes, temp table, trigger e reconstrucao de `profiles`. |
| Uploads/media | Base64 JSON; `fs.writeFileSync`, `fs.createReadStream`; keys `area/uuid-filename`; metadados SQL | R2 privado + metadados D1 | Alta | Requer bindings, streaming, autorizacao por objeto/relato/curso e estrategia de objetos orfaos. O detalhe esta em `cloudflare-r2-migration.md`. |
| Sessoes | Cookies `HttpOnly`, `SameSite=Lax`, `Secure` em prod; token hash SHA-256 na tabela `sessoes` | Worker + D1 (ou Durable Object se surgir requisito de coord. forte) | Media | Manter revogacao/logout, expiracao, cookies e origem same-origin; avaliar dominio final e limites de concorrencia. |
| Auth e recuperacao | PBKDF2-SHA512 sincrono com 210.000 iteracoes; tokens de reset SHA-256; entrega via webhook | Web Crypto async + D1 + Secrets/binding de entrega | Alta | Preservar verificadores existentes e planear verificacao/upgrade de hash; manter tokens single-use, rate limit e revogacao de sessoes. |
| API routes | 36 paths explicitos e 4 familias dinamicas centralizados em `server/index.mjs` | `fetch(Request, env, ctx)` Worker router | Alta | O arquivo mistura HTTP, autorizacao, regras, SQL e filesystem. Manter todos os contratos e cobrir cada rota em port incremental. |
| Security & Trust Layer | `securityTrust.mjs`, SQL persistente, mapa rate-limit em memoria, scheduler `setInterval`, alertas webhook | Worker + D1 + Rate Limiting/DO + Cron Triggers/Queues | Alta | O motor deterministico permanece autoridade; o mapa em memoria perde estado ao escalar/reiniciar e timers Node nao sao runtime Worker. |
| Rate limiting | Map global por processo, limites SQL por IP/usuario e enumeracao de codigo | Cloudflare Rate Limiting + Durable Objects/D1 para contadores de dominio | Alta | Decidir chave/IP confiavel, janela/consistencia e tratamento de bursts. `request.cf` substitui socket/X-Forwarded-For sem confiar em cabecalho arbitrario. |
| IA agricola | `/api/ia/chat` -> Qwen local, health polling, concorrencia 1, timeout; fallback OpenAI opcional | Provider abstraction -> Workers AI binding; alternativamente AI Gateway/Connector para Qwen externo | Alta | Worker nao alcança `127.0.0.1:8080`. Preservar contrato `{conversaId,resposta,confianca}`; detalhes em `cloudflare-ai-migration.md`. |
| Security AI | `securityTrust.mjs` chama parser consultivo em `localAi.mjs`; fallback opcional; decisao continua deterministica | Mesmo provider abstrato sob regras deterministicas | Media/Alta | IA nao pode escolher severidade efetiva, executar acao nem mudar contas/permissoes. Nao atrelar disponibilidade da defesa ao provider. |
| Reports e respostas | SQL em `relatos`, `relato_midias`, `relato_respostas`; autorizacao por autor/tecnico/admin | D1 repository + Worker authorization | Alta | Preservar acesso tecnico cross-provincial e privacidade do agricultor/codigo publico, incluindo limites anti-enumeracao. |
| News e RSS | `news.mjs`, `fetch`, DNS publico validado por `node:dns/promises`, sem redirects, max 2 MiB | Worker fetch + D1; Cron/Queue para sincronizacao | Media/Alta | Reimplementar verificacao anti-SSRF em runtime Workers; fonte, URL e logs continuam server-side. |
| Alertas/notificacoes | SQL D1-alvo, escopo por usuario; frontend cache IndexedDB | D1 + Queue opcional/Web Push binding externo | Media | Notificacoes internas nao equivalem a entrega push/email; manter leitura e isolamento de caches offline. |
| Academia | Cursos, licoes, quizzes e progresso em SQL; uploads locais | D1 + R2 | Media/Alta | Preservar correcao do quiz no servidor, nao expor `resposta_correta` e manter progresso offline scoped. |
| Market | Produtos e ownership em SQL | D1 | Media | Revalidar uniqueness, filtros, checks de preco/quantidade e ownership concorrente. |
| Logistics/transportadores | Pedidos, estados, cadastro/verificacao e directorio em SQL | D1 | Alta | Estados sao mutacoes condicionais/atomicas; concorrencia de aceite precisa de update condicional ou transaction/batch comprovado. |
| Denuncias | Denuncia, historico, notificacoes e auditoria SQL | D1 | Media/Alta | Preservar transacao log/historico/auditoria e governanca Admin Chefe. |
| PWA/offline sync | Vite PWA, service worker cache-first de assets, Dexie/IndexedDB e filas com owner ID | Static assets Worker + IndexedDB existente + API Worker | Media | IndexedDB fica no browser e pode ser reutilizado; alinhar origem final, cookies e retries idempotentes. |
| Static assets | Node serve `dist/` e SPA fallback via `fs` | Worker Assets binding ou Cloudflare Pages | Baixa/Media | Escolher Pages vs Workers Assets; validar fallback SPA, headers CSP, manifest, SW e icones. |
| Runtime/config | `process.env`, `PORT`, paths locais, schedulers e trust proxy | `env` bindings, Secrets, Cron/Queues, bindings D1/R2/AI | Alta | Separar configuracao local e bindings sem quebrar o start Node atual durante convivencia. |
| GitHub/source | Repositorio e scripts atuais | GitHub continua source of code; CI publica artefato em fase futura | Baixa | Nenhum recurso/CI/deploy foi criado nesta auditoria. |

## Separacao de camadas atual e futura

| Camada atual | Superficie principal | Separacao necessaria |
|---|---|---|
| Logica de negocio | Regras embutidas nos ramos de `server/index.mjs`; validacoes em `news.mjs` e `localAi.mjs` | Extrair casos de uso sem HTTP/SQL: autenticacao, reports, admin, media, market/logistics, academia, news e IA. Nao duplicar regras no adapter Worker. |
| HTTP/API | `server/index.mjs`: `http.createServer`, parsing body/cookie, status/headers, CORS/Origin, rotas e static fallback | Criar camada de transporte Worker `fetch(Request, env, ctx)` com handlers comuns/serializacao; conservar adaptador Node como runtime local durante a migracao. |
| Persistencia | `server/db.mjs`, SQL direto no dispatcher e services; `hydrate/jsonColumn` | Introduzir repositories/ports async; implementacoes `infrastructure/sqlite` e futura `cloudflare/d1`. A camada de dominio nao deve importar `db`. |
| Filesystem | `server/index.mjs` media/static, `db.mjs` migrations, `backup.mjs` | Ports de objeto/asset/backup; implementacoes local filesystem e R2/Cloudflare Assets. |
| IA | `server/localAi.mjs`, chamada em `/api/ia/chat`, `securityTrust.mjs` e fallback em `index.mjs` | AI provider interface async; adaptadores `local-ai` e `workers-ai`/AI Connector. Provider devolve resposta/analise tipada; nao recebe autoridade de seguranca. |
| Seguranca | `securityTrust.mjs`, validacao/auth embutida no dispatcher, PBKDF2 e Origin | Separar policy deterministica de armazenamento/transporte; adapters D1, Rate Limiting, Cron/Queue, Web Crypto. |
| Runtime/config | `process.env`, paths, `PORT`, `setInterval`, IP de socket | Config schema tipado: Node process env vs Worker `env`; Cron Trigger para relatorios/backup/scheduler e `request.cf` para IP. |

### Modulos a separar em fases futuras

1. Extrair handlers/use-cases do `server/index.mjs` sem trocar a interface HTTP: `auth`, `profiles/admin`, `reports/media`, `news/alerts`, `academy`, `market/logistics`, `complaints/notifications` e `ia`.
2. Substituir injecao global do singleton `db` por interfaces repository async, mantendo implementacao SQLite do runtime Node.
3. Extrair objeto/media store de `fs` para uma interface com adapters filesystem e R2; manter o caminho local funcional.
4. Isolar `securityTrust` em policy deterministica + repository/clock/rate-limit/notification ports; nao portar timers em processo.
5. Colocar `localAi.mjs` e futuro Workers AI sob provider interface com timeout/validacao comum e fallback explicito.
6. Separar bootstrap Node (`http.createServer`, serving `dist`) do handler HTTP agnostico.

## Dependencias Node-only confirmadas

Imports de builtins nos seis arquivos de runtime ativos: `node:crypto`, `node:dns/promises`, `node:fs`, `node:http`, `node:net`, `node:path`, `node:sqlite`, `node:url` (8 modulos). Tambem existem `process.env` (30 referencias), `Buffer` (RSS), `setInterval().unref()`, `req.socket`/Node streams e `DatabaseSync` sincrono. `server/adminChief.test.mjs` e scripts usam `node:child_process`, `node:sqlite`, `node:net`, `node:fs`, `node:os`; sao ferramentas Node, nao bundle Worker.

## Compatibilidade

**Cloudflare compatibility: REQUER ALTERACAO.** A camada funcional ainda esta acoplada ao runtime, SQL e filesystem Node. A compatibilidade nao foi demonstrada por Worker local/miniflare, e Wrangler esta ausente. Nenhum deployment ou binding foi criado.

Componentes reutilizaveis diretamente ou com alteracao pequena: tipos/interfaces do frontend, contratos HTTP JSON, componentes React, Dexie/IndexedDB, validacoes puras de media, schema conceitual, parse/classificacao pura de RSS, parser/validador de resposta IA e testes de regras puros. Requerem adaptador: auth/crypto, SQL, uploads, provider IA, rate limit, clock/scheduler e notificacoes. Requerem reescrita de runtime: Node HTTP server, migration bootstrap por fs, `node:sqlite`, fs static/media e backup VACUUM.

### Riscos confirmados para resolver antes do cutover

- **Alto, conversas IA:** `/api/ia/chat` aceita `conversaId` enviado pelo cliente. O caminho deve comprovar ownership do ID antes de gravar/consultar mensagens; adicionar teste cross-user antes de portar use-case/repository.
- **Uploads:** a autorizacao e baseada em metadata SQL antes de ler o objeto; repetir no Worker antes de `R2.get`. DELETE de metadata nao remove o objeto local hoje e requer reconciliacao de orfaos.
- **D1/atomicidade:** os prepared statements estao embutidos no dispatcher; portar sem limites transacionais pode quebrar registro, aprovacao, denuncia/auditoria, metadata de upload e estados de logistica.
- **Runtime:** backup diario com `setInterval`, `VACUUM INTO`, serving via filesystem, `node:sqlite`, `node:http`, streams e DNS Node nao existem no mesmo formato em Workers.
- **Auth:** PBKDF2 sincrono precisa de caminho Web Crypto async; validar cookies no dominio final mantendo revogacao, SameSite, Secure, Origin e CSRF.

## Wrangler futuro (conceitual; nao criado)

O alvo precisara de um entrypoint `fetch`, `compatibility_date` suportada e binding de assets para `dist`; bindings nomeados para D1, R2 e AI; secrets para credenciais e URLs de integracao. Tarefas atuais de `setInterval` precisam de Cron Triggers/Queues; rate limiting compartilhado pode exigir binding de Rate Limiting ou Durable Object. `nodejs_compat` so deve ser habilitado se adapters realmente precisarem dessas APIs. Nenhum `wrangler.toml/jsonc` foi criado porque o Worker ainda nao foi implementado e Wrangler nao esta instalado.

## Proximas fases recomendadas

1. Definir binding map/env local e criar harness Workers de teste (sem deployment), deixando Node intacto.
2. Extrair interfaces async de repositories e preservar testes Node/SQLite como baseline.
3. Prototipar D1 com migrations revisadas em banco descartavel local; comparar constraints/queries e exercitar migracao/rollback.
4. Implementar adapter R2 privado e validar upload/download/auth/limites antes de copiar qualquer dado.
5. Adaptar API HTTP com testes de contrato route a route; manter cookies/Origin e adiciona testes CSRF/staging.
6. Portar sessoes/hashing, limiters e Security & Trust com armazenamento compartilhado e Cron/Queues.
7. Introduzir provider Workers AI sem remover Qwen local; comparar respostas, limites, fallback e comportamento deterministico.
8. Servir assets/PWA na origem alvo e validar Android/desktop/offline sob os mesmos dominos/cookies.
9. Fazer ensaio de dados, reconciliacao R2, observabilidade, rollback e criterios de cutover antes de qualquer deployment.

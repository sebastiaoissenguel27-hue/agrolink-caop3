# IA local do AgroLink

O AgroLink usa opcionalmente o Qwen3 1.7B Q4_K_M através de `llama-server`. O GGUF deve permanecer fora deste repositório. No Codespace, o hook `postStartCommand` executa `npm run ai:ensure`, que inicia o container detached, aplica `restart=unless-stopped` e aguarda o health antes de concluir.

## Preparar o modelo

Baixe `Qwen3-1.7B-Q4_K_M.gguf` do repositório público `ggml-org/Qwen3-1.7B-GGUF` para um diretório fora do repositório. No Codespace, use `/workspaces/.codespaces/.persistedshare/agrolink-models/`; esse volume persiste entre reinícios/recriações do container e não é incluído no Git ou ZIP. O AgroLink não faz download automático.

## Configuração

Defina no ambiente do backend:

```dotenv
AGROLINK_AI_MODEL_PATH=/opt/agrolink/models/Qwen3-1.7B-Q4_K_M.gguf
AGROLINK_AGRI_AI_URL=http://127.0.0.1:8080/v1/chat/completions
AGROLINK_AGRI_AI_MODEL=qwen3-1.7b
AGROLINK_AGRI_AI_TIMEOUT_MS=12000
AGROLINK_AGRI_AI_ENABLED=true
AGROLINK_AI_OPENAI_FALLBACK=false
```

## Iniciar e verificar

No Codespace, o serviço inicia automaticamente pelo `postStartCommand`. Para iniciar ou recuperar manualmente o container com a mesma política de health:

```bash
AGROLINK_AI_MODEL_PATH=/workspaces/.codespaces/.persistedshare/agrolink-models/Qwen3-1.7B-Q4_K_M.gguf npm run ai:ensure
npm run ai:health
npm run ai:smoke
```

O script aplica 2 threads, contexto 2048, limite de memória de 7 GiB, CPU (`-ngl 0`) e publica o container somente em `127.0.0.1:8080`. O backend verifica `/health` antes de enviar cada prompt; se o serviço não ficar saudável dentro do timeout configurado, a IA agrícola retorna ao fallback seguro existente. OpenAI permanece desativado por padrão. Para operar sem Docker, os mesmos parâmetros podem ser usados com um binário `llama-server` instalado fora do projeto.

## Estado da validação (2026-09-26)

Runtime real validado no Codespace: health saudável, `ai:smoke` concluído e `/api/ia/chat` respondeu pelo modelo local sem fallback externo. O container foi reiniciado e recuperado pelo hook `ai:ensure`; a configuração mantém `restart=unless-stopped`. O GGUF fica no volume persistente do Codespace, fora do workspace Git.

## Resiliência e segurança

O provider local usa timeout, uma requisição concorrente por vez e fallback seguro. A IA agrícola mantém o contrato existente. No Security & Trust Layer, o modelo produz apenas análise e recomendação; severidade, contenção, bloqueios e modo de emergência continuam determinísticos. Saídas de segurança que não forem JSON estrito são descartadas.
# Desenvolvimento Cloudflare Local

## Estado e ferramentas

Wrangler `4.145.0` está instalado como dependência de desenvolvimento. `workerd` é usado pelo Wrangler para executar o Worker local. Os scripts locais não usam `--remote`; nenhum deployment, recurso remoto ou dado de produção foi criado ou consultado.

## Configuração

`wrangler.toml` aponta para a entrada isolada `worker/index.mjs`, serve o PWA compilado de `dist/` e encaminha `/api/*` ao Worker antes dos assets. A porta local é `8790`, separada do servidor Node (`8787`) e do Vite (`4173`).

Bindings locais:

- `DB`: D1 `agrolink-caop-local`, com database ID placeholder para o modo local.
- `BUCKET`: R2 `agrolink-caop-local`.
- `AI`: binding Workers AI configurado para o Worker; os testes locais substituem o binding por doubles e não solicitam inferência remota.
- `ASSETS`: assets compilados do frontend/PWA.

`AI_MODEL` escolhe o modelo (default `@cf/meta/llama-3.1-8b-instruct`) e `AI_TIMEOUT_MS` limita a inferência. Os testes diretos do handler injetam um binding mock para validar sucesso, falhas e persistência D1 sem acesso Cloudflare. O binding no `wrangler.toml` não usa `remote = true`; inferência remota em `wrangler dev` exige autenticação. Qwen local continua no servidor Node.

## Iniciar localmente

```sh
npm run build
npm run cloudflare:d1:migrate
npm run cloudflare:dev
```

`wrangler d1 migrations apply ... --local` cria/inicializa somente o estado D1 local; o script npm define `CI=1` para evitar prompts interativos. Wrangler cria o estado local do bucket quando o binding R2 é utilizado. O estado persistente fica em `.wrangler/state/` e é ignorado pelo Git. Não executar `wrangler d1 create`, `wrangler r2 bucket create`, `--remote` ou `wrangler deploy` para esta fase.

A migration `cloudflare/migrations/0001_local_core.sql` contém somente users, profiles, sessoes, ia_conversas, ia_mensagens e limite_taxa_eventos, com as relações e índices necessários aos testes de autenticação/chat. Não inclui nem migra as 47 tabelas da aplicação.

## Rotas implementadas

- `GET /api/health`: confirma a instância Worker.
- `POST /api/auth/login` e `GET /api/auth/session`: login PBKDF2-SHA512 compatível com o formato de hash existente, sessão persistida em D1 e cookie HttpOnly.
- `GET/PATCH /api/profile`: leitura/atualização do nome do perfil autenticado através do D1DatabaseAdapter.
- `POST /api/ia/chat`: autenticação, ownership, quota, contexto/histórico e mensagens em D1; inferência via Workers AI, com fallback de confiança baixa se o binding estiver indisponível.
- `PUT/GET/HEAD/DELETE /api/storage/:key`: operação R2 local, chave prefixada pelo ID do utilizador, autorização por custom metadata, Content-Type validado/preservado e limite de 2 MiB.
- Requests não-API são delegados ao binding `ASSETS`, incluindo fallback SPA.

## Testes

`npm test` inclui `worker/worker.test.mjs`. A suíte cria uma pasta temporária, aplica a migration com Wrangler local, semeia dois utilizadores artificiais e inicia `wrangler dev --local`. Testa autenticação, SELECT/UPDATE D1, relação de conversa/mensagens, ownership, fallback do chat e o ciclo PUT/HEAD/GET/DELETE R2 com autorização cruzada. A pasta é apagada ao terminar; nenhum dado SQLite ou upload da aplicação é lido ou alterado.

Executar apenas os testes Worker com `npm run cloudflare:local:test`.

## Diferenças e limitações

O servidor atual continua Node + SQLite síncrono + filesystem + Qwen local em `server/index.mjs`. O Worker é uma entrada independente e usa D1 async e R2; não importa nem move o dispatcher Node. A migration Worker é independente das migrations SQLite.

O Worker ainda não implementa Security & Trust persistido, scheduler e relatórios. Os uploads filesystem existentes permanecem intocados. O chat Worker usa o binding configurado; sem ligação remota utilizável, mantém o fallback. Inferência efetiva na conta Cloudflare depende de autenticação Wrangler.

Não houve deployment, configuração de produção, binding remoto, criação de recursos Cloudflare de produção ou migração de dados reais.
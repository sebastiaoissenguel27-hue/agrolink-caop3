# Arquitetura inicial de adapters Cloudflare

Estado: preparação incremental. SQLite, filesystem e Qwen local continuam a ser os defaults. Não houve deployment, criação de recursos Cloudflare, instalação de Wrangler ou migração de dados.

## Arquitetura atual

O runtime ativo continua a ser o servidor HTTP Node em `server/index.mjs`. O dispatcher concentra handlers e regras, e a maioria das operações de negócio ainda consulta diretamente o singleton SQLite. As rotas de mídia validam as associações SQL e servem ficheiros do diretório local. `/api/ia/chat` valida sessão, limite e dados, persiste conversa/mensagens e normaliza a resposta para `{ conversaId, resposta, confianca }`.

## Adapters criados

### SQLite e D1

`server/databaseAdapter.mjs` define o contrato assíncrono `DatabaseAdapter`, `SQLiteDatabaseAdapter` e `D1DatabaseAdapter`. O SQLite atual implementa quota, ownership, criação de conversa e persistência/leitura de mensagens. A API injeta o adapter SQLite por omissão. A implementação D1 usa `prepare/bind/first/all/run`, mas não está ligada a um Worker nem a um binding real.

Este é o primeiro fluxo encapsulado, não uma substituição geral do banco: grande parte do SQL dos outros endpoints continua diretamente em `server/index.mjs` e nos serviços existentes. As escritas do chat ainda são operações separadas, sem transação multi-operação validada em D1. O runner de migrations, PRAGMAs, backups e os demais fluxos síncronos também continuam SQLite-only.

### Filesystem e R2

`server/storageAdapter.mjs` define `StorageAdapter`, `LocalFilesystemStorageAdapter` e `R2StorageAdapter`. Uploads de mídia, verificação da associação de mídia de relato e leitura autenticada passam pela interface. O filesystem é o adapter ativo e mantém chaves relativas, uploads idempotentes por conteúdo e streaming local. R2 apenas delega ao binding fornecido; não existe binding nem configuração Cloudflare neste projeto.

O fluxo continua a usar Base64/JSON com o limite atual. A autorização permanece no servidor e a leitura exige metadata SQL antes de obter o objeto. Falta desenhar streaming de entrada, reconciliação entre objeto e metadata, política MIME/checksum e limpeza de objetos órfãos.

### Qwen local e Workers AI

`server/aiProvider.mjs` define `AIProvider`, `LocalQwenProvider` e `WorkersAIProvider`. O provider local continua ativo no Node/Express e usa o health check, timeout, concorrência e configuração atuais de `server/localAi.mjs`. O Worker usa `env.AI.run(model, input)`, modelo configurável por `AI_MODEL`, timeout por `AI_TIMEOUT_MS` e tamanho máximo de resposta. A integração não altera Security & Trust: o modelo é consultivo e não determina risco, ações ou permissões.

O contrato de sucesso de `/api/ia/chat` continua exatamente `{ conversaId, resposta, confianca }`; os fallbacks existentes permanecem ativos. `conversaId` é verificado contra `ia_conversas.utilizador_id` antes de quota, histórico ou escrita, com resposta 404 para IDs de terceiros/inexistentes.

## Security & Trust Layer

O provider pode fornecer análise consultiva, mas `buildSecurityAiResult` conserva o nível decidido pelo sinal determinístico e não produz ações. Falhas de IA continuam sem substituir as regras nem a contenção determinística. A migração ainda precisa preservar persistência/atomicidade, rate limit compartilhado e scheduler, hoje dependentes de SQLite e runtime Node.

## O que falta migrar

- Extrair os restantes repositórios/fluxos SQL e adaptar chamadas síncronas para D1 assíncrono.
- Rever e testar as dez migrations para D1, especialmente PRAGMAs, transações, triggers, tabela temporária e reconstrução de `profiles`.
- Validar atomicidade/idempotência no chat e nos fluxos de autenticação, denúncias, segurança, logística e uploads.
- A integração Workers AI dispõe de testes locais com binding simulado; inferência remota/deployment depende de autenticação Wrangler. Nenhum recurso Cloudflare foi criado nesta implementação local.
- Separar bootstrap HTTP Node do futuro `fetch(Request, env, ctx)` e migrar auth/crypto, rate limiting, scheduler, RSS/DNS, backups e assets.
- Definir política de upload streaming, MIME, checksum, URLs privadas, reconciliação e restauração antes de migrar objetos.
- Comparar Workers AI com Qwen local e preservar fallback consultivo antes de qualquer cutover.

Nenhum deploy, binding, recurso, arquivo Wrangler ou migração de dados faz parte desta fase. Não foram alteradas dependências.
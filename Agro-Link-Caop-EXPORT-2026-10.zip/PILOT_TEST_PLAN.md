
> **Estado arquitetural atualizado (15/09/2026):** o runtime ativo foi migrado de Supabase para a base de dados interna do AgroLink (`server/db.mjs` + `server/migrations/001_platform.sql`). As referências a Supabase nestes documentos podem ser históricas.

# AgroLink Caop — Pilot Test Plan

Data prevista: 31/08/2026
Branch: `pilot/ai-for-sdgs-2026`
Ambiente: Staging/teste controlado. Nunca usar credenciais ou dados de produção neste plano.

## Pré-condições

- URL Supabase de Staging e chave anon configuradas apenas em `.env.local`.
- Migrations `0001`–`0026` aplicadas somente na base de teste, após confirmar o estado dessa base.
- Secrets das Edge Functions configurados no ambiente de teste pelo responsável.
- Dois utilizadores de teste: agricultor e técnico/admin.
- Um smartphone Android e um smartphone iOS, quando disponíveis.

## Casos de teste

| ID | Cenário | Passo principal | Resultado esperado |
|---|---|---|---|
| T01 | Abrir aplicação | Abrir o endereço do piloto | App carrega sem erro e mostra acesso |
| T02 | Registo | Criar conta de agricultor com dados de teste | Conta criada e sessão iniciada ou confirmação claramente apresentada |
| T03 | Login | Sair e entrar novamente | Dashboard abre com o perfil correto |
| T04 | Perfil | Consultar e editar localização básica | Dados são guardados e reaparecem ao recarregar |
| T05 | Criar relato online | Informar cultura, localização, problema e descrição; enviar | Relato é gravado no Supabase e recebe estado/código |
| T06 | Consultar relato | Abrir lista e detalhe do relato criado | Relato aparece somente para o utilizador autorizado |
| T07 | Resposta técnica | Técnico consultar e responder ao relato de teste | Agricultor visualiza a resposta e o estado atualizado |
| T08 | Assistente IA | Enviar uma pergunta agrícola simples | Resposta chega pela Edge Function sem expor a chave |
| T09 | Erro IA | Testar mensagem vazia ou IA não configurada | Mensagem clara; app não quebra |
| T10 | Offline | Desligar rede, criar relato e reabrir a lista | Operação fica na fila local e permanece visível |
| T11 | Sincronização | Restaurar rede e aguardar sync | Relato é enviado uma vez e não duplica |
| T12 | Mobile | Repetir T03, T05 e T08 em smartphone | Sem overflow; teclado, scroll e botões utilizáveis |
| T13 | PWA | Verificar manifest, instalar e abrir | Instalação funciona quando os três ícones estiverem disponíveis |
| T14 | Segurança | Inspecionar bundle e Network; testar utilizador sem permissão | Sem service role/API key no frontend; RLS bloqueia acesso indevido |

## Registo

Para cada caso, registar data, dispositivo/browser, ambiente, resultado PASS/FAIL/PENDING e evidência mínima. Não registar passwords, tokens ou chaves.

## Critério de saída

O piloto só pode ser marcado `READY` após T01–T08, T10–T12 e T14 passarem em Staging. T13 fica bloqueado até os assets PWA originais existirem. Qualquer falha de Auth, RLS, exposição de credenciais, perda/duplicação de relatos ou IA indisponível mantém a decisão `NOT READY`.

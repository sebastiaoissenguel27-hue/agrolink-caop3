
> **Estado arquitetural atualizado (15/09/2026):** o runtime ativo foi migrado de Supabase para a base de dados interna do AgroLink (`server/db.mjs` + `server/migrations/001_platform.sql`). As referências a Supabase nestes documentos podem ser históricas.

# AgroLink Caop — PROJECT_STATUS.md

Documento de estado real, gerado por auditoria do código existente — não por memória de
conversa. Cada afirmação abaixo foi verificada diretamente nos ficheiros do projeto nesta
sessão. Onde não foi possível verificar algo (ex: execução real), isso é dito
explicitamente, nunca assumido.

---

## 1. Projeto

**Nome:** AgroLink Caop — plataforma agrícola angolana que liga agricultores, técnicos e
administradores.

**Stack:** React + TypeScript + Vite, PWA (instalável, incl. Android), Supabase
(Postgres + Auth + Storage + Edge Functions), Dexie (IndexedDB) para offline.

**Arquitetura geral:**
```
PWA (React+TS, offline-first)
 └─ Dexie/IndexedDB: 14 tabelas locais (filas de sync + caches de leitura)
        │
        ▼
Supabase: Auth · Postgres (38 tabelas, RLS em todas) · Storage (5 buckets privados)
          · Edge Functions (3: ia-agricola-proxy, sync-noticias, ia-resumo-mensal)
```

**Frontend:** organizado por `src/app` (rotas/layout/páginas de sistema), `src/features/
<domínio>` (13 domínios — ver secção 2), `src/offline` (Dexie + motor de sincronização),
`src/shared` (cliente Supabase, tipos, i18n). Um serviço (`api/*Service.ts`) por domínio;
nenhum componente acede ao Supabase diretamente fora dessa camada.

**Backend:** inteiramente Supabase — sem servidor próprio. Toda a lógica de negócio
sensível vive em RLS, funções `SECURITY DEFINER`, triggers, e 3 Edge Functions.

**PWA:** `vite-plugin-pwa` configurado (`vite.config.ts`), manifest com nome/cores/ícones,
service worker registado em `src/main.tsx`. Ícones do manifest (`public/icons/`) ainda por
gerar/colocar — ver secção 4.

**Offline:** ver secção 9.

---

## 2. Funcionalidades concluídas

Confirmado por existência real de: migração SQL + tipos TS + serviço + página + rota.

- **Plataforma base**: autenticação (login/registo/recuperação de password), 3 papéis
  (agricultor/técnico/admin) + 1 papel preparado sem frontend (transportador — ver
  secção 6), status de conta, verificação de técnico, perfis com localização.
- **Relatos agrícolas**: com/sem cadastro (código público único), várias fotos, áudio,
  offline completo, 6 estados, respostas técnicas.
- **Painéis**: agricultor (dashboard), técnico (fila filtrável), admin (11 abas:
  utilizadores, notícias, fontes de notícias, alertas, centro de recursos, biblioteca,
  academia, IA Analytics, mensagens, estatísticas, auditoria).
- **Notícias**: pesquisa, categorização (manual + por IA), fontes RSS, cache offline.
- **Alertas**: nacional/provincial/municipal, cache offline.
- **Assistente IA**: chat multimodal (texto+foto), confiança, encaminhamento a técnico,
  voz (TTS) — ver secção 7 para o detalhe exato do que existe e do que não existe.
- **Configurações**: preferências de notificação, seletor de idioma (i18n), gestão de
  cache offline.
- **Ferramentas Agrícolas**: 2 calculadoras (dose de insumo, calendário de plantio) +
  histórico offline.
- **Centro de Recursos**: recursos externos + FAQ.
- **Biblioteca AgroLink**: documentos/PDFs com upload, pesquisa, categoria.
- **Academia AgroLink**: cursos, lições (texto/imagem/pdf), questionários corrigidos no
  servidor, progresso offline.
- **Notificações Inteligentes**: 6 tipos de evento, sino em tempo real, cache offline,
  fila de leituras offline.
- **IA Analytics**: dashboard admin (10 métricas), resumo mensal narrativo gerado por IA
  a partir de agregados.

---

## 3. Funcionalidades parcialmente implementadas

- **Security & Trust Layer** — **só a base de dados existe** (migrações `0024`-`0026`):
  papel `transportador`, `logs_seguranca`, rate limiting aplicacional, tabela
  `transportadores`, `denuncias`, `denuncia_historico`, `reputacao`, `avaliacoes`. **Sem
  nenhum tipo TypeScript, serviço, página, componente ou rota** — confirmado por busca
  direta no código (`grep` a `src/` não encontra nenhuma referência a estes conceitos
  fora do SQL). Este é o trabalho interrompido mais recente do projeto.
- **AgroLink Logística** — só schema preparatório (`logistica_transportadoras`,
  `logistica_pedidos`, migração `0018`), sem qualquer frontend.
- **SIE, Mercado AgroLink, Mapas, Sensores IoT** — só schema preparatório, sem frontend.
- **i18n** — infraestrutura real (`LanguageContext`, seletor em Configurações, coluna
  `idioma` persistida por utilizador), mas só Português tem tradução verdadeira.
  Kimbundu/Umbundu/Kikongo/Cokwe estão registados mas caem em fallback para português —
  decisão deliberada, documentada em `docs/i18n.md`, para não mostrar traduções
  fabricadas.
- **Notícias — fontes oficiais**: só 2 das 16 fontes pedidas têm URL de feed real
  confirmado (FAO Newsroom, ANGOP/Agricultura). As restantes 14 (MINAGRIF, IDA, IIA, ISV,
  Jornal de Angola, IFAD, CGIAR, CABI, CIMMYT, IITA, World Bank, AfDB, Reuters, etc.) estão
  pré-registadas na tabela `noticias_fontes` mas **inativas**, com `url_rss = null` — por
  desenho não foram inventados feeds.

---

## 4. Funcionalidades ainda não implementadas

- Frontend do Security & Trust Layer (denúncias, reputação, Centro de Segurança e
  Confiança, perfil de transportador).
- Mercado AgroLink (frontend).
- AgroLink Logística (frontend).
- Mapas/GPS, Meteorologia agrícola, Sensores IoT (frontend).
- Push notifications reais (schema `dispositivos_push` existe, sem integração FCM/APNs).
- Upload de documentos de verificação de técnico (schema `tecnico_documentos` existe,
  sem UI).
- Vídeo (Academia e IA) — tipo `video` existe no enum de lições, mas a interface mostra
  "em breve", por decisão deliberada.
- STT no assistente IA (entrada de áudio transcrita) — ver secção 7.
- RAG / base de conhecimento vetorial para a IA.
- Memória/histórico de longo prazo da IA além do histórico de conversa já guardado.
- Testes automatizados (unitários ou E2E) — nunca foram criados; toda a validação até
  agora foi auditoria estática manual (ver secção 12).
- Ícones reais do PWA (`public/icons/icon-192.png` etc.) — só documentados como
  necessários, nunca gerados.

Não inventei nada acima do que não pude confirmar como ausente por inspeção direta.

---

## 5. Base de dados

**28 migrações**, `0001` a `0026`, sequenciais, nomeadas por conteúdo (lista completa em
`supabase/migrations/`). **38 tabelas**, todas com `enable row level security`. **41
índices** (`create index`, incluindo os de todas as FKs, corrigidos numa auditoria
anterior). **33 funções/RPC** (`SECURITY DEFINER` na generalidade — a lista completa está
nos ficheiros; nomes incluem `is_admin`, `consultar_relato_por_codigo`,
`obter_estatisticas_ia`, `confirmar_denuncia`, `verificar_limite_taxa`, etc.). **5 buckets
de Storage**, todos privados: `relatos`, `documentos`, `biblioteca`, `academia`,
`denuncias-evidencias`.

**Relações importantes**: `profiles` é o centro (papel/status/verification_status);
`relatos` liga a `profiles` (autor, técnico atribuído) e a `relato_midias`/
`relato_respostas`; `denuncias`/`avaliacoes` ligam duas `profiles` (autor↔denunciado,
avaliador↔avaliado) e opcionalmente a `logistica_pedidos`; `academia_progresso` é a única
tabela com chave primária composta (`utilizador_id, licao_id`).

### ⚠️ A) SQL existente vs. B) SQL aplicado — distinção obrigatória

**A) Existe**: todas as 28 migrações, como ficheiros `.sql` no repositório.

A migration `0027` foi corrigida para ser executável em bases parcialmente restauradas (os ENUMs são tratados de forma condicional). A migration `0028` adiciona criação automática de perfil após `auth.users`, necessária quando a confirmação de email está ativa, e torna os uploads de `relatos` dependentes do relato proprietário.

**B) Aplicado a um Supabase real: NENHUMA.** Este ambiente de desenvolvimento nunca teve
ligação de rede a um projeto Supabase — sem CLI `supabase`, sem `psql`, sem credenciais
configuradas. Tudo o que este documento diz sobre "tabelas", "RLS", "políticas" é
**leitura do texto dos ficheiros `.sql`**, nunca inspeção de uma base de dados viva.
Confirmar isto é o primeiro passo real de qualquer trabalho futuro.

---

## 6. Security & Trust Layer — estado exato

**O que já existe (só base de dados, migrações `0024`-`0026`):**
- `papel_utilizador` ganhou o valor `'transportador'`.
- `logs_seguranca` (admin-only), com função `registar_log_seguranca()`.
- `limite_taxa_eventos` + função `verificar_limite_taxa(chave, max, janela_segundos)` —
  rate limiting **aplicacional** (contagem em BD), não rate limiting de rede/gateway (isso
  exigiria infraestrutura como Cloudflare, fora do alcance de código de aplicação).
- `transportadores` (extensão de perfil: foto, foto do camião, matrícula, tipo de
  veículo, capacidade, documentos, estado de verificação) — auto-proteção contra
  auto-aprovação via trigger.
- `denuncias` (bidirecional, UUID, categoria/estado/prioridade fixos, sem UPDATE nem
  DELETE para o autor depois de submetida) + `denuncia_historico` (auditoria automática
  de mudanças de estado/prioridade/decisão).
- `reputacao` + `avaliacoes` — reputação **nunca** decresce por uma simples denúncia; só
  a função `confirmar_denuncia()` (admin-only) incrementa `denuncias_confirmadas`.
  Avaliações protegidas contra duplicação (`unique (avaliador_id, avaliado_id,
  transporte_id)`).

**O que falta**: literalmente todo o frontend — tipos TypeScript, `denunciasService.ts`,
`reputacaoService.ts`, `transportadorService.ts`, páginas de denúncia (criar/consultar
estado), Centro de Segurança e Confiança (página pública com as 8 secções pedidas:
Segurança AgroLink, Transportadores verificados, Como funciona a reputação, Como
denunciar, Como evitar fraudes, Segurança da conta, Estado das denúncias, Contactar
suporte), rotas, integração com o sino de notificações (o trigger `ao_resolver_denuncia`
já cria a notificação no lado da BD, mas nada no frontend ainda a mostra de forma
dedicada). IA de moderação assistida (classificação/deteção de duplicados) — **não
implementada**, nem a Edge Function correspondente existe.

---

## 7. IA — estado exato

**Edge Functions**: `ia-agricola-proxy` (chat principal) e `ia-resumo-mensal` (resumo
mensal agregado, agendável).

**Modelo**: `gemini-2.5-flash` via Gemini API, chamado só a partir das Edge
Functions (chave `GEMINI_API_KEY` nunca chega ao cliente).

**Entrada de texto**: sim, completo.
**Entrada de imagem**: sim — o cliente envia a foto em base64, a Edge Function inclui-a
como bloco `image` na mensagem ao modelo.
**Entrada de áudio / STT**: **parcial**. Existe um botão de ditado no `IAChatPage.tsx`
que usa a Web Speech API do navegador (`SpeechRecognition`/`webkitSpeechRecognition`) para
transcrever localmente e preencher o campo de texto — funciona só em navegadores com
suporte (Chrome/Edge; não Firefox/Safari) e é inteiramente client-side, sem envio de áudio
ao servidor. O áudio é enviado diretamente ao Gemini para compreensão e transcrição.
**TTS**: sim — `falarResposta()` usa `window.speechSynthesis` (nativo do navegador),
sem custo de servidor.
**Analytics**: tabela `ia_perguntas_analytics` (tema/culturas/pragas detetados por
palavras-chave, confiança, encaminhamento — nunca o texto da conversa), RPC
`obter_estatisticas_ia()` admin-only, dashboard `AdminIA.tsx`.
**Memória/histórico**: `ia_conversas`/`ia_mensagens` guardam o histórico de conversa por
utilizador; `IAChatPage` recupera a última conversa ao abrir. **Não existe** memória de
longo prazo estruturada (perfil agrícola do utilizador, preferências aprendidas) nem
personalização baseada em histórico agregado.
**RAG**: **não existe**. A IA responde só com o que o modelo já sabe + o texto da
pergunta atual — não há base de conhecimento vetorial nem recuperação de documentos da
Biblioteca/Academia/FAQ para aumentar o contexto.

---

## 8. Notícias — estado exato

**Sincronização**: Edge Function `sync-noticias`, com parser RSS por regex (não uma
biblioteca XML completa — cobre RSS 2.0 comum). Filtro de relevância agrícola por lista de
palavras-chave (determinístico) antes de qualquer inserção. Classificação automática nas
10 categorias fixas pedidas, via chamada à IA (Anthropic), só para itens que passam o
filtro. Deduplicação por `url_original` `UNIQUE`. Log por fonte e por execução em
`noticias_sync_logs` (sucesso/erro nunca interrompe as restantes fontes).

**Fontes configuradas**: 16 pré-registadas, só 2 ativas com feed real (ver secção 3).
Prioridade (`prioridade`) e âmbito (`nacional`/`internacional`) por fonte, geridos pelo
admin em `AdminFontesNoticias.tsx`, incluindo campo para colar o URL das fontes ainda sem
feed confirmado.

---

## 9. Offline

**IndexedDB via Dexie**, versão de schema atual: **8** (`src/offline/db.ts`), com 14
tabelas locais:
- Filas de sincronização (dados criados offline, esperando envio):
  `relatosPendentes`, `midiasPendentes`, `calculosPendentes`, `progressoPendente`,
  `leiturasPendentes`.
- Caches de leitura (dados do servidor, para consulta offline):
  `noticiasCache`, `alertasCache`, `iaHistoricoCache`, `recursosCache`, `faqCache`,
  `bibliotecaCache`, `academiaCursosCache`, `academiaLicoesCache`, `notificacoesCache`.

**Motor de sincronização** (`src/offline/syncEngine.ts`): ponto único `sincronizarTudo()`
chama, em sequência, `sincronizar()` (relatos), `sincronizarCalculos()`,
`sincronizarProgresso()`, `sincronizarLeiturasNotificacoes()`. Ativado automaticamente
via listener do evento `online`, ligado em `AuthContext` enquanto há sessão (bug corrigido
numa auditoria anterior — a função existia mas nunca era chamada).

**UUIDs/idempotência**: cada item da fila usa `crypto.randomUUID()` como `localId` gerado
no cliente antes de qualquer contacto com o servidor — evita duplicados em caso de retry.
**Retry com backoff**: **não existe** — o motor tenta uma vez por chamada de
`sincronizarTudo()`; falhas ficam marcadas (`erroSincronizacao`) para a próxima tentativa,
mas sem espera exponencial entre tentativas.

**Estados de relato**: `pendente` / `sincronizando` / `enviado` / `respondido` /
`resolvido` / `erro` (os 3 primeiros são estado local; os 3 últimos vêm do servidor).

---

## 10. Rotas

| Rota | Página |
|---|---|
| `/entrar` | LoginPage |
| `/registar` | RegisterPage |
| `/esqueci-password` | ForgotPasswordPage |
| `/redefinir-password` | ResetPasswordPage |
| `/relato-anonimo` | RelatoAnonimoPage |
| `/sobre` | InstitucionalPage (pública) |
| `/acesso-negado` | AcessoNegadoPage |
| `/conta-pendente` | ContaPendentePage |
| `/conta-bloqueada` | ContaBloqueadaPage |
| `/` | HomePage (despacha por papel) |
| `/perfil` | PerfilPage |
| `/noticias` | NoticiasPage |
| `/alertas` | AlertasPage |
| `/assistente` | IAChatPage |
| `/configuracoes` | ConfiguracoesPage |
| `/ferramentas` | FerramentasPage |
| `/recursos` | RecursosPage |
| `/biblioteca` | BibliotecaPage |
| `/academia` | AcademiaPage |
| `/academia/:cursoId` | CursoDetalhePage |
| `/relatos` | RelatosPage (só agricultor) |
| `/tecnico` | TecnicoPage (só técnico) |
| `/admin` | AdminPage (só admin, 11 abas internas) |

Nenhuma rota de Security & Trust, Mercado ou Logística existe ainda.

---

## 11. Ambiente

- **Node.js**: recomendado 20.x LTS ou 22.x (o `package.json` não fixa uma versão
  mínima explícita — a testar no ambiente real).
- **Instalar dependências**: `npm install`
- **Desenvolvimento**: `npm run dev` (Vite, porta 5173 por omissão)
- **Build**: `npm run build` (`tsc -b && vite build`)
- **Variáveis de ambiente do cliente** (`.env.local`, a partir de `.env.example`):
  `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`.
- **Segredos das Edge Functions** (nunca no cliente, configurar via
  `supabase secrets set`): `GEMINI_API_KEY`. `SUPABASE_URL`, `SUPABASE_ANON_KEY` e
  `SUPABASE_SERVICE_ROLE_KEY` ficam disponíveis automaticamente dentro de qualquer Edge
  Function, não precisam de ser configurados manualmente.
- **Aplicar as 28 migrações**: por ordem numérica, via `supabase db push` (CLI) ou colando
  cada ficheiro no SQL Editor do painel Supabase, começando por `0001` até `0028`.
- **Deploy das Edge Functions**: `supabase functions deploy ia-agricola-proxy`,
  `supabase functions deploy sync-noticias`, `supabase functions deploy ia-resumo-mensal`.
  Agendamento recomendado (Supabase Dashboard → Edge Functions → Schedule):
  `sync-noticias` a cada 6h, `ia-resumo-mensal` 1x/mês.
- **Nenhuma chave secreta está commitada no repositório** — `.env.example` só tem
  placeholders.

---

## 12. Limitações conhecidas (confirmadas nesta sessão, não hipotéticas)

- `npm install` **não pôde ser executado** neste ambiente: erro `403 host_not_allowed` ao
  contactar `registry.npmjs.org` — bloqueio de rede do próprio ambiente, sem cache local
  de pacotes.
- Por consequência, `npm run build` (real, com `tsc` completo e `vite build`) **nunca foi
  executado** neste projeto, em nenhuma sessão. Toda a validação feita até agora foi
  auditoria estática manual (resolução de imports/exports por script Python, equilíbrio de
  chavetas/parênteses, leitura direta dos ficheiros SQL) — **não substitui** uma
  verificação de tipos real do `tsc` nem um build real do Vite.
- Nenhum Supabase real está ligado a este ambiente — ver secção 5.
- Nenhuma Edge Function foi implantada nem executada em produção.
- Sem testes automatizados (unitários ou E2E).
- Sem auditoria formal de acessibilidade (contraste de cor, navegação completa por
  teclado) — só correções pontuais (aria-labels, alt text) feitas ao longo do projeto.

---

## 13. Próximos passos (ordem recomendada)

1. **Executar o primeiro build real** num ambiente com rede — `npm install && npm run
   build` — e corrigir o que `tsc` encontrar (a auditoria estática não apanha tudo).
2. Ligar um projeto Supabase real, aplicar as 28 migrações por ordem, e confirmar por
   inspeção direta (Table Editor + Database → Policies) que RLS/índices ficaram como os
   ficheiros descrevem.
3. Implantar as 3 Edge Functions e testar cada uma manualmente antes de agendar.
4. Terminar o frontend do Security & Trust Layer (é o trabalho interrompido mais
   recente — ver secção 6): tipos → serviços → páginas → rotas → testes → auditoria.
5. Só depois, avançar para o Mercado AgroLink (Checkpoint 2, conforme a ordem de
   prioridade já definida para a v3.0).

---

## 14. Regras para a próxima IA/equipa

- Não recriar o projeto do zero — já existe uma arquitetura estabelecida e testada
  estaticamente.
- Não apagar nenhuma funcionalidade já implementada (secção 2).
- Não alterar a arquitetura existente sem justificação técnica explícita.
- Auditar primeiro, implementar depois — mesmo que este documento pareça completo, a
  primeira ação deve ser confirmar por inspeção direta do código, não confiar cegamente
  neste ficheiro.
- Distinguir sempre código existente (ficheiro no repositório) de código realmente
  executado/testado/aplicado — este documento faz essa distinção deliberadamente em
  várias secções; continuar a fazê-lo.
- Nunca afirmar que algo foi testado se não foi executado de facto.
- Correr as verificações possíveis (build, tipos, RLS) antes de implementar
  funcionalidades novas.
- Criar checkpoints (commits ou pacotes) com frequência — este projeto já teve um
  incidente de reset de ambiente a meio de uma sessão; só não perdeu trabalho porque
  tinha sido reempacotado pouco antes.

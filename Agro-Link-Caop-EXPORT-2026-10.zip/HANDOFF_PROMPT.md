
> **Estado arquitetural atualizado (15/09/2026):** o runtime ativo foi migrado de Supabase para a base de dados interna do AgroLink (`server/db.mjs` + `server/migrations/001_platform.sql`). As referências a Supabase nestes documentos podem ser históricas.

# HANDOFF_PROMPT.md

Copie o texto abaixo como a primeira mensagem à IA que vai continuar este projeto.

---

Recebeste um projeto existente chamado **AgroLink Caop** (plataforma agrícola angolana,
React + TypeScript + Supabase + PWA offline-first). Este não é um projeto novo — já tem
código real, 28 migrações SQL, 3 Edge Functions, e vários módulos completos.

**Antes de escreveres uma única linha de código:**

1. Lê `PROJECT_STATUS.md` na íntegra — é um documento de estado gerado por auditoria
   direta do código, não um resumo de memória de conversa. Descreve exatamente o que está
   concluído, o que está parcialmente feito, e o que não existe.
2. Audita o código-fonte por ti próprio para confirmares que o que o documento diz bate
   certo com a realidade — não assumas que o documento está 100% atualizado, sobretudo
   se algum tempo tiver passado.
3. Presta atenção especial à secção 5 do `PROJECT_STATUS.md`: as migrações SQL existem
   como ficheiros, mas **nunca foram aplicadas a um Supabase real** nesta sessão de
   desenvolvimento. Não assumas que uma base de dados real já reflete este schema — isso
   tem de ser verificado (ou feito) por ti.
4. Presta atenção à secção 12 (Limitações conhecidas): `npm install`/`npm run build`
   nunca correram de verdade neste projeto, por bloqueio de rede do ambiente anterior. Se
   tiveres acesso a rede, esse deve ser um dos teus primeiros passos — corre o build real
   e corrige o que aparecer.

**Regras a seguir durante todo o desenvolvimento:**

- Não recries o projeto do zero.
- Não apagues nenhuma funcionalidade já implementada.
- Não alteres a arquitetura existente sem justificação técnica clara.
- Audita primeiro, implementa depois.
- Distingue sempre "existe no código" de "foi realmente executado/testado/aplicado" —
  nunca afirmes que algo foi testado se não correste esse teste tu mesma.
- Corre os testes e verificações possíveis antes de avançar para funcionalidades novas.
- Cria checkpoints (commits, ou pacotes reempacotados) com frequência — este projeto já
  teve um incidente de perda de ambiente de trabalho a meio de uma auditoria; só não
  perdeu progresso porque tinha sido reempacotado pouco antes.

**Estado exato de onde parar de ler passivamente e começar a trabalhar:** o trabalho mais
recente e ainda incompleto é o **Security & Trust Layer** — a base de dados existe
(migrações `0024` a `0026`), mas o frontend (tipos TypeScript, serviços, páginas, rotas)
ainda não foi criado. A secção 6 do `PROJECT_STATUS.md` descreve exatamente o que falta.
Depois disso, a ordem de prioridade definida para a v3.0 é: Mercado AgroLink → AgroLink
Logística → IA com memória/RAG → Mapas/GPS → Meteorologia agrícola → Sensores IoT →
Integrações futuras.

Trabalha por módulos pequenos, testa cada um, corrige o que encontrares, e só avances
automaticamente para o módulo seguinte quando o atual estiver realmente estável — não
apenas "código escrito".


> **Estado arquitetural atualizado (15/09/2026):** o runtime ativo foi migrado de Supabase para a base de dados interna do AgroLink (`server/db.mjs` + `server/migrations/001_platform.sql`). As referências a Supabase nestes documentos podem ser históricas.

# AgroLink Caop — Pilot Readiness

Identificação: `PILOTO AGROLINK CAOP — 31/08/2026`
Branch: `pilot/ai-for-sdgs-2026`
Data da avaliação: 2026-08-28
Base utilizada: `f05a81d` (`main`), com restauração do handoff e correções mínimas na branch piloto.

| Área | Estado | Evidência/pendência |
|---|---|---|
| BUILD | PASS | `npm run build` concluído; apenas aviso de bundle grande. |
| TYPESCRIPT | PASS | `npx tsc -b --force` sem erros. |
| AUTH | BLOCKED | Endpoint Auth responde; não foi fornecido email controlado para criar uma conta de teste. `mailer_autoconfirm=false`; o perfil após `signUp` depende de sessão/RLS. |
| DATABASE | PENDING | 28 migrations presentes; não aplicadas a nenhum ambiente. |
| RLS | PENDING | Policies preservadas; requer validação num Supabase de teste. |
| IA | PENDING | Proxy estruturalmente restaurado e compilável; secrets e chamada real não testados. |
| RELATOS | PENDING | Código e offline restaurados; fluxo real ainda não testado. |
| NOTÍCIAS | PENDING | Código e function restaurados; integração RSS/Supabase não testada. |
| OFFLINE | PENDING | Dexie e sincronização presentes; requer teste sem conectividade. |
| PWA | PASS | Manifest/service worker e os três PNGs válidos estão presentes; os ícones são PLACEHOLDER provisórios, não identidade oficial. |
| ADMIN | PENDING | Área restaurada; autorização e dados reais não testados. |
| MOBILE | PENDING | Requer validação em browser/dispositivo móvel. |
| DEPLOY | PENDING | Nenhum deployment foi configurado ou executado. |
| LINK DO PILOTO | PENDING | `DEPLOYMENT PENDENTE`; não existe URL público confirmado. |

## Matriz E2E atual

| Cenário | Resultado | Evidência |
|---|---|---|
| Abrir aplicação | PASS | Build Vite concluído e `dist/index.html` gerado durante a validação. |
| Registo/Login | BLOCKED | Auth responde, mas falta email controlado e não foi criada conta de teste; `mailer_autoconfirm=false`. A mensagem de erro distingue falhas comuns sem expor detalhes sensíveis. |
| Dashboard | PENDING | Requer sessão Supabase válida. |
| Criar relato | PENDING | Requer Auth, schema, RLS e escrita real no Supabase. |
| Ler relato | PENDING | Requer leitura real sujeita a RLS. |
| IA Agrícola | PENDING | Requer URL/configuração Supabase, JWT e `GEMINI_API_KEY`. |
| Offline | PENDING | Dexie/syncEngine verificados estaticamente; falta teste browser offline. |
| Sincronização | PENDING | Falta teste de perda/retorno de rede e não duplicação. |
| Mobile | PENDING | Falta validação em viewport/dispositivo. |
| PWA | PASS | Manifest/service worker gerados e ícones 192/512/maskable válidos; placeholders provisórios precisam ser substituídos por assets oficiais. |
| Segurança básica | PASS | Scan sem secrets reais; chaves de IA não estão no frontend. |

## Matriz de resultados solicitada

| Teste | Resultado | Evidência |
|---|---|---|
| Build | PASS | `npm run build` passou localmente. |
| TypeScript | PASS | `npx tsc -b --force` passou sem erros. |
| Auth | PENDING | `BLOCKED — Supabase/Staging credentials unavailable`. |
| Supabase | PENDING | Sem URL/chave de Staging; nenhuma operação remota executada. |
| RLS | PENDING | Migrations locais preservadas; validação requer Staging. |
| Criar relato | PENDING | Fluxo offline/local analisado; INSERT real não testado. |
| Ler relato | PENDING | SELECT real e RLS não testados. |
| IA online | PENDING | `PENDING — AI provider credential unavailable`; invoke e contrato estáticos analisados. |
| Assistente offline | PENDING | Não implementado no handoff; modo offline atual cobre fila/cache, não respostas agrícolas. |
| Sincronização | PENDING | Código analisado; perda/retorno de rede e não duplicação não testados em browser. |
| Mobile | PENDING | Nenhum dispositivo/browser mobile disponível para teste documentado. |
| PWA | PASS | Build gera manifest/service worker e os três ícones provisórios válidos. |
| Segurança | PASS | Nenhum secret real no código; `.env.local` está ignorado pelo Git e a IA usa secret somente na Edge Function. |

## Supabase Staging

**BLOCKED — Supabase/Staging credentials unavailable**

Não foram encontradas variáveis de ambiente, configuração de projeto, CLI Supabase ou credenciais documentadas. Por isso não foram executados registo/login, Auth, RLS, INSERT/SELECT de relatos, Storage, Edge Functions ou migrations remotas.

## IA híbrida offline

Estado: **POST-PILOT** para um LLM local completo.

O handoff já possui fila/cache Dexie e sincronização para operações agrícolas, mas não possui base de conhecimento nem respostas offline do assistente. Um modo inicial por FAQ/regras seria tecnicamente mais adequado que um LLM: pequeno armazenamento local, sem WebGPU/WebAssembly obrigatório e compatível com Android de baixo/médio desempenho. Ainda assim, adicionar conteúdo e regras agrícolas exige definição funcional e testes que não cabem na validação atual.

Um LLM local é **NOT VIABLE FOR PILOT** neste prazo sem escolher modelo, quantização, runtime WebAssembly/WebGPU, tamanho, memória, armazenamento, tempo de carregamento e impacto de bateria. O custo de download inicial e a variabilidade de suporte PWA tornam-no inadequado para o piloto de 31/08 sem estudo e dispositivo-alvo.

Arquitetura recomendada futura: com rede, `IA ONLINE`; sem rede, respostas locais limitadas e claramente identificadas; ao voltar a rede, `IA ONLINE`. Não foi implementada uma chamada de rede quando offline.

## Offline-first dos relatos

Análise estática confirmada: `NovoRelatoForm` grava relato e mídias em Dexie, `sincronizar()` envia quando `navigator.onLine` é verdadeiro e o listener `online` chama `sincronizarTudo()`. O teste de fechar/reabrir, sincronizar em rede real e provar ausência de duplicação permanece `PENDING`.

Risco: o envio usa INSERT e marca a fila como sincronizada após resposta; uma falha entre o INSERT remoto e a marcação local pode permitir duplicação numa nova tentativa. Deve ser testado/corrigido antes de declarar o piloto pronto.

## Fase 3.3 — Correções aplicadas

- Mensagens seguras e específicas para falhas de registo, sem mostrar secrets ou detalhes internos.
- Mostrar/ocultar palavra-passe em registo, login e redefinição, com `aria-label`, `title` e área de toque mínima.
- Três ícones PWA PNG provisórios, derivados das cores existentes do projeto; não são identidade oficial.
- Rota administrativa não foi alterada: continua protegida por papel `admin` no `ProtectedRoute`.

O teste Auth real continua bloqueado por falta de um identificador de teste controlado. Não foram criadas contas, não foram feitas alterações no Supabase remoto e não houve deploy.

## Decisão

**NOT READY** para agricultores reais enquanto Auth/Supabase/IA/offline/mobile não forem testados. O PWA está tecnicamente instalável com placeholders provisórios; os assets oficiais continuam pendentes.

## Próximo passo autorizado

Validar a aplicação em ambiente de teste, sem produção: configurar variáveis locais não versionadas, aplicar migrations somente numa base descartável, testar Auth/RLS/relatos/IA/offline e executar verificação manual mobile/PWA. Nenhuma operação remota foi executada nesta fase.

# AgroLink Caop — Auditoria e alterações — 15/09/2026

## Objetivo
Consolidar a plataforma sobre backend/SQLite interno, reforçar governação, denúncias, Security & Trust Layer, continuidade operacional e recuperação de acesso, sem alterar GitHub/main nem qualquer Supabase remoto.

## Prioridade 1 — Segurança e controlo de emergência
- Security & Trust Layer defensivo implementado.
- Deteção de falhas de login, excesso de pedidos e payloads suspeitos.
- Rate limiting global por IP.
- Contenção autónoma apenas reversível e defensiva.
- Se o administrador-chefe estiver ativo, incidentes altos/críticos ficam para decisão humana.
- Se estiver operacionalmente indisponível, incidentes altos/críticos podem ser contidos automaticamente.
- Incidente crítico sem administrador-chefe pode ativar automaticamente o Modo de Emergência.
- Modo de Emergência com funcionalidades selecionáveis e reversão auditada.
- Nenhum protocolo ofensivo, contra-ataque, eliminação de contas/dados ou escalada de privilégios.

## Prioridade 2 — Autenticação e recuperação
- Recuperação de palavra-passe implementada com token aleatório, hash SHA-256, uso único e expiração de 60 minutos.
- Solicitações limitadas por email.
- Sessões existentes são revogadas após redefinição.
- Entrega preparada por webhook HTTPS configurável.
- Em desenvolvimento, link pode ser devolvido explicitamente quando permitido.

## Prioridade 3 — Continuidade e backups
- Verificação `PRAGMA integrity_check`.
- Backup SQLite via `VACUUM INTO`.
- Verificação do ficheiro de backup depois da criação.
- Endpoint administrativo para criar/listar/verificar backups.
- Scheduler diário com retenção configurável.
- Documentada a necessidade de armazenamento persistente e cópia off-site em produção.

## Prioridade 4 — Hardening de produção
- Headers de segurança e CSP.
- Validação de Origin em pedidos mutáveis quando Origin é enviado.
- Limite de corpo de 25 MB.
- Proteção contra path traversal em mídia.
- `X-Forwarded-For` só deve ser confiado com `AGROLINK_TRUST_PROXY=true` atrás de proxy controlado.

## Governação
- Papéis: agricultor, técnico, transportador, admin, auditor, admin_chefe.
- Apenas admin_chefe promove para admin/auditor.
- Admin-chefe pode suspender/reativar outras contas, mas não a própria.
- Contas não podem ser eliminadas pelo painel/API administrativo.
- Denúncias entre utilizadores com histórico e decisão administrativa.

## Migrações
- `001_platform.sql`
- `002_security_admin_denuncias.sql`
- `003_security_trust_layer.sql`
- `004_emergency_recovery_backup.sql`

## Validação executada
- `node --check server/index.mjs` — PASS
- `node --check server/db.mjs` — PASS
- `node --check server/securityTrust.mjs` — PASS
- `node --check server/backup.mjs` — PASS
- 95 ficheiros TS/TSX transpilados para verificação sintática — 0 diagnósticos
- imports locais — 0 ausentes
- Teste de recuperação: gerar token → redefinir password → novo login — PASS
- Teste de Modo de Emergência: bloquear registos — PASS
- Teste de backup SQLite + integrity check — PASS

## Limitação conhecida
`npm ci` excedeu o tempo disponível nesta execução; portanto o build completo `tsc -b && vite build` continua pendente de um ambiente com instalação de dependências concluída. Não considerar o projeto pronto para produção apenas com a validação sintática.

## Estado de entrega
Esta versão contém o backend e frontend atualizados. Não foram feitas alterações a GitHub/main ou a Supabase remoto.

## 15/09/2026 — hardening final desta etapa

- Removido bypass automático de IP bloqueado para qualquer sessão administrativa; contenção de origem agora é efetiva para todos os utilizadores.
- Produção exige `AGROLINK_DATA_DIR` para persistência explícita.
- SQLite configurado com WAL + busy timeout.
- Endpoint de backups deixou de devolver caminhos absolutos do servidor.
- Avisos de configuração adicionados para recuperação de password e alertas externos.
- Smoke test do backend interno: `/api/health`, criação/promocão do administrador-chefe, autenticação e integridade/backup executados com sucesso.
- `npm run build` continua bloqueado neste ambiente porque a instalação completa de dependências do Node não concluiu; isto é uma pendência de ambiente, não foi mascarado como sucesso.

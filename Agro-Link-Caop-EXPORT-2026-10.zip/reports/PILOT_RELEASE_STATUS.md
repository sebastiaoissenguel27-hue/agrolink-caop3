# AgroLink Caop - Status de Release do Piloto

Data: 2026-09-18
Branch: `copilot/audit-2026-09-17`

## Decisão

**APTO PARA PILOTO CONTROLADO**, com dados de teste/staging e acompanhamento próximo da equipa. O fluxo de agricultor foi exercitado contra o backend local e o build continua aprovado.

Não é uma declaração de produção aberta: entrega de e-mail/SMS, deploy, domínio HTTPS, testes em dispositivos físicos e operação de suporte ainda precisam ser preparados no ambiente do piloto.

## Funcionalidades prontas

- Escolha de país e entrada na aplicação.
- Registo de agricultor com nome, e-mail, palavra-passe e localização.
- Login, sessão persistente e logout.
- Dashboard e rotas autenticadas.
- Criação de relato com tipo, descrição, localização, fotografias e áudio opcional.
- Persistência local de relatos e sincronização posterior via Dexie.
- Geração de código público do relato.
- Consulta anônima do relato por código.
- Acompanhamento do estado e respostas do técnico.
- Notícias e alertas com cache local quando aplicável.
- Assistente agrícola com fallback determinístico quando não há IA externa configurada.
- PWA com manifest, nome, descrição, `display: standalone`, `start_url`, ícones e service worker.
- Modo visitante offline e indicadores de sincronização.
- Painel administrativo para utilizadores, denúncias, segurança, emergência e backup/integridade, coberto pelo smoke de staging.

## Problemas corrigidos nesta fase

- O formulário de registo aceitava senhas com 6 caracteres, mas o backend exige 8. O `minLength` foi alinhado para 8, evitando uma rejeição previsível no piloto.

## Validação executada

- `npm run build`: **PASS**
- Registo via API local: **201**
- Login e sessão de agricultor: **200**
- Criação de relato: **201**, com código público
- Consulta do relato por código: **200**
- Notícias: **200**
- Alertas: **200**
- IA/fallback: **200**, resposta determinística sem chave externa
- `node scripts/build-preflight.mjs`: **PASS** na auditoria anterior
- `node scripts/security-autonomous-smoke.mjs`: **PASS** na auditoria anterior
- `node scripts/staging-smoke.mjs`: **PASS** na auditoria anterior

O teste visual automatizado não foi executado porque o container não possui as bibliotecas gráficas necessárias para iniciar o Chromium do Playwright (`libatk-1.0.so.0`). Isso é uma limitação do ambiente de validação, não um erro reportado pelo build.

## Funcionalidades ainda incompletas ou dependentes do ambiente

- Instalação PWA deve ser confirmada em Chrome/Edge Android e Safari iOS. O botão de instalação usa o evento nativo; no iOS apresenta a instrução de adicionar ao ecrã principal.
- Offline/reconexão deve ser repetido em dispositivo real, incluindo criação de relato sem rede e sincronização ao recuperar conexão.
- Recuperação de palavra-passe em staging exige configurar `AGROLINK_PASSWORD_RESET_WEBHOOK_URL` ou um provedor equivalente.
- Alertas externos de segurança exigem configuração opcional de `AGROLINK_SECURITY_ALERT_WEBHOOK_URL`.
- Conteúdo real de notícias e alertas precisa ser carregado pelo administrador ou pelo sincronizador RSS autorizado.
- Não há runner de testes unitários configurado no `package.json`.

## Problemas conhecidos

- `npm audit` reporta 5 vulnerabilidades transitivas de tooling/dependências (4 moderadas e 1 alta). Não foram tratadas nesta fase porque não há risco direto demonstrado ao runtime e uma atualização forçada poderia introduzir regressões.
- Teste visual mobile e teste de instalação dependem de um ambiente com browser funcional e/ou dispositivos físicos.
- O fallback de IA é informativo e não substitui validação de um técnico; perguntas de risco devem ser encaminhadas conforme o fluxo disponível.

## Instruções para iniciar

### Backend SQLite local

```bash
AGROLINK_DATA_DIR=/tmp/agrolink-data \
AGROLINK_UPLOADS_DIR=/tmp/agrolink-data/uploads \
AGROLINK_ADMIN_CHEFE_EMAIL=admin@example.com \
AGROLINK_ADMIN_CHEFE_PASSWORD='trocar-por-uma-palavra-passe-forte' \
npm run server
```

### Frontend Vite

Em outro terminal:

```bash
npm run dev
```

Abra `http://localhost:4173/`. O Vite encaminha `/api` para `http://localhost:8787`.

Para um ambiente de piloto, use HTTPS, um `AGROLINK_DATA_DIR` persistente e configure o provedor de recuperação de palavra-passe antes de convidar utilizadores reais.

## Instalação PWA

1. Abra o endereço HTTPS do piloto num navegador compatível.
2. No Chrome/Edge Android ou desktop, use o botão `Instalar app` quando aparecer no cabeçalho ou o comando de instalação do navegador.
3. No Safari iOS, use `Partilhar` e `Adicionar ao ecrã principal`.
4. Abra a aplicação instalada e confirme o carregamento da página inicial.
5. Com a aplicação carregada uma vez, teste uma consulta offline e depois a sincronização ao voltar à rede.

## Próximos passos do piloto

1. Publicar em staging HTTPS com SQLite persistente e backups persistentes.
2. Configurar recuperação de palavra-passe e canal de alertas sob responsabilidade da organização.
3. Criar contas de teste de agricultor e técnico sem reutilizar credenciais administrativas.
4. Repetir registo, relato, consulta, resposta técnica, offline/reconexão e PWA em Android e iOS.
5. Recolher feedback dos primeiros utilizadores sobre clareza dos formulários, consumo de dados e tempo de sincronização.
6. Tratar as vulnerabilidades transitivas em uma tarefa separada, com atualização controlada e nova validação.

## Governança da entrega

- Nenhum merge foi realizado.
- Nenhum push foi realizado.
- `main` não foi alterada.
- Nenhum serviço externo, banco externo ou credencial foi modificado.

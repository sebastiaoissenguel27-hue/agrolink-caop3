# AgroLink Caop - Readiness para Utilização Real

Data: 2026-09-18
Branch: `copilot/audit-2026-09-17`

## Estado final

**Pronto para piloto controlado** dos fluxos de agricultor, técnico, administração, denúncias, segurança, IA fallback, PWA e relatos offline.

**Ainda não pronto para anunciar um piloto logístico completo**: o código contém as tabelas SQLite e o perfil persistente de transportador, mas não contém páginas, serviços frontend ou endpoints de oportunidades/aceitação/atualização de fretes. Essa lacuna foi mantida explícita para não inventar uma logística diferente da definida anteriormente.

Não houve merge, push, deploy ou alteração de `main`.

## Estado dos módulos

| Módulo | Frontend | Backend/persistência | Estado |
| --- | --- | --- | --- |
| Escolha de país/visitante | Ligado | N/A | Operacional |
| Autenticação e sessão | Ligado | Node + SQLite | Operacional |
| Agricultor/dashboard | Ligado | Node + SQLite | Operacional |
| Relatos | Ligado | Criação, código, consulta, respostas e estados | Operacional |
| Offline/Dexie | Ligado | Fila de relatos e sync | Operacional onde suportado |
| Notícias | Ligado | SQLite e endpoints de leitura/admin | Operacional; sincronizador RSS ainda é placeholder |
| Alertas | Ligado | SQLite e endpoints de leitura/admin | Operacional |
| Assistente IA | Ligado | IA opcional + fallback determinístico | Operacional |
| Técnico | Ligado | Filtro por zona, resposta e estado | Operacional após aprovação |
| Transportador/perfil | Navegação segura, sem painel logístico | Perfil SQLite persistente | Parcial |
| Logística/fretes | Não há página/serviço ativo | Tabelas existem, endpoints de operação não | Incompleto |
| Administração | Ligado | Utilizadores, denúncias, conteúdo, auditoria | Operacional |
| Admin chefe/governança | Ligado | Promoção, suspensão, emergência, backup | Operacional |
| Recuperação de password | Ligado | Token hash, expiração e revogação | Operacional com webhook ou modo dev |
| PWA | Ligado | Manifest, service worker e cache de assets | Preparado para Android |

## Correções realizadas

1. `server/index.mjs` passou a incluir `verification_status` na sessão carregada pelo backend. Técnicos aprovados agora são reconhecidos pelo filtro de zona e podem responder a relatos.
2. A criação de relatos tornou-se idempotente pelo `id` local quando o mesmo agricultor repete uma sincronização. Isso evita duplicação e evita que uma falha após o POST deixe o relato preso para sempre.
3. O endpoint genérico passou a persistir o perfil da tabela `transportadores` por `utilizador_id`, com atualização segura do próprio perfil ou por administração.
4. O contexto de autenticação frontend trata falha inicial de rede sem rejeição não tratada.
5. A navegação do papel `transportador` deixou de mostrar links de agricultor, como `/relatos`, que seriam recusados pelo controle de papel.
6. Foi criado `scripts/real-use-smoke.mjs`, um teste reproduzível dos fluxos principais e da persistência após restart.
7. A chamada opcional da IA no SecurityTrust agora usa `AbortController` com timeout de 8 segundos. Timeout, erro HTTP, resposta inválida ou falha de rede seguem para o fallback determinístico sem alterar a severidade ou interromper a contenção.

## Testes executados

- `npm ci`: passou anteriormente com lockfile normalizado.
- `npm run build`: passou após as correções.
- `npx tsc --noEmit`: passou anteriormente e está incluído no build.
- `node scripts/build-preflight.mjs`: passou anteriormente: 95 fontes, zero erros sintáticos/imports ausentes/falhas de lock.
- `node scripts/security-autonomous-smoke.mjs`: passou.
- `node scripts/staging-smoke.mjs`: passou.
- `node scripts/real-use-smoke.mjs`: passou com 13 verificações:
  - agricultor: registo, login, sessão, relato, código, consulta e retry idempotente;
  - técnico: aprovação, listagem por zona, resposta e alteração de estado;
  - transportador: registo, login e perfil persistente;
  - admin: utilizadores e denúncias;
  - notícias, alertas e fallback de IA;
  - recuperação de password e revogação de sessões;
  - emergency mode;
  - backup/integrity;
  - persistência após restart do SQLite;
  - logout.
- `npm start` com `NODE_ENV=production`: iniciou e serviu health `200`, HTML `200`, manifest `200` e service worker `200`.
- `git diff --check`: passou.
- Teste sintético de timeout da IA: **PASS**; `AbortSignal` acionado em aproximadamente 8 segundos, fallback persistido, incidente contido, ações defensivas executadas e processo encerrado sem ficar pendurado.

## Funcionalidades operacionais para o primeiro piloto

- Agricultores podem criar contas, iniciar sessão e consultar o painel.
- Relatos podem ser guardados localmente, sincronizados e consultados pelo código público.
- Retries de sincronização do mesmo relato não duplicam a linha no SQLite.
- Técnicos precisam ser aprovados pelo admin e depois veem relatos da sua província, respondem e atualizam o estado.
- Notícias e alertas podem ser consultados e ficam em cache quando os serviços correspondentes fazem cache local.
- IA continua disponível com resposta fallback quando `OPENAI_API_KEY` não existe.
- A IA de segurança é uma camada auxiliar: a severidade e a proteção continuam determinadas pelo motor determinístico, inclusive após timeout.
- Administradores conseguem gerir utilizadores, denúncias, conteúdo e segurança.
- Admin chefe mantém controle de promoção, suspensão/reactivação, emergência e backup.
- PWA é servida com `display: standalone`, `start_url=/`, ícones e service worker.

## Offline e conectividade fraca

O relato é gravado primeiro no Dexie, com estado pendente e erro de sincronização visível. A sincronização é tentada quando existe rede, no evento `online`, ao iniciar uma sessão e pelo botão manual. Mídias ficam em fila local e são enviadas durante a sincronização.

Notícias, alertas, recursos, biblioteca, academia e notificações possuem caches locais conforme cada serviço. A IA e a abertura de ficheiros da biblioteca dependem de rede; a interface deve comunicar essa limitação.

O teste real em Android instalado, com rádio desligado e reconexão, não pôde ser feito neste container por falta de bibliotecas gráficas do Chromium e de um dispositivo físico. O teste de persistência/sincronização do backend foi executado em SQLite temporário.

## Configuração necessária

Variáveis obrigatórias em produção:

```env
NODE_ENV=production
AGROLINK_DATA_DIR=/srv/agrolink/data
AGROLINK_UPLOADS_DIR=/srv/agrolink/uploads
AGROLINK_BACKUP_DIR=/srv/agrolink/backups
AGROLINK_ADMIN_CHEFE_EMAIL=admin-chefe@example.org
AGROLINK_ADMIN_CHEFE_PASSWORD=<definir diretamente no servidor>
AGROLINK_PUBLIC_URL=https://agrolink.example.org
```

Variáveis opcionais:

```env
OPENAI_API_KEY=<opcional; somente no backend>
OPENAI_MODEL=gpt-4o-mini
AGROLINK_PASSWORD_RESET_WEBHOOK_URL=<webhook HTTPS controlado>
AGROLINK_SECURITY_ALERT_WEBHOOK_URL=<webhook HTTPS controlado>
AGROLINK_BACKUP_RETENTION=14
AGROLINK_TRUST_PROXY=false
```

Não colocar valores reais em `.env.example`, no frontend ou no Git. O backend deve usar armazenamento persistente; hospedagem puramente estática não é compatível com SQLite, sessões, uploads e backups.

Sem webhook de recuperação em produção, o backend não entrega o link ao utilizador; o modo de devolver o link diretamente é apenas para desenvolvimento/testes (`AGROLINK_ALLOW_DEV_RECOVERY_LINK=true`).

## Passos para deployment

1. Usar um servidor Node com HTTPS/reverse proxy controlado e disco persistente.
2. Copiar o projeto sem `.env` e sem dados temporários.
3. Configurar as variáveis acima no ambiente secreto do servidor.
4. Executar `npm ci`.
5. Executar `npm run build`.
6. Executar `npm start` com `NODE_ENV=production`.
7. Confirmar `GET /api/health` e verificar `database: internal`.
8. Confirmar `GET /manifest.webmanifest` e `GET /sw.js`.
9. Confirmar permissões de leitura/escrita em `AGROLINK_DATA_DIR`, uploads e backups.
10. Confirmar backup, integrity check e retenção em disco persistente.
11. Configurar monitorização do processo e rotação/armazenamento dos logs.

Não foi feito deploy automático.

## Passos para o primeiro piloto

1. Criar ambiente de staging isolado com dados persistentes.
2. Configurar o admin chefe e o webhook de recuperação de password.
3. Criar uma conta de teste de agricultor e uma de técnico; aprovar o técnico pelo painel.
4. Testar em Android real: registo, login, relato online, relato offline, reconexão, consulta por código e resposta técnica.
5. Instalar a PWA pelo Chrome Android e repetir o teste de abertura após instalação.
6. Publicar conteúdo inicial de alertas e notícias no painel administrativo.
7. Definir a equipa que responde aos relatos e o tempo esperado de resposta.
8. Só depois convidar um grupo pequeno de agricultores e acompanhar erros de sync e suporte.

## Limitações e riscos restantes

- Logística de fretes ainda não possui fluxo de produto; transportadores podem registar-se e persistir o perfil, mas não aceitar oportunidades dentro da aplicação.
- Sincronização RSS de notícias retorna uma mensagem de indisponibilidade até o agendador interno ser implementado/configurado.
- Testes de browser visual, instalação PWA e offline real em Android/iOS não foram possíveis neste ambiente.
- Entrega externa de recuperação de password e alertas críticos depende de webhooks configurados pela organização.
- `npm audit` reporta vulnerabilidades transitivas de tooling; não foram alteradas nesta fase por não haver risco direto demonstrado ao runtime.
- Não existe runner de testes unitários configurado no `package.json`.
- O caminho real com o fornecedor OpenAI continua pendente enquanto não existir `OPENAI_API_KEY` no ambiente de teste; nenhum teste externo foi fingido ou executado com uma chave criada para este trabalho.

## Arquivos alterados nesta fase

- `server/index.mjs`
- `server/securityTrust.mjs`
- `src/features/auth/context/AuthContext.tsx`
- `src/app/components/AppLayout.tsx`
- `scripts/real-use-smoke.mjs`
- `reports/REAL_USE_READINESS.md`

Alterações anteriores de build/auditoria permanecem na mesma branch e estão descritas nos relatórios existentes em `reports/`.

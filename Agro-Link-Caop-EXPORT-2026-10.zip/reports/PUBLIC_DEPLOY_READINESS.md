# AgroLink Caop - Public Deploy Readiness

Data da validação: 2026-09-18
Branch: `copilot/audit-2026-09-17`

## Estado atual

O projeto está apto para um piloto controlado em infraestrutura Node.js com HTTPS, volume persistente e acompanhamento operacional. Os fluxos de agricultor, técnico aprovado, transportador, administração, segurança, IA sem chave externa e persistência SQLite passaram nos smoke tests locais. Isto não constitui autorização para abertura pública sem configurar a infraestrutura e os canais operacionais indicados abaixo.

## Arquitetura

- Frontend: React + TypeScript + Vite.
- Backend: Node.js HTTP interno, servido pelo mesmo processo em produção.
- Persistência: SQLite via `node:sqlite`, migrations SQL idempotentes e WAL.
- Offline: Dexie/PWA com sincronização posterior no frontend.
- Produção: `server/index.mjs` serve `dist`, API `/api/*` e fallback SPA para rotas React.
- Segurança: cookies HttpOnly, SameSite, CSRF/origin check, headers de segurança, rate limiting, auditoria, `securityTrust`, contenção reversível e modo de emergência.

## Execução

Build:

```bash
npm ci
npm run build
```

Produção:

```bash
NODE_ENV=production \
PORT=8787 \
AGROLINK_DATA_DIR=/data/agrolink \
AGROLINK_UPLOADS_DIR=/data/agrolink/uploads \
npm start
```

Health: `GET /api/health`, esperado `200` com `ok: true` e `database: "internal"`.

## Persistência obrigatória

O provedor deve manter volumes persistentes para:

- `AGROLINK_DATA_DIR`: banco SQLite e dados da aplicação.
- `AGROLINK_UPLOADS_DIR`: fotografias, áudio e documentos carregados.
- `AGROLINK_BACKUP_DIR`: backups SQLite, preferencialmente em volume ou destino externo distinto.

O processo falha intencionalmente em `NODE_ENV=production` quando `AGROLINK_DATA_DIR` não está definido. As migrations são aplicadas uma vez e registadas em `_agrolink_migrations`. Backups manuais e automáticos usam `VACUUM INTO` e `PRAGMA integrity_check`.

## Variáveis de ambiente

Necessárias no piloto:

- `NODE_ENV=production`
- `PORT`
- `AGROLINK_DATA_DIR`
- `AGROLINK_ADMIN_CHEFE_EMAIL`
- `AGROLINK_ADMIN_CHEFE_PASSWORD` apenas para o bootstrap inicial, com segredo forte

Recomendadas:

- `AGROLINK_UPLOADS_DIR`
- `AGROLINK_BACKUP_DIR`
- `AGROLINK_BACKUP_RETENTION`
- `AGROLINK_PUBLIC_URL`
- `AGROLINK_PASSWORD_RESET_WEBHOOK_URL`
- `AGROLINK_SECURITY_ALERT_WEBHOOK_URL`
- `AGROLINK_TRUST_PROXY=true` somente atrás de reverse proxy controlado

## Secrets

- `AGROLINK_ADMIN_CHEFE_PASSWORD`
- `OPENAI_API_KEY`, opcional
- Credenciais dos webhooks de recuperação de palavra-passe e alertas, se o provedor exigir autenticação

Nenhum secret deve ser colocado no frontend, no repositório ou em imagens públicas.

## PWA e rede fraca

O build gera manifest, ícones e service worker. O servidor de produção serve estes artefactos e devolve `index.html` para rotas client-side, permitindo abrir diretamente páginas como `/login`. O cache/offline de dados é tratado por Dexie e pelo motor de sincronização existente. A instalação e o comportamento de reconexão ainda devem ser confirmados em Android e iOS reais, em redes móveis representativas.

## Funcionalidades futuras ou dependentes de operação

- Oportunidades logísticas completas ainda não estão implementadas; o módulo de transportador mantém cadastro e perfil funcionais sem apresentar dados fictícios.
- Sincronização RSS de notícias está reservada para um agendador/backend autorizado; conteúdo real deve ser carregado por administração enquanto isso.
- Recuperação de palavra-passe exige webhook/provedor configurado em produção.
- Alertas externos de segurança são opcionais; sem webhook, ficam nas notificações internas.
- IA externa é opcional. Sem `OPENAI_API_KEY`, o fallback determinístico mantém o serviço disponível; com chave, erros e timeout devem ser monitorizados.
- Testes em dispositivos físicos, instalação PWA e operação de suporte não podem ser concluídos apenas neste container.

## Testes executados

Todos os comandos abaixo passaram em 2026-09-18:

- `npm ci` - PASS; 5 vulnerabilidades transitivas reportadas pelo npm (4 moderadas, 1 alta).
- `npm run build` - PASS.
- `node scripts/build-preflight.mjs` - PASS: 95 ficheiros, 0 erros de sintaxe, 0 imports locais ausentes, 0 falhas de lockfile.
- `node scripts/security-autonomous-smoke.mjs` - PASS: incidente crítico contido, IP bloqueado e modo de emergência ativado.
- `node scripts/staging-smoke.mjs` - PASS: admin-chefe, autenticação, promoção, denúncias, suspensão, reativação, emergência e backup.
- `node scripts/real-use-smoke.mjs` - PASS: HTML, fallback SPA, manifest, service worker, agricultor, relato, técnico, transportador, admin, IA, reset, backup, restart e logout.
- `npx tsc --noEmit` - PASS.
- `git diff --check` - PASS.

## Antes da publicação

1. Configurar HTTPS, domínio, reverse proxy e volume persistente.
2. Definir os secrets fora do repositório e criar o admin-chefe apenas por bootstrap controlado.
3. Configurar backups externos e testar restauração, não apenas criação/integridade.
4. Configurar o provedor de recuperação de palavra-passe e o canal de alertas de segurança.
5. Executar os fluxos offline/PWA em Android e iOS reais.
6. Definir monitorização, retenção de logs, suporte e procedimento de resposta a incidentes.
7. Rever as 5 vulnerabilidades transitivas antes de uma exposição pública ampla.

Não foi feito merge, push para `main` nem deploy automático.

# AgroLink Caop — Base de dados interna

A partir desta versão, o AgroLink Caop **não depende do Supabase**.

- Banco: SQLite interno (`data/agrolink.sqlite`), criado pelo backend.
- API: `server/index.mjs`.
- Sessões: cookie HTTP-only; palavra-passe com PBKDF2-SHA512.
- A base de dados não é exposta ao navegador nem por uma API SQL genérica.
- Utilizadores normais só chegam aos dados através de endpoints com regras de acesso.
- Administradores têm acesso às áreas administrativas.
- **Administrador-chefe (`admin_chefe`)** é o único papel autorizado a promover `admin`/`auditor`.
- O administrador-chefe **não pode eliminar contas**; o backend bloqueia qualquer DELETE de perfis/utilizadores.
- `auditor` tem acesso de leitura às áreas administrativas/auditoria, sem poderes de alteração.
- Nenhum formulário público pode criar `admin`, `admin_chefe` ou `auditor`.
- O primeiro administrador-chefe só é criado através de `AGROLINK_ADMIN_CHEFE_EMAIL` + `AGROLINK_ADMIN_CHEFE_PASSWORD` no servidor.

## Desenvolvimento

Terminal 1:

`npm run server`

Terminal 2:

`npm run dev`

O Vite encaminha `/api/*` para o backend interno em `localhost:8787`.

## Produção

`npm run build`

`npm start`

O backend serve também o `dist/` gerado.

## Nota sobre dados antigos

Esta migração remove a dependência de Supabase no código, mas **não copia dados de uma instância remota do Supabase**, porque isso exigiria acesso à base remota. O schema interno preserva as principais tabelas e relações do modelo AgroLink. A importação de dados existentes pode ser feita depois, caso seja disponibilizado um dump/export autorizado.

## Governança administrativa e denúncias

- A base de dados é interna ao backend e não é exposta diretamente ao navegador.
- O papel `admin_chefe` é reservado a uma única conta e não pode ser criado por promoção normal.
- O administrador-chefe pode promover utilizadores para `admin` ou `auditor`.
- O administrador-chefe pode suspender qualquer outra conta, incluindo agricultor, técnico, auditor ou administrador, sempre com motivo registado.
- A suspensão invalida imediatamente as sessões da conta alvo. O administrador-chefe não pode suspender a própria conta.
- Contas de utilizadores não podem ser eliminadas pelo painel administrativo.
- Qualquer utilizador autenticado pode enviar uma denúncia contra outro utilizador. A denúncia é registada e gera notificações para administradores e auditores ativos.
- Administradores podem tratar denúncias; auditores têm acesso de consulta; o administrador-chefe também pode suspender diretamente o utilizador denunciado.

## Security & Trust Layer

A plataforma inclui uma camada defensiva de segurança com:
- deteção de padrões anormais de autenticação e excesso de pedidos;
- incidentes persistentes, ações e auditoria;
- análise IA opcional, sem permitir instruções ofensivas;
- protocolo autónomo para cenários de indisponibilidade do administrador-chefe;
- contenção automática apenas reversível e defensiva (bloqueio temporário de origem), sem eliminação de contas ou dados e sem contra-ataque;
- quando o administrador-chefe está disponível, incidentes relevantes ficam em `aberto` e geram uma notificação pedindo decisão;
- painel administrativo de incidentes e relatórios;
- relatório mensal automático do mês anterior, guardado na base e enviado como notificação ao administrador-chefe.

### Protocolo autónomo

1. O motor recolhe sinais e cria um incidente.
2. A IA classifica/explica o risco quando disponível; o motor determinístico continua a funcionar se a IA externa estiver indisponível.
3. Risco relevante + administrador-chefe disponível: notificar e aguardar decisão humana.
4. Risco alto/crítico + administrador-chefe indisponível: aplicar somente contenção defensiva reversível, registar a ação e notificar o administrador-chefe assim que a conta voltar a estar disponível.
5. O sistema nunca contra-ataca a origem, apaga contas, apaga dados ou promove privilégios automaticamente.

## Security & Trust Layer — operação autónoma

- A plataforma deteta falhas repetidas de autenticação, excesso global de pedidos e pedidos potencialmente malformados/suspeitos.
- O administrador-chefe recebe a recomendação da IA e decide quando está disponível.
- Quando não há sessão ativa do administrador-chefe, risco alto/crítico pode ativar contenção defensiva reversível.
- Incidentes alto/crítico que permaneçam sem decisão por 5 minutos também podem ser escalados para o protocolo autónomo se o administrador-chefe continuar indisponível.
- A contenção limita temporariamente a origem; não existe contra-ataque, exploração externa, eliminação de dados/contas ou promoção automática de privilégios.
- Alertas críticos podem ser encaminhados para um webhook HTTPS configurado em `AGROLINK_SECURITY_ALERT_WEBHOOK_URL`.
- O painel de segurança faz atualização periódica e pode mostrar notificações do navegador quando o administrador-chefe autorizar.
- O backend aplica cabeçalhos de segurança e valida a origem de pedidos mutáveis.

## Segurança operacional adicional — 15/09/2026

- **Modo de Segurança:** `normal`, `alerta` e `emergencia`. Apenas o administrador-chefe pode alterar o modo. Em emergência, funcionalidades selecionadas podem ser colocadas em proteção (`registos`, `uploads`, `ia`, `logistica`, `notificacoes`, `academia`). O administrador-chefe mantém acesso de emergência para recuperar o serviço.
- **Escalação autónoma:** se um incidente atingir nível crítico e o administrador-chefe estiver operacionalmente indisponível, o sistema pode ativar automaticamente o Modo de Emergência e aplicar contenção reversível. Isto nunca elimina contas/dados, não promove privilégios e não executa contra-ataques.
- **Recuperação de palavra-passe:** tokens aleatórios com hash SHA-256, expiração de 60 minutos, uso único e revogação das sessões existentes após redefinição. Em produção deve ser configurado `AGROLINK_PASSWORD_RESET_WEBHOOK_URL` e `AGROLINK_PUBLIC_URL`; em desenvolvimento pode-se permitir o link direto com `AGROLINK_ALLOW_DEV_RECOVERY_LINK=true`.
- **Backups:** `VACUUM INTO` cria cópias SQLite verificadas com `PRAGMA integrity_check`. Há endpoint administrativo e agendamento automático diário, com retenção configurável (`AGROLINK_BACKUP_RETENTION`).
- **Persistência:** `AGROLINK_DATA_DIR` e `AGROLINK_BACKUP_DIR` devem apontar para armazenamento persistente no ambiente de produção. Não usar filesystem efémero nem múltiplas instâncias com SQLite local sem uma estratégia explícita de persistência/serialização.
- **Proxy:** `X-Forwarded-For` só é considerado quando `AGROLINK_TRUST_PROXY=true` e deve existir um reverse proxy controlado.

## Requisitos adicionais de produção

- `AGROLINK_DATA_DIR` é obrigatório em produção e deve apontar para um volume persistente. O servidor recusa iniciar em produção sem essa variável.
- SQLite usa WAL e `busy_timeout` para melhorar a resistência a concorrência local.
- A recuperação de palavra-passe exige `AGROLINK_PASSWORD_RESET_WEBHOOK_URL` para entrega real em produção.
- `AGROLINK_SECURITY_ALERT_WEBHOOK_URL` é recomendado para alertas fora do navegador; sem ele, os alertas permanecem no sistema interno.
- Backups devem ser armazenados em volume persistente separado e periodicamente copiados para armazenamento externo seguro.

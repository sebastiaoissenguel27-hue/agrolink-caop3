# Conteúdo do pacote Claude

Incluído: código-fonte atual, backend, frontend, migrations internas, scripts de smoke/preflight, documentação e relatórios de auditoria.

Excluído intencionalmente:
- `node_modules/` — Claude deve executar `npm ci` num ambiente com Internet.
- `data/` — contém o SQLite/runtime state local e não é necessário para instalar/buildar o projeto.
- `server/uploads/` — uploads privados/runtime.
- `.env` e segredos reais.
- `dist/` e artefactos de build.
- `*.tsbuildinfo`.

O `.env.example` foi incluído.

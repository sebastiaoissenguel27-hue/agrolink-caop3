
> **Estado arquitetural atualizado (15/09/2026):** o runtime ativo foi migrado de Supabase para a base de dados interna do AgroLink (`server/db.mjs` + `server/migrations/001_platform.sql`). As referências a Supabase nestes documentos podem ser históricas.

# AgroLink Caop — Reconstruction Audit

Data da auditoria: 2026-08-27
Fonte auditada: `agrolink-caop-v3-handoff.zip`
Repositório: `sebastiaoissenguel27-hue/agrolink-caop`

## Escopo e segurança da auditoria

Esta fase foi somente de leitura. O handoff foi inspecionado diretamente e também extraído apenas para `/tmp/agrolink-caop-handoff-audit/`, fora do workspace. Não foram criados branches, instaladas dependências, executadas migrations, feitos deploys ou alterações no Supabase.

`.git` e `node_modules` foram excluídos da comparação. O ZIP passou em `unzip -tq` sem erros e contém 116 ficheiros, além das entradas de diretórios.

## Estado inicial

- Branch atual: `main`
- Remote: `origin https://github.com/sebastiaoissenguel27-hue/agrolink-caop`
- Estado Git: `main...origin/main`, sem alterações locais reportadas
- Handoff encontrado: `agrolink-caop-v3-handoff.zip`
- O workspace atual contém 19 ficheiros e não contém a árvore de aplicação restaurada.

## Comparação handoff versus repositório

Comparação feita por caminho normalizado (`agrolink-caop/` removido do ZIP) e SHA-256.

| Estado | Quantidade |
|---|---:|
| IDÊNTICOS | 0 |
| AUSENTES | 115 |
| DIFERENTES | 1 |
| ADICIONAIS NO REPO | 18 |

Nota: o handoff contém 116 ficheiros. O único caminho comum é `README.md`, mas o conteúdo difere. A contagem anterior de ausentes que incluía `public/icons/.gitkeep` não corresponde a ficheiro presente no ZIP atual; a listagem e os hashes desta auditoria consideram somente as 116 entradas de ficheiro efetivas.

### Ficheiro diferente

- `README.md`

### Ficheiros adicionais no repositório

- `AgroLink IA v2 - Editor do projeto - Apps Script`
- `agrolink-caop-v3-handoff.zip`
- `agrolink-caop-v3.zip`
- `gemini-code-1787317227401.py`
- `gemini-code-1787317744554.py`
- `gemini-code-1787353208324.txt`
- `gemini-code-1787353582715.py`
- `gemini-code-1787414864005.md`
- `gemini-code-1787426587052.txt`
- `gemini-code-1787426592369.md`
- `gemini-code-1787426594805.md`
- `gemini-code-1787426596445.md`
- `gemini-code-1787426599210.md`
- `gemini-code-1787426600729.ts`
- `gemini-code-1787426606474.ts`
- `gemini-code-1787426608402.ts`
- `gemini-code-1787426609910.txt`
- `gemini-code-1787426612922.ts`

### Estrutura esperada no handoff

- Ficheiros de raiz: `package.json`, `tsconfig.json`, `vite.config.ts`, `index.html`, `README.md`, `PROJECT_STATUS.md`, `HANDOFF_SUMMARY.md`, `HANDOFF_PROMPT.md`, `.env.example`
- `src/`: 70 ficheiros
- `docs/`: 7 ficheiros
- `supabase/migrations/`: 26 ficheiros SQL
- `supabase/functions/`: 3 ficheiros `index.ts`
- `public/`: apenas referências/configuração de ícones; os três PNG pedidos não estão no ZIP

### Estrutura atual

- `README.md`
- 17 ficheiros auxiliares `gemini-code-*`/documentos
- um ficheiro chamado `AgroLink IA v2 - Editor do projeto - Apps Script`
- `agrolink-caop-v3.zip`
- `agrolink-caop-v3-handoff.zip`
- Não existem `src/`, `docs/`, `public/`, `supabase/`, `package.json`, `tsconfig.json`, `vite.config.ts` ou `index.html`.

## Configuração auditada

- `package.json`: React 18, TypeScript 5.5, Vite 5.4, React Router 6, Supabase JS, Dexie e `vite-plugin-pwa`; scripts `dev`, `build`, `preview` e `lint`.
- `tsconfig.json`: `strict: true`, `noUnusedLocals`, `noUnusedParameters`, aliases somente para `@/app/*`, `@/features/*` e `@/shared/*`.
- `vite.config.ts`: React e PWA configurados; os aliases Vite também não incluem `@/offline`.
- `index.html`: entrada React, idioma `pt-AO`, metadata PWA e referência a `/icons/icon-192.png`.
- `.env.example`: contém somente placeholders `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY`.

### Problemas de configuração

- **ALTO — Alias offline não configurado:** vários ficheiros importam `@/offline/db` e `@/offline/syncEngine`, mas esse alias não existe em `tsconfig.json` nem em `vite.config.ts`. Isto deve causar imports quebrados em TypeScript/Vite.
- **MÉDIO — Build não verificável neste ambiente:** o clone temporário não tem `node_modules`; `npm run build` terminou com `tsc: not found` (exit 127). Não foi executado `npm install` por esta ser uma auditoria e por não haver autorização para instalar dependências nesta fase.
- **MÉDIO — Lint não verificável:** `npm run lint` terminou com `eslint: not found` (exit 127). Além disso, o handoff não contém configuração ESLint visível.
- **MÉDIO — Ícones PWA ausentes:** o manifest e `index.html` referenciam `icon-192.png`, `icon-512.png` e `icon-512-maskable.png`, mas esses três ficheiros não estão no ZIP.

## Edge Functions

### Funções presentes no handoff

1. `supabase/functions/ia-agricola-proxy/index.ts`
2. `supabase/functions/sync-noticias/index.ts`
3. `supabase/functions/ia-resumo-mensal/index.ts`

### Estado do proxy IA

- **CRÍTICO — `ia-agricola-proxy` parece truncado/incompleto.** O ficheiro contém `if (req.method !== 'POST')` em escopo de módulo, sem wrapper `Deno.serve(...)` e sem declaração de `req`. Termina com `});`, que aparenta ser o fecho de um wrapper ausente. A função tem 176 linhas e zero ocorrências de `Deno.serve`, ao contrário das outras duas functions.
- Não foi inventado nem aplicado código para completar o trecho.
- A chave Anthropic é obtida por `Deno.env.get('ANTHROPIC_API_KEY')`; não foi encontrada chave real hardcoded.

### Outras Edge Functions

- `sync-noticias/index.ts`: 186 linhas, um `Deno.serve`, usa `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY` e opcionalmente `ANTHROPIC_API_KEY` via ambiente.
- `ia-resumo-mensal/index.ts`: 108 linhas, um `Deno.serve`, usa os secrets via `Deno.env`.
- **INFORMATIVO:** não foi feito deploy nem validação no runtime Deno/Supabase.
- **MÉDIO:** as funções dependem de secrets/configuração remota (`SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `SUPABASE_ANON_KEY` e/ou `ANTHROPIC_API_KEY`); a presença desses valores no ambiente não foi testada.

## Migrations, banco e RLS

- O handoff contém exatamente as migrations `0001` até `0028`, em ordem, sem lacunas.
- O repositório atual contém zero migrations.
- Foram encontradas 38 ocorrências de ativação de RLS nas migrations.
- A análise textual encontrou declarações repetidas para as policies `profiles_insert_proprio` e `profiles_update_proprio`, e para `ao_responder_relato()`. Isto pode ser intencional em migrations incrementais, mas requer execução controlada numa base descartável para confirmar idempotência/conflitos.
- **ALTO:** as migrations não foram executadas, portanto schema, RPCs, policies, constraints e compatibilidade efetiva com o código permanecem pendentes.
- **INFORMATIVO:** os serviços e functions referenciam tabelas/RPCs do domínio de perfis, relatos, notícias, notificações, IA, academia, biblioteca, recursos e preferências; a fonte de tipos `src/shared/types/database.types.ts` está incluída no handoff.

## Fluxos e arquitetura identificados

- Autenticação: login, registo, recuperação e redefinição de password, contexto de sessão e rotas protegidas.
- Agricultor: dashboard, perfil, relatos, alertas, notícias, assistente IA, ferramentas, recursos, biblioteca, academia e configurações.
- Relatos: criação anónima/autenticada, consulta, estados, respostas técnicas e sincronização.
- Administrador: utilizadores, relatos/mensagens, notícias/fontes, academia, biblioteca, recursos, alertas, IA, estatísticas e auditoria.
- Técnico: lista e detalhe de relatos para acompanhamento/resposta.
- Offline: Dexie/IndexedDB em `src/offline/db.ts`, motor de sincronização em `src/offline/syncEngine.ts`, cache e filas para operações selecionadas.
- PWA: `vite-plugin-pwa`, service worker registado em `src/main.tsx`, manifest e cache Workbox.

### Rotas declaradas

`/entrar`, `/registar`, `/esqueci-password`, `/redefinir-password`, `/relato-anonimo`, `/sobre`, `/acesso-negado`, `/conta-pendente`, `/conta-bloqueada`, `/`, `/perfil`, `/noticias`, `/alertas`, `/assistente`, `/configuracoes`, `/ferramentas`, `/recursos`, `/biblioteca`, `/academia`, `/academia/:cursoId`, `/relatos`, `/tecnico` e `/admin`.

As referências de navegação observadas correspondem a estas rotas principais. A validação de compilação e execução continua pendente por falta das dependências.

## Segurança

- **INFORMATIVO:** não foram encontrados padrões de chaves Anthropic, JWT ou service-role hardcoded no conteúdo auditado.
- **INFORMATIVO:** o frontend usa `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY`; a chave Anthropic aparece somente nas Edge Functions.
- **ALTO — Validação pendente:** uso efetivo de RLS, autorização por papel e exposição de dados não pode ser confirmado sem aplicar migrations num ambiente de teste controlado. Nenhuma migration foi executada.
- **MÉDIO — Entrada externa:** o proxy aceita imagem em base64 e as funções fazem fetch de RSS/Anthropic; limites, timeouts e validação operacional devem ser verificados antes do piloto.
- O README contém apenas um exemplo abreviado `sk-ant-...` como documentação de comando, não uma credencial utilizável.

## Classificação consolidada

| Severidade | Problema |
|---|---|
| CRÍTICO | `ia-agricola-proxy/index.ts` está sem wrapper `Deno.serve`, com `req` fora de escopo e fecho incompleto. |
| ALTO | Aliases `@/offline/*` usados pelo código não estão configurados em TypeScript/Vite. |
| ALTO | RLS, schema e RPCs não foram validados em execução; o repositório atual não possui migrations. |
| MÉDIO | Build não executável sem dependências instaladas (`tsc: not found`). |
| MÉDIO | Lint não executável e configuração ESLint não encontrada no handoff. |
| MÉDIO | Ícones PWA referenciados estão ausentes. |
| MÉDIO | Secrets/configuração remota das Edge Functions ainda não foram verificados em ambiente de teste. |
| MÉDIO | Validação de entradas, limites e timeouts de IA, imagens e RSS requer testes antes do piloto. |
| INFORMATIVO | ZIP íntegro; migrations 0001–0028 e três Edge Functions estão presentes no pacote. |
| INFORMATIVO | Não foram encontradas credenciais reais hardcoded. |

## Estratégia recomendada para a próxima fase

1. Criar um checkpoint e uma branch de piloto, sem tocar em `main`.
2. Restaurar apenas ficheiros ausentes do handoff; comparar `README.md` antes de qualquer sobrescrita.
3. Corrigir primeiro a integridade estrutural do proxy e a resolução dos aliases, documentando cada alteração.
4. Instalar exatamente as dependências declaradas, sem alterar versões, e executar TypeScript/build/lint.
5. Validar migrations e RLS somente num ambiente Supabase de teste, nunca em produção.
6. Tratar os ícones PWA como pendência explícita, sem inventar assets nesta etapa.
7. Testar primeiro autenticação, relatos, assistente IA, mobile/PWA e offline essencial antes de funcionalidades secundárias.

## Conclusão

O workspace atual não corresponde ao codebase de handoff. O pacote é acessível e íntegro, mas a referência não está pronta para reconstrução cega: há pelo menos um ficheiro de Edge Function truncado, um alias de import ausente, assets PWA ausentes e validações de build/lint ainda não executadas com dependências disponíveis. A reconstrução deve aguardar autorização explícita após esta auditoria.

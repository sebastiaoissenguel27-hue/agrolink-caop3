import test, { after, before } from 'node:test';
import assert from 'node:assert/strict';
import { spawn, spawnSync } from 'node:child_process';
import { createServer } from 'node:net';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const ROOT = process.cwd();
const CONFIG = path.join(ROOT, '.wrangler', 'wrangler.worker-test.toml');
const WRANGLER_CLI = path.join(ROOT, 'node_modules/wrangler/bin/wrangler.js');
const PASSWORD = 'LocalCloudflare123!';
const USER_ONE = { id: 'worker-local-user-one', email: 'worker-one@example.test', name: 'Utilizador Worker Um' };
const USER_TWO = { id: 'worker-local-user-two', email: 'worker-two@example.test', name: 'Utilizador Worker Dois' };
const RECOVERY_USER = { email: 'worker-recovery@example.test', name: 'Utilizador Recuperação' };
const RECOVERY_PASSWORD = 'RecoveryWorker123!';
const TECH_USER = { id: 'worker-local-tech', email: 'worker-tech@example.test', name: 'Técnico Verificado' };
const UNVERIFIED_TECH_USER = { id: 'worker-local-unverified-tech', email: 'worker-unverified-tech@example.test', name: 'Técnico Não Verificado' };
const ADMIN_USER = { id: 'worker-local-admin', email: 'worker-admin@example.test', name: 'Admin Normal' };
const AUDITOR_USER = { id: 'worker-local-auditor', email: 'worker-auditor@example.test', name: 'Admin Auditor' };
const HIDDEN_USER = { id: 'worker-local-hidden', email: 'worker-hidden@example.test', name: 'Perfil Oculto' };
const ADMIN_EMAIL = 'sebastiaoissenguel27@gmail.com';
const ADMIN_PASSWORD = 'WorkerChief123!';
let persistDirectory;
let port;
let server;
let serverOutput = '';
let userOneCookie;
let userTwoCookie;
let adminCookie;
let technicianCookie;
let unverifiedTechnicianCookie;
let normalAdminCookie;
let auditorCookie;

function runWrangler(args) {
  const result = spawnSync(process.execPath, [WRANGLER_CLI, ...args], {
    cwd: ROOT,
    encoding: 'utf8',
    timeout: 60000,
    env: { ...process.env, WRANGLER_SEND_METRICS: 'false', NO_COLOR: '1' },
  });
  assert.equal(result.status, 0, `Wrangler falhou: ${result.stdout}\n${result.stderr}`);
  return result.stdout;
}

function sqlString(value) {
  return `'${String(value).replaceAll("'", "''")}'`;
}

function fixtureSql(user) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(PASSWORD, Buffer.from(salt, 'hex'), 210000, 64, 'sha512').toString('hex');
  return `INSERT INTO users(id,email,password_hash,password_salt) VALUES(${sqlString(user.id)},${sqlString(user.email)},${sqlString(hash)},${sqlString(salt)});`
    + `INSERT INTO profiles(id,nome,papel,tipo_perfil,status,provincia) VALUES(${sqlString(user.id)},${sqlString(user.name)},'utilizador','agricultor','ativo','Huambo');`;
}

function profileUpdateSql(user, updates) {
  const assignments = Object.entries(updates).map(([column, value]) => `${column}=${sqlString(value)}`).join(',');
  return `UPDATE profiles SET ${assignments} WHERE id=${sqlString(user.id)};`;
}

async function findFreePort() {
  const probe = createServer();
  await new Promise((resolve) => probe.listen(0, '127.0.0.1', resolve));
  const selected = probe.address().port;
  await new Promise((resolve) => probe.close(resolve));
  return selected;
}

async function request(pathname, options = {}) {
  const response = await fetch(`http://127.0.0.1:${port}${pathname}`, options);
  const raw = await response.text();
  let body = null;
  try { body = raw ? JSON.parse(raw) : null; } catch { body = raw; }
  return {
    status: response.status,
    body,
    headers: response.headers,
    cookie: response.headers.get('set-cookie')?.split(';')[0] || null,
  };
}

async function login(user, password = PASSWORD) {
  const response = await request('/api/auth/login', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ email: user.email, password }),
  });
  assert.equal(response.status, 200, `Login Worker falhou: ${JSON.stringify(response.body)}\n${serverOutput}`);
  assert.ok(response.cookie);
  return response.cookie;
}

before(async () => {
  persistDirectory = fs.mkdtempSync(path.join(os.tmpdir(), 'agrolink-worker-local-'));
  const testConfig = fs.readFileSync(path.join(ROOT, 'wrangler.toml'), 'utf8')
    .replace('STORAGE_PROVIDER = "b2"', 'STORAGE_PROVIDER = "r2"')
    .replace(/^B2_(?:ENDPOINT|REGION|BUCKET)\s*=.*\n/gm, '')
    .replace('main = "worker/index.mjs"', 'main = "../worker/index.mjs"')
    .replace('migrations_dir = "cloudflare/migrations"', 'migrations_dir = "../cloudflare/migrations"')
    .replace('directory = "./dist"', 'directory = "../dist"')
    + '\n[[r2_buckets]]\nbinding = "BUCKET"\nbucket_name = "agrolink-caop-local"\n';
  fs.writeFileSync(CONFIG, testConfig);
  const commonArgs = ['--local', '--persist-to', persistDirectory, '--config', CONFIG];
  runWrangler(['d1', 'migrations', 'apply', 'agrolink-caop-local', ...commonArgs]);
  const fixtures = [USER_ONE, USER_TWO, TECH_USER, UNVERIFIED_TECH_USER, ADMIN_USER, AUDITOR_USER, HIDDEN_USER].map(fixtureSql).join('');
  const roleProfiles = profileUpdateSql(TECH_USER, { papel: 'utilizador', tipo_perfil: 'tecnico', status: 'ativo', verification_status: 'aprovado' })
    + profileUpdateSql(UNVERIFIED_TECH_USER, { papel: 'utilizador', tipo_perfil: 'tecnico', status: 'ativo', verification_status: 'pendente' })
    + profileUpdateSql(ADMIN_USER, { papel: 'admin', tipo_perfil: 'administrador', nivel_admin: 'normal', status: 'ativo' })
    + profileUpdateSql(AUDITOR_USER, { papel: 'admin', tipo_perfil: 'administrador', nivel_admin: 'auditor', status: 'ativo' })
    + profileUpdateSql(HIDDEN_USER, { visibilidade: 'oculto', status: 'ativo' });
  runWrangler(['d1', 'execute', 'agrolink-caop-local', ...commonArgs, '--command', fixtures + roleProfiles]);

  port = await findFreePort();
  server = spawn(process.execPath, [WRANGLER_CLI, 'dev', '--local', '--ip', '127.0.0.1', '--port', String(port), '--persist-to', persistDirectory, '--config', CONFIG, '--assets', 'public'], {
    cwd: ROOT,
    env: { ...process.env, WRANGLER_SEND_METRICS: 'false', NO_COLOR: '1' },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  server.stdout.on('data', (chunk) => { serverOutput += chunk; });
  server.stderr.on('data', (chunk) => { serverOutput += chunk; });

  let ready = false;
  for (let attempt = 0; attempt < 100; attempt += 1) {
    try {
      const health = await request('/api/health');
      if (health.status === 200 && health.body?.runtime === 'cloudflare-worker') { ready = true; break; }
    } catch {}
    if (server.exitCode !== null) break;
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  assert.ok(ready, `Worker local indisponível: ${serverOutput}`);
  userOneCookie = await login(USER_ONE);
  userTwoCookie = await login(USER_TWO);
  technicianCookie = await login(TECH_USER);
  unverifiedTechnicianCookie = await login(UNVERIFIED_TECH_USER);
  normalAdminCookie = await login(ADMIN_USER);
  auditorCookie = await login(AUDITOR_USER);
});

after(async () => {
  if (server) {
    server.kill('SIGTERM');
    await new Promise((resolve) => server.once('exit', resolve));
  }
  if (persistDirectory) fs.rmSync(persistDirectory, { recursive: true, force: true });
  if (fs.existsSync(CONFIG)) fs.rmSync(CONFIG);
});

test('Worker responde health sem delegar ao backend Node', async () => {
  const response = await request('/api/health');
  assert.equal(response.status, 200);
  assert.deepEqual(response.body, { ok: true, runtime: 'cloudflare-worker' });
});

test('Worker sincroniza RSS apenas para administradores e regista falhas de destino bloqueado', async () => {
  runWrangler(['d1', 'execute', 'agrolink-caop-local', '--local', '--persist-to', persistDirectory, '--config', CONFIG,
    '--command', `INSERT INTO noticias_fontes(id,nome,url_rss,categoria,ativo,pais,prioridade) VALUES('worker-rss-private','RSS privado','https://127.0.0.1/rss','Culturas',1,'Angola',10);`]);

  const unauthenticated = await request('/api/admin/sync-noticias', { method: 'POST' });
  assert.equal(unauthenticated.status, 401);
  const forbidden = await request('/api/admin/sync-noticias', { method: 'POST', headers: { cookie: userOneCookie } });
  assert.equal(forbidden.status, 403);

  const synchronized = await request('/api/admin/sync-noticias', { method: 'POST', headers: { cookie: normalAdminCookie } });
  assert.equal(synchronized.status, 200);
  assert.equal(synchronized.body.fontes_processadas, 1);
  assert.equal(synchronized.body.inseridas, 0);
  assert.match(synchronized.body.erros[0], /IP literal não permitido/);

  const logs = await request('/api/data/noticias_sync_logs?fonte_id=worker-rss-private', {
    headers: { cookie: normalAdminCookie },
  });
  assert.equal(logs.status, 200);
  assert.equal(logs.body.length, 1);
  assert.equal(logs.body[0].sucesso, false);
  assert.match(logs.body[0].mensagem_erro, /IP literal não permitido/);
});

test('Worker local resolve DNS, faz fetch HTTPS e envia a resposta ao parser RSS', async () => {
  runWrangler(['d1', 'execute', 'agrolink-caop-local', '--local', '--persist-to', persistDirectory, '--config', CONFIG,
    '--command', `UPDATE noticias_fontes SET ativo=0; INSERT INTO noticias_fontes(id,nome,url_rss,categoria,ativo,pais,prioridade) VALUES('worker-rss-public-fetch','RSS público','https://example.com/','Culturas',1,'Angola',10);`]);

  const synchronized = await request('/api/admin/sync-noticias', { method: 'POST', headers: { cookie: normalAdminCookie } });
  assert.equal(synchronized.status, 200);
  assert.equal(synchronized.body.fontes_processadas, 1);
  assert.equal(synchronized.body.erros.length, 1);
  assert.match(synchronized.body.erros[0], /XML inválido/);
});

test('Worker autentica sessão e executa SELECT/UPDATE através do D1DatabaseAdapter', async () => {
  const session = await request('/api/auth/session', { headers: { cookie: userOneCookie } });
  assert.equal(session.status, 200);
  assert.equal(session.body.session.user.id, USER_ONE.id);
  assert.equal(session.body.profile.id, USER_ONE.id);
  assert.equal(session.body.profile.status, 'ativo');

  const initial = await request('/api/profile', { headers: { cookie: userOneCookie } });
  assert.equal(initial.status, 200);
  assert.equal(initial.body.nome, USER_ONE.name);
  const updated = await request('/api/profile', {
    method: 'PATCH',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ nome: 'Nome Atualizado no D1', provincia: 'Benguela', papel: 'admin', nivel_admin: 'normal' }),
  });
  assert.equal(updated.status, 200);
  assert.equal(updated.body.nome, 'Nome Atualizado no D1');
  assert.equal(updated.body.provincia, 'Benguela');
  assert.equal(updated.body.papel, 'utilizador');

  const unauthenticated = await request('/api/profile');
  assert.equal(unauthenticated.status, 401);

  const otherSession = await request('/api/auth/session', { headers: { cookie: userTwoCookie } });
  assert.equal(otherSession.body.session.user.id, USER_TWO.id);
  const otherProfile = await request('/api/profile', { headers: { cookie: userTwoCookie } });
  assert.equal(otherProfile.body.id, USER_TWO.id);
});

test('Worker regista perfis pendentes sem aceitar papéis administrativos do payload', async () => {
  const registered = await request('/api/auth/register', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      email: '  worker-pending-admin@example.test ',
      password: 'PendingWorker123!',
      nome: 'Administrador pendente',
      papel: 'admin_chefe',
      tipo_perfil: 'administrador',
    }),
  });
  assert.equal(registered.status, 201);
  assert.deepEqual(registered.body, { status: 'criada', confirmacao_pendente: false, admin_chefe: false });

  const pendingLogin = await request('/api/auth/login', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ email: 'worker-pending-admin@example.test', password: 'PendingWorker123!' }),
  });
  assert.equal(pendingLogin.status, 200);
  const pendingCookie = pendingLogin.cookie;
  assert.equal(pendingLogin.body.profile.papel, 'utilizador');
  assert.equal(pendingLogin.body.profile.tipo_perfil, 'administrador');
  assert.equal(pendingLogin.body.profile.status, 'pendente');

  const pendingSession = await request('/api/auth/session', { headers: { cookie: pendingCookie } });
  assert.equal(pendingSession.body.session.user.email, 'worker-pending-admin@example.test');
  assert.equal(pendingSession.body.profile.status, 'pendente');
  const protectedProfile = await request('/api/profile', { headers: { cookie: pendingCookie } });
  assert.equal(protectedProfile.status, 403);
  assert.deepEqual(protectedProfile.body, { error: 'A conta aguarda aprovação.' });

  const chiefRegistration = await request('/api/auth/register', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ email: ADMIN_EMAIL.toUpperCase(), password: ADMIN_PASSWORD, nome: 'Admin Chefe' }),
  });
  assert.equal(chiefRegistration.status, 201);
  assert.equal(chiefRegistration.body.admin_chefe, true);
  adminCookie = await login({ email: ADMIN_EMAIL }, ADMIN_PASSWORD);

  const hiddenRegistration = await request('/api/auth/register', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ email: 'celcioissenguel@gmail.com', password: 'HiddenWorker123!', nome: 'Admin Chefe Oculto', tipo_perfil: 'tecnico' }),
  });
  assert.equal(hiddenRegistration.status, 201);
  const hiddenLogin = await request('/api/auth/login', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ email: 'celcioissenguel@gmail.com', password: 'HiddenWorker123!' }),
  });
  assert.equal(hiddenLogin.body.profile.papel, 'admin_chefe');
  assert.equal(hiddenLogin.body.profile.status, 'ativo');
  assert.equal(hiddenLogin.body.profile.tipo_perfil, 'tecnico');
  assert.equal(hiddenLogin.body.profile.visibilidade, 'oculto');
});

test('Worker só permite a Admin Chefe aprovar os perfis pendentes elegíveis', async () => {
  const registration = await request('/api/auth/register', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ email: 'worker-approval-admin@example.test', password: 'ApproveWorker123!', nome: 'Admin para aprovar', tipo_perfil: 'administrador' }),
  });
  assert.equal(registration.status, 201);
  const pendingLogin = await request('/api/auth/login', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ email: 'worker-approval-admin@example.test', password: 'ApproveWorker123!' }),
  });
  const denied = await request('/api/admin/users/approve', {
    method: 'POST',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ id: pendingLogin.body.profile.id }),
  });
  assert.equal(denied.status, 403);

  const approved = await request('/api/admin/users/approve', {
    method: 'POST',
    headers: { cookie: adminCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ id: pendingLogin.body.profile.id }),
  });
  assert.equal(approved.status, 200);
  assert.deepEqual(approved.body, { ok: true, papel: 'admin', status: 'ativo' });
  const approvedLogin = await request('/api/auth/login', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ email: 'worker-approval-admin@example.test', password: 'ApproveWorker123!' }),
  });
  assert.equal(approvedLogin.body.profile.papel, 'admin');

  const farmerRegistration = await request('/api/auth/register', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ email: 'worker-approval-farmer@example.test', password: 'ApproveFarmer123!', nome: 'Agricultor pendente' }),
  });
  assert.equal(farmerRegistration.status, 201);
  const farmer = await request('/api/auth/login', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ email: 'worker-approval-farmer@example.test', password: 'ApproveFarmer123!' }),
  });
  const commonAdminDenied = await request('/api/admin/users/approve-account', {
    method: 'POST',
    headers: { cookie: approvedLogin.cookie, 'content-type': 'application/json' },
    body: JSON.stringify({ id: farmer.body.profile.id }),
  });
  assert.equal(commonAdminDenied.status, 403);
  const farmerApproved = await request('/api/admin/users/approve-account', {
    method: 'POST',
    headers: { cookie: adminCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ id: farmer.body.profile.id }),
  });
  assert.equal(farmerApproved.status, 200);
  assert.deepEqual(farmerApproved.body, { ok: true, status: 'ativo' });
});

test('Worker logout revoga apenas a sessão apresentada e limpa o cookie', async () => {
  const freshCookie = await login(USER_ONE);
  const logout = await request('/api/auth/logout', { method: 'POST', headers: { cookie: freshCookie } });
  assert.equal(logout.status, 200);
  assert.deepEqual(logout.body, { ok: true });
  assert.match(logout.headers.get('set-cookie'), /Max-Age=0/);
  const revoked = await request('/api/auth/session', { headers: { cookie: freshCookie } });
  assert.deepEqual(revoked.body, { session: null, profile: null });
  const unaffected = await request('/api/auth/session', { headers: { cookie: userTwoCookie } });
  assert.equal(unaffected.body.session.user.id, USER_TWO.id);
});

test('Worker recuperação redefine hash e revoga todas as sessões do utilizador', async () => {
  const registered = await request('/api/auth/register', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      email: RECOVERY_USER.email,
      password: RECOVERY_PASSWORD,
      nome: RECOVERY_USER.name,
    }),
  });
  assert.equal(registered.status, 201);
  const recoveryCookie = await login(RECOVERY_USER, RECOVERY_PASSWORD);
  const forgot = await request('/api/auth/password/forgot', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ email: RECOVERY_USER.email }),
  });
  assert.equal(forgot.status, 200);
  const recoveryUrl = new URL(forgot.body.recoveryUrl);
  const token = recoveryUrl.searchParams.get('token');
  assert.ok(token);

  const reset = await request('/api/auth/password/reset', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ token, password: 'RecoveredWorker123!' }),
  });
  assert.equal(reset.status, 200);
  assert.deepEqual(reset.body, { ok: true });
  const previousSession = await request('/api/auth/session', { headers: { cookie: recoveryCookie } });
  assert.deepEqual(previousSession.body, { session: null, profile: null });
  const oldPassword = await request('/api/auth/login', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ email: RECOVERY_USER.email, password: RECOVERY_PASSWORD }),
  });
  assert.equal(oldPassword.status, 401);
  const newPassword = await request('/api/auth/login', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ email: RECOVERY_USER.email, password: 'RecoveredWorker123!' }),
  });
  assert.equal(newPassword.status, 200);
  const replay = await request('/api/auth/password/reset', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ token, password: 'AnotherRecovered123!' }),
  });
  assert.equal(replay.status, 400);
});

test('Worker executa PUT/HEAD/GET/DELETE no R2 local e isola objetos por utilizador', async () => {
  const upload = await request('/api/storage/testes/documento.txt', {
    method: 'PUT',
    headers: { cookie: userOneCookie, 'content-type': 'text/plain' },
    body: 'Objeto privado no R2 local.',
  });
  assert.equal(upload.status, 201);
  assert.deepEqual(upload.body, { key: 'testes/documento.txt', size: 27, contentType: 'text/plain' });

  const invalidContentType = await request('/api/storage/testes/bad.bin', {
    method: 'PUT',
    headers: { cookie: userOneCookie, 'content-type': 'application/x-msdownload' },
    body: 'not allowed',
  });
  assert.equal(invalidContentType.status, 415);

  const oversized = await request('/api/storage/testes/oversized.txt', {
    method: 'PUT',
    headers: { cookie: userOneCookie, 'content-type': 'text/plain' },
    body: 'x'.repeat(2 * 1024 * 1024 + 1),
  });
  assert.equal(oversized.status, 413);

  const head = await request('/api/storage/testes/documento.txt', { method: 'HEAD', headers: { cookie: userOneCookie } });
  assert.equal(head.status, 200);
  assert.equal(head.headers.get('content-type'), 'text/plain');
  assert.equal(head.headers.get('content-length'), '27');

  const crossUser = await request('/api/storage/testes/documento.txt', { headers: { cookie: userTwoCookie } });
  assert.equal(crossUser.status, 404);

  const download = await request('/api/storage/testes/documento.txt', { headers: { cookie: userOneCookie } });
  assert.equal(download.status, 200);
  assert.equal(download.headers.get('content-type'), 'text/plain');
  assert.equal(download.body, 'Objeto privado no R2 local.');

  const deleted = await request('/api/storage/testes/documento.txt', { method: 'DELETE', headers: { cookie: userOneCookie } });
  assert.equal(deleted.status, 204);
  const missing = await request('/api/storage/testes/documento.txt', { method: 'HEAD', headers: { cookie: userOneCookie } });
  assert.equal(missing.status, 404);
});

test('Worker mantém contrato do chat e recusa conversa de outro utilizador', async () => {
  const created = await request('/api/ia/chat', {
    method: 'POST',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ mensagem: 'Como cuidar do milho?', contexto: { provincia: 'Huambo' } }),
  });
  assert.equal(created.status, 200);
  assert.deepEqual(Object.keys(created.body).sort(), ['confianca', 'conversaId', 'resposta']);
  assert.equal(created.body.confianca, 'baixa');
  assert.ok(created.body.conversaId);
  assert.match(created.body.resposta, /temporariamente indisponível/);

  const foreign = await request('/api/ia/chat', {
    method: 'POST',
    headers: { cookie: userTwoCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ conversaId: created.body.conversaId, mensagem: 'Lê o histórico alheio.' }),
  });
  assert.equal(foreign.status, 404);
  assert.deepEqual(foreign.body, { error: 'Conversa não encontrada.' });
});

test('Worker cria e lista relatos com idempotência e escopo por papel', async () => {
  const anonymous = await request('/api/data/relatos', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      id: 'worker-anonymous-report',
      autor_id: USER_ONE.id,
      codigo_publico: 'AL-FORGED',
      tipo: 'praga',
      descricao: 'Relato anónimo de uma praga na plantação.',
      provincia: 'Huambo',
      status: 'resolvido',
      tecnico_atribuido_id: TECH_USER.id,
    }),
  });
  assert.equal(anonymous.status, 201, `Criação anónima falhou: ${JSON.stringify(anonymous.body)}\n${serverOutput}`);
  assert.equal(anonymous.body.autor_id, null);
  assert.equal(anonymous.body.status, 'pendente');
  assert.match(anonymous.body.codigo_publico, /^AL-[0-9A-F]{32}$/);
  assert.notEqual(anonymous.body.codigo_publico, 'AL-FORGED');

  const anonymousRetry = await request('/api/data/relatos', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ id: 'worker-anonymous-report', tipo: 'outro', descricao: 'Tentativa repetida.' }),
  });
  assert.equal(anonymousRetry.status, 200);
  assert.equal(anonymousRetry.body.codigo_publico, anonymous.body.codigo_publico);

  const created = await request('/api/data/relatos', {
    method: 'POST',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({
      id: 'worker-user-one-report',
      autor_id: USER_TWO.id,
      codigo_publico: 'AL-USER-FORGED',
      tipo: 'doenca',
      descricao: 'Doença observada numa plantação de milho.',
      provincia: 'Huambo',
    }),
  });
  assert.equal(created.status, 201, `Criação de denúncia falhou: ${JSON.stringify(created.body)}\n${serverOutput}`);
  assert.equal(created.body.autor_id, USER_ONE.id);
  assert.equal(created.body.status, 'pendente');
  assert.equal(created.body.tecnico_atribuido_id, null);
  assert.notEqual(created.body.codigo_publico, 'AL-USER-FORGED');

  const collision = await request('/api/data/relatos', {
    method: 'POST',
    headers: { cookie: userTwoCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ id: 'worker-user-one-report', tipo: 'solo', descricao: 'ID alheio.' }),
  });
  assert.equal(collision.status, 409);

  const farmerList = await request('/api/data/relatos?order=criado_em&limit=500', { headers: { cookie: userOneCookie } });
  assert.equal(farmerList.status, 200);
  assert.deepEqual(farmerList.body.map((report) => report.id), ['worker-user-one-report']);
  assert.equal('codigo_publico' in farmerList.body[0], false);
  const otherFarmerList = await request('/api/data/relatos', { headers: { cookie: userTwoCookie } });
  assert.deepEqual(otherFarmerList.body, []);

  const technicianList = await request('/api/data/relatos?status=pendente&tipo=praga', { headers: { cookie: technicianCookie } });
  assert.deepEqual(technicianList.body.map((report) => report.id), ['worker-anonymous-report']);
  const adminList = await request('/api/data/relatos?limit=500', { headers: { cookie: normalAdminCookie } });
  assert.equal(adminList.body.length, 2);
  const anonymousList = await request('/api/data/relatos');
  assert.equal(anonymousList.status, 403);

  const publicLookup = await request(`/api/relatos/codigo?codigo=${encodeURIComponent(anonymous.body.codigo_publico)}`);
  assert.equal(publicLookup.status, 200);
  assert.deepEqual(publicLookup.body, {
    id: 'worker-anonymous-report',
    tipo: 'praga',
    descricao: 'Relato anónimo de uma praga na plantação.',
    status: 'pendente',
    criado_em: anonymous.body.criado_em,
    respostas: [],
  });
});

test('Worker cria denúncias, limita ownership e exige admin gravável para moderação', async () => {
  const targets = await request('/api/denuncias/alvos?pesquisa=perfil', { headers: { cookie: userOneCookie } });
  assert.equal(targets.status, 200);
  assert.equal(targets.body.some((target) => target.id === HIDDEN_USER.id), false);
  const adminTargets = await request('/api/denuncias/alvos', { headers: { cookie: normalAdminCookie } });
  assert.equal(adminTargets.body.some((target) => target.id === HIDDEN_USER.id), true);
  assert.equal(adminTargets.body.some((target) => target.id === ADMIN_USER.id), false);

  const invalidSelf = await request('/api/denuncias', {
    method: 'POST',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ denunciado_id: USER_ONE.id, categoria: 'fraude', descricao: 'Denúncia contra mim próprio.' }),
  });
  assert.equal(invalidSelf.status, 400);
  const invalidTarget = await request('/api/denuncias', {
    method: 'POST',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ denunciado_id: 'missing-profile', categoria: 'fraude', descricao: 'Denúncia de alvo inexistente.' }),
  });
  assert.equal(invalidTarget.status, 404);

  const created = await request('/api/denuncias', {
    method: 'POST',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({
      autor_id: ADMIN_USER.id,
      denunciado_id: USER_TWO.id,
      categoria: 'conduta',
      descricao: 'Descrição detalhada da denúncia enviada pelo utilizador.',
      prioridade: 'alta',
      evidencias: ['e1', 'e2', 'e3', 'e4', 'e5', 'e6'],
      estado: 'confirmada',
      admin_responsavel_id: ADMIN_USER.id,
      decisao: 'Escalada forjada pelo autor.',
    }),
  });
  assert.equal(created.status, 201);
  assert.equal(created.body.status, 'pendente');
  const complaintNotification = await request('/api/data/notificacoes', { headers: { cookie: normalAdminCookie } });
  assert.equal(complaintNotification.body.some((item) => item.tipo === 'denuncia' && item.relacionado_id === created.body.id), true);

  const own = await request('/api/data/denuncias', { headers: { cookie: userOneCookie } });
  assert.equal(own.status, 200);
  assert.equal(own.body.length, 1);
  assert.equal(own.body[0].autor_id, USER_ONE.id);
  assert.deepEqual(own.body[0].evidencias, ['e1', 'e2', 'e3', 'e4', 'e5']);
  const foreign = await request('/api/data/denuncias', { headers: { cookie: userTwoCookie } });
  assert.deepEqual(foreign.body, []);

  const deniedList = await request('/api/admin/denuncias', { headers: { cookie: userOneCookie } });
  assert.equal(deniedList.status, 403);
  const adminList = await request('/api/admin/denuncias?estado=pendente', { headers: { cookie: normalAdminCookie } });
  assert.equal(adminList.status, 200);
  assert.equal(adminList.body.length, 1);
  assert.equal(adminList.body[0].autor_nome, 'Nome Atualizado no D1');
  assert.equal(adminList.body[0].denunciado_nome, USER_TWO.name);
  assert.deepEqual(adminList.body[0].evidencias, ['e1', 'e2', 'e3', 'e4', 'e5']);
  const auditorList = await request('/api/admin/denuncias?estado=pendente', { headers: { cookie: auditorCookie } });
  assert.equal(auditorList.status, 200);
  assert.equal(auditorList.body.length, 1);

  const auditorWrite = await request('/api/admin/denuncias/atualizar', {
    method: 'PATCH',
    headers: { cookie: auditorCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ id: created.body.id, estado: 'em_analise' }),
  });
  assert.equal(auditorWrite.status, 403);
  const invalidAssignee = await request('/api/admin/denuncias/atualizar', {
    method: 'PATCH',
    headers: { cookie: normalAdminCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ id: created.body.id, admin_responsavel_id: USER_TWO.id }),
  });
  assert.equal(invalidAssignee.status, 400);
  const updated = await request('/api/admin/denuncias/atualizar', {
    method: 'PATCH',
    headers: { cookie: normalAdminCookie, 'content-type': 'application/json' },
    body: JSON.stringify({
      id: created.body.id,
      estado: 'em_analise',
      prioridade: 'urgente',
      decisao: 'Em análise pelo administrador.',
      admin_responsavel_id: ADMIN_USER.id,
    }),
  });
  assert.equal(updated.status, 200);
  assert.equal(updated.body.estado, 'em_analise');
  assert.equal(updated.body.prioridade, 'urgente');
  assert.equal(updated.body.admin_responsavel_id, ADMIN_USER.id);
  const ownHistory = await request(`/api/data/denuncia_historico?denuncia_id=${created.body.id}`, { headers: { cookie: userOneCookie } });
  assert.equal(ownHistory.status, 200);
  assert.deepEqual(ownHistory.body.map((entry) => entry.campo_alterado), ['estado', 'prioridade', 'decisao', 'admin_responsavel_id']);
  const foreignHistory = await request(`/api/data/denuncia_historico?denuncia_id=${created.body.id}`, { headers: { cookie: userTwoCookie } });
  assert.deepEqual(foreignHistory.body, []);
  const auditorHistory = await request(`/api/data/denuncia_historico?denuncia_id=${created.body.id}`, { headers: { cookie: auditorCookie } });
  assert.equal(auditorHistory.body.length, 4);
  const filtered = await request('/api/admin/denuncias?estado=pendente', { headers: { cookie: normalAdminCookie } });
  assert.deepEqual(filtered.body, []);
});

test('Worker responde a relatos e protege a leitura e atualização de estado por papel', async () => {
  const report = await request('/api/data/relatos', {
    method: 'POST',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ id: 'worker-response-report', tipo: 'solo', descricao: 'Relato para testar respostas e estado.' }),
  });
  assert.equal(report.status, 201);

  const farmerReplyDenied = await request('/api/data/relato_respostas', {
    method: 'POST',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ relato_id: report.body.id, comentario: 'Resposta não autorizada.' }),
  });
  assert.equal(farmerReplyDenied.status, 403);

  const farmerStateDenied = await request(`/api/data/relatos?id=${report.body.id}`, {
    method: 'PATCH',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ status: 'resolvido' }),
  });
  assert.equal(farmerStateDenied.status, 403);
  const unverifiedReplyDenied = await request('/api/data/relato_respostas', {
    method: 'POST',
    headers: { cookie: unverifiedTechnicianCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ relato_id: report.body.id, comentario: 'Resposta de técnico não verificado.' }),
  });
  assert.equal(unverifiedReplyDenied.status, 403);
  const unverifiedStateDenied = await request(`/api/data/relatos?id=${report.body.id}`, {
    method: 'PATCH',
    headers: { cookie: unverifiedTechnicianCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ status: 'em_analise' }),
  });
  assert.equal(unverifiedStateDenied.status, 403);

  const techReply = await request('/api/data/relato_respostas', {
    method: 'POST',
    headers: { cookie: technicianCookie, 'content-type': 'application/json' },
    body: JSON.stringify({
      relato_id: report.body.id,
      tecnico_id: USER_TWO.id,
      comentario: '  Recomendação técnica para o agricultor.  ',
    }),
  });
  assert.equal(techReply.status, 201);
  assert.equal(techReply.body.tecnico_id, TECH_USER.id);
  assert.equal(techReply.body.comentario, 'Recomendação técnica para o agricultor.');

  const farmerResponses = await request(`/api/data/relato_respostas?relato_id=${report.body.id}&order=criado_em&asc=1`, {
    headers: { cookie: userOneCookie },
  });
  assert.equal(farmerResponses.status, 200);
  assert.deepEqual(farmerResponses.body.map((response) => response.id), [techReply.body.id]);
  const foreignResponses = await request(`/api/data/relato_respostas?relato_id=${report.body.id}`, {
    headers: { cookie: userTwoCookie },
  });
  assert.deepEqual(foreignResponses.body, []);
  const techResponses = await request(`/api/data/relato_respostas?relato_id=${report.body.id}`, {
    headers: { cookie: technicianCookie },
  });
  assert.deepEqual(techResponses.body.map((response) => response.id), [techReply.body.id]);

  const techExtraFieldDenied = await request(`/api/data/relatos?id=${report.body.id}`, {
    method: 'PATCH',
    headers: { cookie: technicianCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ status: 'em_analise', tipo: 'doenca' }),
  });
  assert.equal(techExtraFieldDenied.status, 403);
  const invalidState = await request(`/api/data/relatos?id=${report.body.id}`, {
    method: 'PATCH',
    headers: { cookie: technicianCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ status: 'bloqueado' }),
  });
  assert.equal(invalidState.status, 400);

  const techState = await request(`/api/data/relatos?id=${report.body.id}`, {
    method: 'PATCH',
    headers: { cookie: technicianCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ status: 'em_analise' }),
  });
  assert.equal(techState.status, 200);
  assert.equal(techState.body.status, 'em_analise');

  const adminReply = await request('/api/data/relato_respostas', {
    method: 'POST',
    headers: { cookie: normalAdminCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ relato_id: report.body.id, tecnico_id: ADMIN_USER.id, comentario: 'Nota do administrador.' }),
  });
  assert.equal(adminReply.status, 201);
  assert.equal(adminReply.body.tecnico_id, ADMIN_USER.id);
  const adminState = await request(`/api/data/relatos?id=${report.body.id}`, {
    method: 'PATCH',
    headers: { cookie: normalAdminCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ status: 'resolvido', tipo: 'clima' }),
  });
  assert.equal(adminState.status, 200);
  assert.equal(adminState.body.status, 'resolvido');
  assert.equal(adminState.body.tipo, 'clima');

  const lookup = await request(`/api/relatos/codigo?codigo=${encodeURIComponent(report.body.codigo_publico)}`);
  assert.equal(lookup.status, 200);
  assert.equal(lookup.body.status, 'resolvido');
  assert.deepEqual(lookup.body.respostas.map((response) => response.comentario), [
    'Recomendação técnica para o agricultor.',
    'Nota do administrador.',
  ]);
});

test('Worker gere anexos de relatos no R2 com validação, ownership, idempotência e remoção administrativa', async () => {
  const report = await request('/api/data/relatos', {
    method: 'POST',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ id: 'worker-media-report', tipo: 'clima', descricao: 'Relato com anexo de imagem.' }),
  });
  assert.equal(report.status, 201);

  const invalidMime = await request('/api/media/upload/relatos', {
    method: 'POST',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ filename: 'ficheiro.exe', mimeType: 'application/x-msdownload', data: btoa('conteúdo') }),
  });
  assert.equal(invalidMime.status, 415);

  const oversized = await request('/api/media/upload/relatos', {
    method: 'POST',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({
      filename: 'grande.png',
      mimeType: 'image/png',
      data: btoa('x'.repeat(18 * 1024 * 1024 + 1)),
    }),
  });
  assert.equal(oversized.status, 400);

  const uploadId = '3fc2690e-14ca-4c1d-94e8-bf8f75f2d120';
  const uploadBody = {
    filename: 'campo.png',
    mimeType: 'image/png',
    data: btoa('imagem local de teste'),
    uploadId,
  };
  const uploaded = await request('/api/media/upload/relatos', {
    method: 'POST',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify(uploadBody),
  });
  assert.equal(uploaded.status, 201);
  assert.equal(uploaded.body.caminho, `relatos/${uploadId}-campo.png`);

  const uploadRetry = await request('/api/media/upload/relatos', {
    method: 'POST',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify(uploadBody),
  });
  assert.equal(uploadRetry.status, 201);
  assert.deepEqual(uploadRetry.body, uploaded.body);

  const uploadConflict = await request('/api/media/upload/relatos', {
    method: 'POST',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ ...uploadBody, data: btoa('conteúdo diferente') }),
  });
  assert.equal(uploadConflict.status, 409);

  const media = await request('/api/data/relato_midias', {
    method: 'POST',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({
      id: 'worker-media-entry',
      relato_id: report.body.id,
      tipo: 'foto',
      caminho_storage: uploaded.body.caminho,
    }),
  });
  assert.equal(media.status, 201);
  assert.equal(media.body.tipo, 'foto');
  const mediaRetry = await request('/api/data/relato_midias', {
    method: 'POST',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({
      id: 'worker-media-entry',
      relato_id: report.body.id,
      tipo: 'foto',
      caminho_storage: uploaded.body.caminho,
    }),
  });
  assert.equal(mediaRetry.status, 200);

  const ownerList = await request(`/api/data/relato_midias?relato_id=${report.body.id}`, { headers: { cookie: userOneCookie } });
  assert.deepEqual(ownerList.body.map((item) => item.id), ['worker-media-entry']);
  const otherUserList = await request(`/api/data/relato_midias?relato_id=${report.body.id}`, { headers: { cookie: userTwoCookie } });
  assert.deepEqual(otherUserList.body, []);

  const foreignAttachment = await request('/api/data/relato_midias', {
    method: 'POST',
    headers: { cookie: userTwoCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ relato_id: report.body.id, tipo: 'foto', caminho_storage: uploaded.body.caminho }),
  });
  assert.equal(foreignAttachment.status, 403);
  const incompatibleMediaType = await request('/api/data/relato_midias', {
    method: 'POST',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ relato_id: report.body.id, tipo: 'audio', caminho_storage: uploaded.body.caminho }),
  });
  assert.equal(incompatibleMediaType.status, 400);

  const ownerDownload = await request(`/api/media/${uploaded.body.caminho.split('/').map(encodeURIComponent).join('/')}`, {
    headers: { cookie: userOneCookie },
  });
  assert.equal(ownerDownload.status, 200);
  assert.equal(ownerDownload.headers.get('content-type'), 'image/png');
  assert.equal(ownerDownload.body, 'imagem local de teste');
  const otherUserDownload = await request(`/api/media/${uploaded.body.caminho.split('/').map(encodeURIComponent).join('/')}`, {
    headers: { cookie: userTwoCookie },
  });
  assert.equal(otherUserDownload.status, 404);
  const technicianDownload = await request(`/api/media/${uploaded.body.caminho.split('/').map(encodeURIComponent).join('/')}`, {
    headers: { cookie: technicianCookie },
  });
  assert.equal(technicianDownload.status, 200);
  const ownerDelete = await request(`/api/data/relato_midias?id=${media.body.id}`, {
    method: 'DELETE',
    headers: { cookie: userOneCookie },
  });
  assert.equal(ownerDelete.status, 403);
  const adminDelete = await request(`/api/data/relato_midias?id=${media.body.id}`, {
    method: 'DELETE',
    headers: { cookie: normalAdminCookie },
  });
  assert.equal(adminDelete.status, 200);
  const deletedMedia = await request(`/api/media/${uploaded.body.caminho.split('/').map(encodeURIComponent).join('/')}`, {
    headers: { cookie: userOneCookie },
  });
  assert.equal(deletedMedia.status, 404);
});

test('Worker conclui rotas administrativas de relatos e estatísticas', async () => {
  const report = await request('/api/data/relatos', {
    method: 'POST',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ id: 'worker-delete-report', tipo: 'outro', descricao: 'Relato para remoção administrativa.' }),
  });
  assert.equal(report.status, 201);

  const stats = await request('/api/admin/stats', { headers: { cookie: normalAdminCookie } });
  assert.equal(stats.status, 200);
  assert.equal(typeof stats.body.total_relatos, 'number');
  assert.equal(typeof stats.body.tecnicos_aprovados, 'number');
  const adminUsers = await request('/api/admin/users?papel=admin', { headers: { cookie: normalAdminCookie } });
  assert.equal(adminUsers.status, 200);
  assert.equal(adminUsers.body.some((profile) => profile.id === ADMIN_USER.id), true);
  const forbiddenStats = await request('/api/admin/stats', { headers: { cookie: userOneCookie } });
  assert.equal(forbiddenStats.status, 403);

  const deniedDelete = await request(`/api/data/relatos?id=${report.body.id}`, {
    method: 'DELETE',
    headers: { cookie: userOneCookie },
  });
  assert.equal(deniedDelete.status, 403);
  const deleted = await request(`/api/data/relatos?id=${report.body.id}`, {
    method: 'DELETE',
    headers: { cookie: normalAdminCookie },
  });
  assert.deepEqual(deleted.body, { ok: true });
  const missing = await request(`/api/data/relatos?id=${report.body.id}`, {
    headers: { cookie: normalAdminCookie },
  });
  assert.deepEqual(missing.body, []);
});

test('Worker serve alertas públicas e mantém notificações e broadcast no respetivo escopo', async () => {
  const created = await request('/api/data/alertas', {
    method: 'POST',
    headers: { cookie: normalAdminCookie, 'content-type': 'application/json' },
    body: JSON.stringify({
      id: 'worker-alert-one',
      titulo: 'Alerta de teste',
      descricao: 'Alerta agrícola local.',
      provincias_alvo: ['Huambo'],
      nivel: 'alto',
    }),
  });
  assert.equal(created.status, 201);
  assert.deepEqual(created.body.provincias_alvo, ['Huambo']);

  const publicAlerts = await request('/api/data/alertas');
  assert.equal(publicAlerts.status, 200);
  assert.equal(publicAlerts.body.some((item) => item.id === 'worker-alert-one'), true);
  const deniedWrite = await request('/api/data/alertas', {
    method: 'POST',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ titulo: 'Não autorizado', descricao: 'Sem permissão.' }),
  });
  assert.equal(deniedWrite.status, 403);

  const broadcast = await request('/api/admin/broadcast', {
    method: 'POST',
    headers: { cookie: normalAdminCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ titulo: 'Mensagem de teste', corpo: 'Notificação local.' }),
  });
  assert.equal(broadcast.status, 200);
  assert.ok(broadcast.body.destinatarios >= 2);
  const ownNotifications = await request('/api/data/notificacoes', { headers: { cookie: userOneCookie } });
  assert.equal(ownNotifications.status, 200);
  const notification = ownNotifications.body.find((item) => item.tipo === 'mensagem_admin');
  assert.ok(notification);
  const otherNotifications = await request('/api/data/notificacoes', { headers: { cookie: userTwoCookie } });
  assert.equal(otherNotifications.body.some((item) => item.id === notification.id), false);
  const marked = await request(`/api/data/notificacoes?id=${notification.id}`, {
    method: 'PATCH',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ lida: true, destinatario_id: USER_TWO.id }),
  });
  assert.equal(marked.status, 200);
  assert.equal(marked.body.lida, true);
  assert.equal(marked.body.destinatario_id, USER_ONE.id);
  const reassigned = await request('/api/data/notificacoes', { headers: { cookie: userTwoCookie } });
  assert.equal(reassigned.body.some((item) => item.id === notification.id), false);
});

test('Worker preserva ownership e transições de transportadores, pedidos e produtos', async () => {
  const transporter = await request('/api/data/transportadores', {
    method: 'POST',
    headers: { cookie: userTwoCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ matricula: 'LD-01-02-AB', tipo_veiculo: 'camião', capacidade_kg: 1200 }),
  });
  assert.equal(transporter.status, 201);
  assert.equal(transporter.body.estado_verificacao, 'pendente');
  const forgedTransporter = await request('/api/data/transportadores', {
    method: 'POST',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ utilizador_id: USER_TWO.id, matricula: 'FAKE-01', tipo_veiculo: 'camião', capacidade_kg: 1000 }),
  });
  assert.equal(forgedTransporter.status, 201);
  assert.equal(forgedTransporter.body.utilizador_id, USER_ONE.id);
  const ownerTransporters = await request('/api/data/transportadores', { headers: { cookie: userOneCookie } });
  assert.equal(ownerTransporters.body.length, 1);
  assert.equal(ownerTransporters.body[0].utilizador_id, USER_ONE.id);
  const hiddenTransporters = await request('/api/data/transportadores', { headers: { cookie: userTwoCookie } });
  assert.equal(hiddenTransporters.body.length, 1);
  assert.equal(hiddenTransporters.body[0].utilizador_id, USER_TWO.id);

  const approval = await request('/api/data/transportadores', {
    method: 'POST',
    headers: { cookie: normalAdminCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ utilizador_id: USER_TWO.id, estado_verificacao: 'aprovado', capacidade_kg: 1200 }),
  });
  assert.equal(approval.status, 200);
  const directory = await request('/api/data/logistica_transportadoras');
  assert.equal(directory.body.some((item) => item.utilizador_id === USER_TWO.id && item.ativo), true);

  const order = await request('/api/data/logistica_pedidos', {
    method: 'POST',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({
      origem_provincia: 'Huambo',
      destino_provincia: 'Benguela',
      produto_descricao: 'Transporte de milho',
      quantidade_kg: 250,
    }),
  });
  assert.equal(order.status, 201);
  assert.equal(order.body.solicitante_id, USER_ONE.id);
  const farmerOrders = await request('/api/data/logistica_pedidos', { headers: { cookie: userOneCookie } });
  assert.equal(farmerOrders.body.some((item) => item.id === order.body.id), true);
  const availableOrders = await request('/api/data/logistica_pedidos', { headers: { cookie: userTwoCookie } });
  assert.equal(availableOrders.body.some((item) => item.id === order.body.id), true);
  const accepted = await request(`/api/data/logistica_pedidos?id=${order.body.id}`, {
    method: 'PATCH',
    headers: { cookie: userTwoCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ status: 'aceite' }),
  });
  assert.equal(accepted.status, 200);
  assert.equal(accepted.body.status, 'aceite');
  const stolenTransition = await request(`/api/data/logistica_pedidos?id=${order.body.id}`, {
    method: 'PATCH',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ status: 'entregue' }),
  });
  assert.equal(stolenTransition.status, 403);

  const product = await request('/api/data/mercado_produtos', {
    method: 'POST',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ vendedor_id: USER_TWO.id, nome: 'Milho', unidade: 'kg', preco: 100, quantidade_disponivel: 25 }),
  });
  assert.equal(product.status, 201);
  assert.equal(product.body.vendedor_id, USER_ONE.id);
  const foreignUpdate = await request(`/api/data/mercado_produtos?id=${product.body.id}`, {
    method: 'PATCH',
    headers: { cookie: userTwoCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ preco: 80 }),
  });
  assert.equal(foreignUpdate.status, 403);
  const ownerUpdate = await request(`/api/data/mercado_produtos?id=${product.body.id}`, {
    method: 'PATCH',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ preco: 90, vendedor_id: USER_TWO.id }),
  });
  assert.equal(ownerUpdate.status, 200);
  assert.equal(ownerUpdate.body.preco, 90);
  assert.equal(ownerUpdate.body.vendedor_id, USER_ONE.id);
});

test('Worker serve academia, progresso e documentos de biblioteca através do D1 e R2 local', async () => {
  const course = await request('/api/data/academia_cursos', {
    method: 'POST',
    headers: { cookie: normalAdminCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ id: 'worker-course-one', titulo: 'Curso local', categoria: 'Agricultura' }),
  });
  assert.equal(course.status, 201);
  const lesson = await request('/api/data/academia_licoes', {
    method: 'POST',
    headers: { cookie: normalAdminCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ id: 'worker-lesson-one', curso_id: course.body.id, titulo: 'Lição 1', conteudo_texto: 'Conteúdo' }),
  });
  assert.equal(lesson.status, 201);
  const question = await request('/api/data/academia_questionarios', {
    method: 'POST',
    headers: { cookie: normalAdminCookie, 'content-type': 'application/json' },
    body: JSON.stringify({
      id: 'worker-question-one',
      licao_id: lesson.body.id,
      pergunta: 'Quanto é 2 + 2?',
      opcoes: ['3', '4'],
      resposta_correta: 1,
    }),
  });
  assert.equal(question.status, 201);

  const quiz = await request(`/api/academia/quiz/${lesson.body.id}`, { headers: { cookie: userOneCookie } });
  assert.equal(quiz.status, 200);
  assert.equal(quiz.body[0].resposta_correta, undefined);
  assert.deepEqual(quiz.body[0].opcoes, ['3', '4']);
  const answer = await request('/api/academia/quiz/answer', {
    method: 'POST',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ questionarioId: question.body.id, resposta: 1 }),
  });
  assert.deepEqual(answer.body, { correto: true });
  const progress = await request('/api/data/academia_progresso', { headers: { cookie: userOneCookie } });
  assert.equal(progress.body.some((item) => item.licao_id === lesson.body.id && item.pontuacao_questionario === 1), true);
  const completed = await request('/api/academia/concluir', {
    method: 'POST',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ licaoId: lesson.body.id }),
  });
  assert.deepEqual(completed.body, { ok: true });
  const legacyAnswer = await request('/api/academia/quiz', {
    method: 'POST',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ questionarioId: question.body.id, licaoId: lesson.body.id, resposta: 0 }),
  });
  assert.deepEqual(legacyAnswer.body, { correto: false });

  const uploaded = await request('/api/media/upload/biblioteca', {
    method: 'POST',
    headers: { cookie: normalAdminCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ filename: 'guia.pdf', data: btoa('PDF local de teste') }),
  });
  assert.equal(uploaded.status, 201);
  assert.match(uploaded.body.caminho, /^biblioteca\/[0-9a-f-]+-guia\.pdf$/);
  const document = await request('/api/data/biblioteca_documentos', {
    method: 'POST',
    headers: { cookie: normalAdminCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ id: 'worker-library-doc', titulo: 'Guia', caminho_storage: uploaded.body.caminho }),
  });
  assert.equal(document.status, 201);
  const file = await request(`/api/media/${uploaded.body.caminho.split('/').map(encodeURIComponent).join('/')}`, {
    headers: { cookie: userOneCookie },
  });
  assert.equal(file.status, 200);
  assert.equal(file.headers.get('content-type'), 'application/pdf');
  assert.equal(file.body, 'PDF local de teste');
  const notLinked = await request(`/api/media/${uploaded.body.caminho.split('/').map(encodeURIComponent).join('/')}`, {
    headers: { cookie: userTwoCookie },
  });
  assert.equal(notLinked.status, 200);

  const academyUpload = await request('/api/media/upload/academia', {
    method: 'POST',
    headers: { cookie: normalAdminCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ filename: 'aula.mp4', data: btoa('video local de teste') }),
  });
  assert.equal(academyUpload.status, 201);
  const linkedLesson = await request(`/api/data/academia_licoes?id=${lesson.body.id}`, {
    method: 'PATCH',
    headers: { cookie: normalAdminCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ caminho_storage: academyUpload.body.caminho }),
  });
  assert.equal(linkedLesson.status, 200);
  const lessonFile = await request(`/api/media/${academyUpload.body.caminho.split('/').map(encodeURIComponent).join('/')}`, {
    headers: { cookie: userOneCookie },
  });
  assert.equal(lessonFile.status, 200);
  assert.equal(lessonFile.headers.get('content-type'), 'video/mp4');
  assert.equal(lessonFile.body, 'video local de teste');
});

test('Worker expõe recursos e preferências do utilizador mantendo ownership', async () => {
  const resource = await request('/api/data/recursos_externos', {
    method: 'POST',
    headers: { cookie: normalAdminCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ id: 'worker-resource-one', titulo: 'Recurso', url: 'https://example.test' }),
  });
  assert.equal(resource.status, 201);
  const publicResources = await request('/api/data/recursos_externos');
  assert.equal(publicResources.body.some((item) => item.id === resource.body.id), true);

  const preferences = await request('/api/data/preferencias_utilizador', {
    method: 'POST',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ utilizador_id: USER_TWO.id, idioma: 'pt', notif_alertas: false }),
  });
  assert.equal(preferences.status, 201);
  assert.equal(preferences.body.utilizador_id, USER_ONE.id);
  assert.equal(preferences.body.notif_alertas, false);
  const ownPreferences = await request('/api/data/preferencias_utilizador', { headers: { cookie: userOneCookie } });
  const otherPreferences = await request('/api/data/preferencias_utilizador', { headers: { cookie: userTwoCookie } });
  assert.equal(ownPreferences.body.length, 1);
  assert.deepEqual(otherPreferences.body, []);

  const device = await request('/api/data/dispositivos_push', {
    method: 'POST',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ id: 'worker-device-one', utilizador_id: USER_TWO.id, token: 'push-token-one' }),
  });
  assert.equal(device.status, 201);
  assert.equal(device.body.utilizador_id, USER_ONE.id);
  const publicDevices = await request('/api/data/dispositivos_push');
  assert.equal(publicDevices.status, 403);
});

test('Worker publica notícias e FAQ locais sem permitir escrita pública', async () => {
  const news = await request('/api/data/noticias', {
    method: 'POST',
    headers: { cookie: normalAdminCookie, 'content-type': 'application/json' },
    body: JSON.stringify({
      id: 'worker-news-one',
      titulo: 'Notícia agrícola local',
      resumo: 'Resumo de teste.',
      conteudo: 'Conteúdo local.',
      categoria: 'Culturas',
      url_original: 'https://example.test/noticia',
    }),
  });
  assert.equal(news.status, 201);
  const publicNews = await request('/api/data/noticias?pesquisa=agrícola');
  assert.equal(publicNews.body.some((item) => item.id === news.body.id), true);
  const deniedNewsWrite = await request('/api/data/noticias', {
    method: 'POST',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ titulo: 'Tentativa pública', conteudo: 'Não autorizado.' }),
  });
  assert.equal(deniedNewsWrite.status, 403);

  const faq = await request('/api/data/perguntas_frequentes', {
    method: 'POST',
    headers: { cookie: normalAdminCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ id: 'worker-faq-one', pergunta: 'Como regar?', resposta: 'Regar com regularidade.' }),
  });
  assert.equal(faq.status, 201);
  const publicFaq = await request('/api/data/perguntas_frequentes');
  assert.equal(publicFaq.body.some((item) => item.id === faq.body.id), true);
});

test('Worker mantém ownership ao criar denúncias pelo endpoint genérico compatível', async () => {
  const created = await request('/api/data/denuncias', {
    method: 'POST',
    headers: { cookie: userOneCookie, 'content-type': 'application/json' },
    body: JSON.stringify({
      id: 'worker-generic-complaint',
      autor_id: USER_TWO.id,
      denunciado_id: USER_TWO.id,
      categoria: 'conduta',
      descricao: 'Denúncia criada pelo endpoint compatível.',
      estado: 'confirmada',
      prioridade: 'alta',
      admin_responsavel_id: ADMIN_USER.id,
      decisao: 'Não deve ser aceite do autor.',
    }),
  });
  assert.equal(created.status, 201);
  assert.equal(created.body.autor_id, USER_ONE.id);
  assert.equal(created.body.estado, 'pendente');
  assert.equal(created.body.prioridade, 'alta');
  assert.equal(created.body.admin_responsavel_id, null);
  assert.equal(created.body.decisao, null);
  const own = await request('/api/data/denuncias?id=worker-generic-complaint', { headers: { cookie: userOneCookie } });
  assert.equal(own.body.length, 1);
  const foreign = await request('/api/data/denuncias', { headers: { cookie: userTwoCookie } });
  assert.equal(foreign.body.some((item) => item.id === created.body.id), false);
});

test('Worker restringe promoção de administrador ao Admin Chefe e protege a conta-chefe', async () => {
  const denied = await request('/api/admin/users/promote', {
    method: 'POST',
    headers: { cookie: normalAdminCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ id: ADMIN_USER.id, papel: 'auditor' }),
  });
  assert.equal(denied.status, 403);

  const chiefSession = await request('/api/auth/session', { headers: { cookie: adminCookie } });
  const protectedTarget = await request('/api/admin/users/promote', {
    method: 'POST',
    headers: { cookie: adminCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ id: chiefSession.body.session.user.id, papel: 'auditor' }),
  });
  assert.equal(protectedTarget.status, 403);

  const promoted = await request('/api/admin/users/promote', {
    method: 'POST',
    headers: { cookie: adminCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ id: ADMIN_USER.id, papel: 'auditor' }),
  });
  assert.deepEqual(promoted.body, { ok: true });
  const session = await request('/api/auth/session', { headers: { cookie: normalAdminCookie } });
  assert.equal(session.body.profile.papel, 'admin');
  assert.equal(session.body.profile.nivel_admin, 'auditor');
});
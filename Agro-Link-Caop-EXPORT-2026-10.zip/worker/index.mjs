import { D1DatabaseAdapter } from '../server/databaseAdapter.mjs';
import { createStorageProvider } from '../server/storageProviderFactory.mjs';
import { WorkersAIProvider } from '../server/aiProvider.mjs';
import { handleBusinessRequest } from './businessRoutes.mjs';
import { synchronizeNewsFeeds } from './rss.mjs';

const encoder = new TextEncoder();
const MAX_CHAT_MESSAGE_LENGTH = 4000;
const MAX_CHAT_CONTEXT_BYTES = 8 * 1024;
const MAX_CHAT_RESPONSE_LENGTH = 12000;
const MAX_STORAGE_OBJECT_SIZE = 2 * 1024 * 1024;
const MAX_REPORT_MEDIA_SIZE = 18 * 1024 * 1024;
const MAX_REPORT_UPLOAD_BODY_SIZE = 25 * 1024 * 1024;
const ADMIN_CHEFE_PUBLIC_EMAIL = 'sebastiaoissenguel27@gmail.com';
const ADMIN_CHEFE_HIDDEN_EMAIL = 'celcioissenguel@gmail.com';
const RESERVED_ADMIN_CHEFE_EMAILS = new Set([ADMIN_CHEFE_PUBLIC_EMAIL, ADMIN_CHEFE_HIDDEN_EMAIL]);
const PASSWORD_RESET_MESSAGE = 'Se existir uma conta com esse email, será enviado um link de recuperação.';
const ALLOWED_CONTENT_TYPES = new Set([
  'application/octet-stream',
  'application/pdf',
  'audio/ogg',
  'audio/webm',
  'image/jpeg',
  'image/png',
  'image/webp',
  'text/plain',
  'video/mp4',
]);
const ALLOWED_REPORT_MEDIA_TYPES = new Set([
  'audio/mp4',
  'audio/ogg',
  'audio/webm',
  'image/gif',
  'image/jpeg',
  'image/png',
  'image/webp',
]);

function json(body, status = 200, headers = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8', ...headers },
  });
}

function error(status, message) {
  return json({ error: message }, status);
}

function now() {
  return new Date().toISOString();
}

function uuid() {
  return crypto.randomUUID();
}

function parseCookie(request, name) {
  const item = (request.headers.get('cookie') || '').split(';').map((part) => part.trim()).find((part) => part.startsWith(`${name}=`));
  if (!item) return null;
  try { return decodeURIComponent(item.slice(name.length + 1)); } catch { return null; }
}

function bytesToHex(bytes) {
  return [...new Uint8Array(bytes)].map((byte) => byte.toString(16).padStart(2, '0')).join('');
}

function hexToBytes(value) {
  if (!/^(?:[0-9a-f]{2})+$/i.test(value)) return null;
  return Uint8Array.from(value.match(/.{2}/g), (pair) => Number.parseInt(pair, 16));
}

function constantTimeEqual(left, right) {
  if (left.length !== right.length) return false;
  let difference = 0;
  for (let index = 0; index < left.length; index += 1) difference |= left[index] ^ right[index];
  return difference === 0;
}

async function hashToken(token) {
  return bytesToHex(await crypto.subtle.digest('SHA-256', encoder.encode(token)));
}

async function verifyPassword(password, saltHex, expectedHex) {
  const salt = hexToBytes(saltHex);
  const expected = hexToBytes(expectedHex);
  if (!salt || !expected || expected.length !== 64) return false;
  const key = await crypto.subtle.importKey('raw', encoder.encode(password), 'PBKDF2', false, ['deriveBits']);
  const derived = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt, iterations: 210000, hash: 'SHA-512' }, key, 512);
  return constantTimeEqual(new Uint8Array(derived), expected);
}

async function hashPassword(password, salt) {
  const key = await crypto.subtle.importKey('raw', encoder.encode(password), 'PBKDF2', false, ['deriveBits']);
  const derived = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt, iterations: 210000, hash: 'SHA-512' }, key, 512);
  return bytesToHex(derived);
}

function validPassword(password) {
  return typeof password === 'string' && password.length >= 8 && password.length <= 128;
}

function encodeBase64Url(bytes) {
  let binary = '';
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

async function currentUser(request, database) {
  const token = parseCookie(request, 'agrolink_session');
  if (!token) return null;
  const user = await database.getAuthenticatedUser(await hashToken(token), now());
  return user || null;
}

function authError(user) {
  if (!user) return error(401, 'Sessão necessária.');
  if (user.status === 'bloqueado') return error(403, 'Conta bloqueada.');
  if (user.status !== 'ativo') return error(403, 'A conta aguarda aprovação.');
  return null;
}

function isAdminUser(user) {
  return ['admin', 'admin_chefe'].includes(user?.papel);
}

function canWriteAdmin(user) {
  return user?.papel === 'admin_chefe' || (user?.papel === 'admin' && user?.nivel_admin !== 'auditor');
}

function isVerifiedTechnician(user) {
  return user?.papel === 'utilizador' && user?.tipo_perfil === 'tecnico' && user?.verification_status === 'aprovado';
}

function parseJsonColumn(value, fallback = []) {
  if (typeof value !== 'string') return value ?? fallback;
  try { return JSON.parse(value); } catch { return fallback; }
}

function requestedLimit(url) {
  const requested = Number(url.searchParams.get('limit') || 100);
  return Number.isFinite(requested) && requested > 0 ? Math.min(Math.floor(requested), 500) : 100;
}

function profilePayload(profile) {
  return profile ? {
    id: profile.id || profile.utilizador_id,
    nome: profile.nome,
    papel: profile.papel,
    status: profile.status,
    tipo_perfil: profile.tipo_perfil,
    nivel_admin: profile.nivel_admin,
    verification_status: profile.verification_status,
    visibilidade: profile.visibilidade,
    provincia: profile.provincia,
    municipio: profile.municipio,
    comuna: profile.comuna,
    telefone: profile.telefone,
  } : null;
}

function storageObjectKey(userId, logicalKey) {
  const normalized = String(logicalKey || '').replace(/\\/g, '/');
  const parts = normalized.split('/');
  if (!normalized || normalized.startsWith('/') || normalized.length > 128 || parts.some((part) => !part || part === '.' || part === '..')) return null;
  if (!/^[A-Za-z0-9._/-]+$/.test(normalized)) return null;
  return `users/${userId}/${normalized}`;
}

async function readLimitedBody(request, maxBytes) {
  if (!request.body) return new Uint8Array();
  const reader = request.body.getReader();
  const chunks = [];
  let size = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    size += value.byteLength;
    if (size > maxBytes) {
      await reader.cancel();
      return null;
    }
    chunks.push(value);
  }
  const result = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) {
    result.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return result;
}

async function handleRequest(request, env) {
  const url = new URL(request.url);
  const database = new D1DatabaseAdapter(env.DB);
  const protectedPost = ['POST', 'PATCH', 'PUT', 'DELETE'].includes(request.method) && url.pathname.startsWith('/api/');

  if (protectedPost && request.headers.has('origin') && request.headers.get('origin') !== url.origin) {
    return error(403, 'Origem do pedido não autorizada.');
  }

  if (url.pathname === '/api/health' && request.method === 'GET') {
    return json({ ok: true, runtime: 'cloudflare-worker' });
  }

  if (url.pathname === '/api/auth/register' && request.method === 'POST') {
    let body;
    try { body = await request.json(); } catch { return error(400, 'JSON inválido.'); }
    const email = String(body.email || '').trim().toLowerCase();
    const password = String(body.password || '');
    const name = String(body.nome || '').trim();
    if (!email || !email.includes('@') || !name || !validPassword(password)) return error(400, 'Dados de registo inválidos.');
    if (await database.findUserByEmail(email)) return error(409, 'Este email já está registado.');

    const requestedType = ['agricultor', 'tecnico', 'administrador'].includes(body.tipo_perfil) ? body.tipo_perfil : 'agricultor';
    const reservedChief = RESERVED_ADMIN_CHEFE_EMAILS.has(email);
    const salt = crypto.getRandomValues(new Uint8Array(16));
    const saltHex = bytesToHex(salt);
    const userId = uuid();
    try {
      await database.createUserWithProfile({
        id: userId,
        email,
        passwordHash: await hashPassword(password, salt),
        passwordSalt: saltHex,
      }, {
        id: userId,
        nome: name,
        papel: reservedChief ? 'admin_chefe' : 'utilizador',
        tipoPerfil: requestedType,
        status: reservedChief ? 'ativo' : 'pendente',
        verificationStatus: requestedType === 'tecnico' ? 'pendente' : null,
        visibilidade: email === ADMIN_CHEFE_HIDDEN_EMAIL ? 'oculto' : 'publico',
        provincia: body.provincia || null,
        municipio: body.municipio || null,
        comuna: body.comuna || null,
        telefone: body.telefone || null,
        createdAt: now(),
      });
    } catch (cause) {
      if (/UNIQUE constraint failed/i.test(String(cause?.message || ''))) return error(409, 'Este email já está registado.');
      throw cause;
    }
    return json({ status: 'criada', confirmacao_pendente: false, admin_chefe: reservedChief }, 201);
  }

  if (url.pathname === '/api/auth/password/forgot' && request.method === 'POST') {
    let body;
    try { body = await request.json(); } catch { return error(400, 'JSON inválido.'); }
    const email = String(body.email || '').trim().toLowerCase();
    if (!email || !email.includes('@')) return error(400, 'Email inválido.');
    const since = new Date(Date.now() - 15 * 60 * 1000).toISOString();
    if (await database.countRecentPasswordResets(email, since) >= 3) {
      return json({ ok: true, message: PASSWORD_RESET_MESSAGE });
    }
    const user = await database.findPasswordResetUser(email);
    if (!user || user.status === 'bloqueado') return json({ ok: true, message: PASSWORD_RESET_MESSAGE });

    const token = encodeBase64Url(crypto.getRandomValues(new Uint8Array(32)));
    const tokenHash = await hashToken(token);
    const resetId = uuid();
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000).toISOString();
    await database.createPasswordReset({ id: resetId, userId: user.id, email: user.email, tokenHash, expiresAt, createdAt: now() });
    const base = String(env.PUBLIC_URL || url.origin).trim().replace(/\/$/, '');
    const recoveryUrl = `${base}/redefinir-password?token=${encodeURIComponent(token)}`;
    const endpoint = String(env.PASSWORD_RESET_WEBHOOK_URL || '').trim();
    if (endpoint) {
      try {
        const response = await fetch(endpoint, {
          method: 'POST',
          headers: { 'content-type': 'application/json', 'x-agrolink-event': 'password_reset' },
          body: JSON.stringify({ source: 'AgroLink Caop', event: 'password_reset', email: user.email, nome: user.nome, recoveryUrl, token, expiresInMinutes: 60 }),
        });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        await database.updatePasswordResetDelivery(resetId, 'enviado', now());
      } catch (cause) {
        await database.updatePasswordResetDelivery(resetId, 'falhou', null, String(cause?.message || cause));
      }
      return json({ ok: true, message: PASSWORD_RESET_MESSAGE });
    }
    if (env.ENVIRONMENT === 'production') {
      await database.updatePasswordResetDelivery(resetId, 'falhou', null, 'Nenhum provedor de entrega configurado.');
      return json({ ok: true, message: PASSWORD_RESET_MESSAGE });
    }
    await database.updatePasswordResetDelivery(resetId, 'enviado', now());
    return json({ ok: true, message: 'Link de recuperação gerado para ambiente de desenvolvimento.', recoveryUrl });
  }

  if (url.pathname === '/api/auth/password/reset' && request.method === 'POST') {
    let body;
    try { body = await request.json(); } catch { return error(400, 'JSON inválido.'); }
    const token = String(body.token || '').trim();
    const password = String(body.password || '');
    if (!token || !validPassword(password)) return error(400, 'Token ou palavra-passe inválidos.');
    const salt = crypto.getRandomValues(new Uint8Array(16));
    const consumed = await database.consumePasswordReset({
      tokenHash: await hashToken(token),
      currentTime: now(),
      passwordHash: await hashPassword(password, salt),
      passwordSalt: bytesToHex(salt),
    });
    if (!consumed) return error(400, 'Link de recuperação inválido ou expirado.');
    return json({ ok: true });
  }

  if (url.pathname === '/api/auth/login' && request.method === 'POST') {
    let body;
    try { body = await request.json(); } catch { return error(400, 'JSON inválido.'); }
    const email = String(body.email || '').trim().toLowerCase();
    const password = String(body.password || '');
    if (!email || password.length > 128) return error(401, 'Email ou palavra-passe inválidos.');
    const user = await database.findUserByEmail(email);
    if (!user || !await verifyPassword(password, user.password_salt, user.password_hash)) return error(401, 'Email ou palavra-passe inválidos.');
    if (user.status === 'bloqueado') return error(403, 'Conta bloqueada.');
    const tokenBytes = crypto.getRandomValues(new Uint8Array(32));
    const token = encodeBase64Url(tokenBytes);
    const createdAt = now();
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();
    await database.createSession({ id: uuid(), userId: user.id, tokenHash: await hashToken(token), expiresAt, createdAt });
    const profile = profilePayload(await database.getProfile(user.id));
    const secure = url.protocol === 'https:' ? '; Secure' : '';
    return json({ session: { user: { id: user.id, email: user.email } }, profile }, 200, {
      'set-cookie': `agrolink_session=${encodeURIComponent(token)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=2592000${secure}`,
    });
  }

  if (url.pathname === '/api/auth/logout' && request.method === 'POST') {
    const token = parseCookie(request, 'agrolink_session');
    if (token) await database.deleteSession(await hashToken(token));
    const secure = url.protocol === 'https:' ? '; Secure' : '';
    return json({ ok: true }, 200, {
      'set-cookie': `agrolink_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0${secure}`,
    });
  }

  if (url.pathname === '/api/auth/session' && request.method === 'GET') {
    const user = await currentUser(request, database);
    if (!user) return json({ session: null, profile: null });
    return json({ session: { user: { id: user.utilizador_id, email: user.email } }, profile: profilePayload(user) });
  }

  if (url.pathname === '/api/admin/users/approve' && request.method === 'POST') {
    const user = await currentUser(request, database);
    const failure = authError(user);
    if (failure) return failure;
    if (user.papel !== 'admin_chefe') return error(403, 'Apenas o administrador-chefe pode aprovar administradores.');
    let body;
    try { body = await request.json(); } catch { return error(400, 'JSON inválido.'); }
    const targetId = String(body.id || '').trim();
    if (!targetId) return error(400, 'ID obrigatório.');
    const target = await database.getProfile(targetId);
    if (!target) return error(404, 'Utilizador não encontrado.');
    if (target.papel !== 'utilizador' || target.tipo_perfil !== 'administrador' || target.status !== 'pendente') {
      return error(409, 'A conta não é um administrador pendente.');
    }
    if (!await database.approveAdmin(targetId)) return error(409, 'A conta deixou de estar pendente.');
    await database.executeQuery(`INSERT INTO notificacoes(id,destinatario_id,titulo,corpo,tipo,criado_em)
      VALUES(?,?,?,?,?,?)`, [uuid(), targetId, 'Conta aprovada', 'A sua conta de administrador foi aprovada pelo administrador-chefe.', 'conta_aprovada', now()]);
    return json({ ok: true, papel: 'admin', status: 'ativo' });
  }

  if (url.pathname === '/api/admin/users/approve-account' && request.method === 'POST') {
    const user = await currentUser(request, database);
    const failure = authError(user);
    if (failure) return failure;
    if (user.papel !== 'admin_chefe') return error(403, 'Apenas o administrador-chefe pode aprovar contas pendentes.');
    let body;
    try { body = await request.json(); } catch { return error(400, 'JSON inválido.'); }
    const targetId = String(body.id || '').trim();
    if (!targetId) return error(400, 'ID obrigatório.');
    const target = await database.getProfile(targetId);
    if (!target) return error(404, 'Utilizador não encontrado.');
    if (target.papel !== 'utilizador' || !['agricultor', 'tecnico'].includes(target.tipo_perfil) || target.status !== 'pendente') {
      return error(409, 'A conta não é um agricultor ou técnico pendente.');
    }
    if (!await database.approveAccount(targetId)) return error(409, 'A conta deixou de estar pendente.');
    await database.executeQuery(`INSERT INTO notificacoes(id,destinatario_id,titulo,corpo,tipo,criado_em)
      VALUES(?,?,?,?,?,?)`, [uuid(), targetId, 'Conta aprovada', 'A sua conta está ativa.', 'conta_aprovada', now()]);
    return json({ ok: true, status: 'ativo' });
  }

  if (url.pathname === '/api/data/relatos' && request.method === 'GET') {
    const user = await currentUser(request, database);
    if (!user) return error(403, 'Sem permissão.');
    const filters = Object.fromEntries(['id', 'status', 'tipo', 'provincia']
      .map((key) => [key, url.searchParams.get(key)])
      .filter(([, value]) => value !== null));
    const reports = await database.listReports({
      userId: user.utilizador_id,
      isAdmin: isAdminUser(user),
      isTech: isVerifiedTechnician(user),
      filters,
      orderBy: url.searchParams.get('order') || 'criado_em',
      ascending: url.searchParams.get('asc') === '1',
      limit: requestedLimit(url),
    });
    return json(reports);
  }

  if (url.pathname === '/api/data/relatos' && request.method === 'POST') {
    const user = await currentUser(request, database);
    if (user) {
      const failure = authError(user);
      if (failure) return failure;
    }
    let body;
    try { body = await request.json(); } catch { return error(400, 'JSON inválido.'); }
    const id = body.id ? String(body.id) : uuid();
    const authorId = user?.utilizador_id || null;
    const existing = await database.findReportById(id);
    if (existing) {
      if (existing.autor_id === authorId) return json(existing, 200);
      return error(409, 'Este identificador de relato já está em uso.');
    }
    const report = await database.createReport({
      id,
      authorId,
      publicCode: `AL-${bytesToHex(crypto.getRandomValues(new Uint8Array(16))).toUpperCase()}`,
      type: body.tipo,
      description: body.descricao,
      province: body.provincia || null,
      municipality: body.municipio || null,
      comuna: body.comuna || null,
      createdAt: body.criado_em || now(),
      location: body.localizacao || null,
    });
    return json(report, 201);
  }

  if (url.pathname === '/api/relatos/codigo' && request.method === 'GET') {
    const code = url.searchParams.get('codigo');
    if (!code) return error(400, 'Código obrigatório.');
    const forwardedIp = request.headers.get('cf-connecting-ip') || request.headers.get('x-forwarded-for')?.split(',')[0].trim() || 'unknown';
    const key = `relato_codigo:${await hashToken(forwardedIp)}`;
    const windowStart = new Date(Date.now() - 10 * 60 * 1000).toISOString();
    await database.clearReportCodeAttempts(key, windowStart);
    if (await database.countReportCodeAttempts(key, windowStart) >= 30) {
      return error(429, 'Demasiadas tentativas de consulta. Tente novamente mais tarde.');
    }
    await database.recordReportCodeAttempt(uuid(), key, now());
    const report = await database.findReportByCode(code);
    if (!report) return error(404, 'Código não encontrado.');
    const responses = await database.listReportResponses(report.id);
    return json({ ...report, respostas: responses });
  }

  if (url.pathname === '/api/data/relato_respostas' && request.method === 'GET') {
    const user = await currentUser(request, database);
    if (!user) return error(403, 'Sem permissão.');
    const filters = Object.fromEntries(['relato_id', 'tecnico_id']
      .map((key) => [key, url.searchParams.get(key)])
      .filter(([, value]) => value !== null));
    const responses = await database.listAuthorizedReportResponses({
      userId: user.utilizador_id,
      isAdmin: isAdminUser(user),
      isTech: isVerifiedTechnician(user),
      filters,
      orderBy: url.searchParams.get('order'),
      ascending: url.searchParams.get('asc') === '1',
      limit: requestedLimit(url),
    });
    return json(responses);
  }

  if (url.pathname === '/api/data/relato_midias' && request.method === 'GET') {
    const user = await currentUser(request, database);
    if (!user) return error(403, 'Sem permissão.');
    const media = await database.listReportMedia({
      userId: user.utilizador_id,
      isAdmin: isAdminUser(user),
      isTech: isVerifiedTechnician(user),
      reportId: url.searchParams.get('relato_id') || null,
      limit: requestedLimit(url),
    });
    return json(media);
  }

  if (url.pathname === '/api/data/relato_midias' && request.method === 'POST') {
    const user = await currentUser(request, database);
    if (!user) return error(401, 'Sessão necessária.');
    const failure = authError(user);
    if (failure) return failure;
    let body;
    try { body = await request.json(); } catch { return error(400, 'JSON inválido.'); }
    const reportId = String(body.relato_id || '').trim();
    const storagePath = String(body.caminho_storage || '');
    const report = await database.findReportById(reportId);
    if (!report) return error(404, 'Relato não encontrado.');
    if (!canWriteAdmin(user) && report.autor_id !== user.utilizador_id) {
      return error(403, 'Só pode anexar ficheiros aos seus próprios relatos.');
    }
    const mediaType = String(body.tipo || '');
    if (!['foto', 'audio'].includes(mediaType) || !storagePath.startsWith('relatos/')) {
      return error(400, 'Ficheiro de relato inválido.');
    }
    const storage = createStorageProvider({ env, provider: env.STORAGE_PROVIDER || 'r2' });
    const stored = await storage.head(storagePath);
    if (!stored || (!canWriteAdmin(user) && stored.customMetadata?.ownerId !== user.utilizador_id)) {
      return error(400, 'Ficheiro de relato inválido.');
    }
    const contentType = stored.httpMetadata?.contentType || '';
    if ((mediaType === 'foto' && !contentType.startsWith('image/')) ||
        (mediaType === 'audio' && !contentType.startsWith('audio/'))) {
      return error(400, 'Tipo de mídia incompatível com o ficheiro.');
    }
    const id = body.id ? String(body.id) : uuid();
    const existing = await database.findReportMedia(id);
    if (existing) {
      if (existing.relato_id === reportId && existing.caminho_storage === storagePath && existing.tipo === mediaType) {
        return json({
          id: existing.id,
          relato_id: existing.relato_id,
          tipo: existing.tipo,
          caminho_storage: existing.caminho_storage,
          criado_em: existing.criado_em,
        });
      }
      return error(409, 'Este identificador de mídia já está em uso.');
    }
    const media = await database.createReportMedia({
      id,
      reportId,
      type: mediaType,
      storagePath,
      createdAt: body.criado_em || now(),
    });
    return json(media, 201);
  }

  if (url.pathname === '/api/data/relato_midias' && request.method === 'DELETE') {
    const user = await currentUser(request, database);
    const failure = authError(user);
    if (failure) return failure;
    if (!canWriteAdmin(user)) return error(403, 'Apenas administradores podem eliminar conteúdo.');
    const id = url.searchParams.get('id');
    if (!id) return error(400, 'ID obrigatório.');
    const media = await database.findReportMedia(id);
    if (media) {
      const storage = createStorageProvider({ env, provider: env.STORAGE_PROVIDER || 'r2' });
      await storage.delete(media.caminho_storage);
      await database.deleteReportMedia(id);
    }
    return json({ ok: true });
  }

  if (url.pathname === '/api/media/upload/relatos' && request.method === 'POST') {
    const user = await currentUser(request, database);
    const failure = authError(user);
    if (failure) return failure;
    const rawBody = await readLimitedBody(request, MAX_REPORT_UPLOAD_BODY_SIZE);
    if (!rawBody) return error(413, 'Pedido demasiado grande.');
    let body;
    try { body = JSON.parse(new TextDecoder().decode(rawBody)); } catch { return error(400, 'JSON inválido.'); }
    if (!body.data || !body.filename) return error(400, 'Ficheiro inválido.');
    const source = String(body.data);
    const dataUrl = source.match(/^data:([^;,]+);base64,(.*)$/is);
    const encoded = dataUrl ? dataUrl[2] : source;
    const contentType = String(body.mimeType || dataUrl?.[1] || '').split(';')[0].trim().toLowerCase();
    if (!ALLOWED_REPORT_MEDIA_TYPES.has(contentType)) return error(415, 'Tipo de conteúdo não permitido.');
    if (encoded.length > 24 * 1024 * 1024 ||
        !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(encoded)) {
      return error(400, 'Conteúdo Base64 inválido.');
    }
    let binary;
    try { binary = atob(encoded); } catch { return error(400, 'Conteúdo Base64 inválido.'); }
    if (!binary.length || binary.length > MAX_REPORT_MEDIA_SIZE) {
      return error(413, 'Ficheiro vazio ou acima do limite de 18 MiB.');
    }
    const uploadId = String(body.uploadId || '');
    if (uploadId && (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(uploadId))) {
      return error(400, 'Identificador de upload inválido.');
    }
    const bytes = Uint8Array.from(binary, (character) => character.charCodeAt(0));
    const safeFilename = String(body.filename).replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 140);
    const storagePath = `relatos/${uploadId || uuid()}-${safeFilename}`;
    const storage = createStorageProvider({ env, provider: env.STORAGE_PROVIDER || 'r2' });
    const digest = bytesToHex(await crypto.subtle.digest('SHA-256', bytes));
    const existing = await storage.head(storagePath);
    if (existing) {
      if (existing.customMetadata?.ownerId === user.utilizador_id && existing.customMetadata?.sha256 === digest) {
        return json({ caminho: storagePath }, 201);
      }
      return error(409, 'Identificador de upload já usado com outro conteúdo.');
    }
    await storage.put(storagePath, bytes, {
      httpMetadata: { contentType },
      customMetadata: { ownerId: user.utilizador_id, sha256: digest },
    });
    return json({ caminho: storagePath }, 201);
  }

  if (url.pathname.startsWith('/api/media/relatos/') && request.method === 'GET') {
    const user = await currentUser(request, database);
    if (!user) return error(401, 'Sessão necessária.');
    let storagePath;
    try {
      storagePath = url.pathname.slice('/api/media/'.length)
        .split('/').map((part) => decodeURIComponent(part)).join('/');
    } catch {
      return error(400, 'Ficheiro não encontrado.');
    }
    if (!storagePath.startsWith('relatos/')) return error(404, 'Ficheiro não encontrado.');
    const media = await database.findReportMediaByPath(storagePath);
    if (!media || (!isAdminUser(user) && media.autor_id !== user.utilizador_id && !isVerifiedTechnician(user))) {
      return error(404, 'Ficheiro não encontrado.');
    }
    const object = await createStorageProvider({ env, provider: env.STORAGE_PROVIDER || 'r2' }).get(storagePath);
    if (!object) return error(404, 'Ficheiro não encontrado.');
    return new Response(object.body, {
      status: 200,
      headers: {
        'content-type': object.httpMetadata?.contentType || 'application/octet-stream',
        'cache-control': 'private, max-age=600',
      },
    });
  }

  if (url.pathname === '/api/data/relato_respostas' && request.method === 'POST') {
    const user = await currentUser(request, database);
    if (!user) return error(403, 'Sem permissão.');
    const failure = authError(user);
    if (failure) return failure;
    if (!isVerifiedTechnician(user) && !isAdminUser(user)) {
      return error(403, 'Só técnicos aprovados ou administradores podem responder a relatos.');
    }
    let body;
    try { body = await request.json(); } catch { return error(400, 'JSON inválido.'); }
    const canWrite = canWriteAdmin(user);
    const reportId = String(body.relato_id || '').trim();
    if (!canWrite) {
      if (!await database.findReportById(reportId)) return error(404, 'Relato não encontrado.');
    }
    const comment = canWrite ? body.comentario : String(body.comentario || '').trim().slice(0, 4000);
    if (!canWrite && !comment) return error(400, 'A resposta técnica não pode estar vazia.');
    const response = await database.createReportResponse({
      id: body.id ? String(body.id) : uuid(),
      reportId,
      technicianId: canWrite ? body.tecnico_id : user.utilizador_id,
      comment,
      createdAt: body.criado_em || now(),
    });
    return json(response, 201);
  }

  if (url.pathname === '/api/data/relatos' && request.method === 'PATCH') {
    const user = await currentUser(request, database);
    if (!user) return error(403, 'Sem permissão.');
    const failure = authError(user);
    if (failure) return failure;
    const canWrite = canWriteAdmin(user);
    const isTech = isVerifiedTechnician(user);
    if (!canWrite && !isTech) return error(403, 'Só técnicos aprovados podem alterar o estado de relatos.');
    const id = url.searchParams.get('id');
    if (!id) return error(400, 'ID obrigatório.');
    let body;
    try { body = await request.json(); } catch { return error(400, 'JSON inválido.'); }
    const report = await database.findReportById(id);
    if (!report) return error(404, 'Relato não encontrado.');
    if (!canWrite && Object.keys(body).some((key) => key !== 'status')) {
      return error(403, 'Técnicos só podem alterar o estado do relato.');
    }
    if (!canWrite && !['pendente', 'em_analise', 'respondido', 'resolvido'].includes(body.status)) {
      return error(400, 'Estado do relato inválido.');
    }
    const allowlist = new Set(['autor_id', 'tipo', 'descricao', 'provincia', 'municipio', 'comuna', 'status', 'tecnico_atribuido_id', 'criado_em']);
    const updates = Object.fromEntries(Object.entries(body).filter(([key]) => allowlist.has(key)));
    if (!Object.keys(updates).length) return json(await database.getProfile(user.utilizador_id));
    const updated = await database.updateReport(id, updates);
    return json(updated);
  }

  if (url.pathname === '/api/denuncias/alvos' && request.method === 'GET') {
    const user = await currentUser(request, database);
    const failure = authError(user);
    if (failure) return failure;
    const targets = await database.listDenunciationTargets({
      userId: user.utilizador_id,
      isAdmin: isAdminUser(user),
      search: String(url.searchParams.get('pesquisa') || '').trim().toLowerCase(),
    });
    return json(targets);
  }

  if (url.pathname === '/api/denuncias' && request.method === 'POST') {
    const user = await currentUser(request, database);
    const failure = authError(user);
    if (failure) return failure;
    let body;
    try { body = await request.json(); } catch { return error(400, 'JSON inválido.'); }
    const targetId = String(body.denunciado_id || '').trim();
    const category = String(body.categoria || '').trim().slice(0, 80);
    const description = String(body.descricao || '').trim().slice(0, 4000);
    if (!targetId || !category || description.length < 10) {
      return error(400, 'Indique a pessoa denunciada, a categoria e uma descrição com pelo menos 10 caracteres.');
    }
    if (targetId === user.utilizador_id) return error(400, 'Não pode denunciar a própria conta.');
    const target = await database.findDenunciationTarget(targetId);
    if (!target) return error(404, 'Utilizador denunciado não encontrado.');
    const priority = ['baixa', 'media', 'alta', 'urgente'].includes(body.prioridade) ? body.prioridade : 'media';
    const created = await database.createDenunciation({
      id: uuid(),
      authorId: user.utilizador_id,
      targetId,
      transportId: body.transporte_id || null,
      category,
      description,
      evidences: Array.isArray(body.evidencias) ? body.evidencias.slice(0, 5) : [],
      priority,
      createdAt: now(),
    });
    const administrators = await database.queryRows("SELECT id FROM profiles WHERE papel IN ('admin','admin_chefe') AND status='ativo'");
    if (administrators.length) {
      const notificationTime = now();
      await database.executeBatch(administrators.map(({ id }) => ({
        sql: `INSERT INTO notificacoes(id,destinatario_id,titulo,corpo,tipo,relacionado_tipo,relacionado_id,criado_em)
          VALUES(?,?,?,?,?,?,?,?)`,
        values: [uuid(), id, 'Nova denúncia recebida', `Uma denúncia contra ${target.nome} foi enviada para análise.`, 'denuncia', 'denuncia', created.id, notificationTime],
      })));
    }
    return json(created, 201);
  }

  if (url.pathname === '/api/data/denuncias' && request.method === 'GET') {
    const user = await currentUser(request, database);
    if (!user) return error(403, 'Sem permissão.');
    const filters = Object.fromEntries(['id', 'status', 'categoria', 'autor_id', 'denunciado_id']
      .map((key) => [key, url.searchParams.get(key)])
      .filter(([, value]) => value !== null));
    const reports = await database.listOwnDenunciations({
      userId: user.utilizador_id,
      isAdmin: isAdminUser(user),
      filters,
      orderBy: url.searchParams.get('order'),
      ascending: url.searchParams.get('asc') === '1',
      limit: requestedLimit(url),
    });
    return json(reports.map((item) => ({ ...item, evidencias: parseJsonColumn(item.evidencias) })));
  }

  if (url.pathname === '/api/data/denuncia_historico' && request.method === 'GET') {
    const user = await currentUser(request, database);
    if (!user) return error(403, 'Sem permissão.');
    const history = await database.listDenunciationHistory({
      userId: user.utilizador_id,
      isAdmin: isAdminUser(user),
      denunciationId: url.searchParams.get('denuncia_id') || null,
      limit: requestedLimit(url),
    });
    return json(history);
  }

  if (url.pathname === '/api/admin/denuncias' && request.method === 'GET') {
    const user = await currentUser(request, database);
    const failure = authError(user);
    if (failure) return failure;
    if (!isAdminUser(user)) return error(403, 'Apenas administradores.');
    const status = url.searchParams.get('estado');
    const reports = await database.listAdminDenunciations(status);
    return json(reports.map((item) => ({ ...item, evidencias: parseJsonColumn(item.evidencias) })));
  }

  if (url.pathname === '/api/admin/denuncias/atualizar' && request.method === 'PATCH') {
    const user = await currentUser(request, database);
    const failure = authError(user);
    if (failure) return failure;
    if (!canWriteAdmin(user)) return error(403, 'Apenas administradores podem tratar denúncias.');
    let body;
    try { body = await request.json(); } catch { return error(400, 'JSON inválido.'); }
    const id = String(body.id || '').trim();
    if (!id) return error(400, 'ID obrigatório.');
    const current = await database.findDenunciation(id);
    if (!current) return error(404, 'Denúncia não encontrada.');
    const updates = {};
    if (['pendente', 'em_analise', 'confirmada', 'rejeitada', 'arquivada'].includes(body.estado)) updates.estado = body.estado;
    if (['baixa', 'media', 'alta', 'urgente'].includes(body.prioridade)) updates.prioridade = body.prioridade;
    if (typeof body.decisao === 'string') updates.decisao = body.decisao.slice(0, 4000);
    if (body.admin_responsavel_id === null || typeof body.admin_responsavel_id === 'string') {
      updates.admin_responsavel_id = body.admin_responsavel_id || null;
    }
    if (!Object.keys(updates).length) return json(current);
    if (updates.admin_responsavel_id) {
      const assignee = await database.findAdminAssignee(updates.admin_responsavel_id);
      if (!assignee || !['admin', 'admin_chefe'].includes(assignee.papel)) return error(400, 'O responsável deve ser um administrador.');
    }
    if (updates.estado && ['confirmada', 'rejeitada', 'arquivada'].includes(updates.estado)) updates.data_resolucao = now();
    const updated = await database.updateDenunciation(id, updates, user.utilizador_id, now());
    return json(updated);
  }

  if (url.pathname === '/api/profile' && (request.method === 'GET' || request.method === 'PATCH')) {
    const user = await currentUser(request, database);
    const failure = authError(user);
    if (failure) return failure;
    if (request.method === 'PATCH') {
      let body;
      try { body = await request.json(); } catch { return error(400, 'JSON inválido.'); }
      if (!body || typeof body !== 'object' || Array.isArray(body)) return error(400, 'JSON inválido.');
      const updates = {};
      for (const key of ['nome', 'provincia', 'municipio', 'comuna', 'telefone']) {
        if (!Object.hasOwn(body, key)) continue;
        if (key === 'nome') {
          updates.nome = String(body.nome || '').trim().slice(0, 120);
          if (!updates.nome) return error(400, 'Nome inválido.');
        } else {
          updates[key] = body[key] === null ? null : String(body[key]).trim();
        }
      }
      if (Object.keys(updates).length) await database.updateProfileDetails(user.utilizador_id, updates);
    }
    return json(profilePayload(await database.getProfile(user.utilizador_id)));
  }

  if (url.pathname === '/api/ia/chat' && request.method === 'POST') {
    const user = await currentUser(request, database);
    const failure = authError(user);
    if (failure) return failure;
    let body;
    try { body = await request.json(); } catch { return error(400, 'JSON inválido.'); }
    const message = String(body.mensagem || body.message || '').trim();
    if (!message || message.length > MAX_CHAT_MESSAGE_LENGTH) return error(400, 'Mensagem inválida.');
    const context = body.contexto ?? {};
    if (!context || typeof context !== 'object' || Array.isArray(context)) return error(400, 'Contexto inválido.');
    if (encoder.encode(JSON.stringify(context)).byteLength > MAX_CHAT_CONTEXT_BYTES) return error(400, 'Contexto demasiado grande.');
    const media = Array.isArray(body.media) ? body.media : [];
    if (media.length > 4 || media.some((item) => !Number.isFinite(Number(item?.size)) || Number(item.size) < 0) ||
        media.reduce((sum, item) => sum + Number(item?.size || 0), 0) > 16 * 1024 * 1024) {
      return error(400, 'Tamanho ou quantidade de mídia excedido.');
    }

    let conversationId = body.conversaId ? String(body.conversaId) : null;
    const createConversation = !conversationId;
    if (conversationId && await database.getConversationOwner(conversationId) !== user.utilizador_id) {
      return error(404, 'Conversa não encontrada.');
    }
    const recent = await database.countRecentChatQuestions(user.utilizador_id, new Date(Date.now() - 10 * 60 * 1000).toISOString());
    if (recent >= 20) return error(429, 'Limite de perguntas atingido. Tente novamente mais tarde.');
    if (createConversation) {
      conversationId = uuid();
      await database.createConversation(conversationId, user.utilizador_id, now());
    }
    await database.recordChatQuestion(uuid(), user.utilizador_id, now());
    await database.addConversationMessage({ id: uuid(), conversationId, role: 'user', content: message, createdAt: now() });
    const history = await database.getConversationHistory(conversationId, 20);
    const timeoutValue = Number(env.AI_TIMEOUT_MS || 12000);
    const timeoutMs = Number.isFinite(timeoutValue) && timeoutValue > 0 ? Math.min(timeoutValue, 60000) : 12000;
    const ai = new WorkersAIProvider({
      binding: env.AI,
      model: env.AI_MODEL || '@cf/meta/llama-3.1-8b-instruct',
      timeoutMs,
      maxResponseChars: MAX_CHAT_RESPONSE_LENGTH,
    });
    const answer = await ai.generateAgriculturalResponse({ message, context, history: history.slice(0, -1) });
    if (!answer || answer.length > MAX_CHAT_RESPONSE_LENGTH) {
      return json({ conversaId: conversationId, resposta: 'O assistente IA está temporariamente indisponível. Um técnico poderá ajudar através de um relato.', confianca: 'baixa' });
    }
    await database.addConversationMessage({ id: uuid(), conversationId, role: 'assistant', content: answer, createdAt: now() });
    return json({ conversaId: conversationId, resposta: answer, confianca: 'media' });
  }

  const storageMatch = url.pathname.match(/^\/api\/storage\/(.+)$/);
  if (storageMatch) {
    const user = await currentUser(request, database);
    const failure = authError(user);
    if (failure) return failure;
    let logicalKey;
    try { logicalKey = decodeURIComponent(storageMatch[1]); } catch { return error(400, 'Chave inválida.'); }
    const key = storageObjectKey(user.utilizador_id, logicalKey);
    if (!key) return error(400, 'Chave inválida.');
    const storage = createStorageProvider({ env, provider: env.STORAGE_PROVIDER || 'r2' });

    if (request.method === 'PUT') {
      const contentType = (request.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
      if (!ALLOWED_CONTENT_TYPES.has(contentType)) return error(415, 'Tipo de conteúdo não permitido.');
      const content = await readLimitedBody(request, MAX_STORAGE_OBJECT_SIZE);
      if (!content?.byteLength) return error(413, 'Objeto vazio ou acima do limite de 2 MiB.');
      await storage.put(key, content, { httpMetadata: { contentType }, customMetadata: { ownerId: user.utilizador_id } });
      return json({ key: logicalKey, size: content.byteLength, contentType }, 201);
    }

    if (!['GET', 'HEAD', 'DELETE'].includes(request.method)) {
      return error(405, 'Método não permitido.');
    }
    const metadata = await storage.head(key);
    if (!metadata || metadata.customMetadata?.ownerId !== user.utilizador_id) return error(404, 'Objeto não encontrado.');
    const headers = {
      'content-type': metadata.httpMetadata?.contentType || 'application/octet-stream',
      'content-length': String(metadata.size),
      'cache-control': 'private, no-store',
    };
    if (request.method === 'HEAD') return new Response(null, { status: 200, headers });
    if (request.method === 'DELETE') {
      await storage.delete(key);
      return new Response(null, { status: 204 });
    }
    const object = await storage.get(key);
    if (!object || object.customMetadata?.ownerId !== user.utilizador_id) return error(404, 'Objeto não encontrado.');
    return new Response(object.body, { status: 200, headers });
  }

  if (url.pathname === '/api/admin/sync-noticias' && request.method === 'POST') {
    const user = await currentUser(request, database);
    const failure = authError(user);
    if (failure) return failure;
    if (!canWriteAdmin(user)) return error(403, 'Apenas administradores podem sincronizar notícias.');
    return json(await synchronizeNewsFeeds({ database }));
  }

  const businessResponse = await handleBusinessRequest(request, url, env, database, {
    currentUser,
    authError,
    canWriteAdmin,
    isVerifiedTechnician,
    isChief: (user) => user?.papel === 'admin_chefe',
    isTransporter: (user, profile) => user?.papel === 'utilizador' && profile?.estado_verificacao === 'aprovado',
  });
  if (businessResponse) return businessResponse;
  if (url.pathname.startsWith('/api/')) return error(404, 'Endpoint não encontrado.');
  return env.ASSETS ? env.ASSETS.fetch(request) : error(404, 'Asset não encontrado.');
}

export default {
  fetch(request, env) {
    return handleRequest(request, env).catch((cause) => {
      console.error('Cloudflare Worker request failed:', cause?.message || cause);
      return error(500, 'Erro interno do servidor.');
    });
  },
};
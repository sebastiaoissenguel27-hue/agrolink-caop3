import test from 'node:test';
import assert from 'node:assert/strict';
import { isPublicAddress, resolveDnsAddresses, synchronizeNewsFeeds } from './rss.mjs';

const validFeed = `<?xml version="1.0"?><rss><channel>
  <item><title>Nova cultura de milho em Angola</title><link>https://news.example.org/milho</link>
  <description><![CDATA[Produção agrícola &amp; rendimento]]></description>
  <pubDate>Mon, 21 Sep 2026 10:00:00 GMT</pubDate></item>
</channel></rss>`;
const publicAddresses = [{ address: '93.184.216.34' }, { address: '2606:4700:4700::1111' }];

function createDatabase(sources) {
  const news = new Map();
  const logs = [];
  return {
    news,
    logs,
    async queryRows(sql) {
      assert.match(sql, /FROM noticias_fontes/);
      return sources;
    },
    async executeQuery(sql, values) {
      if (sql.includes('INSERT OR IGNORE INTO noticias')) {
        const url = values[9];
        if (news.has(url)) return { meta: { changes: 0 } };
        news.set(url, values);
        return { meta: { changes: 1 } };
      }
      if (sql.includes('INSERT INTO noticias_sync_logs')) {
        logs.push(values);
        return { meta: { changes: 1 } };
      }
      throw new Error(`SQL RSS inesperado: ${sql}`);
    },
  };
}

function source(id, url = 'https://feed.example.org/rss') {
  return { id, nome: id, url_rss: url, categoria: 'Culturas', ativo: 1, pais: 'Angola', prioridade: 1 };
}

function feedResponse(xml = validFeed, status = 200, headers = {}) {
  return new Response(xml, { status, headers });
}

test('resolve DNS A e AAAA por DoH usando fetch e valida tipos de resposta', async () => {
  const calls = [];
  const addresses = await resolveDnsAddresses('feed.example.org', {
    fetchImpl: async (url, options) => {
      calls.push({ url: new URL(url), options });
      const type = new URL(url).searchParams.get('type');
      return Response.json({
        Status: 0,
        Answer: [{ type: type === 'A' ? 1 : 28, data: type === 'A' ? '93.184.216.34' : '2606:4700:4700::1111' }],
      });
    },
  });
  assert.equal(calls.length, 2);
  assert.deepEqual(calls.map(({ url }) => url.searchParams.get('type')), ['A', 'AAAA']);
  assert.ok(calls.every(({ options }) => options.redirect === 'manual' && options.headers.accept === 'application/dns-json'));
  assert.deepEqual(addresses, publicAddresses);
});

test('bloqueia endereços IPv4 e IPv6 privados, loopback, link-local, multicast e reservados', () => {
  const blocked = [
    '10.0.0.1', '172.16.0.1', '192.168.1.1', '100.64.0.1', '192.0.2.1',
    '127.0.0.1', '169.254.1.1', '0.0.0.1', '224.0.0.1', '255.255.255.255',
    '::1', '::ffff:192.168.1.1', 'fc00::1', 'fd12:3456::1', 'fe80::1',
    'ff02::1', '2001:db8::1', '2001::1', '2002::1', '3fff:0::1',
  ];
  for (const address of blocked) assert.equal(isPublicAddress(address), false, `${address} deveria ser bloqueado`);
  assert.equal(isPublicAddress('93.184.216.34'), true);
  assert.equal(isPublicAddress('2606:4700:4700::1111'), true);
});

test('sincroniza feed válido, persiste notícias e deduplica URLs repetidas', async () => {
  const database = createDatabase([source('feed-valid')]);
  let feedFetches = 0;
  const dependencies = {
    database,
    resolveHostname: async () => publicAddresses,
    fetchImpl: async (url) => {
      assert.equal(new URL(url).hostname, 'feed.example.org');
      feedFetches += 1;
      return feedResponse(validFeed.replace('</channel>', `<item><title>Milho repetido em Angola</title><link>https://news.example.org/milho</link><description>Produção agrícola</description></item></channel>`));
    },
  };
  const first = await synchronizeNewsFeeds(dependencies);
  assert.deepEqual(first, { fontes_processadas: 1, inseridas: 1, ignoradas: 1, erros: [] });
  assert.equal(database.news.size, 1);
  assert.equal(database.logs[0][2], 1);
  assert.equal(database.logs[0][3], 1);

  const second = await synchronizeNewsFeeds(dependencies);
  assert.deepEqual(second, { fontes_processadas: 1, inseridas: 0, ignoradas: 2, erros: [] });
  assert.equal(database.news.size, 1);
  assert.equal(database.logs.length, 2);
  assert.equal(feedFetches, 2);
});

test('XML inválido é registado como falha da fonte', async () => {
  const database = createDatabase([source('feed-invalid-xml')]);
  const result = await synchronizeNewsFeeds({
    database,
    resolveHostname: async () => publicAddresses,
    fetchImpl: async () => feedResponse('<rss><channel><item></rss>'),
  });
  assert.equal(result.erros.length, 1);
  assert.match(result.erros[0], /XML inválido/);
  assert.equal(database.logs[0][2], 0);
});

test('hostname inexistente e falha de rede são isolados por feed', async () => {
  const database = createDatabase([source('missing', 'https://missing.example.org/rss'), source('network')]);
  let fetchCount = 0;
  const result = await synchronizeNewsFeeds({
    database,
    resolveHostname: async (hostname) => hostname.startsWith('missing') ? [] : publicAddresses,
    fetchImpl: async () => {
      fetchCount += 1;
      throw new Error('falha de rede');
    },
  });
  assert.equal(result.fontes_processadas, 2);
  assert.equal(result.erros.length, 2);
  assert.match(result.erros[0], /não resolvido/);
  assert.match(result.erros[1], /falha de rede/);
  assert.equal(fetchCount, 1);
  assert.equal(database.logs.length, 2);
  assert.equal(database.logs[0][2], 0);
  assert.equal(database.logs[1][2], 0);
});

test('timeout de dez segundos aborta o fetch e grava log sem parar outros feeds', async () => {
  const database = createDatabase([source('timeout'), source('after-timeout')]);
  let requests = 0;
  const result = await synchronizeNewsFeeds({
    database,
    timeoutMs: 10,
    resolveHostname: async () => publicAddresses,
    fetchImpl: async (_url, { signal }) => {
      requests += 1;
      if (requests === 1) {
        return new Promise((resolve, reject) => signal.addEventListener('abort', () => reject(new Error('timeout abortado')), { once: true }));
      }
      return feedResponse(validFeed);
    },
  });
  assert.equal(result.fontes_processadas, 2);
  assert.equal(result.erros.length, 1);
  assert.match(result.erros[0], /timeout abortado/);
  assert.equal(result.inseridas, 1);
  assert.equal(database.logs.length, 2);
});

test('bloqueia respostas DNS com IPv4 privado, loopback, link-local e IPv6 restrito antes do fetch', async () => {
  const blocked = [
    '10.1.2.3', '127.0.0.1', '169.254.169.254', '::1', 'fc00::1', 'fe80::1', 'ff02::1',
  ];
  for (const address of blocked) {
    const database = createDatabase([source(address)]);
    let feedFetched = false;
    const result = await synchronizeNewsFeeds({
      database,
      resolveHostname: async () => [{ address }],
      fetchImpl: async () => {
        feedFetched = true;
        return feedResponse(validFeed);
      },
    });
    assert.equal(result.erros.length, 1, address);
    assert.equal(feedFetched, false, address);
    assert.equal(database.logs[0][2], 0, address);
  }
});

test('não faz fetch para IP literal nem aceita URL que não seja HTTPS', async () => {
  for (const url of ['https://127.0.0.1/rss', 'https://[::1]/rss', 'http://feed.example.org/rss', 'file:///etc/passwd']) {
    const database = createDatabase([source(url, url)]);
    let fetched = false;
    const result = await synchronizeNewsFeeds({
      database,
      resolveHostname: async () => publicAddresses,
      fetchImpl: async () => {
        fetched = true;
        return feedResponse(validFeed);
      },
    });
    assert.equal(result.erros.length, 1, url);
    assert.equal(fetched, false, url);
  }
});

test('não segue redirect para destino bloqueado e revalida a localização', async () => {
  const database = createDatabase([source('redirect')]);
  const validated = [];
  const fetchedUrls = [];
  const result = await synchronizeNewsFeeds({
    database,
    resolveHostname: async (hostname) => {
      validated.push(hostname);
      return publicAddresses;
    },
    fetchImpl: async (url) => {
      fetchedUrls.push(String(url));
      return feedResponse('', 302, { location: 'https://127.0.0.1/private' });
    },
  });
  assert.equal(result.erros.length, 1);
  assert.match(result.erros[0], /IP literal não permitido/);
  assert.deepEqual(validated, ['feed.example.org']);
  assert.deepEqual(fetchedUrls, ['https://feed.example.org/rss']);
});

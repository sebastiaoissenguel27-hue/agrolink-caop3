import { MAX_FEED_BYTES, parseNewsFeed } from '../server/newsFeed.mjs';

const DNS_OVER_HTTPS_ENDPOINT = 'https://cloudflare-dns.com/dns-query';
const FEED_ACCEPT = 'application/rss+xml, application/atom+xml, application/xml, text/xml';

function parseIpv4(address) {
  const parts = address.split('.');
  if (parts.length !== 4 || parts.some((part) => !/^(0|[1-9]\d{0,2})$/.test(part) || Number(part) > 255)) return null;
  return parts.map(Number);
}

function parseIpv6(address) {
  let value = address.toLowerCase().split('%')[0];
  if (value.includes('.')) {
    const separator = value.lastIndexOf(':');
    const ipv4 = parseIpv4(value.slice(separator + 1));
    if (!ipv4) return null;
    value = `${value.slice(0, separator)}:${((ipv4[0] << 8) | ipv4[1]).toString(16)}:${((ipv4[2] << 8) | ipv4[3]).toString(16)}`;
  }
  const halves = value.split('::');
  if (halves.length > 2) return null;
  const left = halves[0] ? halves[0].split(':') : [];
  const right = halves.length === 2 && halves[1] ? halves[1].split(':') : [];
  const groups = [...left, ...(halves.length === 2 ? Array(8 - left.length - right.length).fill('0') : []), ...right];
  if (groups.length !== 8 || groups.some((group) => !/^[\da-f]{1,4}$/.test(group))) return null;
  return groups.map((group) => Number.parseInt(group, 16));
}

export function isPublicAddress(address) {
  if (typeof address !== 'string') return false;
  if (/^\d{1,3}(?:\.\d{1,3}){3}$/.test(address)) {
    const octets = parseIpv4(address);
    if (!octets) return false;
    const [a, b, c] = octets;
    return !(a === 0 || a === 10 || a === 127 || a >= 224
      || (a === 100 && b >= 64 && b <= 127)
      || (a === 169 && b === 254)
      || (a === 172 && b >= 16 && b <= 31)
      || (a === 192 && b === 0 && (c === 0 || c === 2))
      || (a === 192 && b === 168)
      || (a === 192 && b === 88 && c === 99)
      || (a === 198 && (b === 18 || b === 19))
      || (a === 198 && b === 51 && c === 100)
      || (a === 203 && b === 0 && c === 113));
  }

  if (address.includes('%')) return false;
  const groups = parseIpv6(address);
  if (!groups) return false;
  const first = groups[0];
  const second = groups[1];
  const third = groups[2];
  return first >= 0x2000 && first <= 0x3fff
    && !(first === 0x2001 && (second <= 0x01ff || second === 0x0db8))
    && !(first === 0x2002)
    && !(first === 0x3fff && (second & 0xfff0) === 0x0000)
    && !(first === 0x2001 && second === 0x0000 && third === 0x0000);
}

function hostnameOf(url) {
  return url.hostname.replace(/^\[|\]$/g, '').toLowerCase().replace(/\.$/, '');
}

function isIpLiteral(hostname) {
  return hostname.includes(':') || /^\d+(?:\.\d+){3}$/.test(hostname);
}

export async function resolveDnsAddresses(hostname, { fetchImpl = fetch, signal } = {}) {
  const addresses = [];
  for (const type of ['A', 'AAAA']) {
    const query = new URL(DNS_OVER_HTTPS_ENDPOINT);
    query.searchParams.set('name', hostname);
    query.searchParams.set('type', type);
    const response = await fetchImpl(query, {
      method: 'GET',
      redirect: 'manual',
      signal,
      headers: { accept: 'application/dns-json' },
    });
    if (!response.ok || response.status >= 300) throw new Error(`Resolução DNS falhou (HTTP ${response.status}).`);
    const result = await response.json();
    if (result.Status !== 0 || result.Truncated) throw new Error('Hostname RSS não resolvido.');
    for (const answer of result.Answer || []) {
      if ((type === 'A' && answer.type === 1) || (type === 'AAAA' && answer.type === 28)) {
        addresses.push({ address: String(answer.data || '') });
      }
    }
  }
  return addresses;
}

async function validateFeedUrl(rawUrl, { fetchImpl, signal, resolveHostname }) {
  let url;
  try {
    url = new URL(rawUrl);
  } catch {
    throw new Error('URL da fonte RSS inválida.');
  }
  if (url.protocol !== 'https:' || url.username || url.password) {
    throw new Error('A fonte RSS deve usar HTTPS e não pode conter credenciais.');
  }
  if (url.port && url.port !== '443') throw new Error('A fonte RSS deve usar a porta HTTPS padrão.');
  const hostname = hostnameOf(url);
  if (!hostname || hostname === 'localhost' || hostname.endsWith('.localhost') ||
      hostname.endsWith('.local') || hostname.endsWith('.internal') || hostname.endsWith('.lan') ||
      hostname.endsWith('.home.arpa') || hostname.endsWith('.test') || hostname.endsWith('.example') ||
      hostname.endsWith('.invalid') || hostname.endsWith('.onion') || isIpLiteral(hostname)) {
    throw new Error('Destino RSS local ou IP literal não permitido.');
  }
  const addresses = await resolveHostname(hostname, { fetchImpl, signal });
  if (!addresses.length || addresses.some(({ address }) => !isPublicAddress(address))) {
    throw new Error('Destino RSS privado ou não resolvido.');
  }
  return url;
}

async function readFeedBody(response) {
  if (response.body?.getReader) {
    const reader = response.body.getReader();
    const chunks = [];
    let size = 0;
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        size += value.byteLength;
        if (size > MAX_FEED_BYTES) {
          await reader.cancel();
          throw new Error('Feed acima do limite de 2 MB.');
        }
        chunks.push(value);
      }
    } finally {
      reader.releaseLock();
    }
    const bytes = new Uint8Array(size);
    let offset = 0;
    for (const chunk of chunks) {
      bytes.set(chunk, offset);
      offset += chunk.byteLength;
    }
    return new TextDecoder().decode(bytes);
  }
  const text = await response.text();
  if (new TextEncoder().encode(text).byteLength > MAX_FEED_BYTES) throw new Error('Feed acima do limite de 2 MB.');
  return text;
}

export async function synchronizeNewsFeeds({
  database,
  fetchImpl = fetch,
  resolveHostname = resolveDnsAddresses,
  timeoutMs = 10000,
}) {
  const sources = await database.queryRows(`SELECT id,nome,url_rss,categoria,ativo,ambito,pais,prioridade
    FROM noticias_fontes WHERE ativo=1 AND url_rss IS NOT NULL ORDER BY prioridade DESC LIMIT 100`);
  const result = { fontes_processadas: 0, inseridas: 0, ignoradas: 0, erros: [] };

  for (const source of sources) {
    result.fontes_processadas += 1;
    let inserted = 0;
    let ignored = 0;
    let errorMessage = null;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const url = await validateFeedUrl(source.url_rss, {
        fetchImpl,
        signal: controller.signal,
        resolveHostname,
      });
      const response = await fetchImpl(url, {
        signal: controller.signal,
        redirect: 'manual',
        headers: { accept: FEED_ACCEPT },
      });
      if (response.status >= 300 && response.status < 400) {
        const location = response.headers?.get?.('location');
        if (location) {
          const redirectUrl = new URL(location, url);
          await validateFeedUrl(redirectUrl.href, {
            fetchImpl,
            signal: controller.signal,
            resolveHostname,
          });
        }
        throw new Error('Redirecionamentos RSS não são permitidos.');
      }
      if (!response.ok) throw new Error(`Feed respondeu HTTP ${response.status}.`);
      const xml = await readFeedBody(response);
      for (const item of parseNewsFeed(xml, source)) {
        const outcome = await database.executeQuery(`INSERT OR IGNORE INTO noticias
          (id,titulo,resumo,conteudo,categoria,categoria_ia,pais,relevante,publicado_em,url_original,fonte_id)
          VALUES(?,?,?,?,?,?,?,?,?,?,?)`,
        [crypto.randomUUID(), item.titulo, item.resumo, item.conteudo, item.categoria, item.categoria_ia,
          item.pais, item.relevante, item.publicado_em, item.url_original, source.id]);
        if (Number(outcome?.meta?.changes ?? outcome?.changes ?? 0) > 0) inserted += 1;
        else ignored += 1;
      }
    } catch (cause) {
      errorMessage = String(cause?.message || cause).slice(0, 500);
      result.erros.push(`${String(source.nome || 'Fonte RSS').slice(0, 100)}: ${errorMessage}`);
    } finally {
      clearTimeout(timeout);
    }

    result.inseridas += inserted;
    result.ignoradas += ignored;
    await database.executeQuery(`INSERT INTO noticias_sync_logs
      (id,fonte_id,sucesso,itens_inseridos,itens_ignorados,mensagem_erro,executado_em)
      VALUES(?,?,?,?,?,?,?)`,
    [crypto.randomUUID(), source.id, errorMessage ? 0 : 1, inserted, ignored, errorMessage, new Date().toISOString()]);
  }
  return result;
}

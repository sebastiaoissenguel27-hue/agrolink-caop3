import { createStorageProvider } from '../server/storageProviderFactory.mjs';

const COLUMN_ALLOWLIST = {
  profiles: ['nome', 'papel', 'tipo_perfil', 'nivel_admin', 'provincia', 'municipio', 'comuna', 'telefone', 'status', 'verification_status', 'suspenso_em', 'suspenso_por', 'motivo_suspensao', 'visibilidade'],
  relatos: ['id', 'autor_id', 'tipo', 'descricao', 'provincia', 'municipio', 'comuna', 'status', 'tecnico_atribuido_id', 'criado_em'],
  relato_midias: ['id', 'relato_id', 'tipo', 'caminho_storage', 'criado_em'],
  relato_respostas: ['id', 'relato_id', 'tecnico_id', 'comentario', 'criado_em'],
  noticias: ['id', 'titulo', 'resumo', 'conteudo', 'imagem_url', 'autor_id', 'categoria', 'categoria_ia', 'pais', 'relevante', 'publicado_em', 'url_original', 'fonte_id'],
  alertas: ['id', 'titulo', 'descricao', 'tipo', 'provincias_alvo', 'nivel', 'criado_por', 'criado_em', 'expira_em'],
  ia_conversas: ['id', 'utilizador_id', 'criado_em'],
  ia_mensagens: ['id', 'conversa_id', 'role', 'conteudo', 'criado_em'],
  denuncias: ['id', 'autor_id', 'denunciado_id', 'transporte_id', 'categoria', 'descricao', 'evidencias', 'estado', 'prioridade', 'admin_responsavel_id', 'decisao', 'sugestao_ia', 'data_resolucao', 'criado_em'],
  denuncia_historico: ['id', 'denuncia_id', 'campo_alterado', 'valor_anterior', 'valor_novo', 'alterado_por', 'alterado_em'],
  notificacoes: ['id', 'destinatario_id', 'titulo', 'corpo', 'tipo', 'lida', 'relacionado_tipo', 'relacionado_id', 'criado_em'],
  preferencias_utilizador: ['utilizador_id', 'notif_respostas_relato', 'notif_noticias', 'notif_alertas', 'notif_novos_cursos', 'notif_progresso_academia', 'notif_calendario_agricola', 'idioma', 'atualizado_em'],
  ferramenta_calculos: ['id', 'utilizador_id', 'ferramenta', 'entradas', 'resultado', 'criado_em'],
  recursos_externos: ['id', 'titulo', 'descricao', 'categoria', 'url', 'contacto', 'criado_em'],
  perguntas_frequentes: ['id', 'pergunta', 'resposta', 'categoria', 'ordem', 'criado_em'],
  biblioteca_documentos: ['id', 'titulo', 'descricao', 'categoria', 'tipo', 'caminho_storage', 'url_externo', 'autor_id', 'publicado_em'],
  academia_cursos: ['id', 'titulo', 'descricao', 'categoria', 'autor_id', 'publicado_em'],
  academia_licoes: ['id', 'curso_id', 'titulo', 'tipo', 'conteudo_texto', 'caminho_storage', 'ordem', 'criado_em'],
  academia_questionarios: ['id', 'licao_id', 'pergunta', 'opcoes', 'resposta_correta', 'ordem'],
  academia_progresso: ['utilizador_id', 'licao_id', 'concluida', 'pontuacao_questionario', 'atualizado_em'],
  noticias_fontes: ['id', 'nome', 'url_rss', 'categoria', 'ativo', 'ambito', 'pais', 'prioridade', 'criado_em'],
  noticias_sync_logs: ['id', 'fonte_id', 'sucesso', 'itens_inseridos', 'itens_ignorados', 'mensagem_erro', 'executado_em'],
  transportadores: ['utilizador_id', 'foto_url', 'foto_camiao_url', 'matricula', 'tipo_veiculo', 'capacidade_kg', 'documentos', 'estado_verificacao', 'motivo_estado', 'criado_em', 'atualizado_em'],
  mercado_produtos: ['id', 'vendedor_id', 'nome', 'categoria', 'preco', 'unidade', 'quantidade_disponivel', 'provincia', 'ativo', 'criado_em'],
  logistica_transportadoras: ['id', 'nome', 'provincia', 'contacto', 'capacidade_kg', 'ativo', 'utilizador_id', 'criado_em'],
  logistica_pedidos: ['id', 'solicitante_id', 'transportadora_id', 'origem_provincia', 'destino_provincia', 'produto_descricao', 'quantidade_kg', 'status', 'criado_em'],
  dispositivos_push: ['id', 'utilizador_id', 'token', 'plataforma', 'criado_em'],
  tecnico_documentos: ['id', 'tecnico_id', 'caminho_storage', 'descricao', 'criado_em'],
  reputacao: ['utilizador_id', 'transportes_concluidos', 'media_avaliacao', 'total_avaliacoes', 'denuncias_confirmadas', 'atualizado_em'],
  avaliacoes: ['id', 'avaliador_id', 'avaliado_id', 'transporte_id', 'nota', 'comentario', 'criado_em'],
  sensores: ['id', 'exploracao_nome', 'tipo', 'provincia', 'instalado_por', 'criado_em'],
  leituras_sensor: ['id', 'sensor_id', 'valor', 'unidade', 'medido_em'],
  sie_indicadores: ['id', 'tipo_indicador', 'provincia', 'periodo', 'valor', 'calculado_em'],
};

const PRIMARY_KEY = {
  academia_progresso: ['utilizador_id', 'licao_id'],
  preferencias_utilizador: ['utilizador_id'],
  reputacao: ['utilizador_id'],
  transportadores: ['utilizador_id'],
};

const PUBLIC_READ = new Set([
  'noticias', 'alertas', 'recursos_externos', 'perguntas_frequentes', 'biblioteca_documentos',
  'academia_cursos', 'academia_licoes', 'noticias_fontes', 'mercado_produtos', 'logistica_transportadoras',
]);
const ADMIN_ONLY = new Set(['sie_indicadores', 'sensores', 'leituras_sensor', 'noticias_sync_logs']);
const USER_OWNED = new Set([
  'relatos', 'relato_midias', 'relato_respostas', 'ia_conversas', 'ia_mensagens', 'ferramenta_calculos',
  'preferencias_utilizador', 'academia_progresso', 'notificacoes', 'dispositivos_push', 'tecnico_documentos',
  'transportadores', 'denuncias', 'denuncia_historico', 'reputacao', 'avaliacoes', 'logistica_pedidos',
  'mercado_produtos', 'profiles',
]);
const ADMIN_WRITE = new Set([
  'noticias', 'alertas', 'recursos_externos', 'perguntas_frequentes', 'biblioteca_documentos',
  'academia_cursos', 'academia_licoes', 'academia_questionarios', 'noticias_fontes',
  'logistica_transportadoras', 'mercado_produtos', 'transportadores', 'denuncias',
]);
const USER_WRITE = new Set([
  'relatos', 'relato_midias', 'relato_respostas', 'ferramenta_calculos', 'preferencias_utilizador',
  'dispositivos_push', 'denuncias', 'transportadores', 'mercado_produtos', 'logistica_pedidos',
]);
const JSON_COLUMNS = new Set(['provincias_alvo', 'entradas', 'resultado', 'opcoes', 'documentos', 'evidencias', 'sugestao_ia']);
const BOOLEAN_COLUMNS = new Set([
  'ativo', 'relevante', 'lida', 'concluida', 'notificacao', 'sucesso', 'notif_respostas_relato',
  'notif_noticias', 'notif_alertas', 'notif_novos_cursos', 'notif_progresso_academia', 'notif_calendario_agricola',
]);
const FILTER_COLUMNS = [
  'id', 'status', 'tipo', 'categoria', 'categoria_ia', 'provincia', 'papel', 'verification_status',
  'curso_id', 'licao_id', 'relato_id', 'destinatario_id', 'utilizador_id', 'tecnico_id',
  'autor_id', 'fonte_id', 'ativo', 'nivel',
];
const MEDIA_TYPES = {
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp',
  '.gif': 'image/gif', '.pdf': 'application/pdf', '.webm': 'audio/webm', '.mp4': 'video/mp4', '.ogg': 'audio/ogg',
};
const MAX_UPLOAD_BYTES = 18 * 1024 * 1024;
const MAX_UPLOAD_BODY_BYTES = 25 * 1024 * 1024;

function json(body, status = 200, headers = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8', ...headers },
  });
}

function error(status, message) {
  return json({ error: message }, status);
}

function uuid() {
  return crypto.randomUUID();
}

function parseJsonColumn(value, fallback = null) {
  if (typeof value !== 'string') return value ?? fallback;
  try { return JSON.parse(value); } catch { return fallback; }
}

function hydrate(row) {
  if (!row) return row;
  const hydrated = { ...row };
  for (const column of JSON_COLUMNS) {
    if (column in hydrated) hydrated[column] = parseJsonColumn(hydrated[column], ['provincias_alvo', 'documentos', 'evidencias'].includes(column) ? [] : null);
  }
  for (const column of BOOLEAN_COLUMNS) {
    if (column in hydrated) hydrated[column] = Boolean(hydrated[column]);
  }
  return hydrated;
}

function normalize(table, body) {
  const allowed = COLUMN_ALLOWLIST[table];
  const normalized = {};
  for (const [key, value] of Object.entries(body || {})) {
    if (!allowed.includes(key)) continue;
    if (JSON_COLUMNS.has(key)) normalized[key] = value === undefined ? null : JSON.stringify(value);
    else if (typeof value === 'boolean') normalized[key] = value ? 1 : 0;
    else normalized[key] = value;
  }
  return normalized;
}

async function readBody(request) {
  try {
    return await request.json();
  } catch {
    return null;
  }
}

async function readLimitedBody(request, maxBytes) {
  if (!request.body) return new Uint8Array();
  const reader = request.body.getReader();
  const chunks = [];
  let size = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    size += value.byteLength;
    if (size > maxBytes) {
      await reader.cancel();
      return null;
    }
    chunks.push(value);
  }
  const bytes = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return bytes;
}

function isAdmin(user) {
  return ['admin', 'admin_chefe'].includes(user?.papel);
}

function canRead(user, table) {
  if (PUBLIC_READ.has(table)) return true;
  if (!user) return false;
  if (ADMIN_ONLY.has(table) || table === 'academia_questionarios') return isAdmin(user);
  return USER_OWNED.has(table);
}

function primaryKey(table) {
  return PRIMARY_KEY[table] || ['id'];
}

function scopedWhere(user, table, isTechnician, isCarrier) {
  const where = [];
  const values = [];
  if (table === 'mercado_produtos') {
    where.push(user ? '(ativo=1 OR vendedor_id=?)' : 'ativo=1');
    if (user) values.push(user.utilizador_id);
    return { where, values };
  }
  if (!user) return { where, values };
  if (isAdmin(user)) return { where, values };
  if (table === 'logistica_pedidos') {
    const farmer = user.papel === 'utilizador' && user.tipo_perfil === 'agricultor';
    const carrierScope = "(transportadora_id IN (SELECT id FROM logistica_transportadoras WHERE utilizador_id=?) OR (status='pedido' AND transportadora_id IS NULL AND EXISTS (SELECT 1 FROM transportadores WHERE utilizador_id=? AND estado_verificacao='aprovado')))";
    if (farmer && isCarrier) {
      where.push(`(solicitante_id=? OR ${carrierScope})`);
      values.push(user.utilizador_id, user.utilizador_id, user.utilizador_id);
    } else if (farmer) {
      where.push('solicitante_id=?');
      values.push(user.utilizador_id);
    } else if (isCarrier) {
      where.push(carrierScope);
      values.push(user.utilizador_id, user.utilizador_id);
    } else {
      where.push('1=0');
    }
    return { where, values };
  }
  if (table === 'profiles') {
    where.push('id=?');
    values.push(user.utilizador_id);
  } else if (table === 'relatos') {
    if (!isTechnician) {
      where.push('autor_id=?');
      values.push(user.utilizador_id);
    }
  } else if (['notificacoes', 'preferencias_utilizador', 'ferramenta_calculos', 'ia_conversas', 'academia_progresso', 'dispositivos_push', 'tecnico_documentos', 'transportadores', 'reputacao'].includes(table)) {
    const column = table === 'tecnico_documentos' ? 'tecnico_id' : table === 'notificacoes' ? 'destinatario_id' : 'utilizador_id';
    where.push(`${column}=?`);
    values.push(user.utilizador_id);
  } else if (table === 'ia_mensagens') {
    where.push('conversa_id IN (SELECT id FROM ia_conversas WHERE utilizador_id=?)');
    values.push(user.utilizador_id);
  } else if (table === 'relato_midias' || table === 'relato_respostas') {
    if (!isTechnician) {
      where.push('relato_id IN (SELECT id FROM relatos WHERE autor_id=?)');
      values.push(user.utilizador_id);
    }
  } else if (table === 'denuncias') {
    where.push('autor_id=?');
    values.push(user.utilizador_id);
  }
  return { where, values };
}

function requestedLimit(url) {
  const value = Number(url.searchParams.get('limit') || 100);
  return Number.isFinite(value) && value > 0 ? Math.min(Math.floor(value), 500) : 100;
}

async function readRows(database, table, user, url, { isTechnician, isCarrier }) {
  const columns = COLUMN_ALLOWLIST[table];
  const { where, values } = scopedWhere(user, table, isTechnician, isCarrier);
  for (const key of FILTER_COLUMNS) {
    const value = url.searchParams.get(key);
    if (value === null || !columns.includes(key)) continue;
    if (table === 'noticias' && key === 'categoria') {
      where.push('(categoria=? OR categoria_ia=?)');
      values.push(value, value);
    } else {
      where.push(`${key}=?`);
      values.push(value === 'true' ? 1 : value === 'false' ? 0 : value);
    }
  }
  const search = url.searchParams.get('pesquisa');
  if (search && table === 'noticias') {
    where.push("(lower(titulo) LIKE ? OR lower(coalesce(resumo,'')) LIKE ?)");
    const pattern = `%${search.toLowerCase()}%`;
    values.push(pattern, pattern);
  }
  const defaultOrder = ['noticias', 'relatos', 'notificacoes'].includes(table) ? 'criado_em' : null;
  const requestedOrder = url.searchParams.get('order') || defaultOrder;
  const order = requestedOrder && columns.includes(requestedOrder)
    ? ` ORDER BY ${requestedOrder} ${url.searchParams.get('asc') === '1' ? 'ASC' : 'DESC'}`
    : '';
  const sql = `SELECT ${columns.join(',')} FROM ${table}${where.length ? ` WHERE ${where.join(' AND ')}` : ''}${order} LIMIT ?`;
  return (await database.queryRows(sql, [...values, requestedLimit(url)])).map(hydrate);
}

async function currentCarrierProfile(database, userId) {
  return database.queryRow('SELECT * FROM transportadores WHERE utilizador_id=?', [userId]);
}

async function syncCarrierDirectory(database, userId, capacity, approved, creating) {
  const profile = await database.getProfile(userId);
  if (!profile) return false;
  const directory = await database.queryRow('SELECT id FROM logistica_transportadoras WHERE utilizador_id=?', [userId]);
  if (directory) {
    await database.executeQuery(`UPDATE logistica_transportadoras
      SET nome=?,provincia=?,contacto=?,capacidade_kg=coalesce(?,capacidade_kg),ativo=? WHERE utilizador_id=?`,
    [profile.nome, profile.provincia, profile.telefone, capacity, approved ? 1 : 0, userId]);
  } else if (creating) {
    await database.executeQuery(`INSERT INTO logistica_transportadoras(id,nome,provincia,contacto,capacidade_kg,ativo,utilizador_id,criado_em)
      VALUES(?,?,?,?,?,?,?,?)`,
    [uuid(), profile.nome, profile.provincia, profile.telefone, capacity, approved ? 1 : 0, userId, new Date().toISOString()]);
  }
  return true;
}

async function insertRow(database, table, values) {
  const columns = Object.keys(values);
  if (!columns.length) return null;
  const placeholders = columns.map(() => '?').join(',');
  await database.executeQuery(`INSERT INTO ${table} (${columns.join(',')}) VALUES (${placeholders})`, columns.map((key) => values[key]));
  const keys = primaryKey(table);
  const keyValues = keys.map((key) => values[key]);
  if (keyValues.some((value) => value === undefined)) return values;
  return database.queryRow(`SELECT * FROM ${table} WHERE ${keys.map((key) => `${key}=?`).join(' AND ')}`, keyValues);
}

async function createTransporter(database, user, body, admin, timestamp) {
  const values = normalize('transportadores', body);
  values.utilizador_id = admin && values.utilizador_id ? values.utilizador_id : user.utilizador_id;
  if (!admin) {
    values.estado_verificacao = 'pendente';
    delete values.motivo_estado;
  } else if (values.estado_verificacao && !['pendente', 'aprovado', 'rejeitado'].includes(values.estado_verificacao)) {
    return error(400, 'Estado de verificação inválido.');
  }
  if (!values.utilizador_id) return error(400, 'Utilizador obrigatório.');
  if (values.capacidade_kg !== undefined && (!Number.isFinite(Number(values.capacidade_kg)) || Number(values.capacidade_kg) <= 0)) {
    return error(400, 'Capacidade do veículo inválida.');
  }
  if (!admin && (!String(values.matricula || '').trim() || !String(values.tipo_veiculo || '').trim() ||
      !Number.isFinite(Number(values.capacidade_kg)))) {
    return error(400, 'Matrícula, tipo de veículo e capacidade são obrigatórios.');
  }
  if (!await database.getProfile(values.utilizador_id)) return error(404, 'Utilizador não encontrado.');
  const existing = await currentCarrierProfile(database, values.utilizador_id);
  const keys = Object.keys(values).filter((key) => !['utilizador_id', 'criado_em', 'atualizado_em'].includes(key));
  if (existing) {
    if (keys.length) {
      await database.executeQuery(`UPDATE transportadores SET ${keys.map((key) => `${key}=?`).join(',')}, atualizado_em=? WHERE utilizador_id=?`,
        [...keys.map((key) => values[key]), timestamp, values.utilizador_id]);
    }
    if (!await syncCarrierDirectory(database, values.utilizador_id, values.capacidade_kg ?? null, values.estado_verificacao === 'aprovado', false)) {
      return error(404, 'Utilizador não encontrado.');
    }
    return json(hydrate(await currentCarrierProfile(database, values.utilizador_id)));
  }
  values.criado_em ||= timestamp;
  values.atualizado_em ||= timestamp;
  const inserted = await insertRow(database, 'transportadores', values);
  if (!await syncCarrierDirectory(database, values.utilizador_id, values.capacidade_kg ?? null, values.estado_verificacao === 'aprovado', true)) {
    return error(404, 'Utilizador não encontrado.');
  }
  return json(hydrate(inserted), 201);
}

async function handleUpload(request, url, env, database, user, services) {
  const area = url.pathname.slice('/api/media/upload/'.length);
  const failure = services.authError(user);
  if (failure) return failure;
  if (!['relatos', 'biblioteca', 'academia'].includes(area)) return error(400, 'Área de upload inválida.');
  if (area === 'relatos') return error(400, 'Área de upload inválida.');
  if (!services.canWriteAdmin(user)) return error(403, 'Só administradores podem carregar ficheiros para esta área.');
  const raw = await readLimitedBody(request, MAX_UPLOAD_BODY_BYTES);
  if (!raw) return error(413, 'Pedido demasiado grande.');
  let body;
  try { body = JSON.parse(new TextDecoder().decode(raw)); } catch { return error(400, 'JSON inválido.'); }
  if (!body.data || !body.filename) return error(400, 'Ficheiro inválido.');
  const source = String(body.data);
  const dataUrl = source.match(/^data:([^;,]+);base64,(.*)$/is);
  const encoded = dataUrl ? dataUrl[2] : source;
  if (encoded.length > 24 * 1024 * 1024 ||
      !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(encoded)) {
    return error(400, 'Conteúdo Base64 inválido.');
  }
  let binary;
  try { binary = atob(encoded); } catch { return error(400, 'Conteúdo Base64 inválido.'); }
  if (!binary.length || binary.length > MAX_UPLOAD_BYTES) return error(413, 'Ficheiro vazio ou acima do limite de 18 MiB.');
  const bytes = Uint8Array.from(binary, (character) => character.charCodeAt(0));
  if (btoa(binary) !== encoded) return error(400, 'Conteúdo Base64 inválido.');
  if (body.uploadId) return error(400, 'Identificador de upload inválido.');
  const filename = String(body.filename).replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 140);
  const storagePath = `${area}/${uuid()}-${filename}`;
  const extension = storagePath.match(/\.[^.]+$/)?.[0].toLowerCase() || '';
  const contentType = MEDIA_TYPES[extension] || 'application/octet-stream';
  await createStorageProvider({ env, provider: env.STORAGE_PROVIDER || 'r2' }).put(storagePath, bytes, {
    httpMetadata: { contentType },
    customMetadata: { ownerId: user.utilizador_id },
  });
  return json({ caminho: storagePath }, 201);
}

async function handleMedia(request, url, env, database, user) {
  if (!url.pathname.startsWith('/api/media/')) return null;
  if (!user) return error(401, 'Sessão necessária.');
  let storagePath;
  try {
    storagePath = url.pathname.slice('/api/media/'.length).split('/').map(decodeURIComponent).join('/');
  } catch {
    return error(404, 'Ficheiro não encontrado.');
  }
  const [area] = storagePath.split('/');
  if (area !== 'biblioteca' && area !== 'academia') return null;
  if (storagePath.includes('\\') || storagePath.split('/').some((part) => !part || part === '.' || part === '..')) {
    return error(404, 'Ficheiro não encontrado.');
  }
  const reference = area === 'biblioteca'
    ? await database.queryRow('SELECT 1 AS found FROM biblioteca_documentos WHERE caminho_storage=?', [storagePath])
    : await database.queryRow('SELECT 1 AS found FROM academia_licoes WHERE caminho_storage=?', [storagePath]);
  if (!reference) return error(404, 'Ficheiro não encontrado.');
  const object = await createStorageProvider({ env, provider: env.STORAGE_PROVIDER || 'r2' }).get(storagePath);
  if (!object) return error(404, 'Ficheiro não encontrado.');
  const extension = storagePath.match(/\.[^.]+$/)?.[0].toLowerCase() || '';
  return new Response(object.body, {
    status: 200,
    headers: {
      'content-type': object.httpMetadata?.contentType || MEDIA_TYPES[extension] || 'application/octet-stream',
      'cache-control': 'private, max-age=600',
    },
  });
}

async function updateLogisticsOrder(database, user, id, body, timestamp, services) {
  const admin = services.canWriteAdmin(user);
  const carrier = await currentCarrierProfile(database, user.utilizador_id);
  if (body.status && carrier?.estado_verificacao !== 'aprovado') return error(403, 'O perfil de transportador ainda não foi aprovado.');
  if (user.papel === 'utilizador' && user.tipo_perfil === 'agricultor' && (!body.status || body.status === 'cancelado')) {
    if (body.status && body.status !== 'cancelado') return error(403, 'Agricultores só podem cancelar os próprios pedidos.');
    const changed = await database.executeQuery(`UPDATE logistica_pedidos SET status='cancelado'
      WHERE id=? AND solicitante_id=? AND status='pedido' AND transportadora_id IS NULL`, [id, user.utilizador_id]);
    if (!changed.meta?.changes) return error(409, 'Pedido não encontrado ou já aceite.');
  } else if (services.isTransporter(user, carrier)) {
    const provider = await database.queryRow(`SELECT lt.id FROM logistica_transportadoras lt
      JOIN transportadores t ON t.utilizador_id=lt.utilizador_id
      WHERE lt.utilizador_id=? AND lt.ativo=1 AND t.estado_verificacao='aprovado'`, [user.utilizador_id]);
    if (!provider) return error(403, 'Registe o perfil de transportador antes de aceitar pedidos.');
    const nextStatus = String(body.status || 'aceite');
    const transitions = { aceite: ['pedido'], em_transito: ['aceite'], entregue: ['em_transito'] };
    if (!transitions[nextStatus]) return error(400, 'Estado de transporte inválido.');
    const changed = await database.executeQuery(`UPDATE logistica_pedidos SET status=?,transportadora_id=?
      WHERE id=? AND (transportadora_id=? OR (transportadora_id IS NULL AND status='pedido')) AND status IN (?)`,
    [nextStatus, provider.id, id, provider.id, transitions[nextStatus][0]]);
    if (!changed.meta?.changes) return error(409, 'Pedido já foi aceite ou não permite esta transição.');
  } else if (!admin) {
    return error(403, 'Sem permissão.');
  } else {
    const values = normalize('logistica_pedidos', body);
    delete values.id;
    if (Object.keys(values).length) {
      await database.executeQuery(`UPDATE logistica_pedidos SET ${Object.keys(values).map((key) => `${key}=?`).join(',')} WHERE id=?`,
        [...Object.values(values), id]);
    }
  }
  const updated = await database.queryRow('SELECT * FROM logistica_pedidos WHERE id=?', [id]);
  return updated ? json(hydrate(updated)) : error(404, 'Pedido não encontrado.');
}

export async function handleBusinessRequest(request, url, env, database, services) {
  const { pathname } = url;
  const method = request.method;
  const timestamp = new Date().toISOString();

  if (pathname === '/api/public/team' && method === 'GET') {
    const team = await database.queryRows(`SELECT p.id,p.nome,p.papel,p.provincia FROM profiles p
      JOIN users u ON u.id=p.id WHERE lower(trim(u.email))=? AND p.papel='admin_chefe'
      AND p.status='ativo' AND p.visibilidade='publico'`, ['sebastiaoissenguel27@gmail.com']);
    return json(team.map((member) => ({ ...member, identidade: 'equipa_oficial' })));
  }

  if (pathname === '/api/admin/stats' && method === 'GET') {
    const user = await services.currentUser(request, database);
    const failure = services.authError(user);
    if (failure) return failure;
    if (!isAdmin(user)) return error(403, 'Apenas administradores.');
    const counts = await database.queryRow(`SELECT
      (SELECT COUNT(*) FROM relatos) AS total_relatos,
      (SELECT COUNT(*) FROM relatos WHERE status='pendente') AS relatos_pendentes,
      (SELECT COUNT(*) FROM relatos WHERE status='em_analise') AS relatos_em_analise,
      (SELECT COUNT(*) FROM relatos WHERE status='resolvido') AS relatos_resolvidos,
      (SELECT COUNT(*) FROM profiles WHERE papel='utilizador' AND tipo_perfil='agricultor') AS total_agricultores,
      (SELECT COUNT(*) FROM profiles WHERE papel='utilizador' AND tipo_perfil='tecnico') AS total_tecnicos,
      (SELECT COUNT(*) FROM profiles WHERE papel='utilizador' AND tipo_perfil='tecnico' AND verification_status='aprovado') AS tecnicos_aprovados,
      (SELECT COUNT(*) FROM profiles WHERE status='pendente') AS contas_pendentes`);
    return json(Object.fromEntries(Object.entries(counts).map(([key, value]) => [key, Number(value)])));
  }

  if (pathname === '/api/admin/users' && method === 'GET') {
    const user = await services.currentUser(request, database);
    const failure = services.authError(user);
    if (failure) return failure;
    if (!isAdmin(user)) return error(403, 'Apenas administradores.');
    const where = [];
    const values = [];
    for (const key of ['papel', 'status']) {
      const value = url.searchParams.get(key);
      if (value === null) continue;
      where.push(`${key}=?`);
      values.push(value);
    }
    const profiles = await database.queryRows(`SELECT * FROM profiles${where.length ? ` WHERE ${where.join(' AND ')}` : ''} ORDER BY criado_em DESC`, values);
    return json(profiles.map(hydrate));
  }

  if (pathname === '/api/admin/users/promote' && method === 'POST') {
    const user = await services.currentUser(request, database);
    const failure = services.authError(user);
    if (failure) return failure;
    if (!services.isChief(user)) return error(403, 'Apenas o administrador-chefe pode promover funções.');
    const body = await readBody(request);
    if (!body || typeof body !== 'object' || Array.isArray(body)) return error(400, 'JSON inválido.');
    if (body.papel !== 'auditor') return error(400, 'A aprovação de administradores deve usar o fluxo próprio.');
    const id = String(body.id || '').trim();
    if (!id) return error(400, 'ID obrigatório.');
    const target = await database.queryRow('SELECT id,papel,status FROM profiles WHERE id=?', [id]);
    if (!target) return error(404, 'Utilizador não encontrado.');
    if (target.papel === 'admin_chefe') return error(403, 'A conta de administrador-chefe está protegida.');
    await database.executeQuery(`UPDATE profiles SET papel='admin',tipo_perfil='administrador',nivel_admin='auditor',status='ativo' WHERE id=?`, [id]);
    return json({ ok: true });
  }

  if (pathname === '/api/admin/broadcast' && method === 'POST') {
    const user = await services.currentUser(request, database);
    const failure = services.authError(user);
    if (failure) return failure;
    if (!services.canWriteAdmin(user)) return error(403, 'Apenas administradores podem notificar.');
    const body = await readBody(request);
    if (!body || typeof body !== 'object' || Array.isArray(body)) return error(400, 'JSON inválido.');
    const values = [];
    let sql = "SELECT id FROM profiles WHERE status='ativo'";
    if (body.papel) {
      sql += ' AND papel=?';
      values.push(body.papel);
    }
    const recipients = await database.queryRows(sql, values);
    if (recipients.length) {
      await database.executeBatch(recipients.map(({ id }) => ({
        sql: `INSERT INTO notificacoes(id,destinatario_id,titulo,corpo,tipo,criado_em) VALUES(?,?,?,?,?,?)`,
        values: [uuid(), id, body.titulo, body.corpo || null, 'mensagem_admin', timestamp],
      })));
    }
    return json({ destinatarios: recipients.length });
  }

  if (pathname.startsWith('/api/media/upload/') && method === 'POST') {
    return handleUpload(request, url, env, database, await services.currentUser(request, database), services);
  }

  if (pathname.startsWith('/api/media/') && method === 'GET') {
    return handleMedia(request, url, env, database, await services.currentUser(request, database));
  }

  if (pathname.startsWith('/api/academia/quiz/') && method === 'GET') {
    const user = await services.currentUser(request, database);
    const failure = services.authError(user);
    if (failure) return failure;
    const lessonId = pathname.slice('/api/academia/quiz/'.length);
    const questions = await database.queryRows(`SELECT id,licao_id,pergunta,opcoes,ordem
      FROM academia_questionarios WHERE licao_id=? ORDER BY ordem ASC`, [lessonId]);
    return json(questions.map(hydrate));
  }

  if (pathname === '/api/academia/quiz/answer' && method === 'POST') {
    const user = await services.currentUser(request, database);
    const failure = services.authError(user);
    if (failure) return failure;
    const body = await readBody(request);
    if (!body || typeof body !== 'object' || Array.isArray(body)) return error(400, 'JSON inválido.');
    const question = await database.queryRow('SELECT resposta_correta,licao_id FROM academia_questionarios WHERE id=?', [body.questionarioId]);
    if (!question) return error(404, 'Pergunta não encontrada.');
    const correct = Number(question.resposta_correta) === Number(body.resposta);
    await database.executeQuery(`INSERT INTO academia_progresso(utilizador_id,licao_id,concluida,pontuacao_questionario,atualizado_em)
      VALUES(?,?,1,?,?) ON CONFLICT(utilizador_id,licao_id) DO UPDATE SET
      concluida=1,pontuacao_questionario=excluded.pontuacao_questionario,atualizado_em=excluded.atualizado_em`,
    [user.utilizador_id, question.licao_id, correct ? 1 : 0, timestamp]);
    return json({ correto: correct });
  }

  if (pathname === '/api/academia/quiz' && method === 'POST') {
    const user = await services.currentUser(request, database);
    const failure = services.authError(user);
    if (failure) return failure;
    const body = await readBody(request);
    if (!body || typeof body !== 'object' || Array.isArray(body)) return error(400, 'JSON inválido.');
    const question = await database.queryRow('SELECT resposta_correta FROM academia_questionarios WHERE id=?', [body.questionarioId]);
    if (!question) return error(404, 'Pergunta não encontrada.');
    const correct = Number(question.resposta_correta) === Number(body.resposta);
    await database.executeQuery(`INSERT INTO academia_progresso(utilizador_id,licao_id,concluida,pontuacao_questionario,atualizado_em)
      VALUES(?,?,1,?,?) ON CONFLICT(utilizador_id,licao_id) DO UPDATE SET
      concluida=1,pontuacao_questionario=excluded.pontuacao_questionario,atualizado_em=excluded.atualizado_em`,
    [user.utilizador_id, body.licaoId, correct ? 1 : 0, timestamp]);
    return json({ correto: correct });
  }

  if (pathname === '/api/academia/concluir' && method === 'POST') {
    const user = await services.currentUser(request, database);
    const failure = services.authError(user);
    if (failure) return failure;
    const body = await readBody(request);
    if (!body || typeof body !== 'object' || Array.isArray(body)) return error(400, 'JSON inválido.');
    await database.executeQuery(`INSERT INTO academia_progresso(utilizador_id,licao_id,concluida,atualizado_em)
      VALUES(?,?,1,?) ON CONFLICT(utilizador_id,licao_id) DO UPDATE SET
      concluida=1,atualizado_em=excluded.atualizado_em`, [user.utilizador_id, body.licaoId, timestamp]);
    return json({ ok: true });
  }

  if (pathname === '/api/data/relatos' && method === 'DELETE') {
    const user = await services.currentUser(request, database);
    const failure = services.authError(user);
    if (failure) return failure;
    if (!services.canWriteAdmin(user)) return error(403, 'Apenas administradores podem eliminar conteúdo.');
    const id = url.searchParams.get('id');
    if (!id) return error(400, 'ID obrigatório.');
    const media = await database.queryRows('SELECT caminho_storage FROM relato_midias WHERE relato_id=?', [id]);
    const storage = createStorageProvider({ env, provider: env.STORAGE_PROVIDER || 'r2' });
    for (const item of media) await storage.delete(item.caminho_storage);
    await database.executeQuery('DELETE FROM relatos WHERE id=?', [id]);
    return json({ ok: true });
  }

  const dataMatch = pathname.match(/^\/api\/data\/([a-z_]+)$/);
  if (!dataMatch) return null;
  const table = dataMatch[1];
  const columns = COLUMN_ALLOWLIST[table];
  if (!columns) return error(404, 'Tabela não disponível.');

  const user = await services.currentUser(request, database);
  const isTechnician = services.isVerifiedTechnician(user);
  const carrier = user ? await currentCarrierProfile(database, user.utilizador_id) : null;
  const isCarrier = services.isTransporter(user, carrier);
  const anonymousReport = table === 'relatos' && method === 'POST' && !user;
  if (!canRead(user, table) && !anonymousReport) return error(403, 'Sem permissão.');
  if (['POST', 'PATCH', 'PUT', 'DELETE'].includes(method) && user?.status === 'pendente') {
    return error(403, 'A conta aguarda aprovação.');
  }

  if (method === 'GET') {
    if (table === 'logistica_pedidos' && !isAdmin(user) && !(user?.papel === 'utilizador' && user.tipo_perfil === 'agricultor') && !isCarrier) {
      return error(403, 'Sem permissão.');
    }
    if (table === 'academia_questionarios' && !isAdmin(user)) return error(403, 'Questionários devem ser corrigidos no servidor.');
    if (table === 'denuncia_historico') {
      if (!user) return error(403, 'Sem permissão.');
      return json(await database.listDenunciationHistory({
        userId: user.utilizador_id,
        isAdmin: isAdmin(user),
        denunciationId: url.searchParams.get('denuncia_id') || null,
        limit: requestedLimit(url),
      }));
    }
    return json(await readRows(database, table, user, url, { isTechnician, isCarrier }));
  }

  if (method === 'POST') {
    if (!services.canWriteAdmin(user) && !USER_WRITE.has(table)) return error(403, 'Apenas administradores podem modificar esta área.');
    if (table !== 'relatos' && !user) return error(401, 'Sessão necessária.');
    if (table === 'mercado_produtos' && !services.canWriteAdmin(user) &&
        !(user.papel === 'utilizador' && user.tipo_perfil === 'agricultor')) return error(403, 'Só agricultores podem publicar produtos.');
    if (table === 'logistica_pedidos' && !services.canWriteAdmin(user) &&
        !(user.papel === 'utilizador' && user.tipo_perfil === 'agricultor')) return error(403, 'Só agricultores podem solicitar transporte.');
    const body = await readBody(request);
    if (!body || typeof body !== 'object' || Array.isArray(body)) return error(400, 'JSON inválido.');
    if (table === 'transportadores') return createTransporter(database, user, body, services.canWriteAdmin(user), timestamp);

    const values = normalize(table, body);
    if (!values.id && columns.includes('id')) values.id = uuid();
    if (table === 'relatos') {
      values.autor_id = user?.utilizador_id || null;
      values.codigo_publico = `AL-${crypto.randomUUID().replaceAll('-', '').toUpperCase()}`;
      values.status = 'pendente';
    }
    if (table === 'preferencias_utilizador' || table === 'ferramenta_calculos' || table === 'dispositivos_push') {
      if (!services.canWriteAdmin(user)) values.utilizador_id = user.utilizador_id;
    }
    if (table === 'tecnico_documentos' && !services.canWriteAdmin(user)) values.tecnico_id = user.utilizador_id;
    if (table === 'academia_progresso' && !services.canWriteAdmin(user)) values.utilizador_id = user.utilizador_id;
    if (table === 'mercado_produtos') {
      values.vendedor_id = services.canWriteAdmin(user) && values.vendedor_id ? values.vendedor_id : user.utilizador_id;
      values.nome = String(values.nome || '').trim().slice(0, 160);
      values.categoria = String(values.categoria || '').trim().slice(0, 80);
      values.unidade = String(values.unidade || '').trim().slice(0, 40);
      values.provincia = String(values.provincia || user.provincia || '').trim().slice(0, 100);
      values.preco = Number(values.preco);
      values.quantidade_disponivel = Number(values.quantidade_disponivel);
      values.ativo = services.canWriteAdmin(user) ? (values.ativo ?? 1) : 1;
      if (!values.nome || !values.unidade || !Number.isFinite(values.preco) || values.preco < 0 ||
          !Number.isFinite(values.quantidade_disponivel) || values.quantidade_disponivel <= 0) {
        return error(400, 'Dados do produto inválidos.');
      }
    }
    if (table === 'logistica_pedidos') {
      values.solicitante_id = services.canWriteAdmin(user) && values.solicitante_id ? values.solicitante_id : user.utilizador_id;
      values.origem_provincia = String(values.origem_provincia || user.provincia || '').trim().slice(0, 100);
      values.destino_provincia = String(values.destino_provincia || '').trim().slice(0, 100);
      values.produto_descricao = String(values.produto_descricao || '').trim().slice(0, 500);
      values.quantidade_kg = Number(values.quantidade_kg);
      values.transportadora_id = services.canWriteAdmin(user) ? (values.transportadora_id || null) : null;
      values.status = 'pedido';
      if (!values.origem_provincia || !values.destino_provincia || !values.produto_descricao ||
          !Number.isFinite(values.quantidade_kg) || values.quantidade_kg <= 0) {
        return error(400, 'Dados do pedido de transporte inválidos.');
      }
    }
    if (table === 'denuncias' && !services.canWriteAdmin(user)) {
      const targetId = String(values.denunciado_id || '').trim();
      values.categoria = String(values.categoria || '').trim().slice(0, 80);
      values.descricao = String(values.descricao || '').trim().slice(0, 4000);
      if (!targetId || !values.categoria || values.descricao.length < 10) {
        return error(400, 'Indique a pessoa denunciada, a categoria e uma descrição com pelo menos 10 caracteres.');
      }
      if (targetId === user.utilizador_id) return error(400, 'Não pode denunciar a própria conta.');
      const target = await database.findDenunciationTarget(targetId);
      if (!target) return error(404, 'Utilizador denunciado não encontrado.');
      values.autor_id = user.utilizador_id;
      values.estado = 'pendente';
      values.prioridade = ['baixa', 'media', 'alta', 'urgente'].includes(values.prioridade) ? values.prioridade : 'media';
      values.evidencias = JSON.stringify(Array.isArray(body.evidencias) ? body.evidencias.slice(0, 5) : []);
      delete values.admin_responsavel_id;
      delete values.decisao;
      delete values.sugestao_ia;
      delete values.data_resolucao;
    }
    if (table === 'relato_respostas' && !services.canWriteAdmin(user)) {
      if (!isTechnician && !isAdmin(user)) return error(403, 'Só técnicos aprovados ou administradores podem responder a relatos.');
      if (!await database.findReportById(values.relato_id)) return error(404, 'Relato não encontrado.');
      values.tecnico_id = user.utilizador_id;
      values.comentario = String(values.comentario || '').trim().slice(0, 4000);
      if (!values.comentario) return error(400, 'A resposta técnica não pode estar vazia.');
    }
    const inserted = await insertRow(database, table, values);
    if (table === 'denuncias' && !services.canWriteAdmin(user)) {
      const target = await database.findDenunciationTarget(values.denunciado_id);
      const administrators = await database.queryRows("SELECT id FROM profiles WHERE papel IN ('admin','admin_chefe') AND status='ativo'");
      if (administrators.length) {
        await database.executeBatch(administrators.map(({ id }) => ({
          sql: `INSERT INTO notificacoes(id,destinatario_id,titulo,corpo,tipo,relacionado_tipo,relacionado_id,criado_em)
            VALUES(?,?,?,?,?,?,?,?)`,
          values: [uuid(), id, 'Nova denúncia recebida', `Uma denúncia contra ${target.nome} foi enviada para análise.`, 'denuncia', 'denuncia', values.id, timestamp],
        })));
      }
    }
    return json(hydrate(inserted), 201);
  }

  if (method === 'PATCH') {
    const keyColumns = primaryKey(table);
    const id = url.searchParams.get('id');
    const keyValues = keyColumns.map((key) => url.searchParams.get(key) || id);
    if (keyValues.some((value) => !value)) return error(400, 'ID obrigatório.');
    if (table === 'mercado_produtos' && !services.canWriteAdmin(user)) {
      if (!(user.papel === 'utilizador' && user.tipo_perfil === 'agricultor')) return error(403, 'Sem permissão.');
      const existing = await database.queryRow('SELECT vendedor_id FROM mercado_produtos WHERE id=?', [id]);
      if (!existing || existing.vendedor_id !== user.utilizador_id) return error(403, 'Só pode alterar os seus próprios produtos.');
      const body = await readBody(request);
      if (!body || typeof body !== 'object' || Array.isArray(body)) return error(400, 'JSON inválido.');
      const values = normalize(table, body);
      for (const key of ['id', 'vendedor_id', 'criado_em']) delete values[key];
      if (Object.hasOwn(values, 'preco') && (!Number.isFinite(Number(values.preco)) || Number(values.preco) < 0)) return error(400, 'Preço inválido.');
      if (Object.hasOwn(values, 'quantidade_disponivel') && (!Number.isFinite(Number(values.quantidade_disponivel)) || Number(values.quantidade_disponivel) <= 0)) return error(400, 'Quantidade inválida.');
      if (!Object.keys(values).length) return json({ ok: true });
      await database.executeQuery(`UPDATE mercado_produtos SET ${Object.keys(values).map((key) => `${key}=?`).join(',')} WHERE id=? AND vendedor_id=?`,
        [...Object.values(values), id, user.utilizador_id]);
      return json(hydrate(await database.queryRow('SELECT * FROM mercado_produtos WHERE id=?', [id])));
    }
    if (table === 'logistica_pedidos' && !services.canWriteAdmin(user)) {
      const body = await readBody(request);
      if (!body || typeof body !== 'object' || Array.isArray(body)) return error(400, 'JSON inválido.');
      return updateLogisticsOrder(database, user, id, body, timestamp, services);
    }
    if (table === 'profiles' && !services.isChief(user) && !services.canWriteAdmin(user)) return error(403, 'Sem permissão.');
    if (!services.canWriteAdmin(user) && table !== 'notificacoes') return error(403, 'Sem permissão.');
    if (table === 'notificacoes' && !isAdmin(user)) {
      const existing = await database.queryRow('SELECT destinatario_id FROM notificacoes WHERE id=?', [id]);
      if (!existing || existing.destinatario_id !== user.utilizador_id) return error(403, 'Sem permissão.');
    }
    const body = await readBody(request);
    if (!body || typeof body !== 'object' || Array.isArray(body)) return error(400, 'JSON inválido.');
    const values = normalize(table, body);
    delete values.id;
    if (table === 'notificacoes' && !isAdmin(user)) {
      for (const field of ['destinatario_id', 'titulo', 'corpo', 'tipo', 'relacionado_tipo', 'relacionado_id', 'criado_em']) delete values[field];
    }
    if (table === 'profiles') {
      const target = await database.queryRow('SELECT id,papel,tipo_perfil FROM profiles WHERE id=?', [id]);
      if (!target) return error(404, 'Utilizador não encontrado.');
      if (target.papel === 'admin_chefe' && !services.isChief(user)) return error(403, 'A conta de administrador-chefe está protegida.');
      if (Object.hasOwn(values, 'papel') || Object.hasOwn(values, 'nivel_admin')) return error(403, 'Use o fluxo administrativo autorizado para alterar permissões.');
      if (Object.hasOwn(values, 'tipo_perfil')) return error(403, 'O perfil profissional não pode ser alterado neste fluxo.');
      if (Object.hasOwn(values, 'status')) {
        if (!services.isChief(user)) return error(403, 'Apenas o administrador-chefe pode suspender ou reativar contas.');
        if (id === user.utilizador_id && values.status !== 'ativo') return error(403, 'O administrador-chefe não pode suspender a própria conta.');
      }
      if (Object.hasOwn(values, 'verification_status') && target.tipo_perfil !== 'tecnico') return error(400, 'A verificação só se aplica a técnicos.');
    }
    if (!Object.keys(values).length) return json({ ok: true });
    await database.executeQuery(`UPDATE ${table} SET ${Object.keys(values).map((key) => `${key}=?`).join(',')} WHERE ${keyColumns.map((key) => `${key}=?`).join(' AND ')}`,
      [...Object.values(values), ...keyValues]);
    const updated = await database.queryRow(`SELECT * FROM ${table} WHERE ${keyColumns.map((key) => `${key}=?`).join(' AND ')}`, keyValues);
    return json(hydrate(updated));
  }

  if (method === 'DELETE') {
    if (table === 'mercado_produtos' && !services.canWriteAdmin(user)) {
      if (!(user.papel === 'utilizador' && user.tipo_perfil === 'agricultor')) return error(403, 'Sem permissão.');
      const id = url.searchParams.get('id');
      if (!id) return error(400, 'ID obrigatório.');
      const result = await database.executeQuery('DELETE FROM mercado_produtos WHERE id=? AND vendedor_id=?', [id, user.utilizador_id]);
      if (!result.meta?.changes) return error(404, 'Produto não encontrado.');
      return json({ ok: true });
    }
    if (!services.canWriteAdmin(user)) return error(403, 'Apenas administradores podem eliminar conteúdo.');
    if (table === 'profiles') return error(403, 'Contas de utilizadores não podem ser eliminadas pelo painel.');
    const id = url.searchParams.get('id');
    const keyColumns = primaryKey(table);
    const keyValues = keyColumns.map((key) => url.searchParams.get(key) || id);
    if (keyValues.some((value) => !value)) return error(400, 'ID obrigatório.');
    await database.executeQuery(`DELETE FROM ${table} WHERE ${keyColumns.map((key) => `${key}=?`).join(' AND ')}`, keyValues);
    return json({ ok: true });
  }

  return null;
}

import { AwsClient } from 'aws4fetch';
import { StorageAdapter } from './storageContract.mjs';

const DEFAULT_BUCKET = 'agrolink-caop-media-2026';

function validateKey(key) {
  const normalized = String(key || '').replace(/\\/g, '/');
  if (!normalized || normalized.startsWith('/') || normalized.split('/').some((part) => !part || part === '.' || part === '..')) {
    throw new Error('Invalid storage key.');
  }
  return normalized;
}

function metadataFromHeaders(headers) {
  const customMetadata = {};
  for (const [name, value] of headers.entries()) {
    if (name.startsWith('x-amz-meta-')) {
      const key = name.slice('x-amz-meta-'.length);
      customMetadata[key === 'ownerid' ? 'ownerId' : key] = value;
    }
  }
  const contentType = headers.get('content-type');
  const size = Number(headers.get('content-length'));
  return {
    size: Number.isFinite(size) && size >= 0 ? size : 0,
    httpMetadata: contentType ? { contentType } : {},
    customMetadata,
  };
}

export class BackblazeB2StorageProvider extends StorageAdapter {
  constructor(env, { fetchImpl = fetch } = {}) {
    super();
    const endpointValue = String(env.B2_ENDPOINT || '').trim();
    const region = String(env.B2_REGION || '').trim();
    const bucket = String(env.B2_BUCKET || DEFAULT_BUCKET).trim();
    const accessKeyId = String(env.B2_ACCESS_KEY_ID || '').trim();
    const secretAccessKey = String(env.B2_SECRET_ACCESS_KEY || '').trim();

    if (!endpointValue || !region || !bucket || !accessKeyId || !secretAccessKey) {
      throw new Error('Backblaze B2 requires B2_ENDPOINT, B2_REGION, B2_BUCKET, B2_ACCESS_KEY_ID, and B2_SECRET_ACCESS_KEY.');
    }

    let endpoint;
    try {
      endpoint = new URL(endpointValue);
    } catch {
      throw new Error('B2_ENDPOINT must be a valid HTTPS URL.');
    }
    if (endpoint.protocol !== 'https:' || endpoint.username || endpoint.password || endpoint.search || endpoint.hash ||
        (endpoint.pathname !== '/' && endpoint.pathname !== '')) {
      throw new Error('B2_ENDPOINT must be a root HTTPS endpoint without credentials, query, or fragment.');
    }
    if (!/^[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]$/.test(bucket)) {
      throw new Error('B2_BUCKET is invalid.');
    }

    this.endpoint = endpoint.origin;
    this.region = region;
    this.bucket = bucket;
    this.fetchImpl = fetchImpl;
    this.signer = new AwsClient({
      accessKeyId,
      secretAccessKey,
      service: 's3',
      region,
      retries: 0,
    });
  }

  objectUrl(key) {
    const encodedKey = validateKey(key).split('/').map(encodeURIComponent).join('/');
    return `${this.endpoint}/${encodeURIComponent(this.bucket)}/${encodedKey}`;
  }

  async request(key, method, headers = {}, body) {
    const signedRequest = await this.signer.sign(this.objectUrl(key), { method, headers, body });
    const response = await this.fetchImpl(signedRequest);
    if (!response.ok) {
      throw new Error(`Backblaze B2 S3 request failed: ${method} returned HTTP ${response.status}.`);
    }
    return response;
  }

  async put(key, content, options = {}) {
    const headers = new Headers();
    const contentType = options.httpMetadata?.contentType;
    if (contentType) headers.set('content-type', String(contentType));
    for (const [name, value] of Object.entries(options.customMetadata || {})) {
      headers.set(`x-amz-meta-${name.toLowerCase()}`, String(value));
    }
    const bytes = content instanceof Uint8Array ? content : new Uint8Array(content);
    await this.request(key, 'PUT', headers, bytes);
    return validateKey(key);
  }

  async head(key) {
    const safeKey = validateKey(key);
    const response = await this.signedRequest(safeKey, 'HEAD');
    if (response.status === 404) return null;
    if (!response.ok) throw new Error(`Backblaze B2 S3 request failed: HEAD returned HTTP ${response.status}.`);
    return metadataFromHeaders(response.headers);
  }

  async get(key) {
    const safeKey = validateKey(key);
    const response = await this.signedRequest(safeKey, 'GET');
    if (response.status === 404) return null;
    if (!response.ok) throw new Error(`Backblaze B2 S3 request failed: GET returned HTTP ${response.status}.`);
    return { ...metadataFromHeaders(response.headers), body: response.body };
  }

  async delete(key) {
    await this.request(key, 'DELETE');
  }

  async signedRequest(key, method) {
    const signedRequest = await this.signer.sign(this.objectUrl(key), { method });
    return this.fetchImpl(signedRequest);
  }
}

export { DEFAULT_BUCKET as BACKBLAZE_B2_DEFAULT_BUCKET };

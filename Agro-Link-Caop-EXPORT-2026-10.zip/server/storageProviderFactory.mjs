import { R2StorageAdapter } from './r2StorageAdapter.mjs';
import { BackblazeB2StorageProvider } from './backblazeB2StorageProvider.mjs';

export function createStorageProvider({ env = {}, provider = env.STORAGE_PROVIDER || 'r2', bucket = env.BUCKET } = {}) {
  switch (String(provider).trim().toLowerCase()) {
    case 'r2':
      if (!bucket) throw new Error('The BUCKET binding is required for Cloudflare R2 storage.');
      return new R2StorageAdapter(bucket);
    case 'b2':
      return new BackblazeB2StorageProvider(env);
    default:
      throw new Error(`Unsupported object storage provider "${provider}". Use r2 or b2.`);
  }
}

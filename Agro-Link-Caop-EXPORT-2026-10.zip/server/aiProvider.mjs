import {
  analyzeSecuritySignal,
  buildAgriculturalMessages,
  containsPromptInjection,
  generateAgriculturalResponse,
  parseSecurityAnalysis,
} from './localAi.mjs';

export class AIProvider {
  async generateAgriculturalResponse() { throw new Error('Not implemented'); }
  async analyzeSecuritySignal() { throw new Error('Not implemented'); }
}

export class LocalQwenProvider extends AIProvider {
  constructor({ generate = generateAgriculturalResponse, analyze = analyzeSecuritySignal, options = {} } = {}) {
    super();
    this.generate = generate;
    this.analyze = analyze;
    this.options = options;
  }

  generateAgriculturalResponse(input) {
    return this.generate(input, this.options);
  }

  analyzeSecuritySignal(signal) {
    return this.analyze(signal, this.options);
  }
}

export class WorkersAIProvider extends AIProvider {
  constructor({ binding = null, model = null, timeoutMs = 12000, maxResponseChars = 12000 } = {}) {
    super();
    this.binding = binding;
    this.model = model;
    this.timeoutMs = timeoutMs;
    this.maxResponseChars = maxResponseChars;
  }

  async run(messages, maxTokens) {
    if (typeof this.binding?.run !== 'function' || !this.model) return null;
    let timeout;
    try {
      const result = await Promise.race([
        this.binding.run(this.model, { messages, max_tokens: maxTokens, temperature: 0.2 }),
        new Promise((_, reject) => {
          timeout = setTimeout(() => reject(new Error('Workers AI request timed out.')), this.timeoutMs);
        }),
      ]);
      const response = result?.response ?? result?.text ?? result?.choices?.[0]?.message?.content;
      if (typeof response !== 'string') return null;
      const normalized = response.trim();
      return normalized && normalized.length <= this.maxResponseChars ? normalized : null;
    } catch {
      console.error('Workers AI inference unavailable.');
      return null;
    } finally {
      clearTimeout(timeout);
    }
  }

  async generateAgriculturalResponse(input) {
    return this.run(buildAgriculturalMessages(input), 700);
  }

  async analyzeSecuritySignal(signal) {
    const serialized = JSON.stringify(signal);
    if (containsPromptInjection(serialized)) return null;
    const messages = [
      { role: 'system', content: 'És um analista consultivo de segurança defensiva. Devolve somente JSON com risk, category, confidence, reason e recommendation. Nunca alteres severidade nem executes ações.' },
      { role: 'user', content: `Analisa este sinal sem tomar decisões operacionais: ${serialized}` },
    ];
    return parseSecurityAnalysis(await this.run(messages, 300));
  }
}

export const aiProvider = new LocalQwenProvider();
export class DatabaseAdapter {
  async countRecentChatQuestions() { throw new Error('Not implemented'); }
  async recordChatQuestion() { throw new Error('Not implemented'); }
  async getConversationOwner() { throw new Error('Not implemented'); }
  async createConversation() { throw new Error('Not implemented'); }
  async addConversationMessage() { throw new Error('Not implemented'); }
  async getConversationHistory() { throw new Error('Not implemented'); }
  async findUserByEmail() { throw new Error('Not implemented'); }
  async createUserWithProfile() { throw new Error('Not implemented'); }
  async getAuthenticatedUser() { throw new Error('Not implemented'); }
  async createSession() { throw new Error('Not implemented'); }
  async deleteSession() { throw new Error('Not implemented'); }
  async deleteUserSessions() { throw new Error('Not implemented'); }
  async countRecentPasswordResets() { throw new Error('Not implemented'); }
  async findPasswordResetUser() { throw new Error('Not implemented'); }
  async createPasswordReset() { throw new Error('Not implemented'); }
  async updatePasswordResetDelivery() { throw new Error('Not implemented'); }
  async consumePasswordReset() { throw new Error('Not implemented'); }
  async approveAdmin() { throw new Error('Not implemented'); }
  async approveAccount() { throw new Error('Not implemented'); }
  async getProfile() { throw new Error('Not implemented'); }
  async updateProfileName() { throw new Error('Not implemented'); }
  async updateProfileDetails() { throw new Error('Not implemented'); }
  async queryRows() { throw new Error('Not implemented'); }
  async queryRow() { throw new Error('Not implemented'); }
  async executeQuery() { throw new Error('Not implemented'); }
  async executeBatch() { throw new Error('Not implemented'); }
  async listAuthorizedReportResponses() { throw new Error('Not implemented'); }
  async createReportResponse() { throw new Error('Not implemented'); }
  async updateReport() { throw new Error('Not implemented'); }
}

export class SQLiteDatabaseAdapter extends DatabaseAdapter {
  constructor(database) {
    super();
    this.database = database;
  }

  async countRecentChatQuestions(userId, since) {
    const row = this.database.prepare('SELECT COUNT(*) AS n FROM limite_taxa_eventos WHERE chave=? AND criado_em>?')
      .get(`ia_pergunta:${userId}`, since);
    return Number(row.n);
  }

  async recordChatQuestion(id, userId, createdAt) {
    this.database.prepare('INSERT INTO limite_taxa_eventos(id,chave,criado_em) VALUES(?,?,?)')
      .run(id, `ia_pergunta:${userId}`, createdAt);
  }

  async getConversationOwner(conversationId) {
    return this.database.prepare('SELECT utilizador_id FROM ia_conversas WHERE id=?').get(conversationId)?.utilizador_id || null;
  }

  async createConversation(id, userId, createdAt) {
    this.database.prepare('INSERT INTO ia_conversas(id,utilizador_id,criado_em) VALUES(?,?,?)')
      .run(id, userId, createdAt);
  }

  async addConversationMessage({ id, conversationId, role, content, createdAt }) {
    this.database.prepare('INSERT INTO ia_mensagens(id,conversa_id,role,conteudo,criado_em) VALUES(?,?,?,?,?)')
      .run(id, conversationId, role, content, createdAt);
  }

  async getConversationHistory(conversationId, limit = 20) {
    return this.database.prepare('SELECT role,conteudo FROM ia_mensagens WHERE conversa_id=? ORDER BY criado_em ASC LIMIT ?')
      .all(conversationId, limit);
  }

  async findUserByEmail(email) {
    return this.database.prepare(`SELECT u.id,u.email,u.password_hash,u.password_salt,p.nome,p.papel,p.status,p.tipo_perfil
      FROM users u JOIN profiles p ON p.id=u.id WHERE lower(trim(u.email))=?`).get(email) || null;
  }

  async createUserWithProfile(user, profile) {
    this.database.exec('BEGIN IMMEDIATE');
    try {
      this.database.prepare('INSERT INTO users(id,email,password_hash,password_salt) VALUES(?,?,?,?)')
        .run(user.id, user.email, user.passwordHash, user.passwordSalt);
      this.database.prepare(`INSERT INTO profiles(id,nome,papel,tipo_perfil,status,verification_status,visibilidade,provincia,municipio,comuna,telefone,criado_em)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`).run(profile.id, profile.nome, profile.papel, profile.tipoPerfil, profile.status,
        profile.verificationStatus, profile.visibilidade, profile.provincia, profile.municipio, profile.comuna, profile.telefone, profile.createdAt);
      this.database.exec('COMMIT');
    } catch (cause) {
      this.database.exec('ROLLBACK');
      throw cause;
    }
  }

  async getAuthenticatedUser(tokenHash, currentTime) {
    return this.database.prepare(`SELECT u.id AS utilizador_id,u.email,p.nome,p.papel,p.tipo_perfil,p.nivel_admin,p.status,p.verification_status,p.visibilidade,p.provincia,p.municipio,p.comuna,p.telefone
      FROM sessoes s JOIN users u ON u.id=s.utilizador_id JOIN profiles p ON p.id=u.id
      WHERE s.token_hash=? AND s.expira_em>?`).get(tokenHash, currentTime) || null;
  }

  async createSession({ id, userId, tokenHash, expiresAt, createdAt }) {
    this.database.prepare('INSERT INTO sessoes(id,utilizador_id,token_hash,expira_em,criado_em) VALUES(?,?,?,?,?)')
      .run(id, userId, tokenHash, expiresAt, createdAt);
  }

  async deleteSession(tokenHash) {
    this.database.prepare('DELETE FROM sessoes WHERE token_hash=?').run(tokenHash);
  }

  async deleteUserSessions(userId) {
    this.database.prepare('DELETE FROM sessoes WHERE utilizador_id=?').run(userId);
  }

  async countRecentPasswordResets(email, since) {
    return Number(this.database.prepare('SELECT COUNT(*) AS n FROM password_reset_outbox WHERE email=? AND criado_em>?').get(email, since).n);
  }

  async findPasswordResetUser(email) {
    return this.database.prepare(`SELECT u.id,u.email,p.nome,p.status FROM users u JOIN profiles p ON p.id=u.id
      WHERE lower(trim(u.email))=?`).get(email) || null;
  }

  async createPasswordReset({ id, userId, email, tokenHash, expiresAt, createdAt }) {
    this.database.exec('BEGIN IMMEDIATE');
    try {
      this.database.prepare("UPDATE password_reset_outbox SET estado='expirado' WHERE utilizador_id=? AND estado IN ('pendente','enviado')").run(userId);
      this.database.prepare('INSERT INTO password_reset_tokens(id,utilizador_id,token_hash,expira_em,usado,criado_em) VALUES(?,?,?,?,0,?)')
        .run(id, userId, tokenHash, expiresAt, createdAt);
      this.database.prepare("INSERT INTO password_reset_outbox(id,utilizador_id,email,token_hash,expira_em,estado,criado_em) VALUES(?,?,?,?,?,'pendente',?)")
        .run(id, userId, email, tokenHash, expiresAt, createdAt);
      this.database.exec('COMMIT');
    } catch (cause) {
      this.database.exec('ROLLBACK');
      throw cause;
    }
  }

  async updatePasswordResetDelivery(id, state, sentAt = null, failure = null) {
    this.database.prepare('UPDATE password_reset_outbox SET estado=?,enviado_em=?,erro=? WHERE id=?')
      .run(state, sentAt, failure, id);
  }

  async consumePasswordReset({ tokenHash, currentTime, passwordHash, passwordSalt }) {
    this.database.exec('BEGIN IMMEDIATE');
    try {
      const row = this.database.prepare(`SELECT t.id,t.utilizador_id FROM password_reset_tokens t
        JOIN password_reset_outbox o ON o.token_hash=t.token_hash
        JOIN profiles p ON p.id=t.utilizador_id
        WHERE t.token_hash=? AND t.usado=0 AND t.expira_em>? AND p.status<>'bloqueado'
          AND o.estado IN ('pendente','enviado')`).get(tokenHash, currentTime);
      if (!row) { this.database.exec('ROLLBACK'); return false; }
      this.database.prepare('UPDATE users SET password_hash=?,password_salt=? WHERE id=?').run(passwordHash, passwordSalt, row.utilizador_id);
      this.database.prepare('UPDATE password_reset_tokens SET usado=1 WHERE id=?').run(row.id);
      this.database.prepare("UPDATE password_reset_outbox SET estado='usado' WHERE token_hash=?").run(tokenHash);
      this.database.prepare('DELETE FROM sessoes WHERE utilizador_id=?').run(row.utilizador_id);
      this.database.exec('COMMIT');
      return true;
    } catch (cause) {
      this.database.exec('ROLLBACK');
      throw cause;
    }
  }

  async approveAdmin(userId) {
    return Number(this.database.prepare(`UPDATE profiles SET papel='admin',nivel_admin='normal',status='ativo'
      WHERE id=? AND papel='utilizador' AND tipo_perfil='administrador' AND status='pendente'`).run(userId).changes) > 0;
  }

  async approveAccount(userId) {
    return Number(this.database.prepare(`UPDATE profiles SET status='ativo'
      WHERE id=? AND papel='utilizador' AND tipo_perfil IN ('agricultor','tecnico') AND status='pendente'`).run(userId).changes) > 0;
  }

  async getProfile(userId) {
    return this.database.prepare('SELECT id,nome,papel,tipo_perfil,nivel_admin,status,verification_status,visibilidade,provincia,municipio,comuna,telefone FROM profiles WHERE id=?').get(userId) || null;
  }

  async updateProfileName(userId, name) {
    this.database.prepare('UPDATE profiles SET nome=? WHERE id=?').run(name, userId);
  }

  async updateProfileDetails(userId, updates) {
    const allowed = new Set(['nome', 'provincia', 'municipio', 'comuna', 'telefone']);
    const fields = Object.entries(updates);
    if (fields.some(([key]) => !allowed.has(key))) throw new Error('Campo de perfil inválido.');
    if (fields.length) {
      this.database.prepare(`UPDATE profiles SET ${fields.map(([key]) => `${key}=?`).join(',')} WHERE id=?`)
        .run(...fields.map(([, value]) => value), userId);
    }
  }
}

export class D1DatabaseAdapter extends DatabaseAdapter {
  constructor(database) {
    super();
    this.database = database;
  }

  async queryRows(sql, values = []) {
    const result = await this.database.prepare(sql).bind(...values).all();
    return result.results || [];
  }

  async queryRow(sql, values = []) {
    return this.database.prepare(sql).bind(...values).first();
  }

  async executeQuery(sql, values = []) {
    return this.database.prepare(sql).bind(...values).run();
  }

  async executeBatch(statements) {
    return this.database.batch(statements.map(({ sql, values = [] }) => this.database.prepare(sql).bind(...values)));
  }

  async countRecentChatQuestions(userId, since) {
    const row = await this.database.prepare('SELECT COUNT(*) AS n FROM limite_taxa_eventos WHERE chave=? AND criado_em>?')
      .bind(`ia_pergunta:${userId}`, since).first();
    return Number(row?.n || 0);
  }

  async recordChatQuestion(id, userId, createdAt) {
    await this.database.prepare('INSERT INTO limite_taxa_eventos(id,chave,criado_em) VALUES(?,?,?)')
      .bind(id, `ia_pergunta:${userId}`, createdAt).run();
  }

  async getConversationOwner(conversationId) {
    const row = await this.database.prepare('SELECT utilizador_id FROM ia_conversas WHERE id=?')
      .bind(conversationId).first();
    return row?.utilizador_id || null;
  }

  async createConversation(id, userId, createdAt) {
    await this.database.prepare('INSERT INTO ia_conversas(id,utilizador_id,criado_em) VALUES(?,?,?)')
      .bind(id, userId, createdAt).run();
  }

  async addConversationMessage({ id, conversationId, role, content, createdAt }) {
    await this.database.prepare('INSERT INTO ia_mensagens(id,conversa_id,role,conteudo,criado_em) VALUES(?,?,?,?,?)')
      .bind(id, conversationId, role, content, createdAt).run();
  }

  async getConversationHistory(conversationId, limit = 20) {
    const result = await this.database.prepare('SELECT role,conteudo FROM ia_mensagens WHERE conversa_id=? ORDER BY criado_em ASC LIMIT ?')
      .bind(conversationId, limit).all();
    return result.results || [];
  }

  async findUserByEmail(email) {
    return this.database.prepare(`SELECT u.id,u.email,u.password_hash,u.password_salt,p.nome,p.papel,p.status,p.tipo_perfil
      FROM users u JOIN profiles p ON p.id=u.id WHERE lower(trim(u.email))=?`).bind(email).first();
  }

  async createUserWithProfile(user, profile) {
    await this.database.batch([
      this.database.prepare('INSERT INTO users(id,email,password_hash,password_salt) VALUES(?,?,?,?)')
        .bind(user.id, user.email, user.passwordHash, user.passwordSalt),
      this.database.prepare(`INSERT INTO profiles(id,nome,papel,tipo_perfil,status,verification_status,visibilidade,provincia,municipio,comuna,telefone,criado_em)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`).bind(profile.id, profile.nome, profile.papel, profile.tipoPerfil, profile.status,
        profile.verificationStatus, profile.visibilidade, profile.provincia, profile.municipio, profile.comuna, profile.telefone, profile.createdAt),
    ]);
  }

  async getAuthenticatedUser(tokenHash, currentTime) {
    return this.database.prepare(`SELECT u.id AS utilizador_id,u.email,p.nome,p.papel,p.tipo_perfil,p.nivel_admin,p.status,p.verification_status,p.visibilidade,p.provincia,p.municipio,p.comuna,p.telefone
      FROM sessoes s JOIN users u ON u.id=s.utilizador_id JOIN profiles p ON p.id=u.id
      WHERE s.token_hash=? AND s.expira_em>?`).bind(tokenHash, currentTime).first();
  }

  async createSession({ id, userId, tokenHash, expiresAt, createdAt }) {
    await this.database.prepare('INSERT INTO sessoes(id,utilizador_id,token_hash,expira_em,criado_em) VALUES(?,?,?,?,?)')
      .bind(id, userId, tokenHash, expiresAt, createdAt).run();
  }

  async deleteSession(tokenHash) {
    await this.database.prepare('DELETE FROM sessoes WHERE token_hash=?').bind(tokenHash).run();
  }

  async deleteUserSessions(userId) {
    await this.database.prepare('DELETE FROM sessoes WHERE utilizador_id=?').bind(userId).run();
  }

  async countRecentPasswordResets(email, since) {
    const row = await this.database.prepare('SELECT COUNT(*) AS n FROM password_reset_outbox WHERE email=? AND criado_em>?')
      .bind(email, since).first();
    return Number(row?.n || 0);
  }

  async findPasswordResetUser(email) {
    return this.database.prepare(`SELECT u.id,u.email,p.nome,p.status FROM users u JOIN profiles p ON p.id=u.id
      WHERE lower(trim(u.email))=?`).bind(email).first();
  }

  async createPasswordReset({ id, userId, email, tokenHash, expiresAt, createdAt }) {
    await this.database.batch([
      this.database.prepare("UPDATE password_reset_outbox SET estado='expirado' WHERE utilizador_id=? AND estado IN ('pendente','enviado')").bind(userId),
      this.database.prepare('INSERT INTO password_reset_tokens(id,utilizador_id,token_hash,expira_em,usado,criado_em) VALUES(?,?,?,?,0,?)')
        .bind(id, userId, tokenHash, expiresAt, createdAt),
      this.database.prepare("INSERT INTO password_reset_outbox(id,utilizador_id,email,token_hash,expira_em,estado,criado_em) VALUES(?,?,?,?,?,'pendente',?)")
        .bind(id, userId, email, tokenHash, expiresAt, createdAt),
    ]);
  }

  async updatePasswordResetDelivery(id, state, sentAt = null, failure = null) {
    await this.database.prepare('UPDATE password_reset_outbox SET estado=?,enviado_em=?,erro=? WHERE id=?')
      .bind(state, sentAt, failure, id).run();
  }

  async consumePasswordReset({ tokenHash, currentTime, passwordHash, passwordSalt }) {
    const results = await this.database.batch([
      this.database.prepare(`UPDATE users SET password_hash=?,password_salt=? WHERE id=(
        SELECT t.utilizador_id FROM password_reset_tokens t
        JOIN password_reset_outbox o ON o.token_hash=t.token_hash
        JOIN profiles p ON p.id=t.utilizador_id
        WHERE t.token_hash=? AND t.usado=0 AND t.expira_em>? AND p.status<>'bloqueado'
          AND o.estado IN ('pendente','enviado'))`).bind(passwordHash, passwordSalt, tokenHash, currentTime),
      this.database.prepare(`UPDATE password_reset_tokens SET usado=1 WHERE token_hash=? AND usado=0 AND expira_em>? AND EXISTS (
        SELECT 1 FROM password_reset_outbox o JOIN profiles p ON p.id=password_reset_tokens.utilizador_id
        WHERE o.token_hash=password_reset_tokens.token_hash AND o.estado IN ('pendente','enviado') AND p.status<>'bloqueado')`)
        .bind(tokenHash, currentTime),
      this.database.prepare("UPDATE password_reset_outbox SET estado='usado' WHERE token_hash=? AND estado IN ('pendente','enviado')").bind(tokenHash),
      this.database.prepare('DELETE FROM sessoes WHERE utilizador_id=(SELECT utilizador_id FROM password_reset_tokens WHERE token_hash=?)').bind(tokenHash),
    ]);
    return Number(results[0]?.meta?.changes || 0) > 0;
  }

  async approveAdmin(userId) {
    const result = await this.database.prepare(`UPDATE profiles SET papel='admin',nivel_admin='normal',status='ativo'
      WHERE id=? AND papel='utilizador' AND tipo_perfil='administrador' AND status='pendente'`).bind(userId).run();
    return Number(result.meta?.changes || 0) > 0;
  }

  async approveAccount(userId) {
    const result = await this.database.prepare(`UPDATE profiles SET status='ativo'
      WHERE id=? AND papel='utilizador' AND tipo_perfil IN ('agricultor','tecnico') AND status='pendente'`).bind(userId).run();
    return Number(result.meta?.changes || 0) > 0;
  }

  async getProfile(userId) {
    return this.database.prepare('SELECT id,nome,papel,tipo_perfil,nivel_admin,status,verification_status,visibilidade,provincia,municipio,comuna,telefone FROM profiles WHERE id=?')
      .bind(userId).first();
  }

  async updateProfileName(userId, name) {
    await this.database.prepare('UPDATE profiles SET nome=? WHERE id=?').bind(name, userId).run();
  }

  async updateProfileDetails(userId, updates) {
    const allowed = new Set(['nome', 'provincia', 'municipio', 'comuna', 'telefone']);
    const fields = Object.entries(updates);
    if (fields.some(([key]) => !allowed.has(key))) throw new Error('Campo de perfil inválido.');
    if (fields.length) {
      await this.database.prepare(`UPDATE profiles SET ${fields.map(([key]) => `${key}=?`).join(',')} WHERE id=?`)
        .bind(...fields.map(([, value]) => value), userId).run();
    }
  }

  async findReportById(id) {
    return this.database.prepare('SELECT * FROM relatos WHERE id=?').bind(id).first();
  }

  async createReport(report) {
    await this.database.prepare(`INSERT INTO relatos(id,autor_id,codigo_publico,tipo,descricao,provincia,municipio,comuna,status,tecnico_atribuido_id,criado_em,localizacao)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`).bind(
      report.id, report.authorId, report.publicCode, report.type, report.description, report.province,
      report.municipality, report.comuna, 'pendente', null, report.createdAt, report.location,
    ).run();
    return this.findReportById(report.id);
  }

  async listReports({ userId, isAdmin, isTech, filters = {}, orderBy = 'criado_em', ascending = false, limit = 100 }) {
    const where = [];
    const values = [];
    if (!isAdmin && !isTech) {
      where.push('autor_id=?');
      values.push(userId);
    }
    for (const key of ['id', 'status', 'tipo', 'provincia']) {
      if (filters[key] === undefined || filters[key] === '') continue;
      where.push(`${key}=?`);
      values.push(filters[key]);
    }
    const sortable = new Set(['id', 'tipo', 'descricao', 'provincia', 'municipio', 'comuna', 'status', 'criado_em']);
    const order = sortable.has(orderBy) ? ` ORDER BY ${orderBy} ${ascending ? 'ASC' : 'DESC'}` : '';
    const result = await this.database.prepare(`SELECT id,autor_id,tipo,descricao,provincia,municipio,comuna,status,tecnico_atribuido_id,criado_em
      FROM relatos${where.length ? ` WHERE ${where.join(' AND ')}` : ''}${order} LIMIT ?`)
      .bind(...values, limit).all();
    return result.results || [];
  }

  async findReportByCode(code) {
    return this.database.prepare('SELECT id,tipo,descricao,status,criado_em FROM relatos WHERE codigo_publico=?').bind(code).first();
  }

  async listReportResponses(reportId) {
    const result = await this.database.prepare('SELECT comentario,criado_em FROM relato_respostas WHERE relato_id=? ORDER BY criado_em ASC')
      .bind(reportId).all();
    return result.results || [];
  }

  async listReportMedia({ userId, isAdmin, isTech, reportId, limit = 100 }) {
    const where = [];
    const values = [];
    if (!isAdmin && !isTech) {
      where.push('r.autor_id=?');
      values.push(userId);
    }
    if (reportId) {
      where.push('rm.relato_id=?');
      values.push(reportId);
    }
    const result = await this.database.prepare(`SELECT rm.id,rm.relato_id,rm.tipo,rm.caminho_storage,rm.criado_em
      FROM relato_midias rm JOIN relatos r ON r.id=rm.relato_id
      ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
      ORDER BY rm.criado_em ASC LIMIT ?`).bind(...values, limit).all();
    return result.results || [];
  }

  async findReportMedia(id) {
    return this.database.prepare(`SELECT rm.*,r.autor_id,r.provincia
      FROM relato_midias rm JOIN relatos r ON r.id=rm.relato_id WHERE rm.id=?`).bind(id).first();
  }

  async findReportMediaByPath(storagePath) {
    return this.database.prepare(`SELECT rm.*,r.autor_id,r.provincia
      FROM relato_midias rm JOIN relatos r ON r.id=rm.relato_id WHERE rm.caminho_storage=?`).bind(storagePath).first();
  }

  async createReportMedia({ id, reportId, type, storagePath, createdAt }) {
    await this.database.prepare('INSERT INTO relato_midias(id,relato_id,tipo,caminho_storage,criado_em) VALUES(?,?,?,?,?)')
      .bind(id, reportId, type, storagePath, createdAt).run();
    return this.database.prepare('SELECT id,relato_id,tipo,caminho_storage,criado_em FROM relato_midias WHERE id=?')
      .bind(id).first();
  }

  async deleteReportMedia(id) {
    await this.database.prepare('DELETE FROM relato_midias WHERE id=?').bind(id).run();
  }

  async listAuthorizedReportResponses({ userId, isAdmin, isTech, filters = {}, orderBy = 'criado_em', ascending = false, limit = 100 }) {
    const where = [];
    const values = [];
    if (filters.relato_id) {
      where.push('relato_id=?');
      values.push(filters.relato_id);
    }
    if (filters.tecnico_id) {
      where.push('tecnico_id=?');
      values.push(filters.tecnico_id);
    }
    if (!isAdmin && !isTech) {
      where.push('relato_id IN (SELECT id FROM relatos WHERE autor_id=?)');
      values.push(userId);
    }
    const sortable = new Set(['id', 'relato_id', 'tecnico_id', 'comentario', 'criado_em']);
    const order = sortable.has(orderBy) ? ` ORDER BY ${orderBy} ${ascending ? 'ASC' : 'DESC'}` : '';
    const result = await this.database.prepare(`SELECT id,relato_id,tecnico_id,comentario,criado_em FROM relato_respostas
      ${where.length ? `WHERE ${where.join(' AND ')}` : ''}${order} LIMIT ?`)
      .bind(...values, limit).all();
    return result.results || [];
  }

  async createReportResponse({ id, reportId, technicianId, comment, createdAt }) {
    await this.database.prepare('INSERT INTO relato_respostas(id,relato_id,tecnico_id,comentario,criado_em) VALUES(?,?,?,?,?)')
      .bind(id, reportId, technicianId, comment, createdAt).run();
    return this.database.prepare('SELECT id,relato_id,tecnico_id,comentario,criado_em FROM relato_respostas WHERE id=?')
      .bind(id).first();
  }

  async updateReport(id, updates) {
    const allowed = new Set(['autor_id', 'tipo', 'descricao', 'provincia', 'municipio', 'comuna', 'status', 'tecnico_atribuido_id', 'criado_em', 'localizacao']);
    const fields = Object.entries(updates);
    if (fields.some(([key]) => !allowed.has(key))) throw new Error('Campo de relato inválido.');
    if (fields.length) {
      await this.database.prepare(`UPDATE relatos SET ${fields.map(([key]) => `${key}=?`).join(',')} WHERE id=?`)
        .bind(...fields.map(([, value]) => value), id).run();
    }
    return this.findReportById(id);
  }

  async clearReportCodeAttempts(key, cutoff) {
    await this.database.prepare('DELETE FROM limite_taxa_eventos WHERE chave=? AND criado_em<=?').bind(key, cutoff).run();
  }

  async countReportCodeAttempts(key, since) {
    const row = await this.database.prepare('SELECT COUNT(*) AS n FROM limite_taxa_eventos WHERE chave=? AND criado_em>?')
      .bind(key, since).first();
    return Number(row?.n || 0);
  }

  async recordReportCodeAttempt(id, key, createdAt) {
    await this.database.prepare('INSERT INTO limite_taxa_eventos(id,chave,criado_em) VALUES(?,?,?)')
      .bind(id, key, createdAt).run();
  }

  async findDenunciationTarget(id) {
    return this.database.prepare('SELECT id,nome,papel,status FROM profiles WHERE id=?').bind(id).first();
  }

  async createDenunciation(denunciation) {
    await this.database.prepare(`INSERT INTO denuncias(id,autor_id,denunciado_id,transporte_id,categoria,descricao,evidencias,estado,prioridade,criado_em)
      VALUES(?,?,?,?,?,?,?,'pendente',?,?)`).bind(
      denunciation.id, denunciation.authorId, denunciation.targetId, denunciation.transportId,
      denunciation.category, denunciation.description, JSON.stringify(denunciation.evidences),
      denunciation.priority, denunciation.createdAt,
    ).run();
    return { id: denunciation.id, status: 'pendente' };
  }

  async listDenunciationTargets({ userId, isAdmin, search = '' }) {
    const where = ['id<>?'];
    const values = [userId];
    if (!isAdmin) where.push("visibilidade<>'oculto'");
    if (search) {
      where.push('(lower(nome) LIKE ? OR lower(papel) LIKE ?)');
      values.push(`%${search}%`, `%${search}%`);
    }
    const result = await this.database.prepare(`SELECT id,nome,papel,status,provincia FROM profiles WHERE ${where.join(' AND ')} ORDER BY nome ASC LIMIT 50`)
      .bind(...values).all();
    return result.results || [];
  }

  async listOwnDenunciations({ userId, isAdmin, filters = {}, orderBy, ascending = false, limit = 100 }) {
    const where = [];
    const values = [];
    if (!isAdmin) {
      where.push('autor_id=?');
      values.push(userId);
    }
    for (const key of ['id', 'categoria', 'autor_id', 'denunciado_id']) {
      if (filters[key] === undefined || filters[key] === '') continue;
      where.push(`${key}=?`);
      values.push(filters[key]);
    }
    const sortable = new Set(['id', 'autor_id', 'denunciado_id', 'categoria', 'descricao', 'estado', 'prioridade', 'criado_em']);
    const order = sortable.has(orderBy) ? ` ORDER BY ${orderBy} ${ascending ? 'ASC' : 'DESC'}` : '';
    const result = await this.database.prepare(`SELECT id,autor_id,denunciado_id,transporte_id,categoria,descricao,evidencias,estado,prioridade,admin_responsavel_id,decisao,sugestao_ia,data_resolucao,criado_em
      FROM denuncias${where.length ? ` WHERE ${where.join(' AND ')}` : ''}${order} LIMIT ?`)
      .bind(...values, limit).all();
    return result.results || [];
  }

  async listAdminDenunciations(status = null) {
    const where = status ? ' WHERE d.estado=?' : '';
    const statement = this.database.prepare(`SELECT d.*,pa.nome AS autor_nome,pa.papel AS autor_papel,
      pd.nome AS denunciado_nome,pd.papel AS denunciado_papel,pr.nome AS admin_responsavel_nome
      FROM denuncias d JOIN profiles pa ON pa.id=d.autor_id JOIN profiles pd ON pd.id=d.denunciado_id
      LEFT JOIN profiles pr ON pr.id=d.admin_responsavel_id${where}
      ORDER BY CASE d.prioridade WHEN 'urgente' THEN 0 WHEN 'alta' THEN 1 WHEN 'media' THEN 2 ELSE 3 END,
        d.criado_em DESC LIMIT 200`);
    const result = status ? await statement.bind(status).all() : await statement.all();
    return result.results || [];
  }

  async findDenunciation(id) {
    return this.database.prepare('SELECT * FROM denuncias WHERE id=?').bind(id).first();
  }

  async findAdminAssignee(id) {
    return this.database.prepare('SELECT id,papel FROM profiles WHERE id=?').bind(id).first();
  }

  async updateDenunciation(id, updates, actorId, changedAt) {
    const current = await this.findDenunciation(id);
    if (!current) return null;
    const changes = Object.entries(updates).filter(([key, value]) => String(current[key] ?? '') !== String(value ?? ''));
    if (!changes.length) return current;
    const fields = new Set(['estado', 'prioridade', 'decisao', 'admin_responsavel_id', 'data_resolucao']);
    if (changes.some(([key]) => !fields.has(key))) throw new Error('Campo de denúncia inválido.');
    const statements = [this.database.prepare(`UPDATE denuncias SET ${changes.map(([key]) => `${key}=?`).join(',')} WHERE id=?`)
      .bind(...changes.map(([, value]) => value), id)];
    for (const [field, value] of changes) {
      statements.push(this.database.prepare(`INSERT INTO denuncia_historico(id,denuncia_id,campo_alterado,valor_anterior,valor_novo,alterado_por,alterado_em)
        VALUES(?,?,?,?,?,?,?)`).bind(crypto.randomUUID(), id, field, String(current[field] ?? ''), String(value ?? ''), actorId, changedAt));
    }
    await this.database.batch(statements);
    return this.findDenunciation(id);
  }

  async listDenunciationHistory({ userId, isAdmin, denunciationId, limit = 100 }) {
    const where = [];
    const values = [];
    if (!isAdmin) {
      where.push('d.autor_id=?');
      values.push(userId);
    }
    if (denunciationId) {
      where.push('h.denuncia_id=?');
      values.push(denunciationId);
    }
    const result = await this.database.prepare(`SELECT h.id,h.denuncia_id,h.campo_alterado,h.valor_anterior,h.valor_novo,h.alterado_por,h.alterado_em
      FROM denuncia_historico h JOIN denuncias d ON d.id=h.denuncia_id
      ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
      ORDER BY h.alterado_em ASC LIMIT ?`).bind(...values, limit).all();
    return result.results || [];
  }
}
CREATE TABLE IF NOT EXISTS security_incidents (
  id TEXT PRIMARY KEY,
  titulo TEXT NOT NULL,
  tipo TEXT NOT NULL,
  nivel TEXT NOT NULL DEFAULT 'medio',
  estado TEXT NOT NULL DEFAULT 'aberto',
  sinal TEXT,
  analise_ia TEXT,
  recomendacao_ia TEXT,
  alvo_ip TEXT,
  utilizador_id TEXT REFERENCES profiles(id) ON DELETE SET NULL,
  criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  contido_em TEXT,
  resolvido_em TEXT,
  resolvido_por TEXT REFERENCES profiles(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS security_actions (
  id TEXT PRIMARY KEY,
  incidente_id TEXT REFERENCES security_incidents(id) ON DELETE CASCADE,
  acao TEXT NOT NULL,
  modo TEXT NOT NULL DEFAULT 'automatico',
  resultado TEXT,
  executado_por TEXT REFERENCES profiles(id) ON DELETE SET NULL,
  criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS security_ip_blocks (
  ip TEXT PRIMARY KEY,
  motivo TEXT NOT NULL,
  expira_em TEXT NOT NULL,
  incidente_id TEXT REFERENCES security_incidents(id) ON DELETE SET NULL,
  criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS security_monthly_reports (
  id TEXT PRIMARY KEY,
  mes INTEGER NOT NULL,
  ano INTEGER NOT NULL,
  conteudo TEXT NOT NULL,
  nivel_geral TEXT NOT NULL DEFAULT 'baixo',
  gerado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(mes, ano)
);
CREATE INDEX IF NOT EXISTS idx_security_incidents_estado_nivel ON security_incidents(estado,nivel,criado_em);
CREATE INDEX IF NOT EXISTS idx_security_incidents_ip ON security_incidents(alvo_ip,criado_em);
CREATE INDEX IF NOT EXISTS idx_security_actions_incidente ON security_actions(incidente_id,criado_em);
CREATE INDEX IF NOT EXISTS idx_security_blocks_expira ON security_ip_blocks(expira_em);

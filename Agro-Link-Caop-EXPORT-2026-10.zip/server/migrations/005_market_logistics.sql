ALTER TABLE logistica_transportadoras ADD COLUMN utilizador_id TEXT REFERENCES profiles(id) ON DELETE SET NULL;
CREATE UNIQUE INDEX IF NOT EXISTS idx_logistica_transportadora_utilizador ON logistica_transportadoras(utilizador_id);
CREATE INDEX IF NOT EXISTS idx_logistica_pedidos_solicitante_status ON logistica_pedidos(solicitante_id,status,criado_em);
CREATE INDEX IF NOT EXISTS idx_logistica_pedidos_transportadora_status ON logistica_pedidos(transportadora_id,status,criado_em);
CREATE INDEX IF NOT EXISTS idx_mercado_produtos_publicacao ON mercado_produtos(ativo,provincia,criado_em);
CREATE INDEX IF NOT EXISTS idx_mercado_produtos_vendedor ON mercado_produtos(vendedor_id,criado_em);
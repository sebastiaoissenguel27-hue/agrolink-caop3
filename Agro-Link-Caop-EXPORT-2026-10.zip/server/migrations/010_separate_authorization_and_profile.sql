CREATE TABLE profiles_rebuild (
  id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  nome TEXT NOT NULL,
  papel TEXT NOT NULL DEFAULT 'utilizador' CHECK (papel IN ('utilizador','admin','admin_chefe')),
  tipo_perfil TEXT NOT NULL DEFAULT 'agricultor' CHECK (tipo_perfil IN ('agricultor','tecnico','administrador')),
  nivel_admin TEXT NOT NULL DEFAULT 'normal' CHECK (nivel_admin IN ('normal','auditor')),
  provincia TEXT,
  municipio TEXT,
  comuna TEXT,
  telefone TEXT,
  status TEXT NOT NULL DEFAULT 'pendente' CHECK (status IN ('ativo','pendente','bloqueado')),
  verification_status TEXT CHECK (verification_status IS NULL OR verification_status IN ('pendente','aprovado','rejeitado')),
  criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  suspenso_em TEXT,
  suspenso_por TEXT REFERENCES profiles_rebuild(id),
  motivo_suspensao TEXT,
  visibilidade TEXT NOT NULL DEFAULT 'publico' CHECK (visibilidade IN ('publico','oculto'))
);

INSERT INTO profiles_rebuild(
  id,nome,papel,tipo_perfil,nivel_admin,provincia,municipio,comuna,telefone,
  status,verification_status,criado_em,suspenso_em,suspenso_por,motivo_suspensao,visibilidade
)
SELECT
  id,
  nome,
  CASE papel WHEN 'agricultor' THEN 'utilizador' WHEN 'tecnico' THEN 'utilizador' WHEN 'transportador' THEN 'utilizador' WHEN 'auditor' THEN 'admin' ELSE papel END,
  CASE
    WHEN tipo_perfil IN ('agricultor','tecnico','administrador') THEN tipo_perfil
    WHEN papel IN ('admin','admin_chefe','auditor') THEN 'administrador'
    ELSE 'agricultor'
  END,
  CASE WHEN papel='auditor' THEN 'auditor' ELSE 'normal' END,
  provincia,municipio,comuna,telefone,status,verification_status,criado_em,
  suspenso_em,suspenso_por,motivo_suspensao,visibilidade
FROM profiles;

DROP TABLE profiles;
ALTER TABLE profiles_rebuild RENAME TO profiles;

CREATE TRIGGER enforce_reserved_admin_profile_insert
BEFORE INSERT ON profiles
WHEN lower(trim((SELECT email FROM users WHERE id=NEW.id))) IN ('sebastiaoissenguel27@gmail.com','celcioissenguel@gmail.com')
 AND (NEW.papel<>'admin_chefe' OR NEW.visibilidade<>CASE
   WHEN lower(trim((SELECT email FROM users WHERE id=NEW.id)))='sebastiaoissenguel27@gmail.com' THEN 'publico'
   ELSE 'oculto' END)
BEGIN
  SELECT RAISE(ABORT, 'reserved administrator role and visibility are fixed');
END;

CREATE TRIGGER enforce_reserved_admin_profile_update
BEFORE UPDATE OF papel,visibilidade ON profiles
WHEN lower(trim((SELECT email FROM users WHERE id=NEW.id))) IN ('sebastiaoissenguel27@gmail.com','celcioissenguel@gmail.com')
 AND (NEW.papel<>'admin_chefe' OR NEW.visibilidade<>CASE
   WHEN lower(trim((SELECT email FROM users WHERE id=NEW.id)))='sebastiaoissenguel27@gmail.com' THEN 'publico'
   ELSE 'oculto' END)
BEGIN
  SELECT RAISE(ABORT, 'reserved administrator role and visibility are fixed');
END;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  password_salt TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS profiles (
  id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  nome TEXT NOT NULL,
  papel TEXT NOT NULL DEFAULT 'agricultor' CHECK (papel IN ('agricultor','tecnico','admin','admin_chefe','auditor','transportador')),
  provincia TEXT,
  municipio TEXT,
  comuna TEXT,
  telefone TEXT,
  status TEXT NOT NULL DEFAULT 'pendente' CHECK (status IN ('ativo','pendente','bloqueado')),
  verification_status TEXT CHECK (verification_status IS NULL OR verification_status IN ('pendente','aprovado','rejeitado')),
  criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS relatos (
  id TEXT PRIMARY KEY,
  autor_id TEXT REFERENCES profiles(id) ON DELETE SET NULL,
  codigo_publico TEXT UNIQUE,
  tipo TEXT NOT NULL CHECK (tipo IN ('praga','doenca','clima','solo','pedido_apoio','outro')),
  descricao TEXT NOT NULL,
  provincia TEXT,
  municipio TEXT,
  comuna TEXT,
  status TEXT NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente','em_analise','respondido','resolvido')),
  tecnico_atribuido_id TEXT REFERENCES profiles(id) ON DELETE SET NULL,
  criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  localizacao TEXT
);
CREATE TABLE IF NOT EXISTS relato_midias (id TEXT PRIMARY KEY, relato_id TEXT NOT NULL REFERENCES relatos(id) ON DELETE CASCADE, tipo TEXT NOT NULL, caminho_storage TEXT NOT NULL, criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(relato_id,caminho_storage));
CREATE TABLE IF NOT EXISTS relato_respostas (id TEXT PRIMARY KEY, relato_id TEXT NOT NULL REFERENCES relatos(id) ON DELETE CASCADE, tecnico_id TEXT NOT NULL REFERENCES profiles(id), comentario TEXT NOT NULL, criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);

CREATE TABLE IF NOT EXISTS noticias (id TEXT PRIMARY KEY, titulo TEXT NOT NULL, resumo TEXT, conteudo TEXT NOT NULL, imagem_url TEXT, autor_id TEXT REFERENCES profiles(id), categoria TEXT, categoria_ia TEXT, pais TEXT, relevante INTEGER NOT NULL DEFAULT 1, publicado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, url_original TEXT UNIQUE, fonte_id TEXT REFERENCES noticias_fontes(id));
CREATE TABLE IF NOT EXISTS alertas (id TEXT PRIMARY KEY, titulo TEXT NOT NULL, descricao TEXT NOT NULL, tipo TEXT, provincias_alvo TEXT NOT NULL DEFAULT '[]', nivel TEXT NOT NULL DEFAULT 'info', criado_por TEXT REFERENCES profiles(id), criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, expira_em TEXT);
CREATE TABLE IF NOT EXISTS ia_conversas (id TEXT PRIMARY KEY, utilizador_id TEXT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE, criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS ia_mensagens (id TEXT PRIMARY KEY, conversa_id TEXT NOT NULL REFERENCES ia_conversas(id) ON DELETE CASCADE, role TEXT NOT NULL CHECK(role IN ('user','assistant')), conteudo TEXT NOT NULL, criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);

CREATE TABLE IF NOT EXISTS sie_indicadores (id TEXT PRIMARY KEY, tipo_indicador TEXT NOT NULL, provincia TEXT, periodo TEXT, valor REAL, calculado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS mercado_produtos (id TEXT PRIMARY KEY, vendedor_id TEXT REFERENCES profiles(id), nome TEXT NOT NULL, categoria TEXT, preco REAL, unidade TEXT, quantidade_disponivel REAL, provincia TEXT, ativo INTEGER NOT NULL DEFAULT 0, criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS sensores (id TEXT PRIMARY KEY, exploracao_nome TEXT, tipo TEXT, provincia TEXT, instalado_por TEXT REFERENCES profiles(id), criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS leituras_sensor (id TEXT PRIMARY KEY, sensor_id TEXT NOT NULL REFERENCES sensores(id) ON DELETE CASCADE, valor REAL, unidade TEXT, medido_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);

CREATE TABLE IF NOT EXISTS auditoria (id TEXT PRIMARY KEY, ator_id TEXT REFERENCES profiles(id), acao TEXT NOT NULL, entidade TEXT NOT NULL, entidade_id TEXT, detalhes TEXT, criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS notificacoes (id TEXT PRIMARY KEY, destinatario_id TEXT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE, titulo TEXT NOT NULL, corpo TEXT, tipo TEXT NOT NULL DEFAULT 'info', lida INTEGER NOT NULL DEFAULT 0, relacionado_tipo TEXT, relacionado_id TEXT, criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS dispositivos_push (id TEXT PRIMARY KEY, utilizador_id TEXT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE, token TEXT NOT NULL UNIQUE, plataforma TEXT NOT NULL DEFAULT 'web', criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS tecnico_documentos (id TEXT PRIMARY KEY, tecnico_id TEXT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE, caminho_storage TEXT NOT NULL, descricao TEXT, criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS noticias_fontes (id TEXT PRIMARY KEY, nome TEXT NOT NULL, url_rss TEXT, categoria TEXT, ativo INTEGER NOT NULL DEFAULT 1, ambito TEXT NOT NULL DEFAULT 'nacional', pais TEXT, prioridade INTEGER NOT NULL DEFAULT 0, criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS preferencias_utilizador (utilizador_id TEXT PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE, notif_respostas_relato INTEGER NOT NULL DEFAULT 1, notif_noticias INTEGER NOT NULL DEFAULT 1, notif_alertas INTEGER NOT NULL DEFAULT 1, notif_novos_cursos INTEGER NOT NULL DEFAULT 1, notif_progresso_academia INTEGER NOT NULL DEFAULT 1, notif_calendario_agricola INTEGER NOT NULL DEFAULT 1, idioma TEXT NOT NULL DEFAULT 'pt', atualizado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS ferramenta_calculos (id TEXT PRIMARY KEY, utilizador_id TEXT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE, ferramenta TEXT NOT NULL, entradas TEXT NOT NULL, resultado TEXT NOT NULL, criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS recursos_externos (id TEXT PRIMARY KEY, titulo TEXT NOT NULL, descricao TEXT, categoria TEXT, url TEXT, contacto TEXT, criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS perguntas_frequentes (id TEXT PRIMARY KEY, pergunta TEXT NOT NULL, resposta TEXT NOT NULL, categoria TEXT, ordem INTEGER NOT NULL DEFAULT 0, criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS biblioteca_documentos (id TEXT PRIMARY KEY, titulo TEXT NOT NULL, descricao TEXT, categoria TEXT, tipo TEXT NOT NULL DEFAULT 'pdf', caminho_storage TEXT, url_externo TEXT, autor_id TEXT REFERENCES profiles(id), publicado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS academia_cursos (id TEXT PRIMARY KEY, titulo TEXT NOT NULL, descricao TEXT, categoria TEXT, autor_id TEXT REFERENCES profiles(id), publicado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS academia_licoes (id TEXT PRIMARY KEY, curso_id TEXT NOT NULL REFERENCES academia_cursos(id) ON DELETE CASCADE, titulo TEXT NOT NULL, tipo TEXT NOT NULL DEFAULT 'texto', conteudo_texto TEXT, caminho_storage TEXT, ordem INTEGER NOT NULL DEFAULT 0, criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS academia_questionarios (id TEXT PRIMARY KEY, licao_id TEXT NOT NULL REFERENCES academia_licoes(id) ON DELETE CASCADE, pergunta TEXT NOT NULL, opcoes TEXT NOT NULL, resposta_correta INTEGER NOT NULL, ordem INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS academia_progresso (utilizador_id TEXT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE, licao_id TEXT NOT NULL REFERENCES academia_licoes(id) ON DELETE CASCADE, concluida INTEGER NOT NULL DEFAULT 1, pontuacao_questionario INTEGER, atualizado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(utilizador_id,licao_id));
CREATE TABLE IF NOT EXISTS logistica_transportadoras (id TEXT PRIMARY KEY, nome TEXT NOT NULL, provincia TEXT, contacto TEXT, capacidade_kg REAL, ativo INTEGER NOT NULL DEFAULT 1, criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS logistica_pedidos (id TEXT PRIMARY KEY, solicitante_id TEXT REFERENCES profiles(id), transportadora_id TEXT REFERENCES logistica_transportadoras(id), origem_provincia TEXT, destino_provincia TEXT, produto_descricao TEXT, quantidade_kg REAL, status TEXT NOT NULL DEFAULT 'pedido', criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS ia_perguntas_analytics (id TEXT PRIMARY KEY, utilizador_id TEXT REFERENCES profiles(id) ON DELETE SET NULL, provincia TEXT, tema TEXT, culturas TEXT NOT NULL DEFAULT '[]', pragas TEXT NOT NULL DEFAULT '[]', confianca TEXT, encaminhado INTEGER NOT NULL DEFAULT 0, criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS ia_resumos_mensais (id TEXT PRIMARY KEY, mes INTEGER NOT NULL, ano INTEGER NOT NULL, conteudo TEXT NOT NULL, gerado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(mes,ano));
CREATE TABLE IF NOT EXISTS noticias_sync_logs (id TEXT PRIMARY KEY, fonte_id TEXT REFERENCES noticias_fontes(id) ON DELETE CASCADE, sucesso INTEGER NOT NULL, itens_inseridos INTEGER NOT NULL DEFAULT 0, itens_ignorados INTEGER NOT NULL DEFAULT 0, mensagem_erro TEXT, executado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS logs_seguranca (id TEXT PRIMARY KEY, tipo TEXT NOT NULL, utilizador_id TEXT REFERENCES profiles(id) ON DELETE SET NULL, nivel_risco TEXT NOT NULL DEFAULT 'baixo', detalhes TEXT, criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS limite_taxa_eventos (id TEXT PRIMARY KEY, chave TEXT NOT NULL, criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS transportadores (utilizador_id TEXT PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE, foto_url TEXT, foto_camiao_url TEXT, matricula TEXT, tipo_veiculo TEXT, capacidade_kg REAL, documentos TEXT NOT NULL DEFAULT '[]', estado_verificacao TEXT NOT NULL DEFAULT 'pendente', motivo_estado TEXT, criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, atualizado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS denuncias (id TEXT PRIMARY KEY, autor_id TEXT NOT NULL REFERENCES profiles(id), denunciado_id TEXT NOT NULL REFERENCES profiles(id), transporte_id TEXT REFERENCES logistica_pedidos(id) ON DELETE SET NULL, categoria TEXT NOT NULL, descricao TEXT NOT NULL, evidencias TEXT NOT NULL DEFAULT '[]', estado TEXT NOT NULL DEFAULT 'pendente', prioridade TEXT NOT NULL DEFAULT 'media', admin_responsavel_id TEXT REFERENCES profiles(id), decisao TEXT, sugestao_ia TEXT, data_resolucao TEXT, criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, CHECK(autor_id <> denunciado_id));
CREATE TABLE IF NOT EXISTS denuncia_historico (id TEXT PRIMARY KEY, denuncia_id TEXT NOT NULL REFERENCES denuncias(id) ON DELETE CASCADE, campo_alterado TEXT NOT NULL, valor_anterior TEXT, valor_novo TEXT, alterado_por TEXT REFERENCES profiles(id), alterado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS reputacao (utilizador_id TEXT PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE, transportes_concluidos INTEGER NOT NULL DEFAULT 0, media_avaliacao REAL, total_avaliacoes INTEGER NOT NULL DEFAULT 0, denuncias_confirmadas INTEGER NOT NULL DEFAULT 0, atualizado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS avaliacoes (id TEXT PRIMARY KEY, avaliador_id TEXT NOT NULL REFERENCES profiles(id), avaliado_id TEXT NOT NULL REFERENCES profiles(id), transporte_id TEXT REFERENCES logistica_pedidos(id) ON DELETE SET NULL, nota INTEGER NOT NULL CHECK(nota BETWEEN 1 AND 5), comentario TEXT, criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(avaliador_id,avaliado_id,transporte_id), CHECK(avaliador_id <> avaliado_id));

CREATE TABLE IF NOT EXISTS sessoes (id TEXT PRIMARY KEY, utilizador_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, token_hash TEXT NOT NULL UNIQUE, expira_em TEXT NOT NULL, criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS password_reset_tokens (id TEXT PRIMARY KEY, utilizador_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, token_hash TEXT NOT NULL UNIQUE, expira_em TEXT NOT NULL, usado INTEGER NOT NULL DEFAULT 0, criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);

CREATE INDEX IF NOT EXISTS idx_relatos_autor ON relatos(autor_id);
CREATE INDEX IF NOT EXISTS idx_relatos_provincia_status ON relatos(provincia,status);
CREATE INDEX IF NOT EXISTS idx_notificacoes_destinatario ON notificacoes(destinatario_id,criado_em);
CREATE INDEX IF NOT EXISTS idx_auditoria_criado ON auditoria(criado_em);
CREATE INDEX IF NOT EXISTS idx_sessoes_token ON sessoes(token_hash);
CREATE INDEX IF NOT EXISTS idx_rate_key_time ON limite_taxa_eventos(chave,criado_em);

-- A conta inicial de administrador-chefe é criada pelo bootstrap do servidor,
-- nunca por um formulário público.

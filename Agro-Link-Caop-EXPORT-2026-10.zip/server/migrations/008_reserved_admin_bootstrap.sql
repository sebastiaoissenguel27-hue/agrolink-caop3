-- Promove contas existentes dos dois emails reservados sem substituir IDs,
-- credenciais ou dados profissionais.
UPDATE profiles
SET papel='admin_chefe',
    status='ativo',
    tipo_perfil=COALESCE(tipo_perfil, CASE WHEN papel IN ('agricultor','tecnico','transportador') THEN papel ELSE 'agricultor' END),
    visibilidade=CASE
      WHEN lower(trim((SELECT email FROM users WHERE users.id=profiles.id)))='sebastiaoissenguel27@gmail.com' THEN 'publico'
      ELSE 'oculto'
    END
WHERE id IN (
  SELECT id FROM users
  WHERE lower(trim(email)) IN ('sebastiaoissenguel27@gmail.com','celcioissenguel@gmail.com')
);

INSERT INTO auditoria(id,ator_id,acao,entidade,entidade_id,detalhes,criado_em)
SELECT lower(hex(randomblob(16))),NULL,'bootstrap_admin_chefe','profiles',p.id,
       json_object('email',u.email,'origem','migration_008'),CURRENT_TIMESTAMP
FROM profiles p JOIN users u ON u.id=p.id
WHERE lower(trim(u.email)) IN ('sebastiaoissenguel27@gmail.com','celcioissenguel@gmail.com')
  AND p.papel='admin_chefe';

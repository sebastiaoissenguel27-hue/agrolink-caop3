ALTER TABLE profiles ADD COLUMN visibilidade TEXT NOT NULL DEFAULT 'publico'
  CHECK (visibilidade IN ('publico','oculto'));

-- Keep all existing account rows, but quarantine duplicate spellings of the reserved addresses.
WITH ranked AS (
  SELECT u.id,
    ROW_NUMBER() OVER (
      PARTITION BY lower(trim(u.email))
      ORDER BY CASE WHEN p.papel='admin_chefe' THEN 0 ELSE 1 END, u.created_at, u.id
    ) AS duplicate_rank
  FROM users u
  LEFT JOIN profiles p ON p.id=u.id
  WHERE lower(trim(u.email)) IN ('sebastiaoissenguel27@gmail.com','celcioissenguel@gmail.com')
)
UPDATE users
SET email='reserved-duplicate-' || replace(id,'-','') || '@invalid.agrolink.local'
WHERE id IN (SELECT id FROM ranked WHERE duplicate_rank>1);

WITH ranked AS (
  SELECT u.id,
    ROW_NUMBER() OVER (
      PARTITION BY lower(trim(u.email))
      ORDER BY CASE WHEN p.papel='admin_chefe' THEN 0 ELSE 1 END, u.created_at, u.id
    ) AS duplicate_rank
  FROM users u
  LEFT JOIN profiles p ON p.id=u.id
  WHERE lower(trim(u.email)) LIKE '%@invalid.agrolink.local'
    AND lower(trim(u.email)) LIKE 'reserved-duplicate-%'
)
UPDATE profiles SET visibilidade='oculto'
WHERE id IN (SELECT id FROM ranked WHERE duplicate_rank>0);

CREATE UNIQUE INDEX IF NOT EXISTS idx_users_reserved_admin_email_unique
  ON users(lower(trim(email)))
  WHERE lower(trim(email)) IN ('sebastiaoissenguel27@gmail.com','celcioissenguel@gmail.com');

CREATE TRIGGER IF NOT EXISTS protect_reserved_admin_email_update
BEFORE UPDATE OF email ON users
WHEN (lower(trim(OLD.email)) IN ('sebastiaoissenguel27@gmail.com','celcioissenguel@gmail.com')
   OR lower(trim(NEW.email)) IN ('sebastiaoissenguel27@gmail.com','celcioissenguel@gmail.com'))
 AND lower(trim(OLD.email))<>lower(trim(NEW.email))
BEGIN
  SELECT RAISE(ABORT, 'reserved administrator email is immutable');
END;

CREATE TRIGGER IF NOT EXISTS enforce_reserved_admin_profile_insert
BEFORE INSERT ON profiles
WHEN lower(trim((SELECT email FROM users WHERE id=NEW.id))) IN ('sebastiaoissenguel27@gmail.com','celcioissenguel@gmail.com')
 AND (NEW.papel<>'admin_chefe' OR NEW.visibilidade<>CASE
   WHEN lower(trim((SELECT email FROM users WHERE id=NEW.id)))='sebastiaoissenguel27@gmail.com' THEN 'publico'
   ELSE 'oculto' END)
BEGIN
  SELECT RAISE(ABORT, 'reserved administrator role and visibility are fixed');
END;

CREATE TRIGGER IF NOT EXISTS enforce_reserved_admin_profile_update
BEFORE UPDATE OF papel,visibilidade ON profiles
WHEN lower(trim((SELECT email FROM users WHERE id=NEW.id))) IN ('sebastiaoissenguel27@gmail.com','celcioissenguel@gmail.com')
 AND (NEW.papel<>'admin_chefe' OR NEW.visibilidade<>CASE
   WHEN lower(trim((SELECT email FROM users WHERE id=NEW.id)))='sebastiaoissenguel27@gmail.com' THEN 'publico'
   ELSE 'oculto' END)
BEGIN
  SELECT RAISE(ABORT, 'reserved administrator role and visibility are fixed');
END;
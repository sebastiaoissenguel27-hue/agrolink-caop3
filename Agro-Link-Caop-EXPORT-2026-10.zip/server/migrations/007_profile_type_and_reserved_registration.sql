-- Separar autorização (`papel`) do perfil profissional (`tipo_perfil`).
ALTER TABLE profiles ADD COLUMN tipo_perfil TEXT CHECK (tipo_perfil IS NULL OR tipo_perfil IN ('agricultor','tecnico','transportador'));

UPDATE profiles
SET tipo_perfil = CASE
  WHEN papel IN ('agricultor','tecnico','transportador') THEN papel
  ELSE NULL
END
WHERE tipo_perfil IS NULL;

-- A regra de identidade reservada passa a ser controlada pelo backend e pela
-- migration 008. Os triggers antigos impediam o registo normal dos emails.
DROP TRIGGER IF EXISTS enforce_reserved_admin_profile_insert;
DROP TRIGGER IF EXISTS enforce_reserved_admin_profile_update;

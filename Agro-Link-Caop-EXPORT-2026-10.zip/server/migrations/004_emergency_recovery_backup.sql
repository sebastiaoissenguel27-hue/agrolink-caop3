CREATE TABLE IF NOT EXISTS platform_security_state (
  id INTEGER PRIMARY KEY CHECK (id=1),
  modo TEXT NOT NULL DEFAULT 'normal' CHECK (modo IN ('normal','alerta','emergencia')),
  funcionalidades_desativadas TEXT NOT NULL DEFAULT '[]',
  motivo TEXT,
  alterado_por TEXT REFERENCES profiles(id),
  alterado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
INSERT OR IGNORE INTO platform_security_state(id,modo,funcionalidades_desativadas,motivo) VALUES(1,'normal','[]','Estado inicial');

CREATE TABLE IF NOT EXISTS password_reset_outbox (
  id TEXT PRIMARY KEY,
  utilizador_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  token_hash TEXT NOT NULL UNIQUE,
  expira_em TEXT NOT NULL,
  estado TEXT NOT NULL DEFAULT 'pendente' CHECK (estado IN ('pendente','enviado','falhou','usado','expirado')),
  criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  enviado_em TEXT,
  erro TEXT
);
CREATE INDEX IF NOT EXISTS idx_password_reset_outbox_email ON password_reset_outbox(email,criado_em);
CREATE INDEX IF NOT EXISTS idx_password_reset_outbox_estado ON password_reset_outbox(estado,criado_em);

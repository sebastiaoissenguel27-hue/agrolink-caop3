-- Keep one canonical address per account identity without deleting legacy rows.
CREATE TEMP TABLE _agrolink_duplicate_emails AS
WITH ranked AS (
  SELECT u.id, u.email,
    ROW_NUMBER() OVER (
      PARTITION BY lower(trim(u.email))
      ORDER BY CASE WHEN p.papel='admin_chefe' THEN 0 ELSE 1 END,
               CASE WHEN p.status='ativo' THEN 0 ELSE 1 END,
               u.created_at, u.id
    ) AS duplicate_rank
  FROM users u
  LEFT JOIN profiles p ON p.id=u.id
)
SELECT id, email FROM ranked WHERE duplicate_rank>1;

UPDATE users
SET email='duplicate-' || lower(hex(CAST(id AS BLOB))) || '@invalid.agrolink.local'
WHERE id IN (SELECT id FROM _agrolink_duplicate_emails);

UPDATE profiles SET visibilidade='oculto'
WHERE id IN (SELECT id FROM _agrolink_duplicate_emails);

INSERT INTO auditoria(id,ator_id,acao,entidade,entidade_id,detalhes,criado_em)
SELECT lower(hex(randomblob(16))),NULL,'quarentena_email_duplicado','users',id,
       json_object('email_anterior',email,'origem','migration_009'),CURRENT_TIMESTAMP
FROM _agrolink_duplicate_emails;

DROP TABLE _agrolink_duplicate_emails;

UPDATE users SET email=lower(trim(email));

CREATE UNIQUE INDEX IF NOT EXISTS idx_users_normalized_email_unique
  ON users(lower(trim(email)));
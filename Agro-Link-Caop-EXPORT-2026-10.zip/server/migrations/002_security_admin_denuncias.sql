ALTER TABLE profiles ADD COLUMN suspenso_em TEXT;
ALTER TABLE profiles ADD COLUMN suspenso_por TEXT REFERENCES profiles(id);
ALTER TABLE profiles ADD COLUMN motivo_suspensao TEXT;
CREATE INDEX IF NOT EXISTS idx_denuncias_estado_prioridade ON denuncias(estado,prioridade,criado_em);
CREATE INDEX IF NOT EXISTS idx_denuncias_denunciado ON denuncias(denunciado_id,criado_em);

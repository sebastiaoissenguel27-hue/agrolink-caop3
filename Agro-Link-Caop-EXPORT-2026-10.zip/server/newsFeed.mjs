export const MAX_FEED_BYTES = 2 * 1024 * 1024;
const AGRICULTURAL_TERMS = [
  'agricultura', 'agricultural', 'agronom', 'milho', 'mandioca', 'soja', 'feijao', 'arroz',
  'horticultura', 'pecuaria', 'gado', 'veterinar', 'pesca', 'florest', 'praga', 'doenca',
  'irrig', 'solo', 'semente', 'fertiliz', 'colheita', 'cultura agricola', 'farmers', 'crop',
];

function decodeXml(value) {
  return String(value || '').replace(/&#(x[\da-f]+|\d+);|&(amp|lt|gt|quot|apos);/gi, (entity, numeric, named) => {
    if (numeric) {
      const point = numeric[0].toLowerCase() === 'x' ? Number.parseInt(numeric.slice(1), 16) : Number.parseInt(numeric, 10);
      try { return String.fromCodePoint(point); } catch { return ''; }
    }
    return ({ amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" })[named.toLowerCase()] || entity;
  });
}

function textValue(value) {
  return decodeXml(String(value || '').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1'))
    .replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
}

function tagValue(block, tag) {
  const match = block.match(new RegExp(`<(?:(?:[\\w.-]+):)?${tag}\\b[^>]*>([\\s\\S]*?)<\\/(?:(?:[\\w.-]+):)?${tag}\\s*>`, 'i'));
  return match ? textValue(match[1]) : '';
}

function linkValue(block) {
  const tags = block.match(/<link\b[^>]*\/?\s*>/gi) || [];
  for (const tag of tags) {
    const href = tag.match(/\bhref\s*=\s*["']([^"']+)["']/i)?.[1];
    if (href) {
      const rel = tag.match(/\brel\s*=\s*["']([^"']+)["']/i)?.[1];
      if (!rel || rel === 'alternate') return decodeXml(href.trim());
    }
  }
  return tagValue(block, 'link');
}

function classify(text) {
  const value = text.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  if (/clima|chuva|seca|temperatura|meteorolog/.test(value)) return 'Clima';
  if (/mercado|preco|precos|exportac|comercio/.test(value)) return 'Mercados';
  if (/praga|doenca|peste|fungo|virus/.test(value)) return 'Pragas e Doenças';
  if (/pecuaria|gado|veterinar|aves|rebanho/.test(value)) return 'Pecuária';
  if (/politica|ministerio|subsidio|governo|regulament/.test(value)) return 'Políticas Públicas';
  if (/pesquisa|investig|universidade|estudo/.test(value)) return 'Investigação';
  if (/tecnolog|maquina|inovacao|digital/.test(value)) return 'Tecnologia';
  if (/formacao|curso|capacitacao/.test(value)) return 'Formação';
  if (/florest|ambiente|conservacao|biodivers/.test(value)) return 'Ambiente';
  return 'Culturas';
}

function isAgricultural(item, source) {
  const text = `${item.title} ${item.summary} ${item.content} ${item.category || ''} ${source.categoria || ''}`
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  return AGRICULTURAL_TERMS.some((term) => text.includes(term));
}

function validateXml(xml) {
  if (/<!\s*(?:DOCTYPE|ENTITY)\b/i.test(xml)) throw new Error('XML inválido.');
  const stack = [];
  let roots = 0;
  let cursor = xml.charCodeAt(0) === 0xfeff ? 1 : 0;

  while (cursor < xml.length) {
    if (xml[cursor] !== '<') {
      const next = xml.indexOf('<', cursor);
      const text = xml.slice(cursor, next < 0 ? xml.length : next);
      if (stack.length === 0 && text.trim()) throw new Error('XML inválido.');
      if (/&(?!#(?:x[\da-f]+|\d+);|(?:amp|lt|gt|quot|apos);)/i.test(text)) throw new Error('XML inválido.');
      cursor = next < 0 ? xml.length : next;
      continue;
    }

    if (xml.startsWith('<!--', cursor)) {
      const end = xml.indexOf('-->', cursor + 4);
      if (end < 0 || xml.slice(cursor + 4, end).includes('--')) throw new Error('XML inválido.');
      cursor = end + 3;
      continue;
    }
    if (xml.startsWith('<![CDATA[', cursor)) {
      const end = xml.indexOf(']]>', cursor + 9);
      if (end < 0 || stack.length === 0) throw new Error('XML inválido.');
      cursor = end + 3;
      continue;
    }
    if (xml.startsWith('<?', cursor)) {
      const end = xml.indexOf('?>', cursor + 2);
      if (end < 0) throw new Error('XML inválido.');
      cursor = end + 2;
      continue;
    }

    let end = cursor + 1;
    let quote = null;
    for (; end < xml.length; end += 1) {
      const character = xml[end];
      if (quote) {
        if (character === quote) quote = null;
      } else if (character === '"' || character === "'") quote = character;
      else if (character === '>') break;
    }
    if (end >= xml.length || quote) throw new Error('XML inválido.');
    const token = xml.slice(cursor, end + 1);
    const closing = token.match(/^<\/([A-Za-z_][\w.:-]*)\s*>$/);
    if (closing) {
      if (stack.pop() !== closing[1]) throw new Error('XML inválido.');
      cursor = end + 1;
      continue;
    }
    const opening = token.match(/^<([A-Za-z_][\w.:-]*)([\s\S]*)>$/);
    if (!opening) throw new Error('XML inválido.');
    let attributes = opening[2].replace(/\/\s*$/, '');
    while (attributes.trim()) {
      const attribute = attributes.match(/^\s+([A-Za-z_][\w.:-]*)\s*=\s*(?:"[^"]*"|'[^']*')/);
      if (!attribute) throw new Error('XML inválido.');
      attributes = attributes.slice(attribute[0].length);
    }
    if (stack.length === 0) roots += 1;
    if (!/\/\s*>$/.test(token)) stack.push(opening[1]);
    cursor = end + 1;
  }

  if (roots !== 1 || stack.length) throw new Error('XML inválido.');
}

export function parseNewsFeed(xml, source = {}) {
  if (typeof xml !== 'string' || !xml.trim() || new TextEncoder().encode(xml).byteLength > MAX_FEED_BYTES) {
    throw new Error('Feed vazio ou acima do limite de 2 MB.');
  }
  validateXml(xml);
  const blocks = xml.match(/<(?:[\w.-]+:)?(?:item|entry)\b[^>]*>[\s\S]*?<\/(?:[\w.-]+:)?(?:item|entry)\s*>/gi) || [];
  const items = [];
  for (const block of blocks.slice(0, 100)) {
    const title = tagValue(block, 'title').slice(0, 300);
    const summary = (tagValue(block, 'description') || tagValue(block, 'summary')).slice(0, 2000);
    const content = (tagValue(block, 'encoded') || tagValue(block, 'content') || summary).slice(0, 10000);
    const originalUrl = linkValue(block);
    const category = tagValue(block, 'category').slice(0, 80) || source.categoria || null;
    let safeUrl = null;
    try {
      const parsed = new URL(originalUrl);
      if (['http:', 'https:'].includes(parsed.protocol) && !parsed.username && !parsed.password) safeUrl = parsed.href;
    } catch {}
    if (!title || !safeUrl) continue;
    const item = { title, summary, content, category, originalUrl: safeUrl, publishedAt: tagValue(block, 'pubDate') || tagValue(block, 'published') || tagValue(block, 'updated') };
    if (!isAgricultural(item, source)) continue;
    const timestamp = Date.parse(item.publishedAt);
    items.push({
      titulo: title,
      resumo: summary || null,
      conteudo: content || summary || title,
      categoria: category,
      categoria_ia: classify(`${title} ${summary} ${category || ''}`),
      pais: source.pais || null,
      relevante: 1,
      publicado_em: Number.isFinite(timestamp) ? new Date(timestamp).toISOString() : new Date().toISOString(),
      url_original: safeUrl,
    });
  }
  return items;
}

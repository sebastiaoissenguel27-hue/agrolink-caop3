export class StorageAdapter {
  async put() { throw new Error('Not implemented'); }
  async head() { throw new Error('Not implemented'); }
  async get() { throw new Error('Not implemented'); }
  async delete() { throw new Error('Not implemented'); }
}

export class StorageConflictError extends Error {
  constructor(message = 'Storage key already contains different content.') {
    super(message);
    this.name = 'StorageConflictError';
  }
}
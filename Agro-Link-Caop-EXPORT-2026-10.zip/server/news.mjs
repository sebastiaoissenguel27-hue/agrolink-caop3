import { lookup } from 'node:dns/promises';
import { isIP } from 'node:net';
import crypto from 'node:crypto';
import { MAX_FEED_BYTES, parseNewsFeed } from './newsFeed.mjs';
export { parseNewsFeed } from './newsFeed.mjs';

function isPublicAddress(address) {
  if (isIP(address) === 4) {
    const octets = address.split('.').map(Number);
    const [a, b] = octets;
    return !(a === 0 || a === 10 || a === 127 || a >= 224 || (a === 100 && b >= 64 && b <= 127)
      || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31)
      || (a === 192 && b === 168) || (a === 192 && b === 0) || (a === 198 && (b === 18 || b === 19)));
  }
  const parts = address.toLowerCase().split(':');
  const first = Number.parseInt(parts[0] || '0', 16);
  const second = Number.parseInt(parts[1] || '0', 16);
  return first >= 0x2000 && first <= 0x3fff && !(first === 0x2001 && second <= 0x01ff) && !(first === 0x2001 && second === 0x0db8);
}

async function validateFeedUrl(rawUrl, lookupImpl) {
  const url = new URL(rawUrl);
  if (url.protocol !== 'https:' || url.username || url.password) throw new Error('A fonte RSS deve usar HTTPS e não pode conter credenciais.');
  if (url.port && url.port !== '443') throw new Error('A fonte RSS deve usar a porta HTTPS padrão.');
  const hostname = url.hostname.toLowerCase();
  if (hostname === 'localhost' || hostname.endsWith('.localhost') || hostname.endsWith('.local')) throw new Error('Destino RSS local não permitido.');
  const addresses = isIP(hostname) ? [{ address: hostname }] : await lookupImpl(hostname, { all: true, verbatim: true });
  if (!addresses.length || addresses.some(({ address }) => !isPublicAddress(address))) throw new Error('Destino RSS privado ou não resolvido.');
  return url;
}

export async function synchronizeNewsFeeds({ db, fetchImpl = fetch, lookupImpl = lookup }) {
  const sources = db.prepare('SELECT id,nome,url_rss,categoria,ativo,ambito,pais,prioridade FROM noticias_fontes WHERE ativo=1 AND url_rss IS NOT NULL ORDER BY prioridade DESC LIMIT 100').all();
  const result = { fontes_processadas: 0, inseridas: 0, ignoradas: 0, erros: [] };
  for (const source of sources) {
    result.fontes_processadas += 1;
    let inserted = 0;
    let ignored = 0;
    let errorMessage = null;
    try {
      const url = await validateFeedUrl(source.url_rss, lookupImpl);
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 10000);
      let response;
      let xml;
      try {
        response = await fetchImpl(url, { signal: controller.signal, redirect: 'manual', headers: { accept: 'application/rss+xml, application/atom+xml, application/xml, text/xml' } });
        if (!response.ok || response.status >= 300) throw new Error(`Feed respondeu HTTP ${response.status}.`);
        if (response.body?.getReader) {
          const reader = response.body.getReader();
          const chunks = [];
          let size = 0;
          try {
            while (true) {
              const { done, value } = await reader.read();
              if (done) break;
              size += value.byteLength;
              if (size > MAX_FEED_BYTES) { await reader.cancel(); throw new Error('Feed acima do limite de 2 MB.'); }
              chunks.push(Buffer.from(value));
            }
          } finally { reader.releaseLock(); }
          xml = Buffer.concat(chunks).toString('utf8');
        } else {
          xml = await response.text();
          if (Buffer.byteLength(xml, 'utf8') > MAX_FEED_BYTES) throw new Error('Feed acima do limite de 2 MB.');
        }
      } finally { clearTimeout(timeout); }
      for (const item of parseNewsFeed(xml, source)) {
        const outcome = db.prepare('INSERT OR IGNORE INTO noticias(id,titulo,resumo,conteudo,categoria,categoria_ia,pais,relevante,publicado_em,url_original,fonte_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
          .run(crypto.randomUUID(), item.titulo, item.resumo, item.conteudo, item.categoria, item.categoria_ia, item.pais, item.relevante, item.publicado_em, item.url_original, source.id);
        if (outcome.changes) inserted += 1;
        else ignored += 1;
      }
    } catch (error) {
      errorMessage = String(error?.message || error).slice(0, 500);
      result.erros.push(`${String(source.nome || 'Fonte RSS').slice(0, 100)}: ${errorMessage}`);
    }
    result.inseridas += inserted;
    result.ignoradas += ignored;
    db.prepare('INSERT INTO noticias_sync_logs(id,fonte_id,sucesso,itens_inseridos,itens_ignorados,mensagem_erro,executado_em) VALUES(?,?,?,?,?,?,?)')
      .run(crypto.randomUUID(), source.id, errorMessage ? 0 : 1, inserted, ignored, errorMessage, new Date().toISOString());
  }
  return result;
}
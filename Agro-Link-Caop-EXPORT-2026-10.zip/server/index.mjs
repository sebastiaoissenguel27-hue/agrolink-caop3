import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { URL } from 'node:url';
import { db, hydrate, jsonColumn } from './db.mjs';
import { Readable } from 'node:stream';
import { SQLiteDatabaseAdapter } from './databaseAdapter.mjs';
import { clientIp, isIpBlocked, evaluateSecuritySignal, generateMonthlySecurityReport, startSecurityScheduler, getSecurityState, setSecurityState, securityFeatureForPath } from './securityTrust.mjs';
import { createDatabaseBackup, listDatabaseBackups, verifyDatabaseIntegrity, startBackupScheduler } from './backup.mjs';
import { aiProvider } from './aiProvider.mjs';
import { createStorageAdapter, StorageConflictError } from './storageAdapter.mjs';
import { synchronizeNewsFeeds } from './news.mjs';

const PORT = Number(process.env.PORT || 8787);
const IS_PROD = process.env.NODE_ENV === 'production';
if (IS_PROD && !String(process.env.AGROLINK_PASSWORD_RESET_WEBHOOK_URL || '').trim()) console.warn('AgroLink: recuperação de palavra-passe sem provedor de entrega configurado.');
if (IS_PROD && !String(process.env.AGROLINK_SECURITY_ALERT_WEBHOOK_URL || '').trim()) console.warn('AgroLink: alertas externos de segurança não configurados; serão usadas notificações internas.');
const DIST = path.resolve('dist');
const DATA_DIR = path.resolve(process.env.AGROLINK_DATA_DIR || 'data');
const UPLOADS = path.resolve(process.env.AGROLINK_UPLOADS_DIR || path.join(DATA_DIR, 'uploads'));
const databaseAdapter = new SQLiteDatabaseAdapter(db);
const storageAdapter = createStorageAdapter({
  env: process.env,
  provider: process.env.STORAGE_PROVIDER || 'local',
  rootDirectory: UPLOADS,
});

const PUBLIC_READ = new Set(['noticias','alertas','recursos_externos','perguntas_frequentes','biblioteca_documentos','academia_cursos','academia_licoes','noticias_fontes','mercado_produtos','logistica_transportadoras']);
const ADMIN_ONLY = new Set(['auditoria','logs_seguranca','ia_resumos_mensais','noticias_sync_logs','sie_indicadores','sensores','leituras_sensor','limite_taxa_eventos']);
const USER_OWNED = new Set(['relatos','relato_midias','relato_respostas','ia_conversas','ia_mensagens','ferramenta_calculos','preferencias_utilizador','academia_progresso','notificacoes','dispositivos_push','tecnico_documentos','transportadores','denuncias','denuncia_historico','reputacao','avaliacoes','logistica_pedidos','mercado_produtos','profiles']);
const ADMIN_WRITE = new Set(['noticias','alertas','recursos_externos','perguntas_frequentes','biblioteca_documentos','academia_cursos','academia_licoes','academia_questionarios','noticias_fontes','logistica_transportadoras','mercado_produtos','transportadores','denuncias']);
const COLUMN_ALLOWLIST = {
  profiles: ['nome','papel','tipo_perfil','nivel_admin','provincia','municipio','comuna','telefone','status','verification_status','suspenso_em','suspenso_por','motivo_suspensao','visibilidade'],
  relatos: ['id','autor_id','tipo','descricao','provincia','municipio','comuna','status','tecnico_atribuido_id','criado_em'],
  relato_midias: ['id','relato_id','tipo','caminho_storage','criado_em'],
  relato_respostas: ['id','relato_id','tecnico_id','comentario','criado_em'],
  noticias: ['id','titulo','resumo','conteudo','imagem_url','autor_id','categoria','categoria_ia','pais','relevante','publicado_em','url_original','fonte_id'],
  alertas: ['id','titulo','descricao','tipo','provincias_alvo','nivel','criado_por','criado_em','expira_em'],
  ia_conversas: ['id','utilizador_id','criado_em'], ia_mensagens: ['id','conversa_id','role','conteudo','criado_em'],
  auditoria: ['id','ator_id','acao','entidade','entidade_id','detalhes','criado_em'],
  denuncias: ['id','autor_id','denunciado_id','transporte_id','categoria','descricao','evidencias','estado','prioridade','admin_responsavel_id','decisao','sugestao_ia','data_resolucao','criado_em'],
  notificacoes: ['id','destinatario_id','titulo','corpo','tipo','lida','relacionado_tipo','relacionado_id','criado_em'],
  preferencias_utilizador: ['utilizador_id','notif_respostas_relato','notif_noticias','notif_alertas','notif_novos_cursos','notif_progresso_academia','notif_calendario_agricola','idioma','atualizado_em'],
  ferramenta_calculos: ['id','utilizador_id','ferramenta','entradas','resultado','criado_em'],
  recursos_externos: ['id','titulo','descricao','categoria','url','contacto','criado_em'], perguntas_frequentes: ['id','pergunta','resposta','categoria','ordem','criado_em'],
  biblioteca_documentos: ['id','titulo','descricao','categoria','tipo','caminho_storage','url_externo','autor_id','publicado_em'],
  academia_cursos: ['id','titulo','descricao','categoria','autor_id','publicado_em'], academia_licoes: ['id','curso_id','titulo','tipo','conteudo_texto','caminho_storage','ordem','criado_em'], academia_questionarios: ['id','licao_id','pergunta','opcoes','resposta_correta','ordem'], academia_progresso: ['utilizador_id','licao_id','concluida','pontuacao_questionario','atualizado_em'],
  noticias_fontes: ['id','nome','url_rss','categoria','ativo','ambito','pais','prioridade','criado_em'], noticias_sync_logs: ['id','fonte_id','sucesso','itens_inseridos','itens_ignorados','mensagem_erro','executado_em'],
  ia_perguntas_analytics: ['id','utilizador_id','provincia','tema','culturas','pragas','confianca','encaminhado','criado_em'], ia_resumos_mensais: ['id','mes','ano','conteudo','gerado_em'],
  logs_seguranca: ['id','tipo','utilizador_id','nivel_risco','detalhes','criado_em'], limite_taxa_eventos: ['id','chave','criado_em'],
  transportadores: ['utilizador_id','foto_url','foto_camiao_url','matricula','tipo_veiculo','capacidade_kg','documentos','estado_verificacao','motivo_estado','criado_em','atualizado_em'],
  mercado_produtos: ['id','vendedor_id','nome','categoria','preco','unidade','quantidade_disponivel','provincia','ativo','criado_em'],
  logistica_transportadoras: ['id','nome','provincia','contacto','capacidade_kg','ativo','utilizador_id','criado_em'],
  logistica_pedidos: ['id','solicitante_id','transportadora_id','origem_provincia','destino_provincia','produto_descricao','quantidade_kg','status','criado_em'],
};

function now() { return new Date().toISOString(); }
function uuid() { return crypto.randomUUID(); }
function hashToken(token) { return crypto.createHash('sha256').update(token).digest('hex'); }
function passwordHash(password, salt) { return crypto.pbkdf2Sync(password, Buffer.from(salt,'hex'), 210000, 64, 'sha512').toString('hex'); }
function validPassword(password) { return typeof password === 'string' && password.length >= 8 && password.length <= 128; }
function securityHeaders() { return {'x-content-type-options':'nosniff','x-frame-options':'DENY','referrer-policy':'strict-origin-when-cross-origin','permissions-policy':'camera=(), microphone=(), geolocation=()','content-security-policy': IS_PROD ? "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'" : "default-src 'self' 'unsafe-inline' 'unsafe-eval' data: blob:; connect-src 'self' http://localhost:4173 ws://localhost:4173"}; }
function json(res, status, body, headers = {}) { const data = JSON.stringify(body); res.writeHead(status, {'content-type':'application/json; charset=utf-8', ...securityHeaders(), ...headers}); res.end(data); }
function error(res, status, message) { return json(res, status, { error: message }); }
function parseCookie(req, name) { const raw = req.headers.cookie || ''; const hit = raw.split(';').map(x=>x.trim()).find(x=>x.startsWith(name+'=')); return hit ? decodeURIComponent(hit.slice(name.length+1)) : null; }
function isSameOriginRequest(req, origin) {
  try {
    const forwardedProtocol=String(process.env.AGROLINK_TRUST_PROXY||'false').toLowerCase()==='true' ? String(req.headers['x-forwarded-proto']||'').split(',')[0].trim() : '';
    const protocol=forwardedProtocol || (IS_PROD?'https':'http');
    return new URL(origin).origin===new URL(`${protocol}://${req.headers.host||'localhost'}`).origin;
  } catch { return false; }
}
async function body(req) { const chunks=[]; let total=0; for await (const c of req) { total+=c.length; if(total>25*1024*1024) throw new Error('Pedido demasiado grande.'); chunks.push(c); } if (!chunks.length) return {}; try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { throw new Error('JSON inválido.'); } }

function currentUser(req) {
  const token = parseCookie(req,'agrolink_session');
  if (!token) return null;
  const row = db.prepare(`SELECT s.utilizador_id, s.expira_em, u.email, p.id, p.nome, p.papel, p.tipo_perfil, p.nivel_admin, p.status, p.verification_status, p.provincia, p.municipio, p.comuna, p.telefone FROM sessoes s JOIN users u ON u.id=s.utilizador_id JOIN profiles p ON p.id=u.id WHERE s.token_hash=? AND s.expira_em>?`).get(hashToken(token), now());
  return row ? hydrate(row) : null;
}
function requireAuth(req,res) { const user=currentUser(req); if(!user) { error(res,401,'Sessão necessária.'); return null; } if(user.status==='bloqueado') { error(res,403,'Conta bloqueada.'); return null; } if(user.status==='pendente') { error(res,403,'A conta aguarda aprovação.'); return null; } return user; }
function isAdmin(user) { return ['admin','admin_chefe'].includes(user?.papel); }
function canWriteAdmin(user) { return user?.papel === 'admin_chefe' || (user?.papel === 'admin' && user?.nivel_admin !== 'auditor'); }
function isChief(user) { return user?.papel === 'admin_chefe'; }
function isTech(user) { return user?.papel === 'utilizador' && user?.tipo_perfil === 'tecnico' && user?.verification_status === 'aprovado'; }
function isFarmer(user) { return user?.papel === 'utilizador' && user?.tipo_perfil === 'agricultor'; }
function isTransporter(user) { return user?.papel === 'utilizador' && !!db.prepare("SELECT 1 FROM transportadores WHERE utilizador_id=? AND estado_verificacao='aprovado'").get(user.utilizador_id); }
function isReadOnlyAdmin(user) { return user?.papel === 'admin' && user?.nivel_admin === 'auditor'; }

function audit(user, acao, entidade, entidadeId=null, detalhes={}) {
  db.prepare(`INSERT INTO auditoria(id,ator_id,acao,entidade,entidade_id,detalhes,criado_em) VALUES(?,?,?,?,?,?,?)`).run(uuid(),user?.utilizador_id||null,acao,entidade,entidadeId,JSON.stringify(detalhes),now());
}
function security(type,user,level,details={}) {
  db.prepare(`INSERT INTO logs_seguranca(id,tipo,utilizador_id,nivel_risco,detalhes,criado_em) VALUES(?,?,?,?,?,?)`).run(uuid(),type,user?.utilizador_id||null,level,JSON.stringify(details),now());
}

const ADMIN_CHEFE_PUBLIC_EMAIL = 'sebastiaoissenguel27@gmail.com';
const ADMIN_CHEFE_HIDDEN_EMAIL = 'celcioissenguel@gmail.com';
const LEGACY_ADMIN_CHEFE_EMAIL = String(process.env.AGROLINK_ADMIN_CHEFE_EMAIL || ADMIN_CHEFE_PUBLIC_EMAIL).trim().toLowerCase();
const RESERVED_ADMIN_CHEFE_EMAILS = new Set([ADMIN_CHEFE_PUBLIC_EMAIL, ADMIN_CHEFE_HIDDEN_EMAIL]);

async function deliverPasswordReset({ email, nome, recoveryUrl, token }) {
  const endpoint=String(process.env.AGROLINK_PASSWORD_RESET_WEBHOOK_URL||'').trim();
  if(endpoint){
    try{
      const r=await fetch(endpoint,{method:'POST',headers:{'content-type':'application/json','x-agrolink-event':'password_reset'},body:JSON.stringify({source:'AgroLink Caop',event:'password_reset',email,nome,recoveryUrl,token,expiresInMinutes:60})});
      if(!r.ok) throw new Error(`HTTP ${r.status}`);
      return {sent:true,mode:'webhook'};
    }catch(error){ return {sent:false,mode:'webhook',error:String(error?.message||error)}; }
  }
  if(!IS_PROD || process.env.AGROLINK_ALLOW_DEV_RECOVERY_LINK==='true') return {sent:true,mode:'development'};
  return {sent:false,mode:'none',error:'Nenhum provedor de entrega de recuperação configurado.'};
}

async function optionalOpenAiAgriculturalResponse(messages) {
  const key = String(process.env.OPENAI_API_KEY || '').trim();
  if (process.env.AGROLINK_AI_OPENAI_FALLBACK !== 'true' || !key) return null;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), Number(process.env.AGROLINK_AGRI_AI_TIMEOUT_MS || 12000));
  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      signal: controller.signal,
      headers: { 'content-type': 'application/json', authorization: `Bearer ${key}` },
      body: JSON.stringify({ model: process.env.OPENAI_MODEL || 'gpt-4o-mini', messages, max_tokens: 700, temperature: 0.2 }),
    });
    if (!response.ok) return null;
    const data = await response.json();
    const content = data?.choices?.[0]?.message?.content;
    return typeof content === 'string' && content.trim() ? content.trim() : null;
  } catch (error) {
    if (error?.name !== 'AbortError') console.error('Optional OpenAI fallback failed:', error?.message || error);
    return null;
  } finally {
    clearTimeout(timeout);
  }
}


function bootstrapChiefAccounts() {
  const configuredAccounts = new Map([
    [LEGACY_ADMIN_CHEFE_EMAIL, { password: process.env.AGROLINK_ADMIN_CHEFE_PASSWORD || '', visibilidade: 'publico', tipoPerfil: 'agricultor' }],
    [ADMIN_CHEFE_PUBLIC_EMAIL, { password: process.env.AGROLINK_ADMIN_CHEFE_PUBLIC_PASSWORD || (LEGACY_ADMIN_CHEFE_EMAIL === ADMIN_CHEFE_PUBLIC_EMAIL ? process.env.AGROLINK_ADMIN_CHEFE_PASSWORD : '') || '', visibilidade: 'publico', tipoPerfil: 'agricultor' }],
    [ADMIN_CHEFE_HIDDEN_EMAIL, { password: process.env.AGROLINK_ADMIN_CHEFE_HIDDEN_PASSWORD || '', visibilidade: 'oculto', tipoPerfil: 'tecnico' }],
  ]);

  for (const [email, config] of configuredAccounts) {
    if (!email || !email.includes('@') || !validPassword(config.password)) continue;
    const existingUser = db.prepare('SELECT id FROM users WHERE lower(trim(email))=?').get(email);
    const id = existingUser?.id || uuid();
    const salt = crypto.randomBytes(16).toString('hex');
    db.exec('BEGIN IMMEDIATE');
    try {
      if (existingUser) {
        const profile = db.prepare('SELECT id FROM profiles WHERE id=?').get(id);
        if (profile) {
          db.prepare("UPDATE profiles SET papel='admin_chefe',status='ativo',visibilidade=?,tipo_perfil=COALESCE(tipo_perfil,?) WHERE id=?")
            .run(config.visibilidade,config.tipoPerfil,id);
        } else {
          db.prepare("INSERT INTO profiles(id,nome,papel,tipo_perfil,status,visibilidade,criado_em) VALUES(?,?,'admin_chefe',?,'ativo',?,?)")
            .run(id,'Administrador Chefe',config.tipoPerfil,config.visibilidade,now());
        }
      } else {
        db.prepare('INSERT INTO users(id,email,password_hash,password_salt) VALUES(?,?,?,?)')
          .run(id,email,passwordHash(config.password,salt),salt);
        db.prepare("INSERT INTO profiles(id,nome,papel,tipo_perfil,status,visibilidade,criado_em) VALUES(?,?,'admin_chefe',?,'ativo',?,?)")
          .run(id,'Administrador Chefe',config.tipoPerfil,config.visibilidade,now());
      }
      audit(null, existingUser ? 'provisionar_admin_chefe' : 'criar_admin_chefe', 'profiles', id, {email, origem:'bootstrap-servidor'});
      db.exec('COMMIT');
    } catch (error) {
      try { db.exec('ROLLBACK'); } catch {}
      throw error;
    }
  }
}
bootstrapChiefAccounts();
startSecurityScheduler();
startBackupScheduler();

function normalizeForDb(table, obj) {
  const allowed=COLUMN_ALLOWLIST[table]; if(!allowed) throw new Error('Tabela não suportada.');
  const out={}; for(const [k,v] of Object.entries(obj||{})) { if(!allowed.includes(k)) continue; if(['provincias_alvo','entradas','resultado','opcoes','culturas','pragas','documentos','evidencias','sugestao_ia','detalhes'].includes(k)) out[k]=jsonColumn(v, Array.isArray(v)?'[]':null); else if(typeof v==='boolean') out[k]=v?1:0; else out[k]=v; }
  return out;
}
function rowSelect(table, rows) { return rows.map(hydrate); }
function canReadTable(user, table) {
  if (PUBLIC_READ.has(table)) return true;
  if (!user) return false;
  if (ADMIN_ONLY.has(table)) return isAdmin(user);
  if (table==='academia_questionarios') return isAdmin(user);
  if (table==='profiles') return !!user && (isAdmin(user) || true);
  return USER_OWNED.has(table);
}
function scopedWhere(user, table, filters) {
  const where=[]; const params=[];
  if (table==='mercado_produtos') {
    if(isAdmin(user)) return {where,params};
    where.push(user ? '(ativo=1 OR vendedor_id=?)' : 'ativo=1');
    if(user) params.push(user.utilizador_id);
    return {where,params};
  }
  if (!user) return {where,params};
  if (isAdmin(user)) return {where,params};
  if (table==='logistica_pedidos') {
    const farmer=isFarmer(user), transporter=isTransporter(user);
    const carrierScope="(transportadora_id IN (SELECT id FROM logistica_transportadoras WHERE utilizador_id=?) OR (status='pedido' AND transportadora_id IS NULL AND EXISTS (SELECT 1 FROM transportadores WHERE utilizador_id=? AND estado_verificacao='aprovado')))";
    if(farmer && transporter) { where.push(`(solicitante_id=? OR ${carrierScope})`); params.push(user.utilizador_id,user.utilizador_id,user.utilizador_id); }
    else if(farmer) { where.push('solicitante_id=?'); params.push(user.utilizador_id); }
    else if(transporter) { where.push(carrierScope); params.push(user.utilizador_id,user.utilizador_id); }
    else where.push('1=0');
    return {where,params};
  }
  if (table==='profiles') { where.push('id=?'); params.push(user.utilizador_id); }
  else if (table==='relatos') { if (!isTech(user)) { where.push('autor_id=?'); params.push(user.utilizador_id); } }
  else if (['notificacoes','preferencias_utilizador','ferramenta_calculos','ia_conversas','academia_progresso','dispositivos_push','tecnico_documentos','transportadores','reputacao'].includes(table)) { const col=table==='preferencias_utilizador'?'utilizador_id':table==='ia_conversas'?'utilizador_id':table==='academia_progresso'?'utilizador_id':table==='tecnico_documentos'?'tecnico_id':table==='dispositivos_push'?'utilizador_id':table==='transportadores'?'utilizador_id':table==='reputacao'?'utilizador_id':'destinatario_id'; where.push(`${col}=?`); params.push(user.utilizador_id); }
  else if (table==='ia_mensagens') { where.push('conversa_id IN (SELECT id FROM ia_conversas WHERE utilizador_id=?)'); params.push(user.utilizador_id); }
  else if (table==='relato_midias') { if (!isTech(user)) { where.push('relato_id IN (SELECT id FROM relatos WHERE autor_id=?)'); params.push(user.utilizador_id); } }
  else if (table==='relato_respostas') { if (!isTech(user)) { where.push('relato_id IN (SELECT id FROM relatos WHERE autor_id=?)'); params.push(user.utilizador_id); } }
  else if (table==='ferramenta_calculos') { where.push('utilizador_id=?'); params.push(user.utilizador_id); }
  else if (table==='denuncias') { where.push('autor_id=?'); params.push(user.utilizador_id); }
  return {where,params};
}
function applyFilters(table, url, user) {
  const {where,params}=scopedWhere(user,table,{});
  for (const key of ['id','status','tipo','categoria','categoria_ia','provincia','papel','verification_status','curso_id','licao_id','relato_id','destinatario_id','utilizador_id','tecnico_id','autor_id','fonte_id','ativo','nivel']) {
    const value=url.searchParams.get(key); if(value===null || !COLUMN_ALLOWLIST[table]?.includes(key)) continue;
    if(table==='noticias' && key==='categoria') { where.push('(categoria=? OR categoria_ia=?)'); params.push(value,value); }
    else { where.push(`${key}=?`); params.push(value==='true'?1:value==='false'?0:value); }
  }
  const pesquisa=url.searchParams.get('pesquisa'); if(pesquisa && table==='noticias') { where.push(`(lower(titulo) LIKE ? OR lower(coalesce(resumo,'')) LIKE ?)`); const p='%'+pesquisa.toLowerCase()+'%'; params.push(p,p); }
  return {where,params};
}

async function handle(req,res) {
  const url=new URL(req.url,`http://${req.headers.host||'localhost'}`); const pathname=url.pathname; const ip=clientIp(req);
  if(req.method==='OPTIONS'){
    const origin=String(req.headers.origin||'');
    if(origin&&!isSameOriginRequest(req,origin))return error(res,403,'Origem do pedido não autorizada.');
    const corsHeaders=origin?{'access-control-allow-origin':origin,'access-control-allow-credentials':'true','vary':'Origin'}:{};
    res.writeHead(204,{'access-control-allow-headers':'content-type, x-csrf-token','access-control-allow-methods':'GET,POST,PATCH,PUT,DELETE,OPTIONS',...corsHeaders,...securityHeaders()});return res.end();
  }
  try {
    if(['POST','PATCH','PUT','DELETE'].includes(req.method) && pathname.startsWith('/api/') && req.headers.origin && !isSameOriginRequest(req,req.headers.origin)){ await evaluateSecuritySignal({type:'payload_suspeito',ip,details:{motivo:'origin_invalida',endpoint:pathname}}); return error(res,403,'Origem do pedido não autorizada.'); }
    const bucket=globalThis.__agrolinkRate||(globalThis.__agrolinkRate=new Map()); const rt=Date.now(); const hit=bucket.get(ip); if(!hit||rt-hit.t>60000){bucket.set(ip,{t:rt,n:1});}else{hit.n++; if(hit.n>120){await evaluateSecuritySignal({type:'rate_limit_excedido',ip,details:{endpoint:pathname,critical:true}}); return error(res,429,'Demasiados pedidos. Tente novamente mais tarde.');}}
    const contentLength=Number(req.headers['content-length']||0);
    if(contentLength>25*1024*1024){ await evaluateSecuritySignal({type:'payload_suspeito',ip,details:{contentLength}}); return error(res,413,'Pedido demasiado grande.'); }
    if(isIpBlocked(ip)){ return error(res,429,'Origem temporariamente contida pelo sistema de segurança.'); }
    const emergencyState=getSecurityState();
    const emergencyFeature=securityFeatureForPath(pathname);
    if(emergencyState.modo==='emergencia' && emergencyFeature && emergencyState.funcionalidades_desativadas.includes(emergencyFeature)){
      const known=currentUser(req);
      const allowedBypass=known && known.papel==='admin_chefe';
      if(!allowedBypass) return error(res,503,`Funcionalidade temporariamente protegida pelo Modo de Emergência (${emergencyFeature}).`);
    }
    if(pathname==='/api/health') return json(res,200,{ok:true,database:'internal',timestamp:now()});
    if(pathname==='/api/public/team' && req.method==='GET') {
      const members=db.prepare(`SELECT p.id,p.nome,p.papel,p.provincia FROM profiles p JOIN users u ON u.id=p.id
        WHERE lower(trim(u.email))=? AND p.papel='admin_chefe' AND p.status='ativo' AND p.visibilidade='publico'`)
        .all(ADMIN_CHEFE_PUBLIC_EMAIL);
      return json(res,200,members.map((member)=>({...member,identidade:'equipa_oficial'})));
    }
    if(pathname==='/api/auth/register' && req.method==='POST'){
      const b=await body(req); const email=String(b.email||'').trim().toLowerCase(), password=String(b.password||''), nome=String(b.nome||'').trim();
      if(!email || !email.includes('@') || !nome || !validPassword(password)) return error(res,400,'Dados de registo inválidos.');
      const tipoPerfilSolicitado=['agricultor','tecnico','administrador'].includes(b.tipo_perfil) ? b.tipo_perfil : 'agricultor';
      if(db.prepare('SELECT 1 FROM users WHERE lower(trim(email))=?').get(email)) return error(res,409,'Este email já está registado.');
      const isReservedChief=RESERVED_ADMIN_CHEFE_EMAILS.has(email);
      const papel = isReservedChief ? 'admin_chefe' : 'utilizador';
      const tipoPerfil = tipoPerfilSolicitado;
      const status = isReservedChief ? 'ativo' : 'pendente';
      const verificationStatus = tipoPerfil==='tecnico'?'pendente':null;
      const visibilidade = email === ADMIN_CHEFE_HIDDEN_EMAIL ? 'oculto' : 'publico';
      const id=uuid(), salt=crypto.randomBytes(16).toString('hex');
      db.exec('BEGIN IMMEDIATE');
      try {
        db.prepare(`INSERT INTO users(id,email,password_hash,password_salt) VALUES(?,?,?,?)`).run(id,email,passwordHash(password,salt),salt);
        db.prepare(`INSERT INTO profiles(id,nome,papel,tipo_perfil,provincia,municipio,comuna,telefone,status,verification_status,visibilidade,criado_em) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`)
          .run(id,nome,papel,tipoPerfil,b.provincia||null,b.municipio||null,b.comuna||null,b.telefone||null,status,verificationStatus,visibilidade,now());
        security('registo',{utilizador_id:id},'baixo',{email,papel,tipo_perfil:tipoPerfil});
        db.exec('COMMIT');
      } catch (registrationError) {
        try { db.exec('ROLLBACK'); } catch {}
        if (/UNIQUE constraint failed/i.test(String(registrationError?.message || ''))) return error(res,409,'Este email já está registado.');
        throw registrationError;
      }
      return json(res,201,{status:'criada',confirmacao_pendente:false,admin_chefe:isReservedChief});
    }
    if(pathname==='/api/auth/password/forgot' && req.method==='POST'){
      const b=await body(req); const email=String(b.email||'').trim().toLowerCase();
      if(!email || !email.includes('@')) return error(res,400,'Email inválido.');
      const recent=db.prepare("SELECT COUNT(*) n FROM password_reset_outbox WHERE email=? AND criado_em>?").get(email,new Date(Date.now()-15*60*1000).toISOString());
      if(Number(recent.n)>=3) return json(res,200,{ok:true,message:'Se existir uma conta com esse email, será enviado um link de recuperação.'});
      const row=db.prepare('SELECT u.id,u.email,p.nome,p.status FROM users u JOIN profiles p ON p.id=u.id WHERE u.email=?').get(email);
      if(row && row.status!=='bloqueado'){
        db.prepare("UPDATE password_reset_outbox SET estado=CASE WHEN estado IN ('pendente','enviado') THEN 'expirado' ELSE estado END WHERE utilizador_id=? AND estado IN ('pendente','enviado')").run(row.id);
        const token=crypto.randomBytes(32).toString('base64url'); const tokenHash=hashToken(token); const exp=new Date(Date.now()+60*60*1000).toISOString(); const id=uuid();
        db.prepare('INSERT INTO password_reset_tokens(id,utilizador_id,token_hash,expira_em,usado,criado_em) VALUES(?,?,?,?,0,?)').run(id,row.id,tokenHash,exp,now());
        db.prepare("INSERT INTO password_reset_outbox(id,utilizador_id,email,token_hash,expira_em,estado,criado_em) VALUES(?,?,?,?,?,'pendente',?)").run(id,row.id,row.email,tokenHash,exp,now());
        const base=String(process.env.AGROLINK_PUBLIC_URL||'').trim().replace(/\/$/,'') || `http://${String(req.headers.host||'localhost')}`;
        const recoveryUrl=`${base}/redefinir-password?token=${encodeURIComponent(token)}`;
        const delivery=await deliverPasswordReset({email:row.email,nome:row.nome,recoveryUrl,token});
        if(delivery.sent){ db.prepare("UPDATE password_reset_outbox SET estado='enviado',enviado_em=?,erro=NULL WHERE id=?").run(now(),id); if(delivery.mode==='development') return json(res,200,{ok:true,message:'Link de recuperação gerado para ambiente de desenvolvimento.',recoveryUrl}); }
        else db.prepare("UPDATE password_reset_outbox SET estado='falhou',erro=? WHERE id=?").run(delivery.error||'Falha na entrega.',id);
      }
      return json(res,200,{ok:true,message:'Se existir uma conta com esse email, será enviado um link de recuperação.'});
    }
    if(pathname==='/api/auth/password/reset' && req.method==='POST'){
      const b=await body(req); const token=String(b.token||'').trim(); const password=String(b.password||'');
      if(!token || !validPassword(password)) return error(res,400,'Token ou palavra-passe inválidos.');
      const row=db.prepare(`SELECT prt.id,prt.utilizador_id,prt.expira_em,prt.usado,p.status FROM password_reset_tokens prt JOIN profiles p ON p.id=prt.utilizador_id JOIN password_reset_outbox o ON o.token_hash=prt.token_hash AND o.estado IN ('pendente','enviado') WHERE prt.token_hash=?`).get(hashToken(token));
      if(!row || row.usado || row.expira_em<=now() || row.status==='bloqueado') return error(res,400,'Link de recuperação inválido ou expirado.');
      const salt=crypto.randomBytes(16).toString('hex'); db.prepare('UPDATE users SET password_hash=?,password_salt=? WHERE id=?').run(passwordHash(password,salt),salt,row.utilizador_id);
      db.prepare('UPDATE password_reset_tokens SET usado=1 WHERE id=?').run(row.id); db.prepare("UPDATE password_reset_outbox SET estado='usado' WHERE token_hash=?").run(hashToken(token)); db.prepare('DELETE FROM sessoes WHERE utilizador_id=?').run(row.utilizador_id);
      security('password_redefinida',{utilizador_id:row.utilizador_id},'medio',{via:'token'});
      return json(res,200,{ok:true});
    }
    if(pathname==='/api/auth/login' && req.method==='POST'){
      const b=await body(req); const email=String(b.email||'').trim().toLowerCase(); const row=db.prepare(`SELECT u.*,p.status FROM users u JOIN profiles p ON p.id=u.id WHERE u.email=?`).get(email);
      if(!row || !row.password_salt || passwordHash(String(b.password||''),row.password_salt)!==row.password_hash){ security('login_falhado',row?{utilizador_id:row.id}:null,'medio',{email,ip}); await evaluateSecuritySignal({type:'login_falhado',ip,userId:row?.id||null,details:{email}}); return error(res,401,'Email ou palavra-passe inválidos.'); }
      if(row.status==='bloqueado') return error(res,403,'Conta bloqueada.');
      const raw=crypto.randomBytes(32).toString('base64url'); const exp=new Date(Date.now()+1000*60*60*24*30).toISOString();
      db.prepare(`INSERT INTO sessoes(id,utilizador_id,token_hash,expira_em) VALUES(?,?,?,?)`).run(uuid(),row.id,hashToken(raw),exp);
      security('login_sucesso',{utilizador_id:row.id},'baixo');
      return json(res,200,{session:{user:{id:row.id,email:row.email}},profile:hydrate(db.prepare('SELECT * FROM profiles WHERE id=?').get(row.id))},{'set-cookie':`agrolink_session=${encodeURIComponent(raw)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=2592000${IS_PROD?'; Secure':''}`});
    }
    if(pathname==='/api/auth/logout' && req.method==='POST'){
      const token=parseCookie(req,'agrolink_session'); if(token) db.prepare('DELETE FROM sessoes WHERE token_hash=?').run(hashToken(token)); return json(res,200,{ok:true},{'set-cookie':'agrolink_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0'});
    }
    if(pathname==='/api/auth/session' && req.method==='GET'){
      const user=currentUser(req); if(!user) return json(res,200,{session:null,profile:null}); return json(res,200,{session:{user:{id:user.utilizador_id,email:user.email}},profile:user});
    }
    if(pathname==='/api/profile' && req.method==='GET'){ const u=requireAuth(req,res); if(!u)return; return json(res,200,hydrate(db.prepare('SELECT * FROM profiles WHERE id=?').get(u.utilizador_id))); }
    if(pathname==='/api/profile' && req.method==='PATCH'){ const u=requireAuth(req,res); if(!u)return; const b=normalizeForDb('profiles',await body(req)); const keys=Object.keys(b).filter(k=>!['papel','tipo_perfil','nivel_admin','status','verification_status','visibilidade','id'].includes(k)); if(!keys.length)return json(res,200,u); const sql=`UPDATE profiles SET ${keys.map(k=>`${k}=?`).join(',')} WHERE id=?`; db.prepare(sql).run(...keys.map(k=>b[k]),u.utilizador_id); audit(u,'atualizar_perfil','profiles',u.utilizador_id,{campos:keys}); return json(res,200,hydrate(db.prepare('SELECT * FROM profiles WHERE id=?').get(u.utilizador_id))); }

    if(pathname.startsWith('/api/media/upload/') && req.method==='POST') {
      const u=requireAuth(req,res); if(!u)return;
      const area=pathname.split('/').pop(); if(!['relatos','biblioteca','academia'].includes(area)) return error(res,400,'Área de upload inválida.');
      if(area!=='relatos' && !canWriteAdmin(u)) return error(res,403,'Só administradores podem carregar ficheiros para esta área.');
      const b=await body(req); if(!b.data||!b.filename)return error(res,400,'Ficheiro inválido.');
      const encoded=String(b.data).replace(/^data:[^,]*;base64,/i,'');
      if(encoded.length>24*1024*1024 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(encoded)) return error(res,400,'Conteúdo Base64 inválido.');
      const bytes=Buffer.from(encoded,'base64');
      if(!bytes.length || bytes.length>18*1024*1024 || bytes.toString('base64')!==encoded) return error(res,413,'Ficheiro vazio ou acima do limite de 18 MiB.');
      const uploadId=String(b.uploadId||'');
      if(uploadId && (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(uploadId) || area!=='relatos')) return error(res,400,'Identificador de upload inválido.');
      const safe=String(b.filename).replace(/[^a-zA-Z0-9._-]/g,'_').slice(0,140); const rel=path.join(area,`${uploadId||uuid()}-${safe}`);
      try { await storageAdapter.put(rel,bytes); }
      catch(e) { if(e instanceof StorageConflictError)return error(res,409,'Identificador de upload já usado com outro conteúdo.'); throw e; }
      return json(res,201,{caminho:rel});
    }
    if(pathname.startsWith('/api/media/') && req.method==='GET') {
      const u=currentUser(req); if(!u)return error(res,401,'Sessão necessária.');
      const rel=pathname.slice('/api/media/'.length).split('/').map(decodeURIComponent).join('/');
      const area=rel.split('/')[0];
      if(area==='relatos'){
        const media=db.prepare(`SELECT r.autor_id,r.provincia FROM relato_midias rm JOIN relatos r ON r.id=rm.relato_id WHERE rm.caminho_storage=?`).get(rel);
        if(!media || (!isAdmin(u) && media.autor_id!==u.utilizador_id && !isTech(u)))return error(res,404,'Ficheiro não encontrado.');
      }else if(area==='biblioteca'){
        if(!db.prepare('SELECT 1 FROM biblioteca_documentos WHERE caminho_storage=?').get(rel))return error(res,404,'Ficheiro não encontrado.');
      }else if(area==='academia'){
        if(!db.prepare('SELECT 1 FROM academia_licoes WHERE caminho_storage=?').get(rel))return error(res,404,'Ficheiro não encontrado.');
      }else return error(res,404,'Ficheiro não encontrado.');
      const stored=await storageAdapter.get(rel); if(!stored)return error(res,404,'Ficheiro não encontrado.');
      const ext=path.extname(rel); const types={'.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp','.gif':'image/gif','.pdf':'application/pdf','.webm':'audio/webm','.mp4':'video/mp4','.ogg':'audio/ogg'}; res.writeHead(200,{'content-type':types[ext]||'application/octet-stream','cache-control':'private, max-age=600',...securityHeaders()});
      const stream=typeof stored.body?.pipe==='function'?stored.body:Readable.fromWeb(stored.body); return stream.pipe(res);
    }
    if(pathname==='/api/denuncias' && req.method==='POST'){
      const u=requireAuth(req,res); if(!u)return;
      const b=await body(req);
      const denunciadoId=String(b.denunciado_id||'').trim();
      const categoria=String(b.categoria||'').trim().slice(0,80);
      const descricao=String(b.descricao||'').trim().slice(0,4000);
      if(!denunciadoId || !categoria || descricao.length<10) return error(res,400,'Indique a pessoa denunciada, a categoria e uma descrição com pelo menos 10 caracteres.');
      if(denunciadoId===u.utilizador_id) return error(res,400,'Não pode denunciar a própria conta.');
      const target=db.prepare(`SELECT id,nome,papel,status FROM profiles WHERE id=?`).get(denunciadoId);
      if(!target)return error(res,404,'Utilizador denunciado não encontrado.');
      const id=uuid();
      const evidencias=Array.isArray(b.evidencias)?b.evidencias.slice(0,5):[];
      db.prepare(`INSERT INTO denuncias(id,autor_id,denunciado_id,transporte_id,categoria,descricao,evidencias,estado,prioridade,criado_em) VALUES(?,?,?,?,?,?,?,?,?,?)`).run(id,u.utilizador_id,denunciadoId,b.transporte_id||null,categoria,descricao,JSON.stringify(evidencias),'pendente',['baixa','media','alta','urgente'].includes(b.prioridade)?b.prioridade:'media',now());
      const admins=db.prepare(`SELECT id FROM profiles WHERE papel IN ('admin','admin_chefe') AND status='ativo'`).all();
      for(const a of admins){ db.prepare(`INSERT INTO notificacoes(id,destinatario_id,titulo,corpo,tipo,relacionado_tipo,relacionado_id,criado_em) VALUES(?,?,?,?,?,?,?,?)`).run(uuid(),a.id,'Nova denúncia recebida',`Uma denúncia contra ${target.nome} foi enviada para análise.`, 'denuncia','denuncia',id,now()); }
      audit(u,'criar_denuncia','denuncias',id,{denunciado_id:denunciadoId,categoria});
      return json(res,201,{id,status:'pendente'});
    }
    if(pathname==='/api/denuncias/alvos' && req.method==='GET'){
      const u=requireAuth(req,res); if(!u)return;
      const pesquisa=String(url.searchParams.get('pesquisa')||'').trim().toLowerCase();
      const params=[u.utilizador_id]; let sql=`SELECT id,nome,papel,status,provincia FROM profiles WHERE id<>?`;
      if(!isAdmin(u)) sql+=` AND visibilidade<>'oculto'`;
      if(pesquisa){sql+=` AND (lower(nome) LIKE ? OR lower(papel) LIKE ?)`; const q='%'+pesquisa+'%'; params.push(q,q);}
      sql+=' ORDER BY nome ASC LIMIT 50';
      return json(res,200,db.prepare(sql).all(...params));
    }
    if(pathname==='/api/admin/denuncias' && req.method==='GET'){
      const u=requireAuth(req,res); if(!u)return; if(!isAdmin(u))return error(res,403,'Apenas administradores.');
      const estado=url.searchParams.get('estado'); const params=[]; let sql=`SELECT d.*, pa.nome AS autor_nome, pa.papel AS autor_papel, pd.nome AS denunciado_nome, pd.papel AS denunciado_papel, pr.nome AS admin_responsavel_nome FROM denuncias d JOIN profiles pa ON pa.id=d.autor_id JOIN profiles pd ON pd.id=d.denunciado_id LEFT JOIN profiles pr ON pr.id=d.admin_responsavel_id`;
      if(estado){sql+=' WHERE d.estado=?';params.push(estado);} sql+=' ORDER BY CASE d.prioridade WHEN \'urgente\' THEN 0 WHEN \'alta\' THEN 1 WHEN \'media\' THEN 2 ELSE 3 END, d.criado_em DESC LIMIT 200';
      return json(res,200,db.prepare(sql).all(...params).map(hydrate));
    }
    if(pathname==='/api/admin/denuncias/atualizar' && req.method==='PATCH'){
      const u=requireAuth(req,res); if(!u)return; if(!canWriteAdmin(u))return error(res,403,'Apenas administradores podem tratar denúncias.');
      const b=await body(req); const id=String(b.id||'').trim(); if(!id)return error(res,400,'ID obrigatório.');
      const atual=db.prepare(`SELECT * FROM denuncias WHERE id=?`).get(id); if(!atual)return error(res,404,'Denúncia não encontrada.');
      const updates={};
      if(['pendente','em_analise','confirmada','rejeitada','arquivada'].includes(b.estado)) updates.estado=b.estado;
      if(['baixa','media','alta','urgente'].includes(b.prioridade)) updates.prioridade=b.prioridade;
      if(typeof b.decisao==='string') updates.decisao=b.decisao.slice(0,4000);
      if(b.admin_responsavel_id===null || typeof b.admin_responsavel_id==='string') updates.admin_responsavel_id=b.admin_responsavel_id||null;
      if(!Object.keys(updates).length)return json(res,200,atual);
      if(updates.admin_responsavel_id){const assignee=db.prepare(`SELECT id,papel FROM profiles WHERE id=?`).get(updates.admin_responsavel_id); if(!assignee || !['admin','admin_chefe'].includes(assignee.papel))return error(res,400,'O responsável deve ser um administrador.');}
      if(updates.estado && ['confirmada','rejeitada','arquivada'].includes(updates.estado)) updates.data_resolucao=now();
      const sets=Object.keys(updates).map(k=>`${k}=?`).join(','); db.prepare(`UPDATE denuncias SET ${sets} WHERE id=?`).run(...Object.values(updates),id);
      for(const [campo,novo] of Object.entries(updates)){const antigo=atual[campo]; if(String(antigo??'')!==String(novo??'')) db.prepare(`INSERT INTO denuncia_historico(id,denuncia_id,campo_alterado,valor_anterior,valor_novo,alterado_por,alterado_em) VALUES(?,?,?,?,?,?,?)`).run(uuid(),id,campo,String(antigo??''),String(novo??''),u.utilizador_id,now());}
      audit(u,'tratar_denuncia','denuncias',id,{alteracoes:Object.keys(updates)});
      return json(res,200,db.prepare(`SELECT * FROM denuncias WHERE id=?`).get(id));
    }
    if(pathname==='/api/admin/users/suspender' && req.method==='POST'){
      const u=requireAuth(req,res); if(!u)return; if(!isChief(u))return error(res,403,'Apenas o administrador-chefe pode suspender contas.');
      const b=await body(req); const id=String(b.id||'').trim(); const motivo=String(b.motivo||'').trim().slice(0,1000);
      if(!id)return error(res,400,'ID obrigatório.'); if(id===u.utilizador_id)return error(res,403,'O administrador-chefe não pode suspender a própria conta.'); if(motivo.length<5)return error(res,400,'Indique o motivo da suspensão.');
      const target=db.prepare(`SELECT id,papel,status FROM profiles WHERE id=?`).get(id); if(!target)return error(res,404,'Utilizador não encontrado.');
      db.prepare(`UPDATE profiles SET status='bloqueado',suspenso_em=?,suspenso_por=?,motivo_suspensao=? WHERE id=?`).run(now(),u.utilizador_id,motivo,id);
      db.prepare(`DELETE FROM sessoes WHERE utilizador_id=?`).run(id);
      db.prepare(`INSERT INTO notificacoes(id,destinatario_id,titulo,corpo,tipo,criado_em) VALUES(?,?,?,?,?,?)`).run(uuid(),id,'Conta suspensa','A sua conta foi suspensa pelo administrador-chefe. Consulte o motivo na área da conta.','seguranca',now());
      audit(u,'suspender_conta','profiles',id,{papel_anterior:target.papel,motivo}); security('suspensao_conta',u,'alto',{alvo:id,motivo});
      return json(res,200,{ok:true,status:'bloqueado'});
    }
    if(pathname==='/api/admin/users/repor-ativa' && req.method==='POST'){
      const u=requireAuth(req,res); if(!u)return; if(!isChief(u))return error(res,403,'Apenas o administrador-chefe pode reativar contas.');
      const b=await body(req); const id=String(b.id||'').trim(); if(!id)return error(res,400,'ID obrigatório.'); const target=db.prepare(`SELECT id,papel,status FROM profiles WHERE id=?`).get(id); if(!target)return error(res,404,'Utilizador não encontrado.');
      db.prepare(`UPDATE profiles SET status='ativo',suspenso_em=NULL,suspenso_por=NULL,motivo_suspensao=NULL WHERE id=?`).run(id); audit(u,'reativar_conta','profiles',id,{papel:target.papel}); return json(res,200,{ok:true,status:'ativo'});
    }
    if(pathname==='/api/admin/users/approve' && req.method==='POST'){
      const u=requireAuth(req,res); if(!u)return; if(!isChief(u))return error(res,403,'Apenas o administrador-chefe pode aprovar administradores.');
      const b=await body(req); const id=String(b.id||'').trim(); if(!id)return error(res,400,'ID obrigatório.');
      const target=db.prepare('SELECT id,papel,tipo_perfil,status FROM profiles WHERE id=?').get(id);
      if(!target)return error(res,404,'Utilizador não encontrado.');
      if(target.papel!=='utilizador'||target.tipo_perfil!=='administrador'||target.status!=='pendente')return error(res,409,'A conta não é um administrador pendente.');
      db.prepare("UPDATE profiles SET papel='admin',nivel_admin='normal',status='ativo' WHERE id=? AND papel='utilizador' AND tipo_perfil='administrador' AND status='pendente'").run(id);
      audit(u,'aprovar_administrador','profiles',id,{tipo_perfil:target.tipo_perfil});
      db.prepare(`INSERT INTO notificacoes(id,destinatario_id,titulo,corpo,tipo,criado_em) VALUES(?,?,?,?,?,?)`).run(uuid(),id,'Conta aprovada','A sua conta de administrador foi aprovada pelo administrador-chefe.','conta_aprovada',now());
      return json(res,200,{ok:true,papel:'admin',status:'ativo'});
    }
    if(pathname==='/api/admin/users/approve-account' && req.method==='POST'){
      const u=requireAuth(req,res); if(!u)return; if(!isChief(u))return error(res,403,'Apenas o administrador-chefe pode aprovar contas pendentes.');
      const b=await body(req); const id=String(b.id||'').trim(); if(!id)return error(res,400,'ID obrigatório.');
      const target=db.prepare('SELECT id,papel,tipo_perfil,status FROM profiles WHERE id=?').get(id);
      if(!target)return error(res,404,'Utilizador não encontrado.');
      if(target.papel!=='utilizador'||!['agricultor','tecnico'].includes(target.tipo_perfil)||target.status!=='pendente')return error(res,409,'A conta não é um agricultor ou técnico pendente.');
      const changed=db.prepare("UPDATE profiles SET status='ativo' WHERE id=? AND papel='utilizador' AND tipo_perfil IN ('agricultor','tecnico') AND status='pendente'").run(id);
      if(!changed.changes)return error(res,409,'A conta deixou de estar pendente.');
      audit(u,'aprovar_conta','profiles',id,{tipo_perfil:target.tipo_perfil});
      db.prepare(`INSERT INTO notificacoes(id,destinatario_id,titulo,corpo,tipo,criado_em) VALUES(?,?,?,?,?,?)`).run(uuid(),id,'Conta aprovada','A sua conta está ativa.','conta_aprovada',now());
      return json(res,200,{ok:true,status:'ativo'});
    }

    const dataMatch=pathname.match(/^\/api\/data\/([a-z_]+)$/);
    if(dataMatch){
      const table=dataMatch[1]; if(!COLUMN_ALLOWLIST[table]) return error(res,404,'Tabela não disponível.');
      const u=currentUser(req); const anonymousRelatoInsert = table==='relatos' && req.method==='POST' && !u; if(!canReadTable(u,table) && !anonymousRelatoInsert) return error(res,403,'Sem permissão.');
      if(u?.status==='pendente' && ['POST','PATCH','PUT','DELETE'].includes(req.method))return error(res,403,'A conta aguarda aprovação.');
      if(req.method==='GET'){
        if(table==='logistica_pedidos' && !isAdmin(u) && !isFarmer(u) && !isTransporter(u)) return error(res,403,'Sem permissão.');
        if(table==='academia_questionarios' && !isAdmin(u)) return error(res,403,'Questionários devem ser corrigidos no servidor.');
        const {where,params}=applyFilters(table,url,u); let order=''; const allowed=COLUMN_ALLOWLIST[table]; const orderBy=url.searchParams.get('order')||((table==='noticias'||table==='relatos'||table==='auditoria'||table==='notificacoes')?'criado_em':null); if(orderBy && allowed.includes(orderBy)) order=` ORDER BY ${orderBy} ${url.searchParams.get('asc')==='1'?'ASC':'DESC'}`;
        const requestedLimit=Number(url.searchParams.get('limit')||100); const limit=Number.isFinite(requestedLimit)&&requestedLimit>0?Math.min(Math.floor(requestedLimit),500):100; const sql=`SELECT ${allowed.join(',')} FROM ${table}${where.length?' WHERE '+where.join(' AND '):''}${order} LIMIT ${limit}`; return json(res,200,rowSelect(table,db.prepare(sql).all(...params)));
      }
      if(req.method==='POST'){
        if(!canWriteAdmin(u) && !(table==='relatos' || table==='relato_midias' || table==='ferramenta_calculos' || table==='preferencias_utilizador' || table==='relato_respostas' || table==='dispositivos_push' || table==='denuncias' || table==='transportadores' || table==='mercado_produtos' || table==='logistica_pedidos')) return error(res,403,'Apenas administradores podem modificar esta área.');
        if(table!=='relatos' && !u) return error(res,401,'Sessão necessária.');
        if(table==='relato_respostas' && !isTech(u) && !isAdmin(u)) return error(res,403,'Só técnicos aprovados ou administradores podem responder a relatos.');
        if(table==='mercado_produtos' && !canWriteAdmin(u) && !isFarmer(u)) return error(res,403,'Só agricultores podem publicar produtos.');
        if(table==='logistica_pedidos' && !canWriteAdmin(u) && !isFarmer(u)) return error(res,403,'Só agricultores podem solicitar transporte.');
        const b=normalizeForDb(table,await body(req));
        if(table==='relato_midias'){
          const relato=db.prepare('SELECT autor_id FROM relatos WHERE id=?').get(b.relato_id);
          if(!relato)return error(res,404,'Relato não encontrado.');
          if(!canWriteAdmin(u) && relato.autor_id!==u.utilizador_id)return error(res,403,'Só pode anexar ficheiros aos seus próprios relatos.');
          const mediaPath=String(b.caminho_storage||'');
          const mediaObject=mediaPath.startsWith('relatos/')?await storageAdapter.head(mediaPath):null;
          if(!mediaObject)return error(res,400,'Ficheiro de relato inválido.');
          if(!b.id)b.id=uuid();
          const existing=db.prepare('SELECT * FROM relato_midias WHERE id=?').get(b.id);
          if(existing){
            if(existing.relato_id===b.relato_id && existing.caminho_storage===mediaPath && existing.tipo===b.tipo)return json(res,200,hydrate(existing));
            return error(res,409,'Este identificador de mídia já está em uso.');
          }
          b.caminho_storage=mediaPath;
        }
        if(table==='relato_respostas' && !canWriteAdmin(u)){
          const relato=db.prepare('SELECT id FROM relatos WHERE id=?').get(b.relato_id);
          if(!relato)return error(res,404,'Relato não encontrado.');
          b.tecnico_id=u.utilizador_id;
          b.comentario=String(b.comentario||'').trim().slice(0,4000);
          if(!b.comentario)return error(res,400,'A resposta técnica não pode estar vazia.');
        }
        if(table==='mercado_produtos') {
          b.vendedor_id=canWriteAdmin(u)&&b.vendedor_id?b.vendedor_id:u.utilizador_id;
          b.nome=String(b.nome||'').trim().slice(0,160); b.categoria=String(b.categoria||'').trim().slice(0,80);
          b.unidade=String(b.unidade||'').trim().slice(0,40); b.provincia=String(b.provincia||u.provincia||'').trim().slice(0,100);
          b.preco=Number(b.preco); b.quantidade_disponivel=Number(b.quantidade_disponivel); b.ativo=canWriteAdmin(u)?(b.ativo??1):1;
          if(!b.nome||!b.unidade||!Number.isFinite(b.preco)||b.preco<0||!Number.isFinite(b.quantidade_disponivel)||b.quantidade_disponivel<=0) return error(res,400,'Dados do produto inválidos.');
        }
        if(table==='logistica_pedidos') {
          b.solicitante_id=canWriteAdmin(u)&&b.solicitante_id?b.solicitante_id:u.utilizador_id;
          b.origem_provincia=String(b.origem_provincia||u.provincia||'').trim().slice(0,100);
          b.destino_provincia=String(b.destino_provincia||'').trim().slice(0,100);
          b.produto_descricao=String(b.produto_descricao||'').trim().slice(0,500);
          b.quantidade_kg=Number(b.quantidade_kg); b.transportadora_id=canWriteAdmin(u)?(b.transportadora_id||null):null; b.status='pedido';
          if(!b.origem_provincia||!b.destino_provincia||!b.produto_descricao||!Number.isFinite(b.quantidade_kg)||b.quantidade_kg<=0) return error(res,400,'Dados do pedido de transporte inválidos.');
        }
        if(table==='transportadores') {
          if(!canWriteAdmin(u)) b.utilizador_id=u.utilizador_id;
          if(!b.utilizador_id) return error(res,400,'Utilizador obrigatório.');
          if(!canWriteAdmin(u)) { b.estado_verificacao='pendente'; delete b.motivo_estado; }
          else if(b.estado_verificacao && !['pendente','aprovado','rejeitado'].includes(b.estado_verificacao)) return error(res,400,'Estado de verificação inválido.');
          if(b.capacidade_kg!==undefined && (!Number.isFinite(Number(b.capacidade_kg))||Number(b.capacidade_kg)<=0)) return error(res,400,'Capacidade do veículo inválida.');
          if(!canWriteAdmin(u) && (!String(b.matricula||'').trim() || !String(b.tipo_veiculo||'').trim() || !Number.isFinite(Number(b.capacidade_kg)))) return error(res,400,'Matrícula, tipo de veículo e capacidade são obrigatórios.');
          const existing=db.prepare('SELECT utilizador_id FROM transportadores WHERE utilizador_id=?').get(b.utilizador_id);
          if(existing) {
            const keys=Object.keys(b).filter((key)=>!['utilizador_id','criado_em','atualizado_em'].includes(key));
            if(keys.length) db.prepare(`UPDATE transportadores SET ${keys.map((key)=>`${key}=?`).join(',')}, atualizado_em=? WHERE utilizador_id=?`).run(...keys.map((key)=>b[key]),now(),b.utilizador_id);
            const carrier=db.prepare('SELECT nome,provincia,telefone FROM profiles WHERE id=?').get(b.utilizador_id);
            db.prepare('UPDATE logistica_transportadoras SET nome=?,provincia=?,contacto=?,capacidade_kg=coalesce(?,capacidade_kg),ativo=? WHERE utilizador_id=?').run(carrier.nome,carrier.provincia,carrier.telefone,b.capacidade_kg??null,b.estado_verificacao==='aprovado'?1:0,b.utilizador_id);
            audit(u,'atualizar','transportadores',b.utilizador_id,{campos:keys});
            return json(res,200,hydrate(db.prepare('SELECT * FROM transportadores WHERE utilizador_id=?').get(b.utilizador_id)));
          }
          db.prepare(`INSERT INTO transportadores (${Object.keys(b).join(',')}) VALUES (${Object.keys(b).map(()=>'?').join(',')})`).run(...Object.keys(b).map((key)=>b[key]));
          const carrier=db.prepare('SELECT nome,provincia,telefone FROM profiles WHERE id=?').get(b.utilizador_id);
          const existingDirectory=db.prepare('SELECT id FROM logistica_transportadoras WHERE utilizador_id=?').get(b.utilizador_id);
          if(existingDirectory) db.prepare('UPDATE logistica_transportadoras SET nome=?,provincia=?,contacto=?,capacidade_kg=?,ativo=? WHERE utilizador_id=?').run(carrier.nome,carrier.provincia,carrier.telefone,b.capacidade_kg,b.estado_verificacao==='aprovado'?1:0,b.utilizador_id);
          else db.prepare('INSERT INTO logistica_transportadoras(id,nome,provincia,contacto,capacidade_kg,ativo,utilizador_id,criado_em) VALUES(?,?,?,?,?,?,?,?)').run(uuid(),carrier.nome,carrier.provincia,carrier.telefone,b.capacidade_kg,b.estado_verificacao==='aprovado'?1:0,b.utilizador_id,now());
          audit(u,'criar','transportadores',b.utilizador_id,{});
          return json(res,201,hydrate(db.prepare('SELECT * FROM transportadores WHERE utilizador_id=?').get(b.utilizador_id)));
        }
        if(!b.id)b.id=uuid(); if(table==='relatos'){b.autor_id=u?.utilizador_id||null; b.codigo_publico='AL-'+crypto.randomBytes(16).toString('hex').toUpperCase(); b.status='pendente';}
        if(table==='preferencias_utilizador' && !b.utilizador_id)b.utilizador_id=u.utilizador_id;
        if(table==='ferramenta_calculos' && !b.utilizador_id)b.utilizador_id=u.utilizador_id;
        const keys=Object.keys(b), vals=keys.map(k=>b[k]);
        if (table==='relatos') {
          const existente=db.prepare('SELECT * FROM relatos WHERE id=?').get(b.id);
          if (existente) {
            if (existente.autor_id===b.autor_id || (!existente.autor_id && !b.autor_id)) return json(res,200,hydrate(existente));
            return error(res,409,'Este identificador de relato já está em uso.');
          }
        }
        db.prepare(`INSERT INTO ${table} (${keys.join(',')}) VALUES (${keys.map(()=>'?').join(',')})`).run(...vals); audit(u,'criar',''+table,b.id,{}); return json(res,201,hydrate(db.prepare(`SELECT * FROM ${table} WHERE id=?`).get(b.id)||db.prepare(`SELECT * FROM ${table} WHERE rowid=last_insert_rowid()`).get()));
      }
      if(req.method==='PATCH'){
        const id=url.searchParams.get('id'); if(!id)return error(res,400,'ID obrigatório.');
        if(table==='mercado_produtos' && !canWriteAdmin(u)) {
          if(!isFarmer(u)) return error(res,403,'Sem permissão.');
          const current=db.prepare('SELECT vendedor_id FROM mercado_produtos WHERE id=?').get(id);
          if(!current||current.vendedor_id!==u.utilizador_id) return error(res,403,'Só pode alterar os seus próprios produtos.');
          const b=normalizeForDb(table,await body(req)); delete b.id; delete b.vendedor_id; delete b.criado_em;
          if(Object.prototype.hasOwnProperty.call(b,'preco')&&(!Number.isFinite(Number(b.preco))||Number(b.preco)<0)) return error(res,400,'Preço inválido.');
          if(Object.prototype.hasOwnProperty.call(b,'quantidade_disponivel')&&(!Number.isFinite(Number(b.quantidade_disponivel))||Number(b.quantidade_disponivel)<=0)) return error(res,400,'Quantidade inválida.');
          if(!Object.keys(b).length)return json(res,200,{ok:true});
          db.prepare(`UPDATE mercado_produtos SET ${Object.keys(b).map(k=>`${k}=?`).join(',')} WHERE id=? AND vendedor_id=?`).run(...Object.values(b),id,u.utilizador_id);
          audit(u,'atualizar','mercado_produtos',id,{campos:Object.keys(b)}); return json(res,200,hydrate(db.prepare('SELECT * FROM mercado_produtos WHERE id=?').get(id)));
        }
        if(table==='logistica_pedidos' && !canWriteAdmin(u)) {
          const b=await body(req);
          const carrierProfile=db.prepare('SELECT estado_verificacao FROM transportadores WHERE utilizador_id=?').get(u.utilizador_id);
          if(b.status && carrierProfile?.estado_verificacao!=='aprovado')return error(res,403,'O perfil de transportador ainda não foi aprovado.');
          if(isFarmer(u) && (!b.status || b.status==='cancelado')) {
            if(b.status && b.status!=='cancelado')return error(res,403,'Agricultores só podem cancelar os próprios pedidos.');
            const changed=db.prepare("UPDATE logistica_pedidos SET status='cancelado' WHERE id=? AND solicitante_id=? AND status='pedido' AND transportadora_id IS NULL").run(id,u.utilizador_id);
            if(!changed.changes) return error(res,409,'Pedido não encontrado ou já aceite.');
          } else if(isTransporter(u)) {
            const provider=db.prepare("SELECT lt.id FROM logistica_transportadoras lt JOIN transportadores t ON t.utilizador_id=lt.utilizador_id WHERE lt.utilizador_id=? AND lt.ativo=1 AND t.estado_verificacao='aprovado'").get(u.utilizador_id);
            if(!provider) return error(res,403,'Registe o perfil de transportador antes de aceitar pedidos.');
            const nextStatus=String(b.status||'aceite');
            const transitions={aceite:["pedido"],em_transito:["aceite"],entregue:["em_transito"]};
            if(!transitions[nextStatus]) return error(res,400,'Estado de transporte inválido.');
            const prior=transitions[nextStatus];
            const changed=db.prepare(`UPDATE logistica_pedidos SET status=?,transportadora_id=? WHERE id=? AND (transportadora_id=? OR (transportadora_id IS NULL AND status='pedido')) AND status IN (${prior.map(()=>'?').join(',')})`).run(nextStatus,provider.id,id,provider.id,...prior);
            if(!changed.changes) return error(res,409,'Pedido já foi aceite ou não permite esta transição.');
          } else return error(res,403,'Sem permissão.');
          audit(u,'atualizar','logistica_pedidos',id,{status:b.status||'cancelado'}); return json(res,200,hydrate(db.prepare('SELECT * FROM logistica_pedidos WHERE id=?').get(id)));
        }
        if(table==='profiles' && !isChief(u) && !canWriteAdmin(u)) return error(res,403,'Sem permissão.');
        if(!canWriteAdmin(u) && table==='relatos' && !isTech(u)) return error(res,403,'Só técnicos aprovados podem alterar o estado de relatos.');
        if(!canWriteAdmin(u) && table!=='relatos' && table!=='notificacoes') return error(res,403,'Sem permissão.');
        if(table==='notificacoes' && !isAdmin(u)) { const owner=db.prepare('SELECT destinatario_id FROM notificacoes WHERE id=?').get(url.searchParams.get('id')); if(!owner || owner.destinatario_id!==u.utilizador_id) return error(res,403,'Sem permissão.'); }
        const raw=await body(req); const b=normalizeForDb(table,raw); delete b.id;
        if(table==='relatos' && !canWriteAdmin(u)){
          const relato=db.prepare('SELECT provincia FROM relatos WHERE id=?').get(id);
          if(!relato)return error(res,404,'Relato não encontrado.');
          if(Object.keys(raw).some((key)=>key!=='status'))return error(res,403,'Técnicos só podem alterar o estado do relato.');
          if(!['pendente','em_analise','respondido','resolvido'].includes(b.status))return error(res,400,'Estado do relato inválido.');
        }
        if(table==='profiles') { const target=db.prepare('SELECT id,papel,tipo_perfil FROM profiles WHERE id=?').get(id); if(!target)return error(res,404,'Utilizador não encontrado.'); if(target.papel==='admin_chefe' && !isChief(u))return error(res,403,'A conta de administrador-chefe está protegida.'); if(Object.prototype.hasOwnProperty.call(b,'papel') || Object.prototype.hasOwnProperty.call(b,'nivel_admin'))return error(res,403,'Use o fluxo administrativo autorizado para alterar permissões.'); if(Object.prototype.hasOwnProperty.call(b,'tipo_perfil'))return error(res,403,'O perfil profissional não pode ser alterado neste fluxo.'); if(Object.prototype.hasOwnProperty.call(b,'status')){ if(!isChief(u))return error(res,403,'Apenas o administrador-chefe pode suspender ou reativar contas.'); if(id===u.utilizador_id && b.status!=='ativo')return error(res,403,'O administrador-chefe não pode suspender a própria conta.'); } if(Object.prototype.hasOwnProperty.call(b,'verification_status') && target.tipo_perfil!=='tecnico')return error(res,400,'A verificação só se aplica a técnicos.'); }
        const keys=Object.keys(b); if(!keys.length)return json(res,200,{ok:true}); db.prepare(`UPDATE ${table} SET ${keys.map(k=>`${k}=?`).join(',')} WHERE id=?`).run(...keys.map(k=>b[k]),id); audit(u,'atualizar',table,id,{campos:keys}); return json(res,200,hydrate(db.prepare(`SELECT * FROM ${table} WHERE id=?`).get(id)));
      }
      if(req.method==='DELETE'){
        if(table==='mercado_produtos' && !canWriteAdmin(u)) {
          if(!isFarmer(u)) return error(res,403,'Sem permissão.');
          const id=url.searchParams.get('id'); if(!id)return error(res,400,'ID obrigatório.');
          const result=db.prepare('DELETE FROM mercado_produtos WHERE id=? AND vendedor_id=?').run(id,u.utilizador_id);
          if(!result.changes)return error(res,404,'Produto não encontrado.');
          audit(u,'eliminar','mercado_produtos',id,{}); return json(res,200,{ok:true});
        }
        if(!canWriteAdmin(u)) return error(res,403,'Apenas administradores podem eliminar conteúdo.');
        if(table==='profiles'||table==='users') return error(res,403,'Contas de utilizadores não podem ser eliminadas pelo painel.');
        const id=url.searchParams.get('id'); if(!id)return error(res,400,'ID obrigatório.'); db.prepare(`DELETE FROM ${table} WHERE id=?`).run(id); audit(u,'eliminar',table,id,{}); return json(res,200,{ok:true});
      }
    }

    if(pathname==='/api/admin/users' && req.method==='GET'){
      const u=requireAuth(req,res); if(!u)return; if(!isAdmin(u))return error(res,403,'Apenas administradores.'); const papel=url.searchParams.get('papel'); const status=url.searchParams.get('status'); const params=[]; const where=[]; if(papel){where.push('papel=?');params.push(papel);} if(status){where.push('status=?');params.push(status);} const rows=db.prepare(`SELECT * FROM profiles${where.length?' WHERE '+where.join(' AND '):''} ORDER BY criado_em DESC`).all(...params); return json(res,200,rowSelect('profiles',rows));
    }
    if(pathname==='/api/admin/users/promote' && req.method==='POST'){
      const u=requireAuth(req,res); if(!u)return; if(!isChief(u))return error(res,403,'Apenas o administrador-chefe pode promover funções.'); const b=await body(req); if(b.papel!=='auditor')return error(res,400,'A aprovação de administradores deve usar o fluxo próprio.'); const target=db.prepare('SELECT id,papel,status FROM profiles WHERE id=?').get(b.id); if(!target)return error(res,404,'Utilizador não encontrado.'); db.prepare("UPDATE profiles SET papel='admin',tipo_perfil='administrador',nivel_admin='auditor',status='ativo' WHERE id=?").run(b.id); audit(u,'promover_auditor', 'profiles',b.id,{papel_anterior:target.papel}); return json(res,200,{ok:true});
    }
    if(pathname==='/api/admin/stats' && req.method==='GET'){
      const u=requireAuth(req,res); if(!u)return; if(!isAdmin(u))return error(res,403,'Apenas administradores.'); const count=(sql)=>Number(db.prepare(sql).get().n); return json(res,200,{total_relatos:count('SELECT COUNT(*) n FROM relatos'),relatos_pendentes:count("SELECT COUNT(*) n FROM relatos WHERE status='pendente'"),relatos_em_analise:count("SELECT COUNT(*) n FROM relatos WHERE status='em_analise'"),relatos_resolvidos:count("SELECT COUNT(*) n FROM relatos WHERE status='resolvido'"),total_agricultores:count("SELECT COUNT(*) n FROM profiles WHERE papel='utilizador' AND tipo_perfil='agricultor'"),total_tecnicos:count("SELECT COUNT(*) n FROM profiles WHERE papel='utilizador' AND tipo_perfil='tecnico'"),tecnicos_aprovados:count("SELECT COUNT(*) n FROM profiles WHERE papel='utilizador' AND tipo_perfil='tecnico' AND verification_status='aprovado'"),contas_pendentes:count("SELECT COUNT(*) n FROM profiles WHERE status='pendente'")});
    }
    if(pathname==='/api/admin/broadcast' && req.method==='POST'){
      const u=requireAuth(req,res); if(!u)return; if(!canWriteAdmin(u))return error(res,403,'Apenas administradores podem notificar.'); const b=await body(req); let where=`status='ativo'`,params=[]; if(b.papel){where+=' AND papel=?';params.push(b.papel);} const users=db.prepare(`SELECT id FROM profiles WHERE ${where}`).all(...params); for(const x of users)db.prepare(`INSERT INTO notificacoes(id,destinatario_id,titulo,corpo,tipo,criado_em) VALUES(?,?,?,?,?,?)`).run(uuid(),x.id,b.titulo,b.corpo||null,'mensagem_admin',now());audit(u,'enviar_mensagem_admin','notificacoes',null,{destinatarios:users.length,papel:b.papel||null});return json(res,200,{destinatarios:users.length});
    }
    if(pathname==='/api/admin/auditoria' && req.method==='GET'){ const u=requireAuth(req,res); if(!u)return; if(!isAdmin(u))return error(res,403,'Apenas administradores.'); return json(res,200,rowSelect('auditoria',db.prepare('SELECT * FROM auditoria ORDER BY criado_em DESC LIMIT 100').all())); }
    if(pathname==='/api/admin/ia-stats' && req.method==='GET'){ const u=requireAuth(req,res); if(!u)return; if(!isAdmin(u))return error(res,403,'Apenas administradores.'); const total=Number(db.prepare('SELECT COUNT(*) n FROM ia_perguntas_analytics').get().n); const encaminhadas=Number(db.prepare('SELECT COUNT(*) n FROM ia_perguntas_analytics WHERE encaminhado=1').get().n); return json(res,200,{total_perguntas:total,encaminhadas,por_tema:[]}); }
    if(pathname==='/api/admin/ia-resumo' && req.method==='POST'){ const u=requireAuth(req,res); if(!u)return; if(!canWriteAdmin(u))return error(res,403,'Apenas administradores podem gerar resumos.'); const d=new Date(); d.setMonth(d.getMonth()-1); const mes=d.getMonth()+1,ano=d.getFullYear(); const existente=db.prepare('SELECT 1 FROM ia_resumos_mensais WHERE mes=? AND ano=?').get(mes,ano); if(existente)return json(res,200,{gerado:false,motivo:'Resumo já existente.'}); const row=db.prepare("SELECT COUNT(*) n FROM ia_perguntas_analytics WHERE strftime('%m',criado_em)=? AND strftime('%Y',criado_em)=?").get(String(mes).padStart(2,'0'),String(ano)); const total=Number(row.n); const id=uuid(); db.prepare('INSERT INTO ia_resumos_mensais(id,mes,ano,conteudo,gerado_em) VALUES(?,?,?,?,?)').run(id,mes,ano,`Resumo interno: ${total} perguntas IA registadas no período.`,now()); audit(u,'gerar_resumo_ia','ia_resumos_mensais',id,{}); return json(res,200,{gerado:true}); }
    if(pathname==='/api/admin/security/state' && req.method==='GET'){
      const u=requireAuth(req,res); if(!u)return; if(!isAdmin(u))return error(res,403,'Apenas administradores.'); return json(res,200,getSecurityState());
    }
    if(pathname==='/api/admin/security/state' && req.method==='PATCH'){
      const u=requireAuth(req,res); if(!u)return; if(!isChief(u))return error(res,403,'Apenas o administrador-chefe pode alterar o Modo de Segurança.');
      const b=await body(req); const state=setSecurityState({modo:b.modo,funcionalidadesDesativadas:b.funcionalidades_desativadas,motivo:b.motivo,actorId:u.utilizador_id}); audit(u,'alterar_modo_seguranca','platform_security_state','1',{modo:state.modo,funcionalidades_desativadas:state.funcionalidades_desativadas,motivo:state.motivo}); security('alteracao_modo_seguranca',u,state.modo==='emergencia'?'alto':'medio',state); return json(res,200,state);
    }
    if(pathname==='/api/admin/security/backup' && req.method==='POST'){
      const u=requireAuth(req,res); if(!u)return; if(!isChief(u))return error(res,403,'Apenas o administrador-chefe pode criar backups.');
      const backup=createDatabaseBackup(); audit(u,'criar_backup_base','database',null,backup); return json(res,201,{name:path.basename(backup.file),bytes:backup.bytes,createdAt:backup.createdAt,integrity:backup.integrity});
    }
    if(pathname==='/api/admin/security/backup' && req.method==='GET'){
      const u=requireAuth(req,res); if(!u)return; if(!isAdmin(u))return error(res,403,'Apenas administradores.'); return json(res,200,{integrity:verifyDatabaseIntegrity(),backups:listDatabaseBackups().map(({path:_,...safe})=>safe)});
    }
    if(pathname==='/api/admin/security/incidents' && req.method==='GET'){
      const u=requireAuth(req,res); if(!u)return; if(!isAdmin(u))return error(res,403,'Apenas administradores.');
      const estado=url.searchParams.get('estado'); const params=[]; let sql=`SELECT si.*, p.nome AS utilizador_nome, p.papel AS utilizador_papel FROM security_incidents si LEFT JOIN profiles p ON p.id=si.utilizador_id`;
      if(estado){sql+=' WHERE si.estado=?';params.push(estado);}
      sql += ` ORDER BY CASE si.nivel WHEN 'critico' THEN 0 WHEN 'alto' THEN 1 WHEN 'medio' THEN 2 ELSE 3 END, si.criado_em DESC LIMIT 200`;
      return json(res,200,db.prepare(sql).all(...params).map(hydrate));
    }
    if(pathname==='/api/admin/security/incidents/decidir' && req.method==='PATCH'){
      const u=requireAuth(req,res); if(!u)return; if(!isChief(u))return error(res,403,'Apenas o administrador-chefe pode decidir sobre um incidente.');
      const b=await body(req); const id=String(b.id||'').trim(); const acao=String(b.acao||'').trim(); const inc=db.prepare('SELECT * FROM security_incidents WHERE id=?').get(id); if(!inc)return error(res,404,'Incidente não encontrado.');
      const allowed=['encerrar','conter_ip','libertar_ip']; if(!allowed.includes(acao))return error(res,400,'Ação de segurança inválida.');
      if(acao==='conter_ip' && inc.alvo_ip){ const exp=new Date(Date.now()+30*60*1000).toISOString(); db.prepare(`INSERT INTO security_ip_blocks(ip,motivo,expira_em,incidente_id,criado_em) VALUES(?,?,?,?,?) ON CONFLICT(ip) DO UPDATE SET motivo=excluded.motivo,expira_em=excluded.expira_em,incidente_id=excluded.incidente_id`).run(inc.alvo_ip,'Contenção aprovada pelo administrador-chefe',exp,id,now()); db.prepare(`INSERT INTO security_actions(id,incidente_id,acao,modo,resultado,executado_por,criado_em) VALUES(?,?,?,?,?,?,?)`).run(uuid(),id,acao,'humano',`IP contido até ${exp}`,u.utilizador_id,now()); db.prepare("UPDATE security_incidents SET estado='contido',contido_em=?,atualizado_em=? WHERE id=?").run(now(),now(),id); }
      else if(acao==='libertar_ip' && inc.alvo_ip){ db.prepare('DELETE FROM security_ip_blocks WHERE ip=?').run(inc.alvo_ip); db.prepare(`INSERT INTO security_actions(id,incidente_id,acao,modo,resultado,executado_por,criado_em) VALUES(?,?,?,?,?,?,?)`).run(uuid(),id,acao,'humano','IP libertado.',u.utilizador_id,now()); db.prepare("UPDATE security_incidents SET estado='aberto',atualizado_em=? WHERE id=?").run(now(),id); }
      else { db.prepare(`INSERT INTO security_actions(id,incidente_id,acao,modo,resultado,executado_por,criado_em) VALUES(?,?,?,?,?,?,?)`).run(uuid(),id,acao,'humano','Incidente encerrado pelo administrador-chefe.',u.utilizador_id,now()); db.prepare("UPDATE security_incidents SET estado='resolvido',resolvido_em=?,resolvido_por=?,atualizado_em=? WHERE id=?").run(now(),u.utilizador_id,now(),id); }
      audit(u,'decidir_incidente_seguranca','security_incidents',id,{acao}); return json(res,200,db.prepare('SELECT * FROM security_incidents WHERE id=?').get(id));
    }
    if(pathname==='/api/admin/security/report/monthly' && req.method==='POST'){
      const u=requireAuth(req,res); if(!u)return; if(!isChief(u))return error(res,403,'Apenas o administrador-chefe pode gerar o relatório mensal.');
      const result=generateMonthlySecurityReport(); audit(u,'gerar_relatorio_mensal_seguranca','security_monthly_reports',result.id||null,result); return json(res,200,result);
    }
    if(pathname==='/api/admin/security/report/monthly' && req.method==='GET'){
      const u=requireAuth(req,res); if(!u)return; if(!isAdmin(u))return error(res,403,'Apenas administradores.');
      return json(res,200,db.prepare('SELECT * FROM security_monthly_reports ORDER BY ano DESC,mes DESC LIMIT 12').all().map(hydrate));
    }
    if(pathname==='/api/admin/sync-noticias' && req.method==='POST'){ const u=requireAuth(req,res); if(!u)return; if(!canWriteAdmin(u))return error(res,403,'Apenas administradores podem sincronizar notícias.'); return json(res,200,await synchronizeNewsFeeds({db})); }
    if(pathname==='/api/relatos/codigo' && req.method==='GET'){
      const code=url.searchParams.get('codigo'); if(!code)return error(res,400,'Código obrigatório.');
      const ipKey=`relato_codigo:${hashToken(clientIp(req))}`;
      const windowStart=new Date(Date.now()-10*60*1000).toISOString();
      db.prepare('DELETE FROM limite_taxa_eventos WHERE chave=? AND criado_em<=?').run(ipKey,windowStart);
      const attempts=Number(db.prepare('SELECT COUNT(*) n FROM limite_taxa_eventos WHERE chave=? AND criado_em>?').get(ipKey,windowStart).n);
      if(attempts>=30)return error(res,429,'Demasiadas tentativas de consulta. Tente novamente mais tarde.');
      db.prepare('INSERT INTO limite_taxa_eventos(id,chave,criado_em) VALUES(?,?,?)').run(uuid(),ipKey,now());
      const r=db.prepare('SELECT * FROM relatos WHERE codigo_publico=?').get(code); if(!r)return error(res,404,'Código não encontrado.'); const respostas=db.prepare('SELECT comentario,criado_em FROM relato_respostas WHERE relato_id=? ORDER BY criado_em ASC').all(r.id); return json(res,200,{id:r.id,tipo:r.tipo,descricao:r.descricao,status:r.status,criado_em:r.criado_em,respostas});
    }
    if(pathname.startsWith('/api/academia/quiz/') && req.method==='GET') {
      const u=requireAuth(req,res); if(!u)return; const licaoId=pathname.slice('/api/academia/quiz/'.length); const rows=db.prepare('SELECT id,licao_id,pergunta,opcoes,ordem FROM academia_questionarios WHERE licao_id=? ORDER BY ordem ASC').all(licaoId); return json(res,200,rows.map(hydrate));
    }
    if(pathname==='/api/academia/quiz/answer' && req.method==='POST') {
      const u=requireAuth(req,res); if(!u)return; const b=await body(req); const q=db.prepare('SELECT resposta_correta,licao_id FROM academia_questionarios WHERE id=?').get(b.questionarioId); if(!q)return error(res,404,'Pergunta não encontrada.'); const correto=Number(q.resposta_correta)===Number(b.resposta); db.prepare(`INSERT INTO academia_progresso(utilizador_id,licao_id,concluida,pontuacao_questionario,atualizado_em) VALUES(?,?,1,?,?) ON CONFLICT(utilizador_id,licao_id) DO UPDATE SET concluida=1,pontuacao_questionario=excluded.pontuacao_questionario,atualizado_em=excluded.atualizado_em`).run(u.utilizador_id,q.licao_id,correto?1:0,now()); return json(res,200,{correto});
    }
    if(pathname==='/api/academia/quiz' && req.method==='POST'){ const u=requireAuth(req,res); if(!u)return; const b=await body(req); const q=db.prepare('SELECT resposta_correta FROM academia_questionarios WHERE id=?').get(b.questionarioId); if(!q)return error(res,404,'Pergunta não encontrada.'); const correto=Number(q.resposta_correta)===Number(b.resposta); db.prepare(`INSERT INTO academia_progresso(utilizador_id,licao_id,concluida,pontuacao_questionario,atualizado_em) VALUES(?,?,1,?,?) ON CONFLICT(utilizador_id,licao_id) DO UPDATE SET concluida=1,pontuacao_questionario=excluded.pontuacao_questionario,atualizado_em=excluded.atualizado_em`).run(u.utilizador_id,b.licaoId,correto?1:0,now()); return json(res,200,{correto}); }
    if(pathname==='/api/academia/concluir' && req.method==='POST'){ const u=requireAuth(req,res); if(!u)return; const b=await body(req); db.prepare(`INSERT INTO academia_progresso(utilizador_id,licao_id,concluida,atualizado_em) VALUES(?,?,1,?) ON CONFLICT(utilizador_id,licao_id) DO UPDATE SET concluida=1,atualizado_em=excluded.atualizado_em`).run(u.utilizador_id,b.licaoId,now()); return json(res,200,{ok:true}); }
    if(pathname==='/api/ia/encaminhar' && req.method==='POST'){ const u=requireAuth(req,res); if(!u)return; const b=await body(req); const id=uuid(); const desc=`[Encaminhado pelo assistente IA — confiança baixa]\n\nPergunta do agricultor: ${b.perguntaUtilizador}\n\nResposta da IA: ${b.respostaIA}`; db.prepare(`INSERT INTO relatos(id,autor_id,codigo_publico,tipo,descricao,provincia,municipio,comuna,status,criado_em) VALUES(?,?,?,?,?,?,?,?,?,?)`).run(id,u.utilizador_id,'AL-'+crypto.randomBytes(3).toString('hex').toUpperCase(),'pedido_apoio',desc,b.provincia||u.provincia,b.municipio||u.municipio,b.comuna||u.comuna,'pendente',now()); if(b.analyticsId)db.prepare('UPDATE ia_perguntas_analytics SET encaminhado=1 WHERE id=? AND utilizador_id=?').run(b.analyticsId,u.utilizador_id); return json(res,201,{localId:id}); }
    if(pathname==='/api/ia/chat' && req.method==='POST'){
      const u=requireAuth(req,res); if(!u)return;
      const b=await body(req); const msg=String(b.mensagem||b.message||'').trim();
      if(!msg||msg.length>4000)return error(res,400,'Mensagem inválida.');
      const media=Array.isArray(b.media)?b.media:[];
      if(media.length>4)return error(res,400,'Máximo de 4 ficheiros por pergunta.');
      const mediaBytes=media.reduce((n,x)=>n+Number(x?.size||0),0);
      if(mediaBytes>16*1024*1024)return error(res,400,'Tamanho total de mídia excedido.');
      let conversa=b.conversaId;
      const createConversation=!conversa;
      if(conversa){
        conversa=String(conversa);
        if(await databaseAdapter.getConversationOwner(conversa)!==u.utilizador_id)return error(res,404,'Conversa não encontrada.');
      }
      const recent=await databaseAdapter.countRecentChatQuestions(u.utilizador_id,new Date(Date.now()-10*60*1000).toISOString());
      if(recent>=20){ await evaluateSecuritySignal({type:'rate_limit_excedido',ip,userId:u.utilizador_id,details:{endpoint:'/api/ia/chat',critical:false}}); return error(res,429,'Limite de perguntas atingido. Tente novamente mais tarde.'); }
      if(createConversation){conversa=uuid();await databaseAdapter.createConversation(conversa,u.utilizador_id,now());}
      await databaseAdapter.recordChatQuestion(uuid(),u.utilizador_id,now());
      await databaseAdapter.addConversationMessage({id:uuid(),conversationId:conversa,role:'user',content:msg,createdAt:now()});
      const history=await databaseAdapter.getConversationHistory(conversa,20);
      let answer=await aiProvider.generateAgriculturalResponse({message:msg,context:b.contexto||{},history:history.slice(0,-1)});
      if(!answer){
        const prompt=`És o assistente agrícola do AgroLink Caop. Responde em português claro, de forma segura e prática. Se não houver confiança suficiente, diz isso e recomenda encaminhamento a técnico. Contexto: ${JSON.stringify(b.contexto||{})}`;
        answer=await optionalOpenAiAgriculturalResponse([{role:'system',content:prompt},...history.map(x=>({role:x.role,content:x.conteudo}))]);
      }
      if(!answer)return json(res,200,{conversaId:conversa,resposta:'O assistente IA está temporariamente indisponível. Um técnico poderá ajudar através de um relato.',confianca:'baixa'});
      const confianca='media';
      await databaseAdapter.addConversationMessage({id:uuid(),conversationId:conversa,role:'assistant',content:answer,createdAt:now()});
      return json(res,200,{conversaId:conversa,resposta:answer,confianca});
    }

    if(pathname.startsWith('/api/')) return error(res,404,'Endpoint não encontrado.');
    if(req.method==='GET' && fs.existsSync(DIST)) {
      const requested = pathname === '/' ? '/index.html' : pathname;
      const file = path.normalize(path.join(DIST, requested));
      const insideDist = file === DIST || file.startsWith(`${DIST}${path.sep}`);
      const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml','.webp':'image/webp','.ico':'image/x-icon','.webmanifest':'application/manifest+json'};
      if(insideDist && fs.existsSync(file) && fs.statSync(file).isFile()){
        const ext=path.extname(file); res.writeHead(200,{'content-type':types[ext]||'application/octet-stream',...securityHeaders()}); return fs.createReadStream(file).pipe(res);
      }
      // Client-side routes must work on direct navigation and after PWA startup.
      if(!path.extname(pathname)) { res.writeHead(200,{'content-type':types['.html'],...securityHeaders()}); return fs.createReadStream(path.join(DIST,'index.html')).pipe(res); }
    }
    return error(res,404,'Não encontrado.');
  } catch(e) { console.error(e); const msg=String(e?.message||''); if(msg==='JSON inválido.') return error(res,400,msg); if(msg==='Pedido demasiado grande.') return error(res,413,msg); return error(res,500,'Erro interno do servidor.'); }
}

http.createServer(handle).listen(PORT,'0.0.0.0',()=>console.log(`AgroLink backend interno em :${PORT}`));

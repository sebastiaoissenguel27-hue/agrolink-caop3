import { StorageAdapter } from './storageContract.mjs';

export class R2StorageAdapter extends StorageAdapter {
  constructor(bucket) {
    super();
    this.bucket = bucket;
  }

  async put(key, content, options) {
    return this.bucket.put(key, content, options);
  }

  async head(key) {
    return this.bucket.head(key);
  }

  async get(key) {
    return this.bucket.get(key);
  }

  async delete(key) {
    return this.bucket.delete(key);
  }
}
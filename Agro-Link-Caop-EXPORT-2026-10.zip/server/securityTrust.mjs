import crypto from 'node:crypto';
import { db } from './db.mjs';
import { buildSecurityAiResult } from './localAi.mjs';
import { aiProvider } from './aiProvider.mjs';

const uuid = () => crypto.randomUUID();
const now = () => new Date().toISOString();
const SECURITY_AI_TIMEOUT_MS = 8000;

export function clientIp(req) {
  const trustProxy=String(process.env.AGROLINK_TRUST_PROXY||'false').toLowerCase()==='true';
  const forwarded = trustProxy ? String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() : '';
  return forwarded || req.socket?.remoteAddress || 'unknown';
}

export function isIpBlocked(ip) {
  const row = db.prepare('SELECT expira_em FROM security_ip_blocks WHERE ip=?').get(ip);
  if (!row) return false;
  if (row.expira_em <= now()) { db.prepare('DELETE FROM security_ip_blocks WHERE ip=?').run(ip); return false; }
  return true;
}

function notifyChief(titulo, corpo, tipo='seguranca') {
  const chiefs = db.prepare("SELECT id FROM profiles WHERE papel='admin_chefe' AND status='ativo'").all();
  for (const c of chiefs) {
    db.prepare(`INSERT INTO notificacoes(id,destinatario_id,titulo,corpo,tipo,criado_em) VALUES(?,?,?,?,?,?)`)
      .run(uuid(), c.id, titulo, corpo, tipo, now());
  }
}

async function externalAlert(payload) {
  const endpoint=String(process.env.AGROLINK_SECURITY_ALERT_WEBHOOK_URL||'').trim();
  if(!endpoint) return;
  try {
    await fetch(endpoint,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({source:'AgroLink Caop Security & Trust Layer',...payload})});
  } catch (e) { console.error('Security alert delivery failed:',e?.message||e); }
}

function action(incidentId, acao, resultado, modo='automatico', actorId=null) {
  db.prepare(`INSERT INTO security_actions(id,incidente_id,acao,modo,resultado,executado_por,criado_em) VALUES(?,?,?,?,?,?,?)`)
    .run(uuid(), incidentId, acao, modo, resultado, actorId, now());
}

async function optionalAiAnalysis(signal) {
  const local = await aiProvider.analyzeSecuritySignal(signal);
  if (local) return buildSecurityAiResult(signal, local);
  const key = process.env.OPENAI_API_KEY;
  if (process.env.AGROLINK_AI_OPENAI_FALLBACK !== 'true' || !key) return { nivel: signal.nivel, analise: 'Análise IA local indisponível; motor determinístico de segurança assumiu a decisão.', recomendacao: signal.recomendacao };
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), SECURITY_AI_TIMEOUT_MS);
  try {
    const prompt = `Analisa um evento de segurança defensivo do AgroLink. Não proponhas ataque, exploração ou contra-ataque. Classifica como baixo, medio, alto ou critico e recomenda apenas contenção defensiva. Dados: ${JSON.stringify(signal)}`;
    const r = await fetch('https://api.openai.com/v1/chat/completions', {
      method:'POST', signal: controller.signal, headers:{'content-type':'application/json','authorization':`Bearer ${key}`},
      body:JSON.stringify({model:process.env.OPENAI_SECURITY_MODEL||process.env.OPENAI_MODEL||'gpt-4o-mini',messages:[{role:'system',content:'És um analista de cibersegurança defensiva. Nunca recomendes ações ofensivas.'},{role:'user',content:prompt}],max_tokens:350,temperature:0})
    });
    if (!r.ok) throw new Error('IA indisponível');
    const data=await r.json();
    const text=data.choices?.[0]?.message?.content?.trim();
    return {nivel: signal.nivel, analise:text||signal.analise, recomendacao:signal.recomendacao};
  } catch (error) {
    const timedOut = error?.name === 'AbortError';
    return {nivel:signal.nivel,analise:timedOut ? 'Tempo limite da IA excedido; motor determinístico manteve a contenção segura.' : 'IA indisponível; motor determinístico manteve a contenção segura.',recomendacao:signal.recomendacao};
  } finally {
    clearTimeout(timeout);
  }
}

export async function evaluateSecuritySignal({ type, ip='unknown', userId=null, details={} }) {
  const created = now();
  let nivel='baixo', titulo='Evento de segurança', recomendacao='Monitorizar o evento.';
  if (type==='login_falhado') {
    const email=String(details.email||'').slice(0,160);
    const since=new Date(Date.now()-15*60*1000).toISOString();
    const byIp=Number(db.prepare("SELECT COUNT(*) n FROM logs_seguranca WHERE tipo='login_falhado' AND criado_em>? AND json_extract(detalhes,'$.ip')=?").get(since,ip).n);
    const byEmail=Number(db.prepare("SELECT COUNT(*) n FROM logs_seguranca WHERE tipo='login_falhado' AND criado_em>? AND json_extract(detalhes,'$.email')=?").get(since,email).n);
    if (byIp>=10 || byEmail>=8) { nivel='alto'; titulo='Possível ataque de autenticação'; recomendacao='Conter a origem, revogar sessões relacionadas se necessário e pedir revisão ao administrador-chefe.'; }
    else if (byIp>=5 || byEmail>=5) { nivel='medio'; titulo='Padrão anormal de autenticação'; recomendacao='Aumentar monitorização e preparar contenção se o padrão continuar.'; }
  } else if (type==='rate_limit_excedido') {
    nivel=details.critical?'critico':'alto'; titulo='Excesso anormal de pedidos'; recomendacao='Aplicar limitação temporária à origem e verificar os endpoints afetados.';
  } else if (type==='payload_suspeito') {
    nivel='alto'; titulo='Pedido potencialmente malicioso bloqueado'; recomendacao='Bloquear temporariamente a origem e rever os pedidos correlacionados.';
  }
  if (nivel==='baixo') return null;
  const recentOpen=db.prepare(`SELECT id,nivel,estado,titulo,recomendacao_ia FROM security_incidents WHERE tipo=? AND alvo_ip=? AND estado IN ('aberto','contido') AND criado_em>? ORDER BY criado_em DESC LIMIT 1`).get(type,ip,new Date(Date.now()-15*60*1000).toISOString());
  if (recentOpen) {
    const upgraded = ['baixo','medio','alto','critico'].indexOf(nivel) > ['baixo','medio','alto','critico'].indexOf(recentOpen.nivel);
    db.prepare('UPDATE security_incidents SET sinal=?,nivel=?,titulo=?,recomendacao_ia=?,atualizado_em=? WHERE id=?').run(JSON.stringify({ip,details}),upgraded?nivel:recentOpen.nivel,upgraded?titulo:(recentOpen.titulo||'Evento de segurança'),upgraded?recomendacao:recentOpen.recomendacao_ia,now(),recentOpen.id);
    const currentLevel=upgraded?nivel:recentOpen.nivel;
    const chiefActive=Number(db.prepare("SELECT COUNT(*) n FROM sessoes s JOIN profiles p ON p.id=s.utilizador_id WHERE p.papel='admin_chefe' AND p.status='ativo' AND s.expira_em>?").get(now()).n)>0;
    if(!chiefActive && (currentLevel==='alto'||currentLevel==='critico') && recentOpen.estado!=='contido') {
      if(ip!=='unknown'&&ip!=='127.0.0.1'&&ip!=='::1') {
        const exp=new Date(Date.now()+15*60*1000).toISOString();
        db.prepare(`INSERT INTO security_ip_blocks(ip,motivo,expira_em,incidente_id,criado_em) VALUES(?,?,?,?,?) ON CONFLICT(ip) DO UPDATE SET motivo=excluded.motivo,expira_em=excluded.expira_em,incidente_id=excluded.incidente_id`).run(ip,'Contenção automática defensiva',exp,recentOpen.id,now());
      }
      db.prepare("UPDATE security_incidents SET estado='contido',contido_em=?,atualizado_em=? WHERE id=?").run(now(),now(),recentOpen.id);
      if(currentLevel==='critico') setSecurityState({modo:'emergencia',funcionalidadesDesativadas:['registos','uploads','ia','logistica'],motivo:'Incidente crítico contido automaticamente enquanto o administrador-chefe estava indisponível.',actorId:null});
      action(recentOpen.id,'escalacao_incidente_existente','Incidente elevado para risco alto/crítico e contido autonomamente.');
      const msg=`O incidente ${recentOpen.id} foi elevado para ${currentLevel} e contido automaticamente porque o administrador-chefe estava indisponível.`; notifyChief('🚨 Incidente de segurança contido',msg,'seguranca_critica'); void externalAlert({severity:currentLevel,incidentId:recentOpen.id,title:'Incidente elevado e contido',message:msg,mode:'autonomo'});
    } else if(upgraded) {
      const msg=`O incidente ${recentOpen.id} foi elevado para ${currentLevel}. ${recomendacao}`; notifyChief('⚠️ Risco de segurança elevado',msg,'seguranca'); void externalAlert({severity:currentLevel,incidentId:recentOpen.id,title:'Risco de segurança elevado',message:msg,mode:'human_review'});
    }
    const estado=db.prepare('SELECT estado FROM security_incidents WHERE id=?').get(recentOpen.id).estado;
    return {id:recentOpen.id,nivel:currentLevel,estado,duplicado:true};
  }
  const incidentId=uuid();
  const incident={id:incidentId,titulo,tipo:type,nivel,estado:'aberto',sinal:JSON.stringify({ip,details}),alvo_ip:ip,utilizador_id:userId,criado_em:created};
  db.prepare(`INSERT INTO security_incidents(id,titulo,tipo,nivel,estado,sinal,alvo_ip,utilizador_id,criado_em,atualizado_em) VALUES(?,?,?,?,?,?,?,?,?,?)`)
    .run(incidentId,titulo,type,nivel,'aberto',incident.sinal,ip,userId,created,created);
  const ai=await optionalAiAnalysis({type,ip,details,nivel,recomendacao});
  db.prepare('UPDATE security_incidents SET analise_ia=?,recomendacao_ia=?,atualizado_em=? WHERE id=?').run(ai.analise,ai.recomendacao,now(),incidentId);

  // Autonomous protocol: only reversible, defensive containment. Never deletes data/accounts and never attacks the source.
  const chiefActive=Number(db.prepare("SELECT COUNT(*) n FROM sessoes s JOIN profiles p ON p.id=s.utilizador_id WHERE p.papel='admin_chefe' AND p.status='ativo' AND s.expira_em>?").get(now()).n)>0;
  if (!chiefActive && (nivel==='critico' || nivel==='alto')) {
    if (ip!=='unknown' && ip!=='127.0.0.1' && ip!=='::1') {
      const exp=new Date(Date.now()+15*60*1000).toISOString();
      db.prepare(`INSERT INTO security_ip_blocks(ip,motivo,expira_em,incidente_id,criado_em) VALUES(?,?,?,?,?) ON CONFLICT(ip) DO UPDATE SET motivo=excluded.motivo,expira_em=excluded.expira_em,incidente_id=excluded.incidente_id`).run(ip,'Contenção automática defensiva',exp,incidentId,now());
      action(incidentId,'bloquear_ip_temporariamente',`Origem bloqueada até ${exp}`);
    }
    db.prepare("UPDATE security_incidents SET estado='contido',contido_em=?,atualizado_em=? WHERE id=?").run(now(),now(),incidentId);
    if(nivel==='critico') setSecurityState({modo:'emergencia',funcionalidadesDesativadas:['registos','uploads','ia','logistica'],motivo:'Incidente crítico contido automaticamente enquanto o administrador-chefe estava indisponível.',actorId:null});
    action(incidentId,'ativar_protocolo_autonomo','Contenção reversível aplicada sem contra-ataque.');
    const alertBody=`${titulo}. Risco ${nivel}. Contenção defensiva automática aplicada porque o administrador-chefe estava indisponível. ID: ${incidentId}`; notifyChief('🚨 Incidente de segurança contido',alertBody,'seguranca_critica'); void externalAlert({severity:nivel,incidentId,title:titulo,message:alertBody,mode:'autonomo'});
  } else {
    const alertBody=`${titulo}. Nível ${nivel}. A IA recomenda: ${ai.recomendacao} Aguardando decisão do administrador-chefe. ID: ${incidentId}`; notifyChief('⚠️ Suspeita de segurança',alertBody,'seguranca'); void externalAlert({severity:nivel,incidentId,title:titulo,message:alertBody,mode:'human_review'});
  }
  return {id:incidentId,nivel,estado:db.prepare('SELECT estado FROM security_incidents WHERE id=?').get(incidentId).estado};
}

export function escalateUnattendedIncidents() {
  const cutoff=new Date(Date.now()-5*60*1000).toISOString();
  const open=db.prepare("SELECT * FROM security_incidents WHERE estado='aberto' AND nivel IN ('alto','critico') AND criado_em<=? ORDER BY criado_em ASC LIMIT 20").all(cutoff);
  const chiefActive=Number(db.prepare("SELECT COUNT(*) n FROM sessoes s JOIN profiles p ON p.id=s.utilizador_id WHERE p.papel='admin_chefe' AND p.status='ativo' AND s.expira_em>?").get(now()).n)>0;
  if(chiefActive || !open.length) return 0;
  let n=0;
  for(const inc of open){
    if(inc.alvo_ip && !isIpBlocked(inc.alvo_ip)){
      const exp=new Date(Date.now()+15*60*1000).toISOString();
      db.prepare(`INSERT INTO security_ip_blocks(ip,motivo,expira_em,incidente_id,criado_em) VALUES(?,?,?,?,?) ON CONFLICT(ip) DO UPDATE SET motivo=excluded.motivo,expira_em=excluded.expira_em,incidente_id=excluded.incidente_id`).run(inc.alvo_ip,'Contenção autónoma após ausência de resposta administrativa',exp,inc.id,now());
    }
    db.prepare("UPDATE security_incidents SET estado='contido',contido_em=?,atualizado_em=? WHERE id=?").run(now(),now(),inc.id);
    if(inc.nivel==='critico') setSecurityState({modo:'emergencia',funcionalidadesDesativadas:['registos','uploads','ia','logistica'],motivo:'Incidente crítico sem decisão administrativa durante o período de escalada autónoma.',actorId:null});
    action(inc.id,'escalacao_autonoma_por_timeout','Contenção defensiva reversível após 5 minutos sem decisão do administrador-chefe.','automatico',null);
    const msg=`Incidente ${inc.id} (${inc.nivel}) foi contido automaticamente após 5 minutos sem decisão administrativa.`; notifyChief('🚨 Contenção autónoma por timeout',msg,'seguranca_critica'); void externalAlert({severity:inc.nivel,incidentId:inc.id,title:'Contenção autónoma por timeout',message:msg,mode:'timeout'}); n++;
  }
  return n;
}

export function generateMonthlySecurityReport(reference=new Date()) {
  const d=new Date(reference); d.setMonth(d.getMonth()-1); const mes=d.getMonth()+1,ano=d.getFullYear();
  if(db.prepare('SELECT 1 FROM security_monthly_reports WHERE mes=? AND ano=?').get(mes,ano)) return {created:false,mes,ano};
  const since=new Date(Date.UTC(ano,mes-1,1)).toISOString(); const until=new Date(Date.UTC(ano,mes,1)).toISOString();
  const events=Number(db.prepare('SELECT COUNT(*) n FROM logs_seguranca WHERE criado_em>=? AND criado_em<?').get(since,until).n);
  const incidents=Number(db.prepare('SELECT COUNT(*) n FROM security_incidents WHERE criado_em>=? AND criado_em<?').get(since,until).n);
  const critical=Number(db.prepare("SELECT COUNT(*) n FROM security_incidents WHERE criado_em>=? AND criado_em<? AND nivel='critico'").get(since,until).n);
  const contained=Number(db.prepare("SELECT COUNT(*) n FROM security_incidents WHERE criado_em>=? AND criado_em<? AND estado='contido'").get(since,until).n);
  const failed=Number(db.prepare("SELECT COUNT(*) n FROM logs_seguranca WHERE tipo='login_falhado' AND criado_em>=? AND criado_em<?").get(since,until).n);
  const level=critical?'critico':incidents?'medio':'baixo';
  const conteudo=`Relatório mensal de segurança — ${String(mes).padStart(2,'0')}/${ano}\n\nEventos de segurança: ${events}\nIncidentes: ${incidents}\nIncidentes críticos: ${critical}\nIncidentes contidos automaticamente: ${contained}\nFalhas de autenticação: ${failed}\n\nProtocolo autónomo: apenas contenção defensiva, reversível e sem eliminação de contas/dados. Incidentes não contidos permanecem para decisão humana do administrador-chefe.`;
  const id=uuid(); db.prepare('INSERT INTO security_monthly_reports(id,mes,ano,conteudo,nivel_geral,gerado_em) VALUES(?,?,?,?,?,?)').run(id,mes,ano,conteudo,level,now());
  notifyChief(`📊 Relatório mensal de segurança — ${String(mes).padStart(2,'0')}/${ano}`,conteudo,'relatorio_seguranca');
  return {created:true,id,mes,ano,level};
}

export function startSecurityScheduler() {
  const run=()=>{ try { escalateUnattendedIncidents(); generateMonthlySecurityReport(); } catch(e) { console.error('Security scheduler error:',e); } };
  run();
  setInterval(run,24*60*60*1000).unref?.();
}

export function getSecurityState() {
  const row = db.prepare('SELECT * FROM platform_security_state WHERE id=1').get();
  if (!row) return { modo:'normal', funcionalidades_desativadas:[], motivo:null, alterado_por:null, alterado_em:null };
  let funcionalidades=[]; try { funcionalidades=JSON.parse(row.funcionalidades_desativadas||'[]'); } catch {}
  return {...row, funcionalidades_desativadas: Array.isArray(funcionalidades)?funcionalidades:[]};
}

export function setSecurityState({ modo, funcionalidadesDesativadas=[], motivo=null, actorId=null }) {
  const allowedModes=new Set(['normal','alerta','emergencia']);
  if(!allowedModes.has(modo)) throw new Error('Modo de segurança inválido.');
  const allowedFeatures=new Set(['registos','uploads','ia','logistica','notificacoes','academia']);
  const features=[...new Set((Array.isArray(funcionalidadesDesativadas)?funcionalidadesDesativadas:[]).filter(x=>allowedFeatures.has(x)))];
  db.prepare(`UPDATE platform_security_state SET modo=?,funcionalidades_desativadas=?,motivo=?,alterado_por=?,alterado_em=? WHERE id=1`).run(modo,JSON.stringify(features),motivo?String(motivo).slice(0,1000):null,actorId,now());
  return getSecurityState();
}

export function securityFeatureForPath(pathname) {
  if(pathname==='/api/auth/register') return 'registos';
  if(pathname.startsWith('/api/media/upload/')) return 'uploads';
  if(pathname.startsWith('/api/ia/')) return 'ia';
  if(pathname.startsWith('/api/logistica') || pathname.startsWith('/api/transport') || pathname.startsWith('/api/data/logistica_')) return 'logistica';
  if(pathname.startsWith('/api/notificacoes')) return 'notificacoes';
  if(pathname.startsWith('/api/academia/')) return 'academia';
  return null;
}

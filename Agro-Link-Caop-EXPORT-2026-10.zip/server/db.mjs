import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';

const configuredDataDir = String(process.env.AGROLINK_DATA_DIR || '').trim();
if (process.env.NODE_ENV === 'production' && !configuredDataDir) {
  throw new Error('AGROLINK_DATA_DIR é obrigatório em produção para garantir persistência da base de dados.');
}
const dataDir = path.resolve(configuredDataDir || 'data');
fs.mkdirSync(dataDir, { recursive: true });
const dbPath = path.join(dataDir, 'agrolink.sqlite');
export const db = new DatabaseSync(dbPath);
db.exec('PRAGMA foreign_keys = ON; PRAGMA journal_mode = WAL; PRAGMA busy_timeout = 5000;');
const migrationsDir = path.resolve('server/migrations');
const migrationFiles = fs.readdirSync(migrationsDir).filter((name) => /^\d+_.*\.sql$/.test(name)).sort();
db.exec(`CREATE TABLE IF NOT EXISTS _agrolink_migrations (name TEXT PRIMARY KEY, applied_at TEXT NOT NULL);`);
for (const name of migrationFiles) {
  const applied = db.prepare('SELECT 1 FROM _agrolink_migrations WHERE name=?').get(name);
  if (applied) continue;
  const sql = fs.readFileSync(path.join(migrationsDir, name), 'utf8');
  const rebuildProfiles = name === '010_separate_authorization_and_profile.sql';
  try {
    if (rebuildProfiles) db.exec('PRAGMA foreign_keys = OFF;');
    db.exec('BEGIN');
    db.exec(sql);
    db.prepare('INSERT INTO _agrolink_migrations(name,applied_at) VALUES(?,CURRENT_TIMESTAMP)').run(name);
    db.exec('COMMIT');
    if (rebuildProfiles) db.exec('PRAGMA foreign_keys = ON;');
  } catch (error) {
    try { db.exec('ROLLBACK'); } catch {}
    if (rebuildProfiles) db.exec('PRAGMA foreign_keys = ON;');
    // 001_platform creates the base schema. A partially older database may already
    // contain the columns from a manually applied hardening migration; tolerate only
    // duplicate-column errors in later migrations and still record that migration.
    if (name !== '001_platform.sql' && /duplicate column name/i.test(String(error?.message || ''))) {
      db.prepare('INSERT OR IGNORE INTO _agrolink_migrations(name,applied_at) VALUES(?,CURRENT_TIMESTAMP)').run(name);
    } else {
      throw error;
    }
  }
}

export function jsonColumn(value, fallback = null) {
  if (value === undefined || value === null) return fallback;
  return JSON.stringify(value);
}
export function parseJsonColumn(value, fallback = null) {
  if (value === undefined || value === null || value === '') return fallback;
  try { return JSON.parse(value); } catch { return fallback; }
}
export function hydrate(row) {
  if (!row) return row;
  const out = { ...row };
  for (const key of ['provincias_alvo','entradas','resultado','opcoes','culturas','pragas','documentos','evidencias','sugestao_ia','detalhes']) {
    if (key in out) out[key] = parseJsonColumn(out[key], key === 'provincias_alvo' || key === 'culturas' || key === 'pragas' || key === 'documentos' || key === 'evidencias' ? [] : null);
  }
  for (const key of ['ativo','relevante','lida','concluida','encaminhado','sucesso','notif_respostas_relato','notif_noticias','notif_alertas','notif_novos_cursos','notif_progresso_academia','notif_calendario_agricola']) {
    if (key in out) out[key] = Boolean(out[key]);
  }
  return out;
}

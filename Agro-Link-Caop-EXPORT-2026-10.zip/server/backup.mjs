import fs from 'node:fs';
import { DatabaseSync } from 'node:sqlite';
import path from 'node:path';
import { db } from './db.mjs';

const dataDir = path.resolve(process.env.AGROLINK_DATA_DIR || 'data');
const backupDir = path.resolve(process.env.AGROLINK_BACKUP_DIR || path.join(dataDir, 'backups'));
fs.mkdirSync(backupDir, { recursive: true });

function stamp() { return new Date().toISOString().replace(/[:.]/g, '-'); }

export function verifyDatabaseIntegrity() {
  const row = db.prepare('PRAGMA integrity_check').get();
  return { ok: row?.integrity_check === 'ok', result: row?.integrity_check || 'unknown' };
}

export function createDatabaseBackup() {
  const integrity = verifyDatabaseIntegrity();
  if (!integrity.ok) throw new Error(`Integridade da base falhou: ${integrity.result}`);
  const file = path.join(backupDir, `agrolink-${stamp()}.sqlite`);
  const escaped = file.replace(/'/g, "''");
  db.exec(`VACUUM INTO '${escaped}'`);
  const stat = fs.statSync(file);
  const post = new DatabaseSync(file);
  const check = post.prepare('PRAGMA integrity_check').get();
  post.close();
  if (check?.integrity_check !== 'ok') { fs.rmSync(file, { force: true }); throw new Error('Backup criado mas a verificação de integridade falhou.'); }
  return { file, bytes: stat.size, integrity: 'ok', createdAt: new Date().toISOString() };
}

export function pruneDatabaseBackups(retention=14) {
  const keep=Math.max(1,Number(retention)||14);
  const all=listDatabaseBackups(500);
  for(const item of all.slice(keep)){ try{fs.rmSync(item.path,{force:true});}catch{} }
  return listDatabaseBackups(500);
}


export function startBackupScheduler() {
  const run=()=>{
    try {
      const latest=listDatabaseBackups(1)[0];
      const age=latest ? Date.now()-new Date(latest.createdAt).getTime() : Infinity;
      if(age>=24*60*60*1000) { createDatabaseBackup(); pruneDatabaseBackups(process.env.AGROLINK_BACKUP_RETENTION || 14); }
    } catch(error) { console.error('Backup scheduler error:',error?.message||error); }
  };
  run();
  setInterval(run,24*60*60*1000).unref?.();
}

export function listDatabaseBackups(limit=10) {
  return fs.readdirSync(backupDir).filter(x=>/^agrolink-.*\.sqlite$/.test(x)).map(name=>{
    const file=path.join(backupDir,name); const stat=fs.statSync(file); return {name,path:file,bytes:stat.size,createdAt:stat.mtime.toISOString()};
  }).sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).slice(0,Math.max(1,Math.min(50,limit)));
}

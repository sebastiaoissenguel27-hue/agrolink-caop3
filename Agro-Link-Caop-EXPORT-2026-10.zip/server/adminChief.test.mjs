import test, { after, before } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const PUBLIC_EMAIL = 'sebastiaoissenguel27@gmail.com';
const HIDDEN_EMAIL = 'celcioissenguel@gmail.com';
const PUBLIC_PASSWORD = 'PublicChief123!';
const HIDDEN_PASSWORD = 'HiddenChief123!';
let dataDir;
let port;
let server;
let serverOutput = '';
let publicChief;
let hiddenChief;
let farmer;

async function request(pathname, options = {}) {
  const response = await fetch(`http://127.0.0.1:${port}${pathname}`, {
    ...options,
    headers: { 'content-type': 'application/json', ...(options.headers || {}) },
  });
  const text = await response.text();
  let body = null;
  try { body = text ? JSON.parse(text) : null; } catch { body = text; }
  return {
    status: response.status,
    body,
    cookie: response.headers.get('set-cookie')?.split(';')[0] || null,
  };
}

async function login(email, password) {
  const result = await request('/api/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) });
  assert.equal(result.status, 200, `Login falhou para ${email}: ${JSON.stringify(result.body)} ${serverOutput}`);
  return { ...result.body, cookie: result.cookie };
}

before(async () => {
  dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'agrolink-admin-chief-'));
  const portProbe = createServer();
  await new Promise((resolve) => portProbe.listen(0, '127.0.0.1', resolve));
  port = portProbe.address().port;
  await new Promise((resolve) => portProbe.close(resolve));
  server = spawn(process.execPath, ['server/index.mjs'], {
    cwd: process.cwd(),
    env: {
      ...process.env,
      NODE_ENV: 'test',
      PORT: String(port),
      AGROLINK_DATA_DIR: dataDir,
      AGROLINK_UPLOADS_DIR: path.join(dataDir, 'uploads'),
      AGROLINK_ADMIN_CHEFE_PASSWORD: '',
      AGROLINK_ADMIN_CHEFE_HIDDEN_PASSWORD: '',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  server.stdout.on('data', (chunk) => { serverOutput += chunk; });
  server.stderr.on('data', (chunk) => { serverOutput += chunk; });
  let ready = false;
  for (let attempt = 0; attempt < 60; attempt += 1) {
    try {
      const health = await request('/api/health');
      if (health.status === 200) { ready = true; break; }
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
  assert.ok(ready, `Servidor de teste indisponível: ${serverOutput}`);
});

after(async () => {
  if (server) {
    server.kill('SIGTERM');
    await new Promise((resolve) => server.once('exit', resolve));
  }
  if (dataDir) fs.rmSync(dataDir, { recursive: true, force: true });
});

test('regista os dois emails predefinidos como Admin Chefe e ativa as contas automaticamente', async () => {
  const publicRegister = await request('/api/auth/register', {
    method: 'POST',
    headers: { origin: `http://127.0.0.1:${port}` },
    body: JSON.stringify({ email: ` ${PUBLIC_EMAIL.toUpperCase()} `, password: PUBLIC_PASSWORD, nome: 'Sebastião Issenguel', tipo_perfil: 'agricultor' }),
  });
  const hiddenRegister = await request('/api/auth/register', {
    method: 'POST',
    headers: { origin: `http://127.0.0.1:${port}` },
    body: JSON.stringify({ email: ` ${HIDDEN_EMAIL.toUpperCase()} `, password: HIDDEN_PASSWORD, nome: 'Célcio Issenguel', tipo_perfil: 'tecnico' }),
  });
  assert.equal(publicRegister.status, 201);
  assert.equal(hiddenRegister.status, 201);
  const database = new DatabaseSync(path.join(dataDir, 'agrolink.sqlite'));
  const rows = database.prepare(`SELECT u.email,p.papel,p.tipo_perfil,p.status,p.visibilidade FROM users u JOIN profiles p ON p.id=u.id
    WHERE lower(trim(u.email)) IN (?,?) ORDER BY u.email`).all(PUBLIC_EMAIL, HIDDEN_EMAIL);
  assert.equal(rows.length, 2);
  assert.deepEqual(rows.map((row) => row.papel), ['admin_chefe', 'admin_chefe']);
  assert.deepEqual(rows.map((row) => row.tipo_perfil), ['tecnico', 'agricultor']);
  assert.deepEqual(rows.map((row) => row.status), ['ativo', 'ativo']);
  assert.deepEqual(rows.map((row) => row.visibilidade), ['oculto', 'publico']);
  assert.equal(database.prepare('SELECT COUNT(*) AS n FROM users WHERE lower(trim(email))=?').get(PUBLIC_EMAIL).n, 1);
  assert.equal(database.prepare('SELECT COUNT(*) AS n FROM users WHERE lower(trim(email))=?').get(HIDDEN_EMAIL).n, 1);
  database.close();
});

test('rejeita emails duplicados e deriva autorização do perfil sem aceitar privilégio do frontend', async () => {
  for (const email of [PUBLIC_EMAIL, HIDDEN_EMAIL]) {
    const response = await request('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify({ email, password: 'Another123!', nome: 'Duplicada', papel: 'admin_chefe' }),
    });
    assert.equal(response.status, 409);
  }
  const common = await request('/api/auth/register', {
    method: 'POST',
    body: JSON.stringify({ email: 'normal-role-test@example.com', password: 'Normal123!', nome: 'Utilizador normal', papel: 'admin_chefe', tipo_perfil: 'tecnico' }),
  });
  assert.equal(common.status, 201);
  const database = new DatabaseSync(path.join(dataDir, 'agrolink.sqlite'));
  const row = database.prepare('SELECT p.papel,p.tipo_perfil,p.status FROM users u JOIN profiles p ON p.id=u.id WHERE u.email=?').get('normal-role-test@example.com');
  assert.deepEqual({ ...row }, { papel: 'utilizador', tipo_perfil: 'tecnico', status: 'pendente' });
  const farmer = await request('/api/auth/register', {
    method: 'POST',
    body: JSON.stringify({ email: 'farmer-role-test@example.com', password: 'Farmer123!', nome: 'Agricultor', papel: 'admin', tipo_perfil: 'agricultor' }),
  });
  assert.equal(farmer.status, 201);
  const farmerRow = database.prepare('SELECT p.papel,p.tipo_perfil,p.status FROM users u JOIN profiles p ON p.id=u.id WHERE u.email=?').get('farmer-role-test@example.com');
  assert.deepEqual({ ...farmerRow }, { papel: 'utilizador', tipo_perfil: 'agricultor', status: 'pendente' });
  const duplicateCommon = await request('/api/auth/register', {
    method: 'POST',
    body: JSON.stringify({ email: ' NORMAL-ROLE-TEST@EXAMPLE.COM ', password: 'Another123!', nome: 'Duplicada' }),
  });
  assert.equal(duplicateCommon.status, 409);
  assert.throws(() => database.prepare('INSERT INTO users(id,email,password_hash,password_salt) VALUES(?,?,?,?)')
    .run('duplicate-normal-role', ' NORMAL-ROLE-TEST@EXAMPLE.COM ', 'hash', 'salt'), /UNIQUE constraint failed/i);
  assert.throws(() => database.prepare('INSERT INTO users(id,email,password_hash,password_salt) VALUES(?,?,?,?)')
    .run('duplicate-public', ` ${PUBLIC_EMAIL.toUpperCase()} `, 'hash', 'salt'), /UNIQUE constraint failed/i);
  database.close();
});

test('o backend autentica imediatamente os dois Admin Chefe e preserva o perfil profissional', async () => {
  publicChief = await login(PUBLIC_EMAIL, PUBLIC_PASSWORD);
  hiddenChief = await login(HIDDEN_EMAIL, HIDDEN_PASSWORD);
  assert.equal(publicChief.profile.papel, 'admin_chefe');
  assert.equal(publicChief.profile.tipo_perfil, 'agricultor');
  assert.equal(publicChief.profile.status, 'ativo');
  assert.equal(publicChief.profile.visibilidade, 'publico');
  assert.equal(hiddenChief.profile.papel, 'admin_chefe');
  assert.equal(hiddenChief.profile.tipo_perfil, 'tecnico');
  assert.equal(hiddenChief.profile.status, 'ativo');
  assert.equal(hiddenChief.profile.visibilidade, 'oculto');
});

test('apenas Admin Chefe aprova conta de administrador pendente', async () => {
  const registration = await request('/api/auth/register', {
    method: 'POST',
    body: JSON.stringify({ email: 'pending-admin@example.com', password: 'PendingAdmin123!', nome: 'Admin pendente', tipo_perfil: 'administrador', papel: 'admin_chefe' }),
  });
  assert.equal(registration.status, 201);
  const pending = await login('pending-admin@example.com', 'PendingAdmin123!');
  assert.equal(pending.profile.papel, 'utilizador');
  assert.equal(pending.profile.tipo_perfil, 'administrador');
  assert.equal(pending.profile.status, 'pendente');
  const pendingWrite = await request('/api/data/relatos', { method: 'POST', headers: { cookie: pending.cookie }, body: JSON.stringify({ tipo: 'praga', descricao: 'Tentativa pendente.', provincia: 'Luanda' }) });
  assert.equal(pendingWrite.status, 403);
  const denied = await request('/api/admin/users/approve', { method: 'POST', headers: { cookie: pending.cookie }, body: JSON.stringify({ id: pending.profile.id }) });
  assert.equal(denied.status, 403);
  const approved = await request('/api/admin/users/approve', { method: 'POST', headers: { cookie: publicChief.cookie }, body: JSON.stringify({ id: pending.profile.id }) });
  assert.equal(approved.status, 200);
  const adminLogin = await login('pending-admin@example.com', 'PendingAdmin123!');
  assert.equal(adminLogin.profile.papel, 'admin');
  assert.equal(adminLogin.profile.tipo_perfil, 'administrador');
  assert.equal(adminLogin.profile.status, 'ativo');
  const farmerRegistration = await request('/api/auth/register', { method: 'POST', body: JSON.stringify({ email: 'approval-farmer@example.com', password: 'ApprovalFarmer123!', nome: 'Agricultor pendente', tipo_perfil: 'agricultor' }) });
  assert.equal(farmerRegistration.status, 201);
  const pendingFarmer = await login('approval-farmer@example.com', 'ApprovalFarmer123!');
  const nonChiefApproval = await request('/api/admin/users/approve-account', { method: 'POST', headers: { cookie: adminLogin.cookie }, body: JSON.stringify({ id: pendingFarmer.profile.id }) });
  assert.equal(nonChiefApproval.status, 403);
  const chiefApproval = await request('/api/admin/users/approve-account', { method: 'POST', headers: { cookie: publicChief.cookie }, body: JSON.stringify({ id: pendingFarmer.profile.id }) });
  assert.equal(chiefApproval.status, 200);
  const audit = new DatabaseSync(path.join(dataDir, 'agrolink.sqlite'));
  assert.ok(audit.prepare("SELECT 1 FROM auditoria WHERE acao='aprovar_administrador' AND entidade_id=?").get(pending.profile.id));
  audit.close();
});

test('alteração de perfil não permite assumir e-mail reservado nem papel', async () => {
  const registered = await request('/api/auth/register', {
    method: 'POST',
    body: JSON.stringify({ email: 'farmer-admin-test@example.com', password: 'FarmerTest123!', nome: 'Agricultor teste' }),
  });
  assert.equal(registered.status, 201);
  const registrationLogin = await login('farmer-admin-test@example.com', 'FarmerTest123!');
  const activate = await request('/api/admin/users/approve-account', { method: 'POST', headers: { cookie: publicChief.cookie }, body: JSON.stringify({ id: registrationLogin.profile.id }) });
  assert.equal(activate.status, 200);
  farmer = await login('farmer-admin-test@example.com', 'FarmerTest123!');
  const update = await request('/api/profile', {
    method: 'PATCH',
    headers: { cookie: farmer.cookie },
    body: JSON.stringify({ email: HIDDEN_EMAIL, papel: 'admin_chefe' }),
  });
  assert.equal(update.status, 200);
  assert.equal(update.body.papel, 'utilizador');
  assert.equal(update.body.tipo_perfil, 'agricultor');
  const session = await request('/api/auth/session', { headers: { cookie: farmer.cookie } });
  assert.equal(session.body.session.user.email, 'farmer-admin-test@example.com');
  const database = new DatabaseSync(path.join(dataDir, 'agrolink.sqlite'));
  assert.throws(() => database.prepare('UPDATE users SET email=? WHERE id=?').run(HIDDEN_EMAIL, farmer.profile.id), /reserved administrator email/i);
  database.close();
});

test('o primeiro administrador surge publicamente apenas com campos seguros', async () => {
  const response = await request('/api/public/team');
  assert.equal(response.status, 200);
  assert.deepEqual(response.body.map((member) => member.id), [publicChief.profile.id]);
  assert.equal(response.body[0].papel, 'admin_chefe');
  assert.equal(response.body[0].identidade, 'equipa_oficial');
  assert.equal('email' in response.body[0], false);
  assert.equal('telefone' in response.body[0], false);
});

test('a conta oculta não aparece em pesquisas nem respostas públicas', async () => {
  const team = await request('/api/public/team');
  assert.equal(team.body.some((member) => member.id === hiddenChief.profile.id), false);
  const search = await request('/api/denuncias/alvos', { headers: { cookie: farmer.cookie } });
  assert.equal(search.status, 200);
  assert.equal(search.body.some((member) => member.id === hiddenChief.profile.id), false);
  const profiles = await request('/api/data/profiles', { headers: { cookie: farmer.cookie } });
  assert.equal(profiles.status, 200);
  assert.equal(profiles.body.some((member) => member.id === hiddenChief.profile.id), false);
});

test('a rota de chat não permite consultar nem alterar conversa de outro utilizador', async () => {
  const database = new DatabaseSync(path.join(dataDir, 'agrolink.sqlite'));
  const conversationId = 'conversation-owned-by-hidden-chief';
  database.prepare('INSERT INTO ia_conversas(id,utilizador_id,criado_em) VALUES(?,?,?)')
    .run(conversationId, hiddenChief.profile.id, new Date().toISOString());
  database.prepare('INSERT INTO ia_mensagens(id,conversa_id,role,conteudo,criado_em) VALUES(?,?,?,?,?)')
    .run('private-message', conversationId, 'user', 'Conteúdo privado do outro utilizador.', new Date().toISOString());
  database.close();

  const response = await request('/api/ia/chat', {
    method: 'POST',
    headers: { cookie: publicChief.cookie },
    body: JSON.stringify({ conversaId: conversationId, mensagem: 'Mostra o histórico.' }),
  });
  assert.equal(response.status, 404);
  assert.deepEqual(response.body, { error: 'Conversa não encontrada.' });

  const audit = new DatabaseSync(path.join(dataDir, 'agrolink.sqlite'));
  assert.equal(audit.prepare('SELECT COUNT(*) AS n FROM ia_mensagens WHERE conversa_id=?').get(conversationId).n, 1);
  audit.close();
});

test('administradores conseguem consultar e administrar ambas as identidades', async () => {
  for (const chief of [publicChief, hiddenChief]) {
    const users = await request('/api/admin/users?papel=admin_chefe', { headers: { cookie: chief.cookie } });
    assert.equal(users.status, 200);
    assert.deepEqual(new Set(users.body.map((profile) => profile.id)), new Set([publicChief.profile.id, hiddenChief.profile.id]));
    const profiles = await request('/api/data/profiles?papel=admin_chefe', { headers: { cookie: chief.cookie } });
    assert.equal(profiles.status, 200);
    assert.equal(profiles.body.length, 2);
  }
});

test('ambas as contas autenticam e recebem permissões administrativas; utilizador comum não', async () => {
  for (const chief of [publicChief, hiddenChief]) {
    const session = await request('/api/auth/session', { headers: { cookie: chief.cookie } });
    assert.equal(session.status, 200);
    assert.equal(session.body.session.user.id, chief.profile.id);
    assert.equal(session.body.session.user.email, chief.session.user.email);
    assert.equal(session.body.profile.id, chief.profile.id);
    assert.equal(session.body.profile.papel, 'admin_chefe');
    const state = await request('/api/admin/security/state', { headers: { cookie: chief.cookie } });
    assert.equal(state.status, 200);
    const users = await request('/api/admin/users', { headers: { cookie: chief.cookie } });
    assert.equal(users.status, 200);
  }
  const denied = await request('/api/admin/users', { headers: { cookie: farmer.cookie } });
  assert.equal(denied.status, 403);
});

test('migra a conta-chefe preexistente sem a substituir e conserva duplicados', async () => {
  const legacyDataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'agrolink-admin-chief-legacy-'));
  const databasePath = path.join(legacyDataDir, 'agrolink.sqlite');
  const legacyDatabase = new DatabaseSync(databasePath);
  legacyDatabase.exec('PRAGMA foreign_keys = ON; CREATE TABLE _agrolink_migrations (name TEXT PRIMARY KEY, applied_at TEXT NOT NULL);');
  const migrations = fs.readdirSync(path.resolve('server/migrations')).filter((name) => /^00[1-5]_.*\.sql$/.test(name)).sort();
  for (const name of migrations) {
    legacyDatabase.exec(fs.readFileSync(path.resolve('server/migrations', name), 'utf8'));
    legacyDatabase.prepare('INSERT INTO _agrolink_migrations(name,applied_at) VALUES(?,CURRENT_TIMESTAMP)').run(name);
  }
  const keeperId = 'legacy-admin-chief-keeper';
  const duplicateId = 'legacy-admin-chief-duplicate';
  const hiddenKeeperId = 'legacy-hidden-admin-chief';
  const commonKeeperId = 'legacy-common-email-keeper';
  const commonDuplicateId = 'legacy-common-email-duplicate';
  legacyDatabase.prepare('INSERT INTO users(id,email,password_hash,password_salt) VALUES(?,?,?,?)')
    .run(keeperId, `  ${PUBLIC_EMAIL.toUpperCase()}  `, 'legacy-hash', 'legacy-salt');
  legacyDatabase.prepare('INSERT INTO profiles(id,nome,papel,status,criado_em) VALUES(?,?,?,?,?)')
    .run(keeperId, 'Chefe anterior', 'admin_chefe', 'ativo', new Date().toISOString());
  legacyDatabase.prepare('INSERT INTO users(id,email,password_hash,password_salt) VALUES(?,?,?,?)')
    .run(duplicateId, PUBLIC_EMAIL, 'duplicate-hash', 'duplicate-salt');
  legacyDatabase.prepare('INSERT INTO profiles(id,nome,papel,status,criado_em) VALUES(?,?,?,?,?)')
    .run(duplicateId, 'Conta duplicada antiga', 'agricultor', 'ativo', new Date().toISOString());
  legacyDatabase.prepare('INSERT INTO users(id,email,password_hash,password_salt) VALUES(?,?,?,?)')
    .run(hiddenKeeperId, ` ${HIDDEN_EMAIL.toUpperCase()} `, 'hidden-legacy-hash', 'hidden-legacy-salt');
  legacyDatabase.prepare('INSERT INTO profiles(id,nome,papel,status,criado_em) VALUES(?,?,?,?,?)')
    .run(hiddenKeeperId, 'Chefe oculto anterior', 'tecnico', 'pendente', new Date().toISOString());
  legacyDatabase.prepare('INSERT INTO users(id,email,password_hash,password_salt) VALUES(?,?,?,?)')
    .run(commonKeeperId, 'legacy-common@example.com', 'common-hash', 'common-salt');
  legacyDatabase.prepare('INSERT INTO profiles(id,nome,papel,status,criado_em) VALUES(?,?,?,?,?)')
    .run(commonKeeperId, 'Conta comum ativa', 'agricultor', 'ativo', new Date().toISOString());
  legacyDatabase.prepare('INSERT INTO users(id,email,password_hash,password_salt) VALUES(?,?,?,?)')
    .run(commonDuplicateId, ' LEGACY-COMMON@EXAMPLE.COM ', 'duplicate-common-hash', 'duplicate-common-salt');
  legacyDatabase.prepare('INSERT INTO profiles(id,nome,papel,status,criado_em) VALUES(?,?,?,?,?)')
    .run(commonDuplicateId, 'Conta comum duplicada', 'agricultor', 'pendente', new Date().toISOString());
  legacyDatabase.close();

  const portProbe = createServer();
  await new Promise((resolve) => portProbe.listen(0, '127.0.0.1', resolve));
  const legacyPort = portProbe.address().port;
  await new Promise((resolve) => portProbe.close(resolve));
  let legacyOutput = '';
  const legacyServer = spawn(process.execPath, ['server/index.mjs'], {
    cwd: process.cwd(),
    env: {
      ...process.env,
      NODE_ENV: 'test',
      PORT: String(legacyPort),
      AGROLINK_DATA_DIR: legacyDataDir,
      AGROLINK_UPLOADS_DIR: path.join(legacyDataDir, 'uploads'),
      AGROLINK_ADMIN_CHEFE_EMAIL: PUBLIC_EMAIL,
      AGROLINK_ADMIN_CHEFE_PASSWORD: 'LegacyIgnoredPassword123!',
      AGROLINK_ADMIN_CHEFE_HIDDEN_PASSWORD: '',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  legacyServer.stdout.on('data', (chunk) => { legacyOutput += chunk; });
  legacyServer.stderr.on('data', (chunk) => { legacyOutput += chunk; });
  try {
    let ready = false;
    for (let attempt = 0; attempt < 60; attempt += 1) {
      try {
        const health = await fetch(`http://127.0.0.1:${legacyPort}/api/health`);
        if (health.status === 200) { ready = true; break; }
      } catch {}
      await new Promise((resolve) => setTimeout(resolve, 50));
    }
    assert.ok(ready, `Migração da base legada falhou: ${legacyOutput}`);
    const migrated = new DatabaseSync(databasePath);
    assert.equal(migrated.prepare('SELECT id FROM users WHERE lower(trim(email))=?').get(PUBLIC_EMAIL).id, keeperId);
    assert.equal(migrated.prepare('SELECT COUNT(*) AS n FROM users WHERE lower(trim(email))=?').get(PUBLIC_EMAIL).n, 1);
    assert.ok(migrated.prepare('SELECT 1 FROM users WHERE id=?').get(duplicateId));
    const keeper = {...migrated.prepare('SELECT papel,status,visibilidade FROM profiles WHERE id=?').get(keeperId)};
    assert.deepEqual(keeper, {papel:'admin_chefe',status:'ativo',visibilidade:'publico'});
    assert.equal(migrated.prepare('SELECT email FROM users WHERE id=?').get(keeperId).email, PUBLIC_EMAIL);
    assert.equal(migrated.prepare('SELECT password_hash FROM users WHERE id=?').get(keeperId).password_hash, 'legacy-hash');
    const duplicate = migrated.prepare('SELECT u.email,p.visibilidade FROM users u JOIN profiles p ON p.id=u.id WHERE u.id=?').get(duplicateId);
    assert.notEqual(duplicate.email.trim().toLowerCase(), PUBLIC_EMAIL);
    assert.equal(duplicate.visibilidade, 'oculto');
    const hiddenKeeper = migrated.prepare('SELECT u.email,u.password_hash,p.papel,p.tipo_perfil,p.status,p.visibilidade FROM users u JOIN profiles p ON p.id=u.id WHERE u.id=?').get(hiddenKeeperId);
    assert.deepEqual({...hiddenKeeper}, {email:HIDDEN_EMAIL,password_hash:'hidden-legacy-hash',papel:'admin_chefe',tipo_perfil:'tecnico',status:'ativo',visibilidade:'oculto'});
    assert.equal(migrated.prepare('SELECT email FROM users WHERE id=?').get(commonKeeperId).email, 'legacy-common@example.com');
    const migratedCommon = migrated.prepare('SELECT papel,tipo_perfil FROM profiles WHERE id=?').get(commonKeeperId);
    assert.deepEqual({...migratedCommon}, {papel:'utilizador',tipo_perfil:'agricultor'});
    const commonDuplicate = migrated.prepare('SELECT u.email,p.visibilidade FROM users u JOIN profiles p ON p.id=u.id WHERE u.id=?').get(commonDuplicateId);
    assert.match(commonDuplicate.email, /^duplicate-[a-f0-9]+@invalid\.agrolink\.local$/);
    assert.equal(commonDuplicate.visibilidade, 'oculto');
    assert.throws(() => migrated.prepare('INSERT INTO users(id,email,password_hash,password_salt) VALUES(?,?,?,?)')
      .run('legacy-canonical-duplicate', ' LEGACY-COMMON@EXAMPLE.COM ', 'hash', 'salt'), /UNIQUE constraint failed/i);
    migrated.close();
  } finally {
    legacyServer.kill('SIGTERM');
    await new Promise((resolve) => legacyServer.once('exit', resolve));
    fs.rmSync(legacyDataDir, { recursive: true, force: true });
  }
});
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { StorageAdapter, StorageConflictError } from './storageContract.mjs';
import { R2StorageAdapter } from './r2StorageAdapter.mjs';
import { BackblazeB2StorageProvider, BACKBLAZE_B2_DEFAULT_BUCKET } from './backblazeB2StorageProvider.mjs';
import { createStorageProvider } from './storageProviderFactory.mjs';

export { StorageAdapter, StorageConflictError, R2StorageAdapter, BackblazeB2StorageProvider, BACKBLAZE_B2_DEFAULT_BUCKET, createStorageProvider };

export function createStorageAdapter({ env = {}, provider = env.STORAGE_PROVIDER || 'local', rootDirectory, bucket = env.BUCKET } = {}) {
  if (String(provider).trim().toLowerCase() === 'local') {
    if (!rootDirectory) throw new Error('A root directory is required for local storage.');
    return new LocalFilesystemStorageAdapter(rootDirectory);
  }
  return createStorageProvider({ env, provider, bucket });
}

export class LocalFilesystemStorageAdapter extends StorageAdapter {
  constructor(rootDirectory) {
    super();
    this.rootDirectory = path.resolve(rootDirectory);
    fs.mkdirSync(this.rootDirectory, { recursive: true });
  }

  resolveKey(key) {
    const normalized = String(key || '').replace(/\\/g, '/');
    if (!normalized || normalized.startsWith('/') || normalized.split('/').some((part) => !part || part === '.' || part === '..')) {
      throw new Error('Invalid storage key.');
    }
    const absolute = path.resolve(this.rootDirectory, normalized);
    if (!absolute.startsWith(`${this.rootDirectory}${path.sep}`)) throw new Error('Invalid storage key.');
    return absolute;
  }

  async put(key, content) {
    const absolute = this.resolveKey(key);
    const bytes = Buffer.from(content);
    fs.mkdirSync(path.dirname(absolute), { recursive: true });
    try {
      fs.writeFileSync(absolute, bytes, { flag: 'wx' });
    } catch (error) {
      if (error?.code !== 'EEXIST') throw error;
      const current = fs.readFileSync(absolute);
      const currentHash = crypto.createHash('sha256').update(current).digest('hex');
      const incomingHash = crypto.createHash('sha256').update(bytes).digest('hex');
      if (currentHash !== incomingHash) throw new StorageConflictError();
    }
    return String(key).replace(/\\/g, '/');
  }

  async head(key) {
    let absolute;
    try {
      absolute = this.resolveKey(key);
    } catch {
      return null;
    }
    try {
      const stat = fs.statSync(absolute);
      return stat.isFile() ? { size: stat.size } : null;
    } catch (error) {
      if (error?.code === 'ENOENT') return null;
      throw error;
    }
  }

  async get(key) {
    const metadata = await this.head(key);
    if (!metadata) return null;
    return { ...metadata, body: fs.createReadStream(this.resolveKey(key)) };
  }

  async delete(key) {
    fs.rmSync(this.resolveKey(key), { force: true });
  }
}
import test from 'node:test';
import assert from 'node:assert/strict';
import { BackblazeB2StorageProvider, BACKBLAZE_B2_DEFAULT_BUCKET, createStorageAdapter, R2StorageAdapter } from './storageAdapter.mjs';

const config = {
  B2_ENDPOINT: 'https://s3.us-west-004.backblazeb2.com',
  B2_REGION: 'us-west-004',
  B2_BUCKET: 'agrolink-caop-media-2026',
  B2_ACCESS_KEY_ID: 'test-only-not-a-real-access-key',
  B2_SECRET_ACCESS_KEY: 'test-only-not-a-real-secret-key',
};

function mockedProvider(respond) {
  const requests = [];
  const provider = new BackblazeB2StorageProvider(config, {
    fetchImpl: async (request) => {
      requests.push(request);
      return respond(request, requests.length);
    },
  });
  return { provider, requests };
}

test('Backblaze B2 configuration loads required environment values without connecting', () => {
  const provider = createStorageAdapter({
    env: { ...config, STORAGE_PROVIDER: 'b2' },
  });
  assert.ok(provider instanceof BackblazeB2StorageProvider);
  assert.equal(provider.bucket, 'agrolink-caop-media-2026');
  assert.equal(provider.region, 'us-west-004');
  assert.equal(provider.endpoint, config.B2_ENDPOINT);
  assert.equal(BACKBLAZE_B2_DEFAULT_BUCKET, 'agrolink-caop-media-2026');
  assert.equal(new BackblazeB2StorageProvider({ ...config, B2_BUCKET: '' }).bucket, BACKBLAZE_B2_DEFAULT_BUCKET);
});

test('Backblaze B2 configuration rejects missing credentials and non-HTTPS endpoints', () => {
  assert.throws(() => new BackblazeB2StorageProvider({ ...config, B2_SECRET_ACCESS_KEY: '' }), /B2_ENDPOINT.*B2_SECRET_ACCESS_KEY/);
  assert.throws(() => new BackblazeB2StorageProvider({ ...config, B2_ENDPOINT: 'http://s3.example.com' }), /HTTPS/);
});

test('Backblaze B2 signs upload, preserves MIME, metadata and byte size, and downloads object', async () => {
  const { provider, requests } = mockedProvider((request) => {
    assert.match(request.headers.get('authorization'), /^AWS4-HMAC-SHA256 /);
    if (request.method === 'PUT') return new Response(null, { status: 200 });
    if (request.method === 'GET') {
      return new Response(new Uint8Array([1, 2, 3, 4]), {
        status: 200,
        headers: {
          'content-type': 'image/png',
          'content-length': '4',
          'x-amz-meta-ownerid': 'user-1',
          'x-amz-meta-sha256': 'digest',
        },
      });
    }
    throw new Error(`Unexpected ${request.method} request.`);
  });

  assert.equal(await provider.put('relatos/photo.png', new Uint8Array([1, 2, 3, 4]), {
    httpMetadata: { contentType: 'image/png' },
    customMetadata: { ownerId: 'user-1', sha256: 'digest' },
  }), 'relatos/photo.png');
  const upload = requests[0];
  assert.equal(upload.headers.get('content-type'), 'image/png');
  assert.equal(upload.headers.get('x-amz-meta-ownerid'), 'user-1');
  assert.equal(upload.headers.get('x-amz-meta-sha256'), 'digest');
  assert.equal((await upload.arrayBuffer()).byteLength, 4);

  const stored = await provider.get('relatos/photo.png');
  assert.equal(stored.size, 4);
  assert.deepEqual(stored.httpMetadata, { contentType: 'image/png' });
  assert.deepEqual(stored.customMetadata, { ownerId: 'user-1', sha256: 'digest' });
  assert.deepEqual([...new Uint8Array(await new Response(stored.body).arrayBuffer())], [1, 2, 3, 4]);
});

test('Backblaze B2 HEAD reports object existence and absence', async () => {
  const { provider, requests } = mockedProvider((request) => request.url.endsWith('/present.bin')
    ? new Response(null, { status: 200, headers: { 'content-length': '9', 'content-type': 'application/pdf' } })
    : new Response(null, { status: 404 }));
  assert.deepEqual(await provider.head('biblioteca/present.bin'), {
    size: 9,
    httpMetadata: { contentType: 'application/pdf' },
    customMetadata: {},
  });
  assert.equal(await provider.head('biblioteca/missing.bin'), null);
  assert.equal(requests[0].method, 'HEAD');
  assert.equal(requests[1].method, 'HEAD');
});

test('Backblaze B2 delete uses the configured bucket', async () => {
  const { provider, requests } = mockedProvider(() => new Response(null, { status: 204 }));
  await provider.delete('relatos/remove.png');
  assert.equal(requests[0].method, 'DELETE');
  assert.equal(new URL(requests[0].url).pathname, '/agrolink-caop-media-2026/relatos/remove.png');
});

test('Backblaze B2 maps authentication and bucket failures to safe errors', async () => {
  const { provider: unauthorized } = mockedProvider(() => new Response('sensitive provider response', { status: 403 }));
  await assert.rejects(unauthorized.put('relatos/photo.png', new Uint8Array([1])), (error) => {
    assert.match(error.message, /HTTP 403/);
    assert.doesNotMatch(error.message, /sensitive|test-only-not-a-real-secret-key/);
    return true;
  });

  const { provider: missingBucket } = mockedProvider(() => new Response('NoSuchBucket', { status: 404 }));
  await assert.rejects(missingBucket.put('relatos/photo.png', new Uint8Array([1])), /PUT returned HTTP 404/);
});

test('Backblaze B2 blocks traversal and scopes object URLs to each configured bucket', async () => {
  let calls = 0;
  const first = new BackblazeB2StorageProvider(config, { fetchImpl: async () => { calls += 1; return new Response(null, { status: 204 }); } });
  const second = new BackblazeB2StorageProvider({ ...config, B2_BUCKET: 'agrolink-other-media' }, {
    fetchImpl: async () => { calls += 1; return new Response(null, { status: 204 }); },
  });
  await assert.rejects(first.put('../outside.bin', new Uint8Array([1])), /Invalid storage key/);
  await assert.rejects(first.delete('relatos/../../outside.bin'), /Invalid storage key/);
  await assert.rejects(first.head('../outside.bin'), /Invalid storage key/);
  await first.delete('relatos/file.bin');
  await second.delete('relatos/file.bin');
  assert.equal(calls, 2);
  assert.equal(first.bucket, 'agrolink-caop-media-2026');
  assert.equal(second.bucket, 'agrolink-other-media');
});

test('storage provider selection keeps local and R2 alternatives available', () => {
  const bucket = { put() {}, get() {}, head() {}, delete() {} };
  assert.ok(createStorageAdapter({ env: {}, provider: 'r2', bucket }) instanceof R2StorageAdapter);
  assert.throws(() => createStorageAdapter({ env: {}, provider: 'r2' }), /BUCKET binding/);
  assert.throws(() => createStorageAdapter({ env: {}, provider: 'unconfigured' }), /Unsupported object storage provider/);
});

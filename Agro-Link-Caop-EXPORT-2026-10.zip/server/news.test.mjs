import test from 'node:test';
import assert from 'node:assert/strict';
import { parseNewsFeed, synchronizeNewsFeeds } from './news.mjs';

const rss = `<?xml version="1.0"?><rss><channel>
  <item><title>Nova cultura de milho em Angola</title><link>https://example.org/milho</link><description><![CDATA[Produção agrícola &amp; rendimento]]></description><pubDate>Mon, 21 Sep 2026 10:00:00 GMT</pubDate></item>
  <item><title>Resultado de futebol</title><link>https://example.org/futebol</link><description>Desporto nacional</description></item>
</channel></rss>`;

test('filtra e normaliza notícias agrícolas de RSS', () => {
  const items = parseNewsFeed(rss, { categoria: 'Culturas', pais: 'Angola' });
  assert.equal(items.length, 1);
  assert.equal(items[0].titulo, 'Nova cultura de milho em Angola');
  assert.equal(items[0].categoria_ia, 'Culturas');
  assert.equal(items[0].pais, 'Angola');
  assert.match(items[0].resumo, /Produção agrícola & rendimento/);
});

test('aceita Atom com link alternate e ignora itens sem URL válida', () => {
  const atom = '<feed><entry><title>Pesquisa de pragas agrícolas</title><link rel="alternate" href="https://example.org/pragas"/><summary>Nova investigação de pragas.</summary></entry><entry><title>Sem ligação agrícola milho</title></entry></feed>';
  const items = parseNewsFeed(atom);
  assert.equal(items.length, 1);
  assert.equal(items[0].url_original, 'https://example.org/pragas');
  assert.equal(items[0].categoria_ia, 'Pragas e Doenças');
});

test('sincroniza RSS, deduplica URLs e grava log por fonte', async () => {
  const records = new Map();
  const logs = [];
  const source = { id: 'feed-1', nome: 'Fonte de teste', url_rss: 'https://feed.example.org/rss', categoria: 'Culturas', ativo: 1, pais: 'Angola' };
  const db = { prepare(sql) {
    if (sql.startsWith('SELECT id,nome,url_rss')) return { all: () => [source] };
    if (sql.startsWith('INSERT OR IGNORE INTO noticias')) return { run(...values) { const url = values[9]; if (records.has(url)) return { changes: 0 }; records.set(url, values); return { changes: 1 }; } };
    if (sql.startsWith('INSERT INTO noticias_sync_logs')) return { run(...values) { logs.push(values); } };
    throw new Error(`SQL inesperado: ${sql}`);
  } };
  const result = await synchronizeNewsFeeds({
    db,
    lookupImpl: async () => [{ address: '93.184.216.34', family: 4 }],
    fetchImpl: async () => ({ ok: true, status: 200, text: async () => rss }),
  });
  assert.deepEqual(result, { fontes_processadas: 1, inseridas: 1, ignoradas: 0, erros: [] });
  assert.equal(records.size, 1);
  assert.equal(logs.length, 1);
  assert.equal(logs[0][2], 1);
});

test('não consulta destinos RSS privados nem segue redirecionamentos', async () => {
  const source = { id: 'feed-private', nome: 'Privada', url_rss: 'https://feed.example.org/rss', ativo: 1 };
  let fetchCalled = false;
  const db = { prepare(sql) {
    if (sql.startsWith('SELECT id,nome,url_rss')) return { all: () => [source] };
    return { run() {} };
  } };
  const result = await synchronizeNewsFeeds({ db, lookupImpl: async () => [{ address: '127.0.0.1', family: 4 }], fetchImpl: async () => { fetchCalled = true; } });
  assert.equal(fetchCalled, false);
  assert.equal(result.erros.length, 1);
});
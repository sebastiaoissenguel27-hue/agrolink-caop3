
import { Link } from 'react-router-dom';
import { obterPaisSelecionado } from '@/shared/lib/country';
import { Logo } from '@/shared/components/Logo';

export function VisitanteLandingPage() {
  const pais = obterPaisSelecionado();

  return (
    <div style={{ maxWidth: 560, margin: '0 auto', padding: 20, display: 'flex', flexDirection: 'column', gap: 18 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12 }}>
        <Logo size="lg" />
        <div style={{ padding: '10px 12px', borderRadius: 999, background: '#edf7ed', border: '1px solid #dbeedc', fontWeight: 700 }}>
          {pais?.bandeira ?? '🌍'} {pais?.countryCode ?? 'AO'}
        </div>
      </div>

      <section style={{ background: '#fff', border: '1px solid #e6eedf', borderRadius: 16, padding: 16 }}>
        <h2 style={{ marginTop: 0, marginBottom: 8 }}>Modo visitante</h2>
        <p style={{ margin: 0, color: '#4d5d50', lineHeight: 1.6 }}>
          Pode continuar sem conta e aceder às áreas de suporte mais úteis para o piloto.
        </p>
      </section>

      <div style={{ display: 'grid', gap: 12 }}>
        <Link to="/relato-anonimo" style={{ textDecoration: 'none', display: 'block', padding: '16px', borderRadius: 12, background: '#eef5ea', border: '1px solid #d7e3d2', color: '#1f3d2b', fontWeight: 700, textAlign: 'center' }}>
          Relatos
        </Link>

        <Link to="/entrar" style={{ textDecoration: 'none', display: 'block', padding: '16px', borderRadius: 12, background: '#f4f8ef', border: '1px solid #d7e3d2', color: '#1f3d2b', fontWeight: 700, textAlign: 'center' }}>
          Assistente IA (com conta)
        </Link>

        <Link to="/manual" style={{ textDecoration: 'none', display: 'block', padding: '16px', borderRadius: 12, background: '#edf7ed', border: '1px solid #d7e3d2', color: '#1f3d2b', fontWeight: 700, textAlign: 'center' }}>
          Manual
        </Link>

        <Link to="/visitante-offline" style={{ textDecoration: 'none', display: 'block', padding: '16px', borderRadius: 12, background: '#f8f4ea', border: '1px solid #e6dcc0', color: '#1f3d2b', fontWeight: 700, textAlign: 'center' }}>
          Offline
        </Link>
      </div>

      <section style={{ background: '#fafaf8', border: '1px solid #e6eedf', borderRadius: 16, padding: 16 }}>
        <h3 style={{ marginTop: 0 }}>Conta AgroLink</h3>
        <p style={{ margin: '0 0 12px', color: '#4d5d50' }}>
          Para obter acesso completo ao assistente e a funções mais avançadas, pode criar conta ou entrar na sua conta.
        </p>
        <div style={{ display: 'grid', gap: 10 }}>
          <Link to="/registar" style={{ textDecoration: 'none', display: 'block', padding: '14px', borderRadius: 12, background: '#1f7a3d', color: '#fff', fontWeight: 700, textAlign: 'center' }}>
            Criar uma conta
          </Link>
          <Link to="/entrar" style={{ textDecoration: 'none', display: 'block', padding: '14px', borderRadius: 12, background: 'transparent', border: '1px solid #d7e3d2', color: '#1f3d2b', fontWeight: 700, textAlign: 'center' }}>
            Entrar na minha conta
          </Link>
        </div>
      </section>
    </div>
  );
}

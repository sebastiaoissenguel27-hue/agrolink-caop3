
import { useLiveQuery } from 'dexie-react-hooks';
import { dbLocal } from '@/offline/db';
import { Logo } from '@/shared/components/Logo';

export function VisitanteOfflinePage() {
  const noticiasEmCache = useLiveQuery(() => dbLocal.noticiasCache.count(), []) ?? 0;
  const alertasEmCache = useLiveQuery(() => dbLocal.alertasCache.count(), []) ?? 0;

  return (
    <div style={{ maxWidth: 560, margin: '0 auto', padding: 20, display: 'flex', flexDirection: 'column', gap: 18 }}>
      <header>
        <Logo size="md" />
        <p style={{ margin: 0, fontSize: '0.8rem', letterSpacing: 1.1, textTransform: 'uppercase', color: '#49694f' }}>
          Offline
        </p>
        <h1 style={{ margin: '8px 0 0', fontSize: '2rem' }}>Modo offline</h1>
      </header>

      <section style={{ background: '#fff', border: '1px solid #e6eedf', borderRadius: 16, padding: 16 }}>
        <p style={{ marginTop: 0, lineHeight: 1.6 }}>
          O AgroLink já guarda parte do conteúdo no dispositivo para consulta mesmo sem ligação à rede.
          Esta funcionalidade continua disponível para visitantes e utilizadores registados sem exigir conta
          adicional ou alteração na infraestrutura do sistema.
        </p>
        <ul style={{ margin: 0, paddingLeft: 18, display: 'grid', gap: 8 }}>
          <li>Notícias guardadas para consulta offline.</li>
          <li>Alertas e dados locais já sincronizados no dispositivo.</li>
        </ul>
      </section>

      <section style={{ background: '#edf7ed', border: '1px solid #dbeedc', borderRadius: 16, padding: 16 }}>
        <h2 style={{ marginTop: 0 }}>Estado do dispositivo</h2>
        <p style={{ margin: 0, lineHeight: 1.6 }}>
          Notícias: {noticiasEmCache} · Alertas: {alertasEmCache}
        </p>
      </section>
    </div>
  );
}


import { useEffect, useState } from 'react';
import { obterQuestionario, submeterResposta } from '@/features/academia/api/academiaService';
import type { QuestionarioPergunta } from '@/shared/types/database.types';

export function QuizLicao({ licaoId }: { licaoId: string }) {
  const [perguntas, setPerguntas] = useState<QuestionarioPergunta[]>([]);
  const [respostas, setRespostas] = useState<Record<string, number>>({});
  const [resultados, setResultados] = useState<Record<string, boolean>>({});
  const [aCarregar, setACarregar] = useState(true);
  const [erroRede, setErroRede] = useState(false);

  useEffect(() => {
    if (!navigator.onLine) {
      setErroRede(true);
      setACarregar(false);
      return;
    }
    obterQuestionario(licaoId)
      .then(setPerguntas)
      .catch(() => setErroRede(true))
      .finally(() => setACarregar(false));
  }, [licaoId]);

  async function responder(perguntaId: string, indice: number) {
    setRespostas((prev) => ({ ...prev, [perguntaId]: indice }));
    try {
      const correto = await submeterResposta(perguntaId, indice);
      setResultados((prev) => ({ ...prev, [perguntaId]: correto }));
    } catch {
      setErroRede(true);
    }
  }

  if (aCarregar) return <p>A carregar questionário…</p>;
  if (erroRede) {
    return (
      <p role="status">
        O questionário exige rede para ser corrigido — tente novamente quando estiver online.
      </p>
    );
  }
  if (perguntas.length === 0) return null;

  return (
    <div style={{ marginTop: 16, background: '#fff', borderRadius: 8, padding: 16 }}>
      <h3>Questionário</h3>
      {perguntas.map((p) => (
        <div key={p.id} style={{ marginBottom: 16 }}>
          <p>{p.pergunta}</p>
          {p.opcoes.map((opcao, i) => (
            <label key={i} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <input
                type="radio"
                name={`quiz-${p.id}`}
                checked={respostas[p.id] === i}
                onChange={() => responder(p.id, i)}
                disabled={resultados[p.id] !== undefined}
              />
              {opcao}
            </label>
          ))}
          {resultados[p.id] !== undefined && (
            <p role="status" aria-live="polite">
              {resultados[p.id] ? '✅ Correto!' : '❌ Não é essa — mas a resposta já ficou registada.'}
            </p>
          )}
        </div>
      ))}
    </div>
  );
}


import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { listarCursos } from '@/features/academia/api/academiaService';
import type { AcademiaCursoRow } from '@/shared/types/database.types';

export function AcademiaPage() {
  const [cursos, setCursos] = useState<AcademiaCursoRow[]>([]);
  const [aCarregar, setACarregar] = useState(true);

  useEffect(() => {
    listarCursos()
      .then(setCursos)
      .finally(() => setACarregar(false));
  }, []);

  return (
    <div style={{ maxWidth: 720, margin: '0 auto' }}>
      <h1>Academia AgroLink</h1>
      <p style={{ fontSize: '0.85rem', color: 'var(--color-terra)' }}>
        Cursos curtos em texto, imagens e PDF, com questionários no fim de algumas lições.
      </p>
      {!navigator.onLine && <p>Está offline — a mostrar cursos guardados no dispositivo.</p>}

      {aCarregar && <p>A carregar…</p>}
      {!aCarregar && cursos.length === 0 && <p>Ainda não há cursos publicados.</p>}

      <ul style={{ listStyle: 'none', padding: 0 }}>
        {cursos.map((c) => (
          <li key={c.id} style={{ borderBottom: '1px solid #eee', padding: '12px 0' }}>
            <Link to={`/academia/${c.id}`}>
              <strong>{c.titulo}</strong>
            </Link>
            {c.categoria && <span style={{ fontSize: '0.75rem', color: 'var(--color-terra)' }}> · {c.categoria}</span>}
            {c.descricao && <p style={{ margin: '4px 0' }}>{c.descricao}</p>}
          </li>
        ))}
      </ul>
    </div>
  );
}

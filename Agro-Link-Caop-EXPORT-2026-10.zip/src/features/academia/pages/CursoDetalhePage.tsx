
import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  obterCurso,
  listarLicoes,
  obterUrlMidiaLicao,
  obterMeuProgresso,
  marcarLicaoConcluida,
} from '@/features/academia/api/academiaService';
import { QuizLicao } from '@/features/academia/components/QuizLicao';
import type { AcademiaCursoRow, AcademiaLicaoRow, AcademiaProgressoRow } from '@/shared/types/database.types';
import { useAuth } from '@/features/auth/context/AuthContext';

export function CursoDetalhePage() {
  const { perfil } = useAuth();
  const { cursoId } = useParams<{ cursoId: string }>();
  const [curso, setCurso] = useState<AcademiaCursoRow | null>(null);
  const [licoes, setLicoes] = useState<AcademiaLicaoRow[]>([]);
  const [progresso, setProgresso] = useState<AcademiaProgressoRow[]>([]);
  const [indiceAtual, setIndiceAtual] = useState(0);
  const [urlMidia, setUrlMidia] = useState<string | null>(null);
  const [aCarregar, setACarregar] = useState(true);

  useEffect(() => {
    if (!cursoId) return;
    Promise.all([obterCurso(cursoId), listarLicoes(cursoId)]).then(async ([c, l]) => {
      setCurso(c);
      setLicoes(l);
      setProgresso(await obterMeuProgresso(cursoId, l));
      setACarregar(false);
    });
  }, [cursoId]);

  const licaoAtual = licoes[indiceAtual];

  useEffect(() => {
    setUrlMidia(null);
    if (licaoAtual?.caminho_storage && (licaoAtual.tipo === 'imagem' || licaoAtual.tipo === 'pdf')) {
      obterUrlMidiaLicao(licaoAtual.caminho_storage)
        .then(setUrlMidia)
        .catch(() => setUrlMidia(null));
    }
  }, [licaoAtual]);

  async function concluirLicao() {
    if (!licaoAtual) return;
    if (!perfil) return;
    await marcarLicaoConcluida(licaoAtual.id, perfil.id);
    setProgresso((prev) => [
      ...prev.filter((p) => p.licao_id !== licaoAtual.id),
      {
        utilizador_id: '',
        licao_id: licaoAtual.id,
        concluida: true,
        pontuacao_questionario: null,
        atualizado_em: new Date().toISOString(),
      },
    ]);
  }

  if (aCarregar) return <p>A carregar…</p>;
  if (!curso) return <p>Curso não encontrado.</p>;

  const concluida = (licaoId: string) => progresso.some((p) => p.licao_id === licaoId && p.concluida);

  return (
    <div style={{ maxWidth: 780, margin: '0 auto', display: 'flex', gap: 24 }}>
      <nav style={{ width: 200, flexShrink: 0 }}>
        <Link to="/academia">← Todos os cursos</Link>
        <h2 style={{ fontSize: '1rem' }}>{curso.titulo}</h2>
        <ol style={{ listStyle: 'none', padding: 0 }}>
          {licoes.map((l, i) => (
            <li key={l.id}>
              <button
                onClick={() => setIndiceAtual(i)}
                style={{
                  fontWeight: i === indiceAtual ? 700 : 400,
                  textAlign: 'left',
                  width: '100%',
                }}
              >
                {concluida(l.id) ? '✅' : '⬜️'} {l.titulo}
              </button>
            </li>
          ))}
        </ol>
      </nav>

      <div style={{ flex: 1 }}>
        {!licaoAtual && <p>Este curso ainda não tem lições publicadas.</p>}

        {licaoAtual && (
          <div>
            <h1>{licaoAtual.titulo}</h1>

            {licaoAtual.tipo === 'texto' && (
              <p style={{ whiteSpace: 'pre-wrap' }}>{licaoAtual.conteudo_texto}</p>
            )}

            {licaoAtual.tipo === 'imagem' && urlMidia && (
              <img src={urlMidia} alt={licaoAtual.titulo} style={{ maxWidth: '100%', borderRadius: 8 }} />
            )}

            {licaoAtual.tipo === 'pdf' && urlMidia && (
              <a href={urlMidia} target="_blank" rel="noopener noreferrer">
                Abrir PDF da lição →
              </a>
            )}

            {licaoAtual.tipo === 'video' && (
              <p style={{ background: '#fff', borderRadius: 8, padding: 16 }}>
                🎬 Vídeo em breve — este tipo de lição está preparado na plataforma, mas o
                suporte a vídeo ainda não foi ativado nesta versão.
              </p>
            )}

            <QuizLicao licaoId={licaoAtual.id} />

            <div style={{ marginTop: 16, display: 'flex', gap: 8 }}>
              {!concluida(licaoAtual.id) && (
                <button onClick={concluirLicao}>Marcar como concluída</button>
              )}
              {indiceAtual < licoes.length - 1 && (
                <button onClick={() => setIndiceAtual((i) => i + 1)}>Próxima lição →</button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

import { apiGet, apiPost, apiDelete, apiUpload } from '@/shared/lib/apiClient';
import { dbLocal } from '@/offline/db';
import { sincronizarProgresso } from '@/offline/syncEngine';
import type { AcademiaCursoRow, AcademiaLicaoRow, AcademiaProgressoRow, AcademiaQuestionarioAdminRow, QuestionarioPergunta } from '@/shared/types/database.types';
export async function listarCursos():Promise<AcademiaCursoRow[]>{if(!navigator.onLine)return dbLocal.academiaCursosCache.toArray();const d=await apiGet<AcademiaCursoRow[]>('/api/data/academia_cursos?order=publicado_em&limit=500');dbLocal.academiaCursosCache.bulkPut(d);return d;}
export async function obterCurso(id:string):Promise<AcademiaCursoRow|null>{if(!navigator.onLine)return(await dbLocal.academiaCursosCache.get(id))??null;const d=await apiGet<AcademiaCursoRow[]>(`/api/data/academia_cursos?id=${encodeURIComponent(id)}&limit=1`);return d[0]??null;}
export async function listarLicoes(cursoId:string):Promise<AcademiaLicaoRow[]>{if(!navigator.onLine)return dbLocal.academiaLicoesCache.where('curso_id').equals(cursoId).sortBy('ordem');const d=await apiGet<AcademiaLicaoRow[]>(`/api/data/academia_licoes?curso_id=${encodeURIComponent(cursoId)}&order=ordem&asc=1&limit=500`);dbLocal.academiaLicoesCache.bulkPut(d);return d;}
export async function obterUrlMidiaLicao(caminho:string){return `/api/media/${caminho.split('/').map(encodeURIComponent).join('/')}`;}
export async function obterMeuProgresso(_cursoId:string,licoes:AcademiaLicaoRow[]):Promise<AcademiaProgressoRow[]>{const ids=licoes.map(x=>x.id);if(!navigator.onLine||!ids.length)return [];const all=await apiGet<AcademiaProgressoRow[]>('/api/data/academia_progresso?limit=500');return all.filter(x=>ids.includes(x.licao_id));}
export async function marcarLicaoConcluida(licaoId:string,utilizadorId:string){if(!utilizadorId)return;if(navigator.onLine){try{await apiPost('/api/academia/concluir',{licaoId});return;}catch{}}await dbLocal.progressoPendente.add({localId:crypto.randomUUID(),utilizadorId,licaoId,criadoEm:new Date().toISOString(),sincronizado:false});await sincronizarProgresso(utilizadorId);}
export async function obterQuestionario(licaoId:string):Promise<QuestionarioPergunta[]>{return apiGet(`/api/academia/quiz/${encodeURIComponent(licaoId)}`);}
export async function submeterResposta(questionarioId:string,resposta:number):Promise<boolean>{const r=await apiPost<{correto:boolean}>('/api/academia/quiz/answer',{questionarioId,resposta});return r.correto;}
export async function criarCurso(curso:{titulo:string;descricao?:string;categoria?:string;autor_id?:string|null}){await apiPost('/api/data/academia_cursos',curso);}
export async function apagarCurso(id:string){await apiDelete(`/api/data/academia_cursos?id=${encodeURIComponent(id)}`);}
export async function carregarFicheiroAcademia(ficheiro:File){return(await apiUpload('/api/media/upload/academia',ficheiro)).caminho;}
export async function criarLicao(licao:{curso_id:string;titulo:string;tipo:'texto'|'imagem'|'pdf'|'video';conteudo_texto?:string|null;caminho_storage?:string|null;ordem?:number}){await apiPost('/api/data/academia_licoes',licao);}
export async function apagarLicao(id:string){await apiDelete(`/api/data/academia_licoes?id=${encodeURIComponent(id)}`);}
export async function listarPerguntasAdmin(licaoId:string):Promise<AcademiaQuestionarioAdminRow[]>{return apiGet(`/api/data/academia_questionarios?licao_id=${encodeURIComponent(licaoId)}&order=ordem&asc=1&limit=100`);}
export async function criarPergunta(p:{licao_id:string;pergunta:string;opcoes:string[];resposta_correta:number;ordem?:number}){await apiPost('/api/data/academia_questionarios',p);}
export async function apagarPergunta(id:string){await apiDelete(`/api/data/academia_questionarios?id=${encodeURIComponent(id)}`);}

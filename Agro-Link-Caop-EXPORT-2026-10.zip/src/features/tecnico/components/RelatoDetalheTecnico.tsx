
import { useEffect, useState } from 'react';
import { useAuth } from '@/features/auth/context/AuthContext';
import {
  obterMidias,
  obterRespostas,
  obterUrlAssinadaMidia,
  responderRelato,
  atualizarStatusRelato,
} from '@/features/relatos/api/relatosService';
import type {
  RelatoRow,
  RelatoMidiaRow,
  RelatoRespostaRow,
  StatusRelato,
} from '@/shared/types/database.types';

const ESTADOS: StatusRelato[] = ['pendente', 'em_analise', 'respondido', 'resolvido'];

export function RelatoDetalheTecnico({
  relato,
  aoAtualizar,
}: {
  relato: RelatoRow;
  aoAtualizar: () => void;
}) {
  const { perfil } = useAuth();
  const [midias, setMidias] = useState<(RelatoMidiaRow & { url?: string })[]>([]);
  const [respostas, setRespostas] = useState<RelatoRespostaRow[]>([]);
  const [comentario, setComentario] = useState('');
  const [aEnviar, setAEnviar] = useState(false);

  async function carregar() {
    const [m, r] = await Promise.all([obterMidias(relato.id), obterRespostas(relato.id)]);
    const comUrl = await Promise.all(
      m.map(async (midia) => ({
        ...midia,
        url: await obterUrlAssinadaMidia(midia.caminho_storage).catch(() => undefined),
      }))
    );
    setMidias(comUrl);
    setRespostas(r);
  }

  useEffect(() => {
    carregar();
  }, [relato.id]);

  async function enviarResposta() {
    if (!perfil || !comentario.trim()) return;
    setAEnviar(true);
    try {
      await responderRelato(relato.id, perfil.id, comentario.trim());
      setComentario('');
      await carregar();
      aoAtualizar();
    } finally {
      setAEnviar(false);
    }
  }

  async function mudarEstado(novo: StatusRelato) {
    await atualizarStatusRelato(relato.id, novo);
    aoAtualizar();
  }

  return (
    <div style={{ border: '1px solid #ddd', borderRadius: 8, padding: 16, marginBottom: 16 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <strong>{relato.tipo}</strong>
        <select value={relato.status} onChange={(e) => mudarEstado(e.target.value as StatusRelato)}>
          {ESTADOS.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </div>

      <p>{relato.descricao}</p>
      <p style={{ fontSize: '0.85rem', color: 'var(--color-terra)' }}>
        Localização: {[relato.provincia, relato.municipio, relato.comuna].filter(Boolean).join(', ') || '—'}
      </p>

      {midias.length > 0 && (
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 12 }}>
          {midias.map((m) =>
            m.tipo === 'foto' ? (
              <img key={m.id} src={m.url} alt="foto do relato" style={{ width: 100, height: 100, objectFit: 'cover', borderRadius: 6 }} />
            ) : (
              <audio key={m.id} controls src={m.url} />
            )
          )}
        </div>
      )}

      <h4>Respostas</h4>
      <ul>
        {respostas.map((r) => (
          <li key={r.id}>{r.comentario}</li>
        ))}
      </ul>

      <textarea
        rows={2}
        value={comentario}
        onChange={(e) => setComentario(e.target.value)}
        placeholder="Escreva uma resposta para o agricultor…"
        style={{ width: '100%' }}
      />
      <button onClick={enviarResposta} disabled={aEnviar || !comentario.trim()}>
        {aEnviar ? 'A enviar…' : 'Responder'}
      </button>
    </div>
  );
}

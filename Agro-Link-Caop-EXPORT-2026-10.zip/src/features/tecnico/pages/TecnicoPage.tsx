
import { useEffect, useState } from 'react';
import { useAuth } from '@/features/auth/context/AuthContext';
import { listarRelatosParaTecnicoComFiltro } from '@/features/relatos/api/relatosService';
import { RelatoDetalheTecnico } from '@/features/tecnico/components/RelatoDetalheTecnico';
import type { RelatoRow, StatusRelato, TipoRelato } from '@/shared/types/database.types';

export function TecnicoPage() {
  const { perfil } = useAuth();
  const [relatos, setRelatos] = useState<RelatoRow[]>([]);
  const [filtroStatus, setFiltroStatus] = useState<StatusRelato | ''>('');
  const [filtroTipo, setFiltroTipo] = useState<TipoRelato | ''>('');
  const [aCarregar, setACarregar] = useState(true);

  async function carregar() {
    setACarregar(true);
    try {
      const dados = await listarRelatosParaTecnicoComFiltro({
        status: filtroStatus || undefined,
        tipo: filtroTipo || undefined,
      });
      setRelatos(dados);
    } finally {
      setACarregar(false);
    }
  }

  useEffect(() => {
    carregar();
  }, [filtroStatus, filtroTipo]);

  if (perfil?.verification_status !== 'aprovado') {
    return (
      <div style={{ padding: 24 }}>
        <h1>Painel técnico</h1>
        <p>
          A sua conta ainda não foi verificada por um administrador (estado atual:{' '}
          <strong>{perfil?.verification_status}</strong>). Só técnicos aprovados podem ver e
          responder a relatos.
        </p>
      </div>
    );
  }

  return (
    <div style={{ padding: 24, maxWidth: 760, margin: '0 auto' }}>
      <h1>Relatos de todas as províncias</h1>

      <div style={{ display: 'flex', gap: 12, marginBottom: 16 }}>
        <select value={filtroStatus} onChange={(e) => setFiltroStatus(e.target.value as StatusRelato | '')}>
          <option value="">Todos os estados</option>
          <option value="pendente">Pendente</option>
          <option value="em_analise">Em análise</option>
          <option value="respondido">Respondido</option>
          <option value="resolvido">Resolvido</option>
        </select>
        <select value={filtroTipo} onChange={(e) => setFiltroTipo(e.target.value as TipoRelato | '')}>
          <option value="">Todos os tipos</option>
          <option value="praga">Praga</option>
          <option value="doenca">Doença</option>
          <option value="clima">Clima</option>
          <option value="solo">Solo</option>
          <option value="pedido_apoio">Pedido de apoio</option>
          <option value="outro">Outro</option>
        </select>
      </div>

      {aCarregar && <p>A carregar…</p>}
      {!aCarregar && relatos.length === 0 && <p>Sem relatos para os filtros escolhidos.</p>}

      {relatos.map((r) => (
        <RelatoDetalheTecnico key={r.id} relato={r} aoAtualizar={carregar} />
      ))}
    </div>
  );
}


import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useLiveQuery } from 'dexie-react-hooks';
import { useAuth } from '@/features/auth/context/AuthContext';
import { listarMeusRelatos } from '@/features/relatos/api/relatosService';
import { listarNoticias } from '@/features/noticias/api/noticiasService';
import { listarAlertas } from '@/features/alertas/api/alertasService';
import { dbLocal } from '@/offline/db';
import type { RelatoRow, NoticiaRow, AlertaRow } from '@/shared/types/database.types';
import { PageContainer } from '@/shared/components/PageContainer';
import { Card, CardTitle } from '@/shared/components/Card';
import { StatusBadge } from '@/shared/components/StatusBadge';
import { EstadoCarregando, EstadoErro, EstadoVazio } from '@/shared/components/EstadosInterface';

export function AgricultorDashboard() {
  const { perfil } = useAuth();
  const [relatos, setRelatos] = useState<RelatoRow[]>([]);
  const [noticias, setNoticias] = useState<NoticiaRow[]>([]);
  const [alertas, setAlertas] = useState<AlertaRow[]>([]);
  const [aCarregar, setACarregar] = useState(true);
  const [erro, setErro] = useState<string | null>(null);

  const pendentesLocais =
    useLiveQuery(() => perfil ? dbLocal.relatosPendentes.toCollection().filter((item) => !item.sincronizado && item.autorId === perfil.id).count() : 0, [perfil?.id]) ?? 0;

  useEffect(() => {
    let ativo = true;
    setACarregar(true);
    setErro(null);

    Promise.allSettled([
      listarMeusRelatos(),
      listarNoticias(),
      listarAlertas(perfil?.provincia),
    ]).then(([relatosResult, noticiasResult, alertasResult]) => {
      if (!ativo) return;
      if (relatosResult.status === 'fulfilled') setRelatos(relatosResult.value);
      if (noticiasResult.status === 'fulfilled') setNoticias(noticiasResult.value.slice(0, 3));
      if (alertasResult.status === 'fulfilled') setAlertas(alertasResult.value.slice(0, 3));
      if ([relatosResult, noticiasResult, alertasResult].every((result) => result.status === 'rejected')) {
        setErro('Não foi possível carregar o resumo do agricultor.');
      }
    }).finally(() => {
      if (ativo) setACarregar(false);
    });

    return () => {
      ativo = false;
    };
  }, [perfil?.provincia]);

  const resumo = {
    pendentes: relatos.filter((r) => r.status === 'pendente').length + pendentesLocais,
    emAnalise: relatos.filter((r) => r.status === 'em_analise').length,
    respondidos: relatos.filter((r) => r.status === 'respondido').length,
    resolvidos: relatos.filter((r) => r.status === 'resolvido').length,
  };

  return (
    <PageContainer className="al-dashboard">
      <div>
        <h1>Olá, {perfil?.nome ?? '...'}</h1>
        <p style={{ color: 'var(--color-terra)' }}>
          {[perfil?.provincia, perfil?.municipio, perfil?.comuna].filter(Boolean).join(', ') || 'Localização não definida'}
        </p>
      </div>

      {aCarregar && <EstadoCarregando mensagem="A carregar o seu resumo…" />}
      {erro && <EstadoErro mensagem={erro} />}

      <section>
        <h2>Os meus relatos</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(120px, 1fr))', gap: 12 }}>
          {(
            [
              ['Pendentes', resumo.pendentes],
              ['Em análise', resumo.emAnalise],
              ['Respondidos', resumo.respondidos],
              ['Resolvidos', resumo.resolvidos],
            ] as [string, number][]
          ).map(([rotulo, valor]) => (
            <Card key={rotulo} className="al-dashboard-stat">
              <div style={{ fontSize: '1.4rem', fontWeight: 700, color: 'var(--color-verde-mata)' }}>{valor}</div>
              <div style={{ fontSize: '0.75rem', color: 'var(--color-terra)' }}>{rotulo}</div>
            </Card>
          ))}
        </div>
        <Link to="/relatos">Ver todos os relatos →</Link>
      </section>

      <section>
        <CardTitle>Alertas recentes</CardTitle>
        {alertas.length === 0 && <EstadoVazio mensagem="Sem alertas ativos." />}
        {alertas.map((a) => (
          <Card key={a.id} className="al-dashboard-list-item">
            <strong>{a.titulo}</strong> <StatusBadge status={a.nivel} />
          </Card>
        ))}
        <Link to="/alertas">Ver todos os alertas →</Link>
      </section>

      <section>
        <CardTitle>Notícias</CardTitle>
        {noticias.length === 0 && <EstadoVazio mensagem="Sem notícias no momento." />}
        {noticias.map((n) => (
          <Card key={n.id} className="al-dashboard-list-item">
            <strong>{n.titulo}</strong>
          </Card>
        ))}
        <Link to="/noticias">Ver todas as notícias →</Link>
      </section>

      <section>
        <CardTitle>Precisa de ajuda?</CardTitle>
        <p>O assistente IA agrícola responde a perguntas sobre pragas, doenças, solo e clima.</p>
        <Link to="/assistente">Falar com o assistente →</Link>
      </section>
    </PageContainer>
  );
}


import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  PAISES_PALOP,
  type CountryCode,
  guardarPaisSelecionado,
  obterPaisSelecionado,
} from '@/shared/lib/country';

export function EscolhaPaisPage() {
  const navigate = useNavigate();
  const paisAtual = obterPaisSelecionado();
  const [paisSelecionado, setPaisSelecionado] = useState<CountryCode | null>(paisAtual?.countryCode ?? null);

  function escolherPais(countryCode: CountryCode) {
    guardarPaisSelecionado(countryCode);
    setPaisSelecionado(countryCode);
  }

  const paisEscolhido = PAISES_PALOP.find((pais) => pais.countryCode === paisSelecionado) ?? null;

  return (
    <div style={{ maxWidth: 460, margin: '0 auto', padding: 20, display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div style={{ textAlign: 'center' }}>
        <p style={{ margin: 0, fontSize: '0.8rem', letterSpacing: 1.2, textTransform: 'uppercase', color: '#49694f' }}>
          AgroLink Caop
        </p>
        <h1 style={{ margin: '8px 0 0', fontSize: '2rem' }}>Escolha o seu país</h1>
      </div>

      {!paisEscolhido ? (
        <>
          <p style={{ margin: 0, color: '#445a49', fontSize: '0.95rem' }}>
            Selecione o país em que está a trabalhar para adaptar a sua experiência.
          </p>

          <div style={{ display: 'grid', gap: 12 }}>
            {PAISES_PALOP.map((pais) => (
              <button
                key={pais.countryCode}
                type="button"
                onClick={() => escolherPais(pais.countryCode)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  gap: 12,
                  padding: '14px 16px',
                  borderRadius: 12,
                  border: '1px solid #d7e3d2',
                  background: '#fff',
                  fontSize: '1rem',
                  fontWeight: 600,
                  cursor: 'pointer',
                  textAlign: 'left',
                }}
              >
                <span>{pais.bandeira}</span>
                <span style={{ flex: 1 }}>{pais.nome}</span>
                <span aria-hidden="true">→</span>
              </button>
            ))}
          </div>
        </>
      ) : (
        <>
          <div
            style={{
              padding: 16,
              borderRadius: 14,
              background: '#edf7ed',
              border: '1px solid #cfe6d0',
              color: '#1f4e2d',
              fontWeight: 600,
            }}
          >
            {paisEscolhido.bandeira} {paisEscolhido.nome} selecionado.
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <h2 style={{ margin: 0, fontSize: '1.3rem' }}>Como quer usar o AgroLink Caop?</h2>

            <button
              type="button"
              onClick={() => navigate('/registar')}
              style={{
                background: '#1f7a3d',
                color: '#fff',
                border: 'none',
                borderRadius: 12,
                padding: '16px',
                fontSize: '1rem',
                fontWeight: 700,
                cursor: 'pointer',
              }}
            >
              Criar uma conta
            </button>

            <button
              type="button"
              onClick={() => navigate('/visitante')}
              style={{
                background: '#eef5ea',
                color: '#1f3d2b',
                border: '1px solid #d7e3d2',
                borderRadius: 12,
                padding: '16px',
                fontSize: '1rem',
                fontWeight: 700,
                cursor: 'pointer',
              }}
            >
              Continuar sem cadastro
            </button>

            <button
              type="button"
              onClick={() => navigate('/manual')}
              style={{
                background: 'transparent',
                color: '#1f3d2b',
                border: '1px solid #d7e3d2',
                borderRadius: 12,
                padding: '14px',
                fontSize: '0.95rem',
                cursor: 'pointer',
              }}
            >
              Ver manual do agricultor
            </button>
          </div>
        </>
      )}
    </div>
  );
}

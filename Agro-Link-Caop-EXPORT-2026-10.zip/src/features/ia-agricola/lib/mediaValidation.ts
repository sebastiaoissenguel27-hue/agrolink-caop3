
export type MediaType = 'image' | 'audio' | 'video';

export interface MediaPayload {
  type: MediaType;
  mimeType?: string;
  data?: string;
  size?: number;
  durationSeconds?: number;
}

export interface NormalizedMediaPayload extends MediaPayload {
  mimeType: string;
  data: string;
  size: number;
}

export const MAX_MEDIA_BYTES: Record<MediaType, number> = {
  image: 8 * 1024 * 1024,
  audio: 12 * 1024 * 1024,
  video: 25 * 1024 * 1024,
};

const ALLOWED_MIME: Record<MediaType, string[]> = {
  image: ['image/jpeg', 'image/png', 'image/webp'],
  audio: ['audio/webm', 'audio/mp4', 'audio/ogg', 'audio/wav', 'audio/mpeg', 'audio/x-wav'],
  video: ['video/mp4', 'video/webm', 'video/quicktime', 'video/x-matroska'],
};

export function dataUrlToBase64(dataUrl: string): string {
  const match = dataUrl.match(/^data:([^;]+);base64,(.*)$/i);
  if (!match) return dataUrl;
  return match[2];
}

export function normalizeMediaPayload(media: MediaPayload): NormalizedMediaPayload {
  const type = media.type;
  const rawData = typeof media.data === 'string' ? media.data.trim() : '';

  if (!rawData) {
    throw new Error(`${type === 'image' ? 'Foto' : type === 'audio' ? 'Áudio' : 'Vídeo'} vazio.`);
  }

  const mimeType = (media.mimeType ?? inferMimeFromData(rawData) ?? '').toLowerCase();
  const allowed = ALLOWED_MIME[type] ?? [];

  if (!allowed.includes(mimeType)) {
    throw new Error(`MIME type inválido para ${type}: ${mimeType || 'desconhecido'}`);
  }

  const serializedData = rawData.startsWith('data:') ? rawData : `data:${mimeType};base64,${rawData}`;
  const size = typeof media.size === 'number' ? media.size : estimateBytes(serializedData);

  if (size <= 0 || size > MAX_MEDIA_BYTES[type]) {
    throw new Error(`${type === 'image' ? 'A foto' : type === 'audio' ? 'O áudio' : 'O vídeo'} excede o limite permitido (${formatBytes(MAX_MEDIA_BYTES[type])}).`);
  }

  return {
    type,
    mimeType,
    data: serializedData,
    size,
    durationSeconds: media.durationSeconds,
  };
}

export function validateMediaPayload(media: MediaPayload): NormalizedMediaPayload {
  return normalizeMediaPayload(media);
}

export function validateRequestEnvelope(payload: unknown, userId?: string | null): { message: string; media: NormalizedMediaPayload[] } {
  if (!userId) {
    throw new Error('Não autenticado.');
  }

  if (!payload || typeof payload !== 'object') {
    throw new Error('Payload inválido.');
  }

  const value = payload as Record<string, unknown>;
  const messageValue = typeof value.message === 'string' ? value.message : typeof value.mensagem === 'string' ? value.mensagem : undefined;

  if (!messageValue || messageValue.trim().length === 0) {
    throw new Error('Mensagem em falta.');
  }

  const mediaValue = Array.isArray(value.media) ? value.media : [];
  return {
    message: messageValue,
    media: mediaValue.map((item, index) => {
      const normalized = normalizeMediaPayload(item as MediaPayload);
      if (index >= 3) {
        throw new Error('Número máximo de ficheiros excedido.');
      }
      return normalized;
    }),
  };
}

export function extractTranscriptText(payload: unknown): string {
  if (!payload || typeof payload !== 'object') {
    throw new Error('Resposta de transcrição inválida do serviço externo.');
  }

  const value = payload as Record<string, unknown>;
  const transcript =
    typeof value.text === 'string'
      ? value.text
      : typeof value.transcript === 'string'
        ? value.transcript
        : typeof value.transcription === 'string'
          ? value.transcription
          : typeof value.result === 'string'
            ? value.result
            : undefined;

  if (!transcript || transcript.trim().length === 0) {
    throw new Error('Transcrição vazia.');
  }

  return transcript.trim();
}

export function buildTranscriptionPrompt(message: string, transcript: string): string {
  const textoTranscrito = transcript.trim();
  if (!textoTranscrito) {
    throw new Error('Transcrição vazia.');
  }

  return `${message.trim()}\n\nTranscrição do áudio:\n${textoTranscrito}`;
}

function inferMimeFromData(data: string): string | undefined {
  if (data.startsWith('data:')) {
    const match = data.match(/^data:([^;,]+)[;,]/i);
    if (match) return match[1].toLowerCase();
  }
  return undefined;
}

function estimateBytes(data: string): number {
  if (!data) return 0;
  const match = data.match(/^data:.*;base64,(.*)$/i);
  const base64 = match ? match[1] : data;
  return Math.ceil((base64.length * 3) / 4);
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

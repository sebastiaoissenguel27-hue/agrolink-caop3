
import test from 'node:test';
import assert from 'node:assert/strict';

import {
  buildTranscriptionPrompt,
  extractTranscriptText,
  normalizeMediaPayload,
  validateMediaPayload,
  validateRequestEnvelope,
} from './mediaValidation.ts';

test('normalizeMediaPayload accepts valid image payload', () => {
  const result = normalizeMediaPayload({
    type: 'image',
    mimeType: 'image/jpeg',
    data: 'data:image/jpeg;base64,/9j/2w==',
  });

  assert.equal(result.type, 'image');
  assert.equal(result.mimeType, 'image/jpeg');
  assert.ok(result.data.length > 0);
});

test('normalizeMediaPayload accepts valid audio payload', () => {
  const result = normalizeMediaPayload({
    type: 'audio',
    mimeType: 'audio/webm',
    data: 'data:audio/webm;base64,SUQzBAAAAAAA=',
  });

  assert.equal(result.type, 'audio');
  assert.equal(result.mimeType, 'audio/webm');
});

test('normalizeMediaPayload accepts valid video payload', () => {
  const result = normalizeMediaPayload({
    type: 'video',
    mimeType: 'video/mp4',
    data: 'data:video/mp4;base64,AAAA',
  });

  assert.equal(result.type, 'video');
  assert.equal(result.mimeType, 'video/mp4');
});

test('validateMediaPayload rejects invalid MIME type', () => {
  assert.throws(() => {
    validateMediaPayload({
      type: 'image',
      mimeType: 'application/pdf',
      data: 'SGVsbG8=',
    });
  }, /MIME/);
});

test('validateMediaPayload rejects too large file', () => {
  const largeBase64 = 'A'.repeat(30 * 1024 * 1024);
  assert.throws(() => {
    validateMediaPayload({
      type: 'image',
      mimeType: 'image/jpeg',
      data: `data:image/jpeg;base64,${largeBase64}`,
    });
  }, /limite|excede/i);
});

test('validateMediaPayload rejects empty audio', () => {
  assert.throws(() => {
    validateMediaPayload({
      type: 'audio',
      mimeType: 'audio/webm',
      data: '',
    });
  }, /vazio|empty/i);
});

test('validateMediaPayload rejects invalid audio mime', () => {
  assert.throws(() => {
    validateMediaPayload({
      type: 'audio',
      mimeType: 'text/plain',
      data: 'data:audio/webm;base64,SUQzBAAAAAAA=',
    });
  }, /MIME/);
});

test('validateRequestEnvelope rejects payload without media and without user', () => {
  assert.throws(() => {
    validateRequestEnvelope({ message: '' }, 'user-1');
  }, /Mensagem em falta/i);

  assert.throws(() => {
    validateRequestEnvelope({ message: 'Pergunta' }, null);
  }, /Não autenticado/i);
});

test('validateRequestEnvelope accepts valid request shape', () => {
  const result = validateRequestEnvelope({
    message: 'Analisa esta cultura',
    media: [
      {
        type: 'image',
        mimeType: 'image/jpeg',
        data: 'data:image/jpeg;base64,/9j/2w==',
      },
    ],
  }, 'user-1');

  assert.equal(result.message, 'Analisa esta cultura');
  assert.equal(result.media.length, 1);
  assert.equal(result.media[0].type, 'image');
});

test('extractTranscriptText throws on missing transcription', () => {
  assert.throws(() => extractTranscriptText({}), /Transcrição vazia|inválida/i);
});

test('extractTranscriptText returns transcript text from real payload', () => {
  const transcript = extractTranscriptText({ text: 'Olá, tenho uma praga na mandioca.' });
  assert.equal(transcript, 'Olá, tenho uma praga na mandioca.');
});

test('buildTranscriptionPrompt merges message and audio transcript', () => {
  const prompt = buildTranscriptionPrompt('Qual a melhor forma de controlar?', 'A mandioca está com folhas amareladas');
  assert.match(prompt, /Transcrição do áudio:/i);
  assert.match(prompt, /mandioca/i);
});

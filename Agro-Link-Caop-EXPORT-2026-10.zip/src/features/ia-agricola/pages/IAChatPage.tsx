
import { useEffect, useRef, useState } from 'react';
import { useAuth } from '@/features/auth/context/AuthContext';
import {
  enviarMensagemIA,
  obterConversaAtual,
  falarResposta,
  encaminharConversaParaTecnico,
  type MediaPayload,
  type RespostaIA,
} from '@/features/ia-agricola/api/iaService';

interface MensagemUI {
  role: 'user' | 'assistant';
  conteudo: string;
  confianca?: 'alta' | 'media' | 'baixa';
  encaminhado?: boolean;
  analyticsId?: string;
}

const ROTULO_CONFIANCA: Record<string, string> = {
  alta: '✅ Confiança alta',
  media: '🟡 Confiança média',
  baixa: '⚠️ Confiança baixa',
};

const MAX_AUDIO_BYTES = 12 * 1024 * 1024;
const MAX_VIDEO_BYTES = 25 * 1024 * 1024;
const MAX_IMAGE_BYTES = 8 * 1024 * 1024;
const AUDIO_MIME_PREFERENCES = [
  'audio/webm;codecs=opus',
  'audio/webm',
  'audio/mp4',
  'audio/ogg;codecs=opus',
  'audio/wav',
  'audio/mpeg',
];

function formatarTamanho(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function formatarDuracao(segundos: number) {
  if (!Number.isFinite(segundos) || segundos <= 0) return '0:00';
  const mins = Math.floor(segundos / 60);
  const secs = Math.floor(segundos % 60);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

function ficheiroParaDataUrl(ficheiro: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const leitor = new FileReader();
    leitor.onload = () => resolve(String(leitor.result ?? ''));
    leitor.onerror = reject;
    leitor.readAsDataURL(ficheiro);
  });
}

function blobParaDataUrl(ficheiro: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const leitor = new FileReader();
    leitor.onload = () => resolve(String(leitor.result ?? ''));
    leitor.onerror = reject;
    leitor.readAsDataURL(ficheiro);
  });
}

async function comprimirImagemSeNecessario(ficheiro: File): Promise<File> {
  const mime = ficheiro.type && ficheiro.type.startsWith('image/') ? ficheiro.type : 'image/jpeg';
  if (ficheiro.size <= MAX_IMAGE_BYTES && (mime === 'image/jpeg' || mime === 'image/png' || mime === 'image/webp')) {
    return ficheiro;
  }

  const bitmap = await createImageBitmap(ficheiro);
  const ratio = Math.min(1, 1600 / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(bitmap.width * ratio));
  canvas.height = Math.max(1, Math.round(bitmap.height * ratio));

  const context = canvas.getContext('2d');
  if (!context) return ficheiro;
  context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);

  const dataUrl = canvas.toDataURL('image/jpeg', 0.82);
  const blob = await (await fetch(dataUrl)).blob();
  return new File([blob], ficheiro.name || 'foto.jpg', { type: 'image/jpeg', lastModified: Date.now() });
}

async function extrairFramesRepresentativos(ficheiro: File): Promise<File[]> {
  if (!('createImageBitmap' in window)) return [];

  try {
    const url = URL.createObjectURL(ficheiro);
    const video = document.createElement('video');
    video.preload = 'metadata';
    video.muted = true;
    video.playsInline = true;
    video.src = url;
    await new Promise<void>((resolve, reject) => {
      video.onloadedmetadata = () => resolve();
      video.onerror = () => reject(new Error('Não foi possível carregar o vídeo para análise por frames.'));
    });

    const duracao = Number.isFinite(video.duration) ? video.duration : 0;
    const tempos = duracao > 0 ? [0.15, 0.35, 0.6, 0.85].map((percent) => Math.min(duracao - 0.1, duracao * percent)).filter((value) => Number.isFinite(value)) : [0];
    const frames: File[] = [];

    for (const tempo of tempos) {
      video.currentTime = tempo;
      await new Promise<void>((resolve) => {
        video.onseeked = () => resolve();
      });

      const canvas = document.createElement('canvas');
      canvas.width = 1200;
      canvas.height = Math.max(1, Math.round((video.videoHeight / video.videoWidth) * 1200));
      const ctx = canvas.getContext('2d');
      if (!ctx) continue;
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.78);
      const blob = await (await fetch(dataUrl)).blob();
      frames.push(new File([blob], `frame-${frames.length + 1}.jpg`, { type: 'image/jpeg' }));
    }

    URL.revokeObjectURL(url);
    return frames;
  } catch {
    return [];
  }
}

export function IAChatPage() {
  const { perfil } = useAuth();
  const [mensagens, setMensagens] = useState<MensagemUI[]>([]);
  const [texto, setTexto] = useState('');
  const [imagem, setImagem] = useState<File | null>(null);
  const [imagemPreviewUrl, setImagemPreviewUrl] = useState<string | null>(null);
  const [video, setVideo] = useState<File | null>(null);
  const [videoPreviewUrl, setVideoPreviewUrl] = useState<string | null>(null);
  const [videoDuration, setVideoDuration] = useState<number | null>(null);
  const [videoFrames, setVideoFrames] = useState<File[]>([]);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [audioMimeType, setAudioMimeType] = useState<string | null>(null);
  const [audioPreviewUrl, setAudioPreviewUrl] = useState<string | null>(null);
  const [audioDuration, setAudioDuration] = useState<number | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [conversaId, setConversaId] = useState<string | undefined>();
  const [aEnviar, setAEnviar] = useState(false);
  const [aEncaminhar, setAEncaminhar] = useState(false);
  const [aOuvirVoz, setAOuvirVoz] = useState(false);
  const [erro, setErro] = useState<string | null>(null);
  const fimRef = useRef<HTMLDivElement>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const audioPreviewUrlRef = useRef<string | null>(null);

  const SpeechRecognitionCtor =
    (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

  function limparAudio() {
    if (audioPreviewUrlRef.current) {
      URL.revokeObjectURL(audioPreviewUrlRef.current);
      audioPreviewUrlRef.current = null;
    }
    setAudioBlob(null);
    setAudioMimeType(null);
    setAudioPreviewUrl(null);
    setAudioDuration(null);
  }

  function limparImagem() {
    if (imagemPreviewUrl) {
      URL.revokeObjectURL(imagemPreviewUrl);
    }
    setImagem(null);
    setImagemPreviewUrl(null);
  }

  function limparVideo() {
    if (videoPreviewUrl) {
      URL.revokeObjectURL(videoPreviewUrl);
    }
    setVideo(null);
    setVideoPreviewUrl(null);
    setVideoDuration(null);
    setVideoFrames([]);
  }

  function removerTodosAnexos() {
    limparAudio();
    limparImagem();
    limparVideo();
  }

  function perguntarPorVoz() {
    if (!SpeechRecognitionCtor) {
      setErro('O seu navegador não suporta ditado por voz. Pode escrever a pergunta normalmente.');
      return;
    }
    const reconhecimento = new SpeechRecognitionCtor();
    reconhecimento.lang = 'pt-PT';
    reconhecimento.interimResults = false;
    reconhecimento.onstart = () => setAOuvirVoz(true);
    reconhecimento.onend = () => setAOuvirVoz(false);
    reconhecimento.onerror = () => setAOuvirVoz(false);
    reconhecimento.onresult = (evento: any) => {
      const textoTranscrito = evento.results[0]?.[0]?.transcript;
      if (textoTranscrito) setTexto((prev) => (prev ? `${prev} ${textoTranscrito}` : textoTranscrito));
    };
    reconhecimento.start();
  }

  async function iniciarGravacaoAudio() {
    if (typeof MediaRecorder === 'undefined') {
      setErro('Este dispositivo/navegador não suporta gravação de áudio diretamente. Pode tentar atualizar o navegador.');
      return;
    }

    try {
      setErro(null);
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const mimeType = AUDIO_MIME_PREFERENCES.find((tipo) => MediaRecorder.isTypeSupported(tipo)) ?? undefined;
      const recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
      recorderRef.current = recorder;
      chunksRef.current = [];
      setIsRecording(true);

      recorder.ondataavailable = (evento) => {
        if (evento.data.size > 0) chunksRef.current.push(evento.data);
      };

      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: mimeType ?? 'audio/webm' });
        if (blob.size === 0) {
          setErro('A gravação de áudio ficou vazia. Grave novamente antes de enviar.');
          limparAudio();
          return;
        }
        if (blob.size > MAX_AUDIO_BYTES) {
          setErro('O áudio gravado excede o limite do piloto (12 MB). Grave um trecho mais curto.');
          limparAudio();
          return;
        }

        const url = URL.createObjectURL(blob);
        if (audioPreviewUrlRef.current) URL.revokeObjectURL(audioPreviewUrlRef.current);
        audioPreviewUrlRef.current = url;
        setAudioBlob(blob);
        setAudioMimeType(mimeType ?? blob.type ?? 'audio/webm');
        setAudioPreviewUrl(url);
        setAudioDuration(null);

        const audioEl = new Audio(url);
        audioEl.preload = 'metadata';
        audioEl.onloadedmetadata = () => {
          if (Number.isFinite(audioEl.duration)) setAudioDuration(audioEl.duration);
        };
      };

      recorder.start();
    } catch {
      setErro('Não foi possível aceder ao microfone. Verifique a permissão do navegador e tente novamente.');
    }
  }

  function pararGravacaoAudio() {
    if (!recorderRef.current) return;
    recorderRef.current.stop();
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    recorderRef.current = null;
    setIsRecording(false);
  }

  async function anexarImagem(ficheiro: File | null) {
    if (!ficheiro) return;
    if (!ficheiro.type.startsWith('image/')) {
      setErro('O ficheiro selecionado não é uma imagem válida. Use JPG, PNG ou WEBP.');
      return;
    }
    if (ficheiro.size > MAX_IMAGE_BYTES) {
      setErro('A foto excede o limite do piloto (8 MB). Escolha uma imagem mais pequena.');
      return;
    }

    try {
      const imagemComprimida = await comprimirImagemSeNecessario(ficheiro);
      if (imagemPreviewUrl) URL.revokeObjectURL(imagemPreviewUrl);
      const previewUrl = URL.createObjectURL(imagemComprimida);
      setImagem(imagemComprimida);
      setImagemPreviewUrl(previewUrl);
      setErro(null);
    } catch {
      setErro('Não foi possível preparar a imagem para envio. Verifique o ficheiro e tente novamente.');
    }
  }

  async function anexarVideo(ficheiro: File | null) {
    if (!ficheiro) return;
    if (!ficheiro.type.startsWith('video/')) {
      setErro('O ficheiro selecionado não é um vídeo válido.');
      return;
    }
    if (ficheiro.size > MAX_VIDEO_BYTES) {
      setErro('O vídeo excede o limite do piloto (25 MB). Escolha um ficheiro menor.');
      return;
    }

    try {
      const url = URL.createObjectURL(ficheiro);
      if (videoPreviewUrl) URL.revokeObjectURL(videoPreviewUrl);
      setVideoPreviewUrl(url);
      setVideo(ficheiro);
      setVideoFrames([]);

      const videoEl = document.createElement('video');
      videoEl.preload = 'metadata';
      videoEl.src = url;
      videoEl.onloadedmetadata = () => {
        if (Number.isFinite(videoEl.duration)) {
          setVideoDuration(videoEl.duration);
        }
      };

      const frames = await extrairFramesRepresentativos(ficheiro);
      setVideoFrames(frames);
      setErro(null);
    } catch {
      setErro('Não foi possível preparar o vídeo para análise. Verifique o ficheiro e tente outra vez.');
    }
  }

  useEffect(() => {
    if (!perfil) return;

    obterConversaAtual()
      .then((res) => {
        if (!res) return;
        setConversaId(res.conversaId);
        setMensagens(res.mensagens.map((m) => ({ role: m.role, conteudo: m.conteudo })));
      })
      .catch(() => undefined);
  }, [perfil]);

  useEffect(() => {
    fimRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [mensagens]);

  useEffect(() => {
    return () => {
      if (audioPreviewUrlRef.current) URL.revokeObjectURL(audioPreviewUrlRef.current);
      if (imagemPreviewUrl) URL.revokeObjectURL(imagemPreviewUrl);
      if (videoPreviewUrl) URL.revokeObjectURL(videoPreviewUrl);
      streamRef.current?.getTracks().forEach((track) => track.stop());
    };
  }, [imagemPreviewUrl, videoPreviewUrl]);

  async function construirMediaPayload(): Promise<MediaPayload[]> {
    const media: MediaPayload[] = [];

    if (imagem) {
      media.push({
        type: 'image',
        mimeType: imagem.type || 'image/jpeg',
        data: await ficheiroParaDataUrl(imagem),
        size: imagem.size,
      });
    }

    if (audioBlob) {
      media.push({
        type: 'audio',
        mimeType: audioMimeType || audioBlob.type || 'audio/webm',
        data: await blobParaDataUrl(audioBlob),
        size: audioBlob.size,
        durationSeconds: audioDuration ?? undefined,
      });
    }

    if (video) {
      media.push({
        type: 'video',
        mimeType: video.type || 'video/mp4',
        data: await ficheiroParaDataUrl(video),
        size: video.size,
        durationSeconds: videoDuration ?? undefined,
      });
      for (const frame of videoFrames) {
        media.push({
          type: 'image',
          mimeType: frame.type || 'image/jpeg',
          data: await ficheiroParaDataUrl(frame),
          size: frame.size,
        });
      }
    }

    return media;
  }

  async function enviar() {
    const temConteudo = Boolean(texto.trim() || imagem || audioBlob || video);
    if (!temConteudo) return;

    if (!perfil) {
      const mensagem =
        'O assistente público para visitantes está pendente neste piloto. A infraestrutura atual exige autenticação para criar e guardar conversas de IA, por isso não está ativado em modo anónimo de forma segura.';
      setErro(mensagem);
      setMensagens((prev) => [
        ...prev,
        {
          role: 'assistant',
          conteudo: mensagem,
        },
      ]);
      return;
    }

    setErro(null);
    const perguntaAtual = texto.trim() || (audioBlob ? 'Áudio gravado para o assistente' : imagem ? '(foto anexada)' : video ? 'Vídeo anexado para análise' : 'Anexo');
    setMensagens((prev) => [
      ...prev,
      {
        role: 'user',
        conteudo: perguntaAtual,
      },
    ]);
    setTexto('');
    setAEnviar(true);

    try {
      const media = await construirMediaPayload();
      if (!perfil) throw new Error('Sessão necessária.');
      const resultado: RespostaIA = await enviarMensagemIA(perfil.id, perguntaAtual, conversaId, media);
      setConversaId(resultado.conversaId);
      setMensagens((prev) => [
        ...prev,
        {
          role: 'assistant',
          conteudo: resultado.resposta,
          confianca: resultado.confianca,
          analyticsId: resultado.analyticsId,
        },
      ]);
      removerTodosAnexos();
    } catch {
      const mensagem =
        'Não foi possível contactar o assistente agora. Verifique a ligação e tente novamente. Se o problema continuar, é melhor continuar com um técnico humano.';
      setErro(mensagem);
      setMensagens((prev) => [
        ...prev,
        {
          role: 'assistant',
          conteudo: mensagem,
        },
      ]);
    } finally {
      setAEnviar(false);
    }
  }

  async function encaminhar(indice: number) {
    if (!perfil) return;
    const respostaMsg = mensagens[indice];
    const perguntaMsg = mensagens[indice - 1];
    setAEncaminhar(true);
    try {
      await encaminharConversaParaTecnico({
        autorId: perfil.id,
        perguntaUtilizador: perguntaMsg?.conteudo ?? '',
        respostaIA: respostaMsg.conteudo,
        provincia: perfil.provincia,
        municipio: perfil.municipio,
        comuna: perfil.comuna,
        analyticsId: respostaMsg.analyticsId,
      });
      setMensagens((prev) =>
        prev.map((m, i) => (i === indice ? { ...m, encaminhado: true } : m))
      );
    } finally {
      setAEncaminhar(false);
    }
  }

  return (
    <div
      style={{
        maxWidth: 720,
        margin: '0 auto',
        display: 'flex',
        flexDirection: 'column',
        minHeight: '80vh',
        padding: '12px 12px 16px',
        boxSizing: 'border-box',
      }}
    >
      <div style={{ marginBottom: 12 }}>
        <h1 style={{ margin: '0 0 8px', fontSize: '1.8rem' }}>Assistente IA agrícola</h1>
        <p style={{ margin: 0, fontSize: '0.9rem', color: '#4d5d50', lineHeight: 1.5 }}>
          Pergunte sobre pragas, doenças, solo ou clima. Pode anexar imagem, áudio gravado ou vídeo selecionado. O contexto do país selecionado é mantido.
        </p>
      </div>

      {!perfil && (
        <div
          style={{
            marginBottom: 12,
            padding: 12,
            borderRadius: 12,
            background: '#fff8e7',
            border: '1px solid #f0dfb5',
            color: '#614e1a',
            fontSize: '0.92rem',
            lineHeight: 1.5,
          }}
        >
          Estado do piloto: o assistente público para visitantes está pendente. A infraestrutura atual exige autenticação para criar a conversa e guardar o histórico, por isso a sessão anónima ainda não está ativada de forma segura.
        </div>
      )}

      {erro && (
        <div
          style={{
            marginBottom: 12,
            padding: 10,
            borderRadius: 10,
            background: '#fff1f1',
            border: '1px solid #f4c7c7',
            color: '#7a2d2d',
            fontSize: '0.9rem',
          }}
        >
          {erro}
        </div>
      )}

      <div
        role="log"
        aria-live="polite"
        aria-label="Conversa com o assistente"
        style={{
          flex: 1,
          overflowY: 'auto',
          display: 'flex',
          flexDirection: 'column',
          gap: 10,
          padding: '10px 4px 2px',
          minHeight: 260,
        }}
      >
        {mensagens.map((m, i) => (
          <div
            key={i}
            style={{
              alignSelf: m.role === 'user' ? 'flex-end' : 'flex-start',
              background: m.role === 'user' ? '#1f7a3d' : '#ffffff',
              color: m.role === 'user' ? '#ffffff' : '#1f2a1f',
              border: m.role === 'assistant' ? '1px solid #dfe8dc' : '1px solid rgba(31, 122, 61, 0.08)',
              borderRadius: 16,
              padding: '12px 14px',
              maxWidth: '86%',
              boxShadow: '0 1px 2px rgba(0,0,0,0.04)',
              wordBreak: 'break-word',
            }}
          >
            <p style={{ margin: 0, whiteSpace: 'pre-wrap', lineHeight: 1.5 }}>{m.conteudo}</p>

            {m.role === 'assistant' && m.confianca && (
              <div style={{ marginTop: 8, display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
                <small>{ROTULO_CONFIANCA[m.confianca]}</small>
                <button
                  type="button"
                  onClick={() => falarResposta(m.conteudo)}
                  title="Ouvir resposta"
                  aria-label="Ouvir resposta em voz alta"
                  style={{ minWidth: 38, minHeight: 38, borderRadius: 10, border: '1px solid #dfe8dc', background: '#f5f8f2' }}
                >
                  🔊
                </button>
                {m.confianca === 'baixa' && !m.encaminhado && (
                  <button
                    type="button"
                    onClick={() => encaminhar(i)}
                    disabled={aEncaminhar}
                    style={{ minHeight: 38, borderRadius: 10, background: '#f5f8f2', border: '1px solid #dfe8dc', padding: '0 10px' }}
                  >
                    {aEncaminhar ? 'A encaminhar…' : 'Encaminhar para técnico'}
                  </button>
                )}
                {m.encaminhado && <small>✔ Encaminhado para um técnico</small>}
              </div>
            )}
          </div>
        ))}
        {aEnviar && (
          <div style={{ alignSelf: 'flex-start', background: '#f5f8f2', border: '1px solid #dfe8dc', borderRadius: 16, padding: '10px 12px', maxWidth: '80%' }}>
            <strong style={{ fontSize: '0.9rem' }}>A pensar…</strong>
          </div>
        )}
        <div ref={fimRef} />
      </div>

      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 12, alignItems: 'center' }}>
        <button
          type="button"
          onClick={perguntarPorVoz}
          aria-label={aOuvirVoz ? 'A ouvir — fale agora' : 'Perguntar por voz'}
          title="Perguntar por voz"
          disabled={!perfil}
          style={{
            minHeight: 44,
            padding: '0 14px',
            borderRadius: 12,
            border: '1px solid #dfe8dc',
            background: aOuvirVoz ? '#fff0f0' : '#f3f7f0',
            color: '#1f3d2b',
            fontWeight: 700,
            cursor: !perfil ? 'not-allowed' : 'pointer',
          }}
        >
          {aOuvirVoz ? '🔴 A ouvir…' : '🎤 Voz'}
        </button>

        <button
          type="button"
          onClick={isRecording ? pararGravacaoAudio : iniciarGravacaoAudio}
          aria-label={isRecording ? 'Parar gravação de áudio' : 'Gravar áudio'}
          title={isRecording ? 'Parar gravação de áudio' : 'Gravar áudio'}
          disabled={!perfil}
          style={{
            minHeight: 44,
            padding: '0 14px',
            borderRadius: 12,
            border: '1px solid #dfe8dc',
            background: isRecording ? '#fff0f0' : '#f3f7f0',
            color: '#1f3d2b',
            fontWeight: 700,
            cursor: !perfil ? 'not-allowed' : 'pointer',
          }}
        >
          {isRecording ? '⏹️ A gravar...' : '🎙️ Gravar áudio'}
        </button>

        <label
          htmlFor="ia-video"
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            justifyContent: 'center',
            minHeight: 44,
            padding: '0 14px',
            borderRadius: 12,
            background: '#f3f7f0',
            border: '1px solid #dfe8dc',
            cursor: 'pointer',
            fontWeight: 700,
            color: '#1f3d2b',
          }}
        >
          🎥 Vídeo
        </label>
        <input
          id="ia-video"
          type="file"
          accept="video/*"
          onChange={(e) => {
            const ficheiro = e.target.files?.[0] ?? null;
            e.target.value = '';
            void anexarVideo(ficheiro);
          }}
          style={{ display: 'none' }}
          title="Anexar vídeo"
          aria-label="Anexar vídeo à pergunta"
        />

        <label
          htmlFor="ia-anexo"
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            justifyContent: 'center',
            minHeight: 44,
            padding: '0 14px',
            borderRadius: 12,
            background: '#f3f7f0',
            border: '1px solid #dfe8dc',
            cursor: 'pointer',
            fontWeight: 700,
            color: '#1f3d2b',
          }}
        >
          🖼️ Imagem
        </label>
        <input
          id="ia-anexo"
          type="file"
          accept="image/*"
          onChange={(e) => {
            const ficheiro = e.target.files?.[0] ?? null;
            e.target.value = '';
            void anexarImagem(ficheiro);
          }}
          style={{ display: 'none' }}
          title="Anexar foto"
          aria-label="Anexar fotografia à pergunta"
        />
      </div>

      {imagemPreviewUrl && (
        <div style={{ marginTop: 12, padding: 10, borderRadius: 12, background: '#f6f8f3', border: '1px solid #dfe8dc' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 8 }}>
            <strong>Pré-visualização da foto</strong>
            <button type="button" onClick={limparImagem} style={{ borderRadius: 8, border: '1px solid #dfe8dc', background: '#fff', padding: '6px 10px' }}>Remover</button>
          </div>
          <img src={imagemPreviewUrl} alt="Pré-visualização da foto selecionada" style={{ width: '100%', maxHeight: 260, objectFit: 'cover', borderRadius: 10, marginTop: 8 }} />
          {imagem && <small style={{ display: 'block', marginTop: 8, color: '#4d5d50' }}>{imagem.name} · {formatarTamanho(imagem.size)}</small>}
        </div>
      )}

      {audioBlob && (
        <div style={{ marginTop: 12, padding: 12, borderRadius: 12, background: '#f5f8f2', border: '1px solid #dfe8dc' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
            <strong>Áudio gravado</strong>
            <span style={{ color: '#4d5d50', fontSize: '0.85rem' }}>{audioDuration ? formatarDuracao(audioDuration) : '0:00'}</span>
          </div>
          <audio ref={audioRef} controls src={audioPreviewUrl ?? undefined} style={{ width: '100%', marginTop: 8 }} />
          <div style={{ display: 'flex', gap: 8, marginTop: 8, flexWrap: 'wrap' }}>
            <button type="button" onClick={() => audioRef.current?.play()} style={{ borderRadius: 8, border: '1px solid #dfe8dc', background: '#fff', padding: '8px 10px' }}>▶️ Reproduzir</button>
            <button type="button" onClick={limparAudio} style={{ borderRadius: 8, border: '1px solid #dfe8dc', background: '#fff', padding: '8px 10px' }}>🗑️ Apagar</button>
          </div>
        </div>
      )}

      {videoPreviewUrl && (
        <div style={{ marginTop: 12, padding: 10, borderRadius: 12, background: '#f6f8f3', border: '1px solid #dfe8dc' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8, alignItems: 'center' }}>
            <div>
              <strong style={{ fontSize: '0.9rem' }}>Vídeo anexado</strong>
              <div style={{ fontSize: '0.8rem', color: '#4d5d50' }}>{video?.name}</div>
            </div>
            <button type="button" onClick={limparVideo} style={{ borderRadius: 8, border: '1px solid #dfe8dc', background: '#fff', padding: '6px 10px' }}>Remover</button>
          </div>
          <video src={videoPreviewUrl} controls style={{ width: '100%', maxHeight: 260, objectFit: 'cover', borderRadius: 10, marginTop: 8 }} />
          <div style={{ display: 'flex', gap: 8, justifyContent: 'space-between', marginTop: 8, color: '#4d5d50', fontSize: '0.8rem' }}>
            <small>{video ? formatarTamanho(video.size) : ''}</small>
            <small>{videoDuration ? formatarDuracao(videoDuration) : '0:00'}</small>
          </div>
          {videoFrames.length > 0 && <small style={{ display: 'block', marginTop: 8, color: '#4d5d50' }}>Análise por frames: {videoFrames.length} imagens representativas enviadas para contexto agrícola.</small>}
        </div>
      )}

      <div
        style={{
          display: 'flex',
          flexWrap: 'wrap',
          gap: 8,
          marginTop: 12,
          paddingTop: 8,
          borderTop: '1px solid #e6eedf',
          background: '#fff',
          position: 'sticky',
          bottom: 0,
        }}
      >
        <textarea
          id="ia-pergunta"
          rows={2}
          value={texto}
          onChange={(e) => setTexto(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              void enviar();
            }
          }}
          placeholder="Escreva a sua pergunta…"
          style={{
            flex: '1 1 180px',
            minWidth: 0,
            minHeight: 48,
            maxWidth: '100%',
            borderRadius: 12,
            border: '1px solid #dfe8dc',
            padding: '12px 14px',
            fontSize: 16,
            resize: 'vertical',
          }}
        />
        <button
          type="button"
          onClick={() => void enviar()}
          disabled={aEnviar || !perfil}
          style={{
            minWidth: 112,
            minHeight: 48,
            borderRadius: 12,
            border: 'none',
            background: !perfil ? '#b7c7b8' : '#1f7a3d',
            color: '#fff',
            fontWeight: 700,
            cursor: !perfil ? 'not-allowed' : 'pointer',
          }}
        >
          {aEnviar ? 'A pensar…' : 'Enviar'}
        </button>
      </div>
    </div>
  );
}

import { apiGet, apiPost } from '@/shared/lib/apiClient';
import { dbLocal } from '@/offline/db';
import { sincronizar } from '@/offline/syncEngine';
import { obterContextoIA } from '@/shared/lib/country';
export type MediaType='image'|'audio'|'video';
export interface MediaPayload{type:MediaType;mimeType:string;data:string;size?:number;durationSeconds?:number;}
export interface RespostaIA{conversaId:string;resposta:string;confianca:'alta'|'media'|'baixa';analyticsId?:string;}
export async function enviarMensagemIA(utilizadorId:string,mensagem:string,conversaId?:string,media?:MediaPayload[]):Promise<RespostaIA>{const c=obterContextoIA();const r=await apiPost<RespostaIA>('/api/ia/chat',{message:mensagem,mensagem,conversaId,media,contexto:{countryCode:c.countryCode,region:c.region,idioma:c.idioma,contextoAgricola:c.contextoAgricola}});await dbLocal.iaHistoricoCache.add({utilizadorId,conversaId:r.conversaId,role:'user',conteudo:mensagem,criadoEm:new Date().toISOString()});await dbLocal.iaHistoricoCache.add({utilizadorId,conversaId:r.conversaId,role:'assistant',conteudo:r.resposta,criadoEm:new Date().toISOString()});return r;}
export async function obterConversaAtual(){const c=await apiGet<any[]>('/api/data/ia_conversas?order=criado_em&limit=1');const conversa=c[0];if(!conversa)return null;const mensagens=await apiGet<any[]>(`/api/data/ia_mensagens?conversa_id=${encodeURIComponent(conversa.id)}&order=criado_em&asc=1&limit=500`);return{conversaId:conversa.id,mensagens};}
export async function obterHistoricoLocal(utilizadorId:string,conversaId:string){return dbLocal.iaHistoricoCache.where('[utilizadorId+conversaId]').equals([utilizadorId,conversaId]).sortBy('criadoEm');}
export function falarResposta(texto:string){if(!('speechSynthesis'in window))return;const u=new SpeechSynthesisUtterance(texto);u.lang='pt-PT';window.speechSynthesis.speak(u);}
export async function encaminharConversaParaTecnico(dados:{autorId:string;perguntaUtilizador:string;respostaIA:string;provincia?:string|null;municipio?:string|null;comuna?:string|null;analyticsId?:string}):Promise<string>{const r=await apiPost<{localId:string}>('/api/ia/encaminhar',dados);void sincronizar(dados.autorId);return r.localId;}

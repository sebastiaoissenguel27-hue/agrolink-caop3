import { apiGet, apiPost } from '@/shared/lib/apiClient';
import type { FerramentaCalculoRow } from '@/shared/types/database.types';
export async function guardarCalculo(utilizadorId:string,ferramenta:string,entradas:Record<string,unknown>,resultado:Record<string,unknown>){await apiPost('/api/data/ferramenta_calculos',{utilizador_id:utilizadorId,ferramenta,entradas,resultado});}
export async function listarHistoricoRemoto():Promise<FerramentaCalculoRow[]>{return apiGet('/api/data/ferramenta_calculos?limit=100');}

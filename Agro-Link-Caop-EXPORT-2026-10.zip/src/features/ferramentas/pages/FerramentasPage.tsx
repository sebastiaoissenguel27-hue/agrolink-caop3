
import { useEffect, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { useAuth } from '@/features/auth/context/AuthContext';
import { guardarCalculo, listarHistoricoRemoto } from '@/features/ferramentas/api/ferramentasService';
import { dbLocal } from '@/offline/db';
import type { FerramentaCalculoRow } from '@/shared/types/database.types';

const CULTURAS: Record<string, number> = {
  Mandioca: 300,
  Milho: 100,
  Feijão: 80,
  'Batata-doce': 100,
  Amendoim: 100,
};

function CalculadoraDoseInsumo({ utilizadorId }: { utilizadorId: string }) {
  const [area, setArea] = useState('');
  const [dosePorHa, setDosePorHa] = useState('');
  const [resultado, setResultado] = useState<number | null>(null);

  function calcular() {
    const a = parseFloat(area);
    const d = parseFloat(dosePorHa);
    if (isNaN(a) || isNaN(d) || a <= 0 || d <= 0) return;
    const total = a * d;
    setResultado(total);
    guardarCalculo(
      utilizadorId,
      'dose_insumo',
      { area_ha: a, dose_por_ha: d },
      { total }
    );
  }

  return (
    <div style={{ background: '#fff', borderRadius: 8, padding: 16 }}>
      <h3>Calculadora de dose de insumo</h3>
      <p style={{ fontSize: '0.8rem', color: 'var(--color-terra)' }}>
        Calcula a quantidade total de fertilizante/pesticida necessária a partir da dose
        recomendada por hectare.
      </p>
      <label>
        Área (hectares)
        <input type="number" min="0" step="0.01" value={area} onChange={(e) => setArea(e.target.value)} />
      </label>
      <label>
        Dose recomendada por hectare (kg ou L)
        <input type="number" min="0" step="0.01" value={dosePorHa} onChange={(e) => setDosePorHa(e.target.value)} />
      </label>
      <button onClick={calcular}>Calcular</button>
      {resultado !== null && (
        <p role="status" aria-live="polite">
          Quantidade total necessária: <strong>{resultado.toFixed(2)}</strong> (kg ou L, conforme a
          unidade da dose indicada)
        </p>
      )}
    </div>
  );
}

function CalculadoraCalendarioPlantio({ utilizadorId }: { utilizadorId: string }) {
  const [cultura, setCultura] = useState('Mandioca');
  const [dataPlantio, setDataPlantio] = useState('');
  const [dataColheita, setDataColheita] = useState<string | null>(null);

  function calcular() {
    if (!dataPlantio) return;
    const dias = CULTURAS[cultura];
    const data = new Date(dataPlantio);
    data.setDate(data.getDate() + dias);
    const estimada = data.toISOString().slice(0, 10);
    setDataColheita(estimada);
    guardarCalculo(
      utilizadorId,
      'calendario_plantio',
      { cultura, data_plantio: dataPlantio, ciclo_dias: dias },
      { data_colheita_estimada: estimada }
    );
  }

  return (
    <div style={{ background: '#fff', borderRadius: 8, padding: 16 }}>
      <h3>Planeador de calendário de plantio</h3>
      <p style={{ fontSize: '0.8rem', color: 'var(--color-terra)' }}>
        Estimativa aproximada — o ciclo real varia com a variedade e as condições locais.
      </p>
      <label>
        Cultura
        <select value={cultura} onChange={(e) => setCultura(e.target.value)}>
          {Object.keys(CULTURAS).map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
      </label>
      <label>
        Data de plantio
        <input type="date" value={dataPlantio} onChange={(e) => setDataPlantio(e.target.value)} />
      </label>
      <button onClick={calcular}>Calcular</button>
      {dataColheita && (
        <p role="status" aria-live="polite">
          Colheita estimada: <strong>{new Date(dataColheita).toLocaleDateString('pt-PT')}</strong>
        </p>
      )}
    </div>
  );
}

export function FerramentasPage() {
  const { perfil } = useAuth();
  const [historicoRemoto, setHistoricoRemoto] = useState<FerramentaCalculoRow[]>([]);
  const historicoLocal = useLiveQuery(() => dbLocal.calculosPendentes.toArray(), []) ?? [];

  useEffect(() => {
    listarHistoricoRemoto()
      .then(setHistoricoRemoto)
      .catch(() => setHistoricoRemoto([]));
  }, []);

  if (!perfil) return <p>A carregar…</p>;

  const pendentes = historicoLocal.filter((c) => !c.sincronizado);

  return (
    <div style={{ maxWidth: 640, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 16 }}>
      <h1>Ferramentas agrícolas</h1>
      <CalculadoraDoseInsumo utilizadorId={perfil.id} />
      <CalculadoraCalendarioPlantio utilizadorId={perfil.id} />

      <section>
        <h2>Histórico</h2>
        {pendentes.length === 0 && historicoRemoto.length === 0 && <p>Ainda não fez nenhum cálculo.</p>}
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {pendentes.map((c) => (
            <li key={c.localId} style={{ borderBottom: '1px solid #eee', padding: '6px 0' }}>
              {c.ferramenta} — <em>por sincronizar</em>
            </li>
          ))}
          {historicoRemoto.map((c) => (
            <li key={c.id} style={{ borderBottom: '1px solid #eee', padding: '6px 0' }}>
              {c.ferramenta} — {new Date(c.criado_em).toLocaleDateString('pt-PT')}
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}

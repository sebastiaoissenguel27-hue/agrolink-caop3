import { apiGet, apiPost, apiPatch } from '@/shared/lib/apiClient';
import type { RelatoRow, RelatoRespostaRow, RelatoMidiaRow, TipoRelato, StatusRelato } from '@/shared/types/database.types';
export interface RelatoConsultaPublica { id:string; tipo:TipoRelato; descricao:string; status:StatusRelato; criado_em:string; respostas:{comentario:string;criado_em:string}[]; }
export async function listarMeusRelatos():Promise<RelatoRow[]>{return apiGet('/api/data/relatos?order=criado_em&limit=500');}
export async function listarRelatosParaTecnico():Promise<RelatoRow[]>{return apiGet('/api/data/relatos?order=criado_em&limit=500');}
export async function obterMidias(relatoId:string):Promise<RelatoMidiaRow[]>{return apiGet(`/api/data/relato_midias?relato_id=${encodeURIComponent(relatoId)}&limit=100`);}
export async function obterUrlAssinadaMidia(caminhoStorage:string):Promise<string>{return `/api/media/${caminhoStorage.split('/').map(encodeURIComponent).join('/')}`;}
export async function listarRelatosParaTecnicoComFiltro(f:{status?:StatusRelato;tipo?:string}):Promise<RelatoRow[]>{const q=new URLSearchParams();if(f.status)q.set('status',f.status);if(f.tipo)q.set('tipo',f.tipo as TipoRelato);q.set('order','criado_em');q.set('limit','500');return apiGet(`/api/data/relatos?${q}`);}
export async function obterRespostas(relatoId:string):Promise<RelatoRespostaRow[]>{return apiGet(`/api/data/relato_respostas?relato_id=${encodeURIComponent(relatoId)}&order=criado_em&limit=100`);}
export async function responderRelato(relatoId:string,tecnicoId:string,comentario:string){await apiPost('/api/data/relato_respostas',{relato_id:relatoId,tecnico_id:tecnicoId,comentario});}
export async function atualizarStatusRelato(relatoId:string,status:StatusRelato){await apiPatch(`/api/data/relatos?id=${encodeURIComponent(relatoId)}`,{status});}
export async function consultarRelatoPorCodigo(codigo:string):Promise<RelatoConsultaPublica>{return apiGet(`/api/relatos/codigo?codigo=${encodeURIComponent(codigo)}`);}


import type { RelatoPendente } from '@/offline/db';
import type { RelatoRow } from '@/shared/types/database.types';

export type EstadoRelatoUI =
  | 'pendente'
  | 'sincronizando'
  | 'enviado'
  | 'respondido'
  | 'resolvido'
  | 'erro';

export const ROTULO_ESTADO: Record<EstadoRelatoUI, string> = {
  pendente: 'Pendente (no dispositivo)',
  sincronizando: 'A sincronizar…',
  enviado: 'Enviado',
  respondido: 'Respondido',
  resolvido: 'Resolvido',
  erro: 'Erro de sincronização',
};

export const COR_ESTADO: Record<EstadoRelatoUI, string> = {
  pendente: 'var(--color-terra)',
  sincronizando: 'var(--color-azul-rio)',
  enviado: 'var(--color-azul-rio)',
  respondido: 'var(--color-ocre)',
  resolvido: 'var(--color-verde-mata)',
  erro: 'var(--color-erro)',
};

export function estadoDeRelatoLocal(local: RelatoPendente): EstadoRelatoUI {
  if (local.erroSincronizacao) return 'erro';
  if (local.emSincronizacao) return 'sincronizando';
  return 'pendente';
}

export function estadoDeRelatoRemoto(remoto: RelatoRow): EstadoRelatoUI {
  if (remoto.status === 'resolvido') return 'resolvido';
  if (remoto.status === 'respondido') return 'respondido';
  return 'enviado';
}

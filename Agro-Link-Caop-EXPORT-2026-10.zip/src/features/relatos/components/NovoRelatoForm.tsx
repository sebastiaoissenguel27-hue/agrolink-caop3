
import { useEffect, useRef, useState, type FormEvent } from 'react';
import { dbLocal } from '@/offline/db';
import { sincronizar, sincronizarAnonimos } from '@/offline/syncEngine';
import type { TipoRelato } from '@/shared/types/database.types';

const TIPOS: { valor: TipoRelato; rotulo: string }[] = [
  { valor: 'praga', rotulo: 'Praga' },
  { valor: 'doenca', rotulo: 'Doença' },
  { valor: 'clima', rotulo: 'Condição climática' },
  { valor: 'solo', rotulo: 'Solo' },
  { valor: 'pedido_apoio', rotulo: 'Pedido de apoio técnico' },
  { valor: 'outro', rotulo: 'Outro' },
];

interface Props {
  autorId: string | null;
  provincia?: string | null;
  municipio?: string | null;
  comuna?: string | null;
  /** Chamado depois de gravar o relato localmente, com o código gerado (quando anónimo é conhecido só após sync — aqui devolve o localId). */
  aoConcluir?: (localId: string) => void;
}

export function NovoRelatoForm({ autorId, provincia, municipio, comuna, aoConcluir }: Props) {
  const [tipo, setTipo] = useState<TipoRelato>('praga');
  const [descricao, setDescricao] = useState('');
  const [fotos, setFotos] = useState<File[]>([]);
  const [aGravarAudio, setAGravarAudio] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [aEnviar, setAEnviar] = useState(false);
  const [mensagem, setMensagem] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  useEffect(() => {
    if (autorId !== null) return;
    const syncAnonymous = () => void sincronizarAnonimos();
    window.addEventListener('online', syncAnonymous);
    return () => window.removeEventListener('online', syncAnonymous);
  }, [autorId]);

  async function iniciarGravacaoAudio() {
    setMensagem(null);
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === 'undefined') {
      setMensagem('A gravação de áudio não é suportada neste dispositivo.');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mimeType = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg']
        .find((tipo) => MediaRecorder.isTypeSupported(tipo));
      const recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
      chunksRef.current = [];
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };
      recorder.onstop = () => {
        const tipoAudio = recorder.mimeType || mimeType || 'audio/webm';
        setAudioBlob(new Blob(chunksRef.current, { type: tipoAudio }));
        stream.getTracks().forEach((t) => t.stop());
      };
      recorder.start();
      mediaRecorderRef.current = recorder;
      setAGravarAudio(true);
    } catch {
      setMensagem('Não foi possível aceder ao microfone. Autorize o microfone nas permissões da aplicação e tente novamente.');
    }
  }

  function pararGravacaoAudio() {
    mediaRecorderRef.current?.stop();
    setAGravarAudio(false);
  }

  async function submeter(e: FormEvent) {
    e.preventDefault();
    setAEnviar(true);
    setMensagem(null);

    const localId = crypto.randomUUID();
    const criadoEm = new Date().toISOString();

    try {
      await dbLocal.relatosPendentes.add({
        localId,
        autorId,
        tipo,
        descricao,
        provincia: provincia ?? null,
        municipio: municipio ?? null,
        comuna: comuna ?? null,
        criadoEm,
        sincronizado: false,
      });

      for (const f of fotos) {
        await dbLocal.midiasPendentes.add({
          relatoLocalId: localId,
          tipo: 'foto',
          blob: f,
          nomeFicheiro: f.name,
        });
      }
      if (audioBlob) {
        await dbLocal.midiasPendentes.add({
          relatoLocalId: localId,
          tipo: 'audio',
          blob: audioBlob,
          nomeFicheiro: 'audio.webm',
        });
      }

      setMensagem(
        navigator.onLine
          ? 'Relato guardado. A sincronizar…'
          : 'Relato guardado no dispositivo. Será enviado automaticamente quando houver rede.'
      );
      setDescricao('');
      setFotos([]);
      setAudioBlob(null);

      if (autorId) void sincronizar(autorId);
      else void sincronizarAnonimos(localId);
      aoConcluir?.(localId);
    } catch {
      setMensagem('Não foi possível guardar o relato neste dispositivo.');
    } finally {
      setAEnviar(false);
    }
  }

  return (
    <form
      onSubmit={submeter}
      style={{
        display: 'flex',
        flexDirection: 'column',
        gap: 14,
        width: '100%',
        boxSizing: 'border-box',
      }}
    >
      {mensagem && (
        <div
          role="status"
          aria-live="polite"
          style={{
            padding: 12,
            borderRadius: 12,
            background: '#edf7ed',
            border: '1px solid #dbeedc',
            color: '#234b31',
            fontSize: '0.92rem',
          }}
        >
          {mensagem}
        </div>
      )}

      <div style={{ display: 'flex', flexDirection: 'column', gap: 10, padding: 14, borderRadius: 16, background: '#ffffff', border: '1px solid #e6eedf' }}>
        <label style={{ display: 'flex', flexDirection: 'column', gap: 8, fontWeight: 600 }}>
          Tipo de relato
          <select
            value={tipo}
            onChange={(e) => setTipo(e.target.value as TipoRelato)}
            style={{
              width: '100%',
              minHeight: 46,
              borderRadius: 12,
              border: '1px solid #dfe8dc',
              padding: '10px 12px',
              fontSize: 16,
              background: '#fff',
            }}
          >
            {TIPOS.map((t) => (
              <option key={t.valor} value={t.valor}>
                {t.rotulo}
              </option>
            ))}
          </select>
        </label>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 10, padding: 14, borderRadius: 16, background: '#ffffff', border: '1px solid #e6eedf' }}>
        <label style={{ display: 'flex', flexDirection: 'column', gap: 8, fontWeight: 600 }}>
          Descrição
          <textarea
            required
            rows={5}
            value={descricao}
            onChange={(e) => setDescricao(e.target.value)}
            placeholder="Descreva o que está a observar…"
            style={{
              width: '100%',
              minHeight: 120,
              borderRadius: 12,
              border: '1px solid #dfe8dc',
              padding: '12px 14px',
              fontSize: 16,
              resize: 'vertical',
              boxSizing: 'border-box',
            }}
          />
        </label>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 10, padding: 14, borderRadius: 16, background: '#ffffff', border: '1px solid #e6eedf' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, fontWeight: 600 }}>
          Fotografias (opcional)
          <label style={{ fontWeight: 500 }}>
            Escolher ficheiro
            <input
              type="file"
              accept="image/*"
              multiple
              onChange={(e) => setFotos((atuais) => [...atuais, ...Array.from(e.target.files ?? [])])}
              style={{ display: 'block', width: '100%', fontSize: 15, marginTop: 6 }}
            />
          </label>
          <label style={{ fontWeight: 500 }}>
            Tirar fotografia
            <input
              type="file"
              accept="image/*"
              capture="environment"
              onChange={(e) => setFotos((atuais) => [...atuais, ...Array.from(e.target.files ?? [])])}
              style={{ display: 'block', width: '100%', fontSize: 15, marginTop: 6 }}
            />
          </label>
          {fotos.length > 0 && <span style={{ color: '#2b4f33', fontSize: '0.9rem' }}>Selecionadas: {fotos.length}</span>}
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 10, padding: 14, borderRadius: 16, background: '#ffffff', border: '1px solid #e6eedf' }}>
        <div style={{ fontWeight: 600 }}>Áudio (opcional)</div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          {!aGravarAudio ? (
            <button type="button" onClick={iniciarGravacaoAudio} style={{ minHeight: 44, borderRadius: 12, border: '1px solid #dfe8dc', background: '#f3f7f0', padding: '0 14px', fontWeight: 600 }}>
              🎙️ Gravar
            </button>
          ) : (
            <button type="button" onClick={pararGravacaoAudio} style={{ minHeight: 44, borderRadius: 12, border: '1px solid #dfe8dc', background: '#f3f7f0', padding: '0 14px', fontWeight: 600 }}>
              ⏹️ Parar
            </button>
          )}
          {audioBlob && !aGravarAudio && <span style={{ color: '#2b4f33', fontSize: '0.9rem' }}>Áudio gravado ✓</span>}
        </div>
      </div>

      <button
        type="submit"
        disabled={aEnviar}
        style={{
          minHeight: 52,
          borderRadius: 14,
          border: 'none',
          background: '#1f7a3d',
          color: '#fff',
          fontSize: 16,
          fontWeight: 700,
          cursor: aEnviar ? 'wait' : 'pointer',
        }}
      >
        {aEnviar ? 'A guardar…' : 'Enviar relato'}
      </button>
    </form>
  );
}

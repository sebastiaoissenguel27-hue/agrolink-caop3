
import { useState, type FormEvent } from 'react';
import { NovoRelatoForm } from '@/features/relatos/components/NovoRelatoForm';
import { consultarRelatoPorCodigo } from '@/features/relatos/api/relatosService';
import { BackButton } from '@/app/components/BackButton';

export function RelatoAnonimoPage() {
  const [modo, setModo] = useState<'criar' | 'consultar'>('criar');
  const [codigo, setCodigo] = useState('');
  const [resultado, setResultado] = useState<Awaited<
    ReturnType<typeof consultarRelatoPorCodigo>
  > | null>(null);
  const [erro, setErro] = useState<string | null>(null);

  async function consultar(e: FormEvent) {
    e.preventDefault();
    setErro(null);
    setResultado(null);
    try {
      setResultado(await consultarRelatoPorCodigo(codigo));
    } catch {
      setErro('Código não encontrado. Verifique se o introduziu corretamente.');
    }
  }

  return (
    <div style={{ padding: 16, maxWidth: 720, margin: '0 auto', boxSizing: 'border-box', width: '100%' }}>
      <BackButton />
      <div style={{ marginBottom: 18, background: '#ffffff', border: '1px solid #e6eedf', borderRadius: 18, padding: 16, boxShadow: '0 2px 10px rgba(31, 58, 37, 0.04)' }}>
        <h1 style={{ margin: '0 0 8px', fontSize: '1.8rem' }}>Relato sem cadastro</h1>
        <p style={{ margin: 0, color: '#4d5d50', lineHeight: 1.6 }}>
          Pode reportar uma ocorrência sem criar conta. Vai receber um <strong>código único</strong> — guarde-o, porque é o único meio de consultar depois a resposta do técnico.
        </p>
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 18, flexWrap: 'wrap' }}>
        <button
          type="button"
          onClick={() => setModo('criar')}
          disabled={modo === 'criar'}
          style={{
            flex: '1 1 180px',
            minHeight: 52,
            borderRadius: 12,
            border: modo === 'criar' ? 'none' : '1px solid #dfe8dc',
            background: modo === 'criar' ? '#1f7a3d' : '#f3f7f0',
            color: modo === 'criar' ? '#fff' : '#1f3d2b',
            fontWeight: 800,
            fontSize: 16,
          }}
        >
          Criar relato
        </button>
        <button
          type="button"
          onClick={() => setModo('consultar')}
          disabled={modo === 'consultar'}
          style={{
            flex: '1 1 180px',
            minHeight: 52,
            borderRadius: 12,
            border: modo === 'consultar' ? 'none' : '1px solid #dfe8dc',
            background: modo === 'consultar' ? '#1f7a3d' : '#f3f7f0',
            color: modo === 'consultar' ? '#fff' : '#1f3d2b',
            fontWeight: 800,
            fontSize: 16,
          }}
        >
          Consultar por código
        </button>
      </div>

      {modo === 'criar' && (
        <div style={{ background: '#f9faf7', border: '1px solid #e6eedf', borderRadius: 18, padding: 14, width: '100%', boxSizing: 'border-box' }}>
          <NovoRelatoForm autorId={null} />
        </div>
      )}

      {modo === 'consultar' && (
        <form onSubmit={consultar} style={{ display: 'flex', flexDirection: 'column', gap: 10, background: '#fff', border: '1px solid #e6eedf', borderRadius: 18, padding: 16 }}>
          <label style={{ display: 'flex', flexDirection: 'column', gap: 8, fontWeight: 600 }}>
            Código do relato
            <input
              placeholder="Ex: A1B2C3D4"
              value={codigo}
              onChange={(e) => setCodigo(e.target.value)}
              required
              style={{
                width: '100%',
                minHeight: 48,
                borderRadius: 12,
                border: '1px solid #dfe8dc',
                padding: '12px 14px',
                fontSize: 16,
                boxSizing: 'border-box',
              }}
            />
          </label>
          <button type="submit" style={{ minHeight: 48, borderRadius: 12, border: 'none', background: '#1f7a3d', color: '#fff', fontWeight: 700, fontSize: 16 }}>
            Consultar
          </button>
        </form>
      )}

      {erro && <p style={{ marginTop: 16, color: '#7a2d2d', background: '#fff1f1', border: '1px solid #f4c7c7', borderRadius: 12, padding: 12 }}>{erro}</p>}

      {resultado && (
        <div style={{ marginTop: 16, borderTop: '1px solid #e6eedf', paddingTop: 16 }}>
          <p>
            <strong>Tipo:</strong> {resultado.tipo}
          </p>
          <p>
            <strong>Estado:</strong> {resultado.status}
          </p>
          <p>{resultado.descricao}</p>
          <h3>Respostas do técnico</h3>
          {resultado.respostas.length === 0 && <p>Ainda sem resposta.</p>}
          <ul>
            {resultado.respostas.map((r, i) => (
              <li key={i}>{r.comentario}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

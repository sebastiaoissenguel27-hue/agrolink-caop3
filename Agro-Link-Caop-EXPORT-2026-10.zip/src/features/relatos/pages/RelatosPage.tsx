
import { useEffect, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { useAuth } from '@/features/auth/context/AuthContext';
import { NovoRelatoForm } from '@/features/relatos/components/NovoRelatoForm';
import { listarMeusRelatos } from '@/features/relatos/api/relatosService';
import { dbLocal } from '@/offline/db';
import { sincronizar } from '@/offline/syncEngine';
import {
  ROTULO_ESTADO,
  COR_ESTADO,
  estadoDeRelatoLocal,
  estadoDeRelatoRemoto,
} from '@/features/relatos/lib/estadoRelato';
import type { RelatoRow } from '@/shared/types/database.types';

export function RelatosPage() {
  const { perfil } = useAuth();
  const [relatosRemotos, setRelatosRemotos] = useState<RelatoRow[]>([]);
  const [aCarregar, setACarregar] = useState(true);

  // Fila local reativa: atualiza sozinha quando o syncEngine altera Dexie.
  const relatosLocais = useLiveQuery(
    () => perfil ? dbLocal.relatosPendentes.where('autorId').equals(perfil.id).toArray() : [],
    [perfil?.id]
  ) ?? [];

  async function carregarRemotos() {
    setACarregar(true);
    try {
      setRelatosRemotos(await listarMeusRelatos());
    } finally {
      setACarregar(false);
    }
  }

  useEffect(() => {
    carregarRemotos();
  }, []);

  const pendentesOuComErro = relatosLocais.filter((r) => !r.sincronizado);

  return (
    <div style={{ padding: 24, maxWidth: 640, margin: '0 auto' }}>
      <h1>Os meus relatos</h1>

      <details open>
        <summary>Criar novo relato</summary>
        <NovoRelatoForm
          autorId={perfil?.id ?? null}
          provincia={perfil?.provincia}
          municipio={perfil?.municipio}
          comuna={perfil?.comuna}
          aoConcluir={() => setTimeout(carregarRemotos, 1500)}
        />
      </details>

      {pendentesOuComErro.length > 0 && (
        <div style={{ margin: '16px 0' }}>
          <button onClick={() => perfil && sincronizar(perfil.id).then(carregarRemotos)}>
            Sincronizar agora ({pendentesOuComErro.length} pendente
            {pendentesOuComErro.length > 1 ? 's' : ''})
          </button>
        </div>
      )}

      <h2>Histórico</h2>
      {aCarregar && <p>A carregar…</p>}

      <ul style={{ listStyle: 'none', padding: 0 }}>
        {pendentesOuComErro.map((r) => {
          const estado = estadoDeRelatoLocal(r);
          return (
            <li key={r.localId} style={{ borderBottom: '1px solid #eee', padding: '12px 0' }}>
              <strong>{r.tipo}</strong> —{' '}
              <span style={{ color: COR_ESTADO[estado] }}>{ROTULO_ESTADO[estado]}</span>
              <p>{r.descricao}</p>
              {r.erroSincronizacao && (
                <small style={{ color: 'var(--color-erro)' }}>{r.erroSincronizacao}</small>
              )}
              <br />
              <small>{new Date(r.criadoEm).toLocaleString('pt-PT')}</small>
            </li>
          );
        })}

        {relatosRemotos.map((r) => {
          const estado = estadoDeRelatoRemoto(r);
          return (
            <li key={r.id} style={{ borderBottom: '1px solid #eee', padding: '12px 0' }}>
              <strong>{r.tipo}</strong> —{' '}
              <span style={{ color: COR_ESTADO[estado] }}>{ROTULO_ESTADO[estado]}</span>
              <p>{r.descricao}</p>
              <small>{new Date(r.criado_em).toLocaleString('pt-PT')}</small>
            </li>
          );
        })}

        {!aCarregar && pendentesOuComErro.length === 0 && relatosRemotos.length === 0 && (
          <p>Ainda não tem relatos enviados.</p>
        )}
      </ul>
    </div>
  );
}


export function ManualPage() {
  const itens = [
    'Como usar a IA: faça perguntas claras sobre cultura, clima, solo, pragas ou ações a tomar.',
    'Como fazer perguntas: escreva a dúvida em português simples e, se possível, diga a cultura e a zona.',
    'Como relatar problemas: descreva o que viu, a cultura afetada, a localização e, se puder, envie fotografias.',
    'Como enviar fotografias: anexe a imagem na conversa ou no formulário de relato quando a conta estiver ativa.',
    'Como falar com técnicos: envie a sua dúvida ou encaminhe uma resposta da IA para apoio técnico humano.',
    'Como funciona o offline: o aplicativo guarda informação no dispositivo para consulta e sincronização posterior.',
    'Como sincronizar: quando a rede voltar, o sistema tenta enviar os dados pendentes automaticamente.',
    'Como criar conta: depois de escolher o país, pode criar a sua conta e completar o perfil.',
    'Como escolher o país: vá a Definições e use “Alterar país” para ajustar a sua preferência local.',
  ];

  return (
    <div style={{ maxWidth: 700, margin: '0 auto', padding: 20, display: 'flex', flexDirection: 'column', gap: 18 }}>
      <header>
        <p style={{ margin: 0, fontSize: '0.8rem', letterSpacing: 1.2, textTransform: 'uppercase', color: '#49694f' }}>
          AgroLink Caop
        </p>
        <h1 style={{ margin: '8px 0 0', fontSize: '2rem' }}>Como usar o AgroLink</h1>
      </header>

      <section style={{ background: '#fff', border: '1px solid #e6eedf', borderRadius: 16, padding: 16 }}>
        <p style={{ marginTop: 0, color: '#4d5d50', lineHeight: 1.6 }}>
          Este guia foi pensado para agricultores, técnicos e visitantes. Use linguagem simples e a sua conta pode ajudar a guardar melhor o seu perfil.
        </p>
        <ol style={{ margin: 0, paddingLeft: 18, display: 'grid', gap: 10, lineHeight: 1.6 }}>
          {itens.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ol>
      </section>

      <section style={{ background: '#edf7ed', border: '1px solid #dbeedc', borderRadius: 16, padding: 16 }}>
        <h2 style={{ marginTop: 0 }}>Dicas rápidas</h2>
        <ul style={{ margin: 0, paddingLeft: 18, display: 'grid', gap: 8 }}>
          <li>Comece sempre por escolher o país correto.</li>
          <li>Use frases curtas e claras.</li>
          <li>Se a dúvida for importante ou a planta estiver muito afetada, fale com um técnico.</li>
        </ul>
      </section>
    </div>
  );
}

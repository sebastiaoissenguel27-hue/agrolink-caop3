import { apiGet, apiPost, apiPatch, apiDelete } from '@/shared/lib/apiClient';
import { dbLocal } from '@/offline/db';
import type { NoticiaRow, NoticiaInsert, NoticiaFonteInsert, NoticiaFonteRow, NoticiaSyncLogRow } from '@/shared/types/database.types';
export async function listarNoticias(filtros:{pesquisa?:string;categoria?:string}={}):Promise<NoticiaRow[]>{if(!navigator.onLine){const c=await dbLocal.noticiasCache.toArray();return c.filter(n=>(!filtros.categoria||n.categoria===filtros.categoria||n.categoria_ia===filtros.categoria)&&(!filtros.pesquisa||n.titulo.toLowerCase().includes(filtros.pesquisa.toLowerCase())||(n.resumo??'').toLowerCase().includes(filtros.pesquisa.toLowerCase())));}const q=new URLSearchParams();if(filtros.pesquisa)q.set('pesquisa',filtros.pesquisa);if(filtros.categoria)q.set('categoria',filtros.categoria);const data=await apiGet<NoticiaRow[]>(`/api/data/noticias?order=publicado_em&limit=500&${q}`);if(!filtros.pesquisa&&!filtros.categoria)dbLocal.noticiasCache.bulkPut(data);return data;}
export async function criarNoticia(n:NoticiaInsert){await apiPost('/api/data/noticias',n);}
export async function apagarNoticia(id:string){await apiDelete(`/api/data/noticias?id=${encodeURIComponent(id)}`);}
export async function listarFontesNoticias():Promise<NoticiaFonteRow[]>{return apiGet('/api/data/noticias_fontes?order=nome&asc=1&limit=500');}
export async function criarFonteNoticia(f:NoticiaFonteInsert){await apiPost('/api/data/noticias_fontes',f);}
export async function alternarFonteAtiva(id:string,ativo:boolean){await apiPatch(`/api/data/noticias_fontes?id=${encodeURIComponent(id)}`,{ativo});}
export async function atualizarUrlFonte(id:string,url_rss:string){await apiPatch(`/api/data/noticias_fontes?id=${encodeURIComponent(id)}`,{url_rss});}
export async function apagarFonteNoticia(id:string){await apiDelete(`/api/data/noticias_fontes?id=${encodeURIComponent(id)}`);}
export interface ResultadoSyncNoticias{fontes_processadas:number;inseridas:number;ignoradas:number;erros:string[];}
export async function sincronizarNoticiasAgora():Promise<ResultadoSyncNoticias>{return apiPost('/api/admin/sync-noticias');}
export async function listarSyncLogs():Promise<NoticiaSyncLogRow[]>{return apiGet('/api/data/noticias_sync_logs?limit=50');}

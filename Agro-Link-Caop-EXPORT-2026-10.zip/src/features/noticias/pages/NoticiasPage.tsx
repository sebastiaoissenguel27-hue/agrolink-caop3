
import { useEffect, useState } from 'react';
import { listarNoticias, sincronizarNoticiasAgora } from '@/features/noticias/api/noticiasService';
import { useAuth } from '@/features/auth/context/AuthContext';
import type { NoticiaRow, CategoriaNoticia } from '@/shared/types/database.types';

const CATEGORIAS: CategoriaNoticia[] = [
  'Culturas', 'Pecuária', 'Clima', 'Mercados', 'Tecnologia',
  'Investigação', 'Políticas Públicas', 'Pragas e Doenças', 'Formação', 'Ambiente',
];

export function NoticiasPage() {
  const { perfil } = useAuth();
  const [noticias, setNoticias] = useState<NoticiaRow[]>([]);
  const [pesquisa, setPesquisa] = useState('');
  const [categoria, setCategoria] = useState('');
  const [aCarregar, setACarregar] = useState(true);
  const [erro, setErro] = useState('');
  const [mensagem, setMensagem] = useState('');
  const [aSincronizar, setASincronizar] = useState(false);

  async function carregar() {
    setACarregar(true);
    setErro('');
    try {
      setNoticias(await listarNoticias({ pesquisa: pesquisa || undefined, categoria: categoria || undefined }));
    } catch (error) {
      setErro(error instanceof Error ? error.message : 'Não foi possível carregar as notícias.');
    } finally {
      setACarregar(false);
    }
  }

  async function sincronizar() {
    setASincronizar(true); setErro(''); setMensagem('');
    try {
      const result = await sincronizarNoticiasAgora();
      setMensagem(`${result.inseridas} novas, ${result.ignoradas} repetidas, ${result.erros.length} fontes com erro.`);
      await carregar();
    } catch (error) { setErro(error instanceof Error ? error.message : 'Não foi possível sincronizar as fontes.'); }
    finally { setASincronizar(false); }
  }

  useEffect(() => {
    const t = setTimeout(carregar, 300); // debounce da pesquisa
    return () => clearTimeout(t);
  }, [pesquisa, categoria]);

  return (
    <div style={{ maxWidth: 720, margin: '0 auto' }}>
      <h1>Notícias agrícolas</h1>
      <p style={{ fontSize: '0.8rem', color: 'var(--color-terra)' }}>
        Só notícias relacionadas com agricultura, pecuária, pescas, florestas, ambiente,
        clima e mercados agrícolas — o resto é filtrado automaticamente na sincronização.
      </p>
      {['admin','admin_chefe'].includes(perfil?.papel || '') && <button type="button" disabled={aSincronizar} onClick={() => void sincronizar()}>{aSincronizar ? 'A sincronizar…' : 'Sincronizar fontes'}</button>}
      {erro && <p role="alert">{erro}</p>}
      {mensagem && <p role="status">{mensagem}</p>}
      {!navigator.onLine && <p>Está offline — a mostrar notícias guardadas no dispositivo.</p>}

      <div style={{ display: 'flex', gap: 8, marginBottom: 16, flexWrap: 'wrap' }}>
        <input
          placeholder="Pesquisar…"
          value={pesquisa}
          onChange={(e) => setPesquisa(e.target.value)}
        />
        <select value={categoria} onChange={(e) => setCategoria(e.target.value)}>
          <option value="">Todas as categorias</option>
          {CATEGORIAS.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
      </div>

      {aCarregar && <p>A carregar…</p>}
      {!aCarregar && noticias.length === 0 && <p>Sem notícias para mostrar.</p>}

      {noticias.map((n) => (
        <article key={n.id} style={{ borderBottom: '1px solid #eee', padding: '16px 0' }}>
          {n.imagem_url && (
            <img src={n.imagem_url} alt={n.titulo} style={{ maxWidth: '100%', borderRadius: 8 }} />
          )}
          <h2 style={{ marginBottom: 4 }}>{n.url_original ? <a href={n.url_original} target="_blank" rel="noreferrer">{n.titulo}</a> : n.titulo}</h2>
          <small>
            {(n.categoria_ia ?? n.categoria) ? `${n.categoria_ia ?? n.categoria} · ` : ''}
            {n.pais ? `${n.pais} · ` : ''}
            {new Date(n.publicado_em).toLocaleDateString('pt-PT')}
          </small>
          <p>{n.resumo ?? n.conteudo.slice(0, 200)}</p>
        </article>
      ))}
    </div>
  );
}

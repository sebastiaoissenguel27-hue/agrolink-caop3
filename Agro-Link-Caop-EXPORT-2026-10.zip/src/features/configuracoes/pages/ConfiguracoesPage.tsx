
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useLiveQuery } from 'dexie-react-hooks';
import { obterPreferencias, atualizarPreferencias } from '@/features/configuracoes/api/preferenciasService';
import { useIdioma, IDIOMAS_DISPONIVEIS } from '@/shared/i18n/LanguageContext';
import { dbLocal } from '@/offline/db';
import { useAuth } from '@/features/auth/context/AuthContext';
import type { PreferenciasUtilizadorRow } from '@/shared/types/database.types';

const VALORES_PADRAO: Omit<PreferenciasUtilizadorRow, 'utilizador_id' | 'atualizado_em' | 'idioma'> = {
  notif_respostas_relato: true,
  notif_noticias: true,
  notif_alertas: true,
  notif_novos_cursos: true,
  notif_progresso_academia: true,
  notif_calendario_agricola: true,
};

export function ConfiguracoesPage() {
  const { perfil } = useAuth();
  const { idioma, traducaoDisponivel, mudarIdioma } = useIdioma();
  const [preferencias, setPreferencias] = useState(VALORES_PADRAO);
  const [aCarregar, setACarregar] = useState(true);
  const [aGuardar, setAGuardar] = useState(false);
  const [aLimparCache, setALimparCache] = useState(false);
  const [mensagem, setMensagem] = useState<string | null>(null);

  const pendentesSync =
    useLiveQuery(() => perfil ? dbLocal.relatosPendentes.toCollection().filter((item) => !item.sincronizado && item.autorId === perfil.id).count() : 0, [perfil?.id]) ?? 0;
  const noticiasEmCache = useLiveQuery(() => dbLocal.noticiasCache.count(), []) ?? 0;
  const alertasEmCache = useLiveQuery(() => dbLocal.alertasCache.count(), []) ?? 0;

  useEffect(() => {
    if (!perfil) { setACarregar(false); return; }
    obterPreferencias(perfil.id)
      .then((p) => {
        if (p) setPreferencias(p);
      })
      .finally(() => setACarregar(false));
  }, [perfil?.id]);

  async function alternar(campo: keyof typeof VALORES_PADRAO) {
    const novoValor = !preferencias[campo];
    setPreferencias((prev) => ({ ...prev, [campo]: novoValor }));
    setAGuardar(true);
    setMensagem(null);
    try {
      if (!perfil) throw new Error('Sessão necessária.');
      await atualizarPreferencias(perfil.id, { [campo]: novoValor });
    } catch {
      // Reverte visualmente se a gravação falhar (ex: sem rede).
      setPreferencias((prev) => ({ ...prev, [campo]: !novoValor }));
      setMensagem('Não foi possível guardar agora — tentando fica registada localmente até haver rede.');
    } finally {
      setAGuardar(false);
    }
  }

  async function limparCacheLeitura() {
    setALimparCache(true);
    try {
      await Promise.all([
        dbLocal.noticiasCache.clear(),
        dbLocal.alertasCache.clear(),
        dbLocal.iaHistoricoCache.clear(),
      ]);
      setMensagem('Dados guardados no dispositivo (notícias, alertas, histórico da IA) foram limpos.');
    } finally {
      setALimparCache(false);
    }
  }

  if (aCarregar) return <p>A carregar…</p>;

  return (
    <div style={{ maxWidth: 520, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 24 }}>
      <h1>Configurações</h1>

      {mensagem && (
        <div role="status" aria-live="polite">
          {mensagem}
        </div>
      )}

      <section>
        <h2>Idioma</h2>
        <select value={idioma} onChange={(e) => mudarIdioma(e.target.value as typeof idioma)}>
          {IDIOMAS_DISPONIVEIS.map((i) => (
            <option key={i.valor} value={i.valor}>
              {i.nome}
              {!i.traduzido ? ' (tradução a caminho)' : ''}
            </option>
          ))}
        </select>
        {!traducaoDisponivel && (
          <p style={{ fontSize: '0.8rem', color: 'var(--color-terra)' }}>
            Esta língua ainda não tem tradução própria — a interface continua em português até
            estar pronta, para não mostrar traduções incorretas. A sua escolha fica guardada.
          </p>
        )}
      </section>

      <section>
        <h2>Notificações</h2>
        <p style={{ fontSize: '0.85rem', color: 'var(--color-terra)' }}>
          Escolha que tipos de notificação quer receber. Notificações sobre o estado da sua
          própria conta (ativação, bloqueio, verificação) são sempre enviadas, por segurança.
        </p>
        <label style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <input
            type="checkbox"
            checked={preferencias.notif_respostas_relato}
            onChange={() => alternar('notif_respostas_relato')}
            disabled={aGuardar}
          />
          Respostas dos técnicos aos meus relatos
        </label>
        <label style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <input
            type="checkbox"
            checked={preferencias.notif_noticias}
            onChange={() => alternar('notif_noticias')}
            disabled={aGuardar}
          />
          Novidades sobre notícias agrícolas
        </label>
        <label style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <input
            type="checkbox"
            checked={preferencias.notif_alertas}
            onChange={() => alternar('notif_alertas')}
            disabled={aGuardar}
          />
          Novos alertas na minha zona
        </label>
        <label style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <input
            type="checkbox"
            checked={preferencias.notif_novos_cursos}
            onChange={() => alternar('notif_novos_cursos')}
            disabled={aGuardar}
          />
          Novos cursos na Academia
        </label>
        <label style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <input
            type="checkbox"
            checked={preferencias.notif_progresso_academia}
            onChange={() => alternar('notif_progresso_academia')}
            disabled={aGuardar}
          />
          Lembretes para continuar cursos
        </label>
        <label style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <input
            type="checkbox"
            checked={preferencias.notif_calendario_agricola}
            onChange={() => alternar('notif_calendario_agricola')}
            disabled={aGuardar}
          />
          Lembretes do calendário agrícola
        </label>
      </section>

      <section>
        <h2>Dados guardados neste dispositivo</h2>
        <p style={{ fontSize: '0.85rem' }}>
          {noticiasEmCache} notícia(s) e {alertasEmCache} alerta(s) em cache para consulta offline.
        </p>
        {pendentesSync > 0 ? (
          <p style={{ fontSize: '0.85rem', color: 'var(--color-erro)' }}>
            Tem {pendentesSync} relato(s) ainda por sincronizar — estes <strong>nunca</strong> são
            apagados por este botão, só o cache de leitura (notícias/alertas/histórico da IA).
          </p>
        ) : null}
        <button onClick={limparCacheLeitura} disabled={aLimparCache}>
          {aLimparCache ? 'A limpar…' : 'Limpar dados em cache'}
        </button>
      </section>

      <section>
        <h2>Conta</h2>
        <p>
          <Link to="/perfil">Editar dados do perfil</Link>
        </p>
        <p>
          <Link to="/pais">Alterar país</Link>
        </p>
        <p>
          <Link to="/esqueci-password">Alterar palavra-passe</Link>
        </p>
      </section>

      <section>
        <h2>Sobre</h2>
        <p style={{ fontSize: '0.85rem', color: 'var(--color-terra)' }}>AgroLink Caop — versão 2.0</p>
      </section>
    </div>
  );
}

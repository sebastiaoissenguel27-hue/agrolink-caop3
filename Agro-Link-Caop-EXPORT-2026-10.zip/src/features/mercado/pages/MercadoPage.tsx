import { useEffect, useState } from 'react';
import { useAuth } from '@/features/auth/context/AuthContext';
import { PageContainer } from '@/shared/components/PageContainer';
import { Button } from '@/shared/components/Button';
import { ApiError } from '@/shared/lib/apiClient';
import { atualizarProdutoMercado, criarProdutoMercado, listarProdutosMercado, removerProdutoMercado, type ProdutoMercado } from '@/features/mercado/api/mercadoService';

export function MercadoPage() {
  const { perfil } = useAuth();
  const [produtos, setProdutos] = useState<ProdutoMercado[]>([]);
  const [aCarregar, setACarregar] = useState(true);
  const [erro, setErro] = useState('');
  const [mensagem, setMensagem] = useState('');
  const [nome, setNome] = useState('');
  const [categoria, setCategoria] = useState('');
  const [preco, setPreco] = useState('');
  const [unidade, setUnidade] = useState('kg');
  const [quantidade, setQuantidade] = useState('');

  async function carregar() {
    setACarregar(true);
    setErro('');
    try { setProdutos(await listarProdutosMercado()); }
    catch (error) { setErro(error instanceof ApiError && error.status === 403 ? 'O seu perfil não tem acesso ao mercado.' : 'Não foi possível carregar as ofertas.'); }
    finally { setACarregar(false); }
  }

  useEffect(() => { void carregar(); }, []);

  async function publicar(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setErro('');
    try {
      await criarProdutoMercado({ nome, categoria, preco: Number(preco), unidade, quantidade_disponivel: Number(quantidade), provincia: perfil?.provincia || undefined });
      setNome(''); setCategoria(''); setPreco(''); setQuantidade('');
      setMensagem('Oferta publicada.');
      await carregar();
    } catch (error) { setErro(error instanceof Error ? error.message : 'Não foi possível publicar a oferta.'); }
  }

  async function mudarDisponibilidade(produto: ProdutoMercado) {
    try { await atualizarProdutoMercado(produto.id, { ativo: !produto.ativo }); await carregar(); }
    catch (error) { setErro(error instanceof Error ? error.message : 'Não foi possível alterar a oferta.'); }
  }

  async function remover(id: string) {
    try { await removerProdutoMercado(id); await carregar(); }
    catch (error) { setErro(error instanceof Error ? error.message : 'Não foi possível remover a oferta.'); }
  }

  const podePublicar = perfil?.papel === 'utilizador' && perfil.tipo_perfil === 'agricultor';
  return (
    <PageContainer className="al-dashboard">
      <header>
        <h1>Mercado agrícola</h1>
        <p>Ofertas publicadas por agricultores do AgroLink.</p>
      </header>
      {erro && <p role="alert">{erro}</p>}
      {mensagem && <p role="status">{mensagem}</p>}
      {podePublicar && <section>
        <h2>Publicar produto</h2>
        <form onSubmit={publicar} style={{ display: 'grid', gap: 12, maxWidth: 520 }}>
          <label>Produto<input required maxLength={160} value={nome} onChange={(event) => setNome(event.target.value)} /></label>
          <label>Categoria<input maxLength={80} value={categoria} onChange={(event) => setCategoria(event.target.value)} /></label>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))', gap: 12 }}>
            <label>Preço<input required type="number" min="0" step="0.01" value={preco} onChange={(event) => setPreco(event.target.value)} /></label>
            <label>Unidade<input required maxLength={40} value={unidade} onChange={(event) => setUnidade(event.target.value)} /></label>
            <label>Quantidade<input required type="number" min="0.01" step="0.01" value={quantidade} onChange={(event) => setQuantidade(event.target.value)} /></label>
          </div>
          <Button type="submit">Publicar oferta</Button>
        </form>
      </section>}
      <section>
        <h2>Ofertas</h2>
        {aCarregar && <p>A carregar…</p>}
        {!aCarregar && produtos.length === 0 && <p>Não há ofertas disponíveis.</p>}
        {produtos.map((produto) => <article key={produto.id} style={{ borderBottom: '1px solid #d8ded5', padding: '14px 0' }}>
          <h3>{produto.nome}</h3>
          <p>{produto.categoria || 'Produto agrícola'} · {produto.preco.toLocaleString('pt-PT')} / {produto.unidade} · {produto.quantidade_disponivel} {produto.unidade} disponíveis</p>
          <small>{produto.provincia || 'Província não indicada'} · {produto.ativo ? 'Disponível' : 'Pausada'}</small>
          {produto.vendedor_id === perfil?.id && <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
            <Button variant="secondary" type="button" onClick={() => void mudarDisponibilidade(produto)}>{produto.ativo ? 'Pausar oferta' : 'Reativar oferta'}</Button>
            <Button variant="danger" type="button" onClick={() => void remover(produto.id)}>Remover</Button>
          </div>}
        </article>)}
      </section>
    </PageContainer>
  );
}
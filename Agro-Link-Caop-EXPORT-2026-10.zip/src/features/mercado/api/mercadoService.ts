import { apiDelete, apiGet, apiPatch, apiPost } from '@/shared/lib/apiClient';

export interface ProdutoMercado {
  id: string;
  vendedor_id: string;
  nome: string;
  categoria: string | null;
  preco: number;
  unidade: string;
  quantidade_disponivel: number;
  provincia: string | null;
  ativo: boolean;
  criado_em: string;
}

export interface NovoProdutoMercado {
  nome: string;
  categoria?: string;
  preco: number;
  unidade: string;
  quantidade_disponivel: number;
  provincia?: string;
}

export function listarProdutosMercado() {
  return apiGet<ProdutoMercado[]>('/api/data/mercado_produtos?order=criado_em&limit=200');
}

export function criarProdutoMercado(produto: NovoProdutoMercado) {
  return apiPost<ProdutoMercado>('/api/data/mercado_produtos', produto);
}

export function atualizarProdutoMercado(id: string, changes: Partial<Pick<ProdutoMercado, 'preco' | 'quantidade_disponivel' | 'ativo'>>) {
  return apiPatch<ProdutoMercado>(`/api/data/mercado_produtos?id=${encodeURIComponent(id)}`, changes);
}

export function removerProdutoMercado(id: string) {
  return apiDelete(`/api/data/mercado_produtos?id=${encodeURIComponent(id)}`);
}
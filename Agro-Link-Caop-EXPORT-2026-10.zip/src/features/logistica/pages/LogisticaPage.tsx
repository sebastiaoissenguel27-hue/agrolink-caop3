import { useEffect, useState, type FormEvent } from 'react';
import { useAuth } from '@/features/auth/context/AuthContext';
import { PageContainer } from '@/shared/components/PageContainer';
import { Button } from '@/shared/components/Button';
import { ApiError } from '@/shared/lib/apiClient';
import { atualizarPedidoLogistico, criarPedidoLogistico, definirVerificacaoTransportador, guardarPerfilTransportador, listarPedidosLogisticos, listarPerfisTransportadores, obterPerfilTransportador, type PedidoLogistico, type PerfilTransportador } from '@/features/logistica/api/logisticaService';

export function LogisticaPage() {
  const { perfil } = useAuth();
  const [pedidos, setPedidos] = useState<PedidoLogistico[]>([]);
  const [perfilTransporte, setPerfilTransporte] = useState<PerfilTransportador | null>(null);
  const [transportadores, setTransportadores] = useState<PerfilTransportador[]>([]);
  const [origem, setOrigem] = useState(perfil?.provincia || '');
  const [destino, setDestino] = useState('');
  const [produto, setProduto] = useState('');
  const [quantidade, setQuantidade] = useState('');
  const [matricula, setMatricula] = useState('');
  const [veiculo, setVeiculo] = useState('');
  const [capacidade, setCapacidade] = useState('');
  const [erro, setErro] = useState('');
  const [aCarregar, setACarregar] = useState(true);
  const eTransportador = perfilTransporte?.estado_verificacao === 'aprovado';
  const eAgricultor = perfil?.papel === 'utilizador' && perfil.tipo_perfil === 'agricultor';
  const eAdmin = perfil?.papel === 'admin_chefe' || (perfil?.papel === 'admin' && perfil.nivel_admin !== 'auditor');

  async function carregar() {
    setACarregar(true); setErro('');
    try {
      const [carriers, carrierRows] = await Promise.all([perfil?.papel === 'utilizador' ? obterPerfilTransportador() : Promise.resolve([]), eAdmin ? listarPerfisTransportadores() : Promise.resolve([])]);
      const carrierProfile = carriers[0] || null;
      const mayListOrders = eAgricultor || eAdmin || carrierProfile?.estado_verificacao === 'aprovado';
      const rows = mayListOrders ? await listarPedidosLogisticos() : [];
      setPedidos(rows);
      setPerfilTransporte(carrierProfile);
      setTransportadores(carrierRows);
      if (carriers[0]) { setMatricula(carriers[0].matricula || ''); setVeiculo(carriers[0].tipo_veiculo || ''); setCapacidade(String(carriers[0].capacidade_kg || '')); }
    } catch (error) { setErro(error instanceof ApiError && error.status === 403 ? 'A área logística está disponível para agricultores, transportadores e administração.' : 'Não foi possível carregar a logística.'); }
    finally { setACarregar(false); }
  }

  useEffect(() => { void carregar(); }, [perfil?.papel, perfil?.tipo_perfil]);

  async function submeterPedido(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    try { await criarPedidoLogistico({ origem_provincia: origem, destino_provincia: destino, produto_descricao: produto, quantidade_kg: Number(quantidade) }); setDestino(''); setProduto(''); setQuantidade(''); await carregar(); }
    catch (error) { setErro(error instanceof Error ? error.message : 'Não foi possível criar o pedido.'); }
  }

  async function guardarPerfil(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    try { await guardarPerfilTransportador({ matricula, tipo_veiculo: veiculo, capacidade_kg: Number(capacidade) }); await carregar(); }
    catch (error) { setErro(error instanceof Error ? error.message : 'Não foi possível guardar o perfil do transportador.'); }
  }

  async function transicionar(pedido: PedidoLogistico, estado?: string) {
    try { await atualizarPedidoLogistico(pedido.id, estado); await carregar(); }
    catch (error) { setErro(error instanceof Error ? error.message : 'Não foi possível atualizar o transporte.'); }
  }

  async function verificarTransportador(id: string, estado: 'aprovado' | 'rejeitado') {
    try { await definirVerificacaoTransportador(id, estado); await carregar(); }
    catch (error) { setErro(error instanceof Error ? error.message : 'Não foi possível rever o perfil do transportador.'); }
  }

  return (
    <PageContainer className="al-dashboard">
      <header><h1>Logística agrícola</h1><p>Pedidos de transporte e disponibilidade de transportadores.</p></header>
      {erro && <p role="alert">{erro}</p>}
      {eAdmin && <section>
        <h2>Verificação de transportadores</h2>
        {transportadores.length === 0 && <p>Não há perfis de transporte registados.</p>}
        {transportadores.map((carrier) => <article key={carrier.utilizador_id} style={{ borderBottom: '1px solid #d8ded5', padding: '12px 0' }}>
          <strong>{carrier.matricula || carrier.utilizador_id}</strong> · {carrier.tipo_veiculo || 'Veículo não indicado'} · {carrier.capacidade_kg || '—'} kg · {carrier.estado_verificacao}
          {carrier.estado_verificacao !== 'aprovado' && <Button type="button" onClick={() => void verificarTransportador(carrier.utilizador_id, 'aprovado')}>Aprovar</Button>}
          {carrier.estado_verificacao !== 'rejeitado' && <Button variant="secondary" type="button" onClick={() => void verificarTransportador(carrier.utilizador_id, 'rejeitado')}>Rejeitar</Button>}
        </article>)}
      </section>}
      {eAgricultor && <section>
        <h2>Solicitar transporte</h2>
        <form onSubmit={submeterPedido} style={{ display: 'grid', gap: 12, maxWidth: 620 }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 12 }}>
            <label>Origem<input required maxLength={100} value={origem} onChange={(event) => setOrigem(event.target.value)} /></label>
            <label>Destino<input required maxLength={100} value={destino} onChange={(event) => setDestino(event.target.value)} /></label>
          </div>
          <label>Produto/carga<input required maxLength={500} value={produto} onChange={(event) => setProduto(event.target.value)} /></label>
          <label>Quantidade (kg)<input required type="number" min="0.01" step="0.01" value={quantidade} onChange={(event) => setQuantidade(event.target.value)} /></label>
          <Button type="submit">Criar pedido</Button>
        </form>
      </section>}
      {(eAgricultor || eTransportador) && <section>
        <h2>Perfil de transporte</h2>
        <form onSubmit={guardarPerfil} style={{ display: 'grid', gap: 12, maxWidth: 620 }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 12 }}>
            <label>Matrícula<input required maxLength={40} value={matricula} onChange={(event) => setMatricula(event.target.value)} /></label>
            <label>Veículo<input required maxLength={80} value={veiculo} onChange={(event) => setVeiculo(event.target.value)} /></label>
            <label>Capacidade (kg)<input required type="number" min="1" step="1" value={capacidade} onChange={(event) => setCapacidade(event.target.value)} /></label>
          </div>
          <Button type="submit">{perfilTransporte ? 'Atualizar perfil' : 'Registar transportador'}</Button>
        </form>
      </section>}
      <section>
        <h2>{eTransportador ? 'Pedidos disponíveis e atribuídos' : 'Os meus pedidos'}</h2>
        {aCarregar && <p>A carregar…</p>}
        {!aCarregar && pedidos.length === 0 && <p>Não há pedidos de transporte.</p>}
        {pedidos.map((pedido) => <article key={pedido.id} style={{ borderBottom: '1px solid #d8ded5', padding: '14px 0' }}>
          <h3>{pedido.origem_provincia} → {pedido.destino_provincia}</h3>
          <p>{pedido.produto_descricao} · {pedido.quantidade_kg} kg</p>
          <small>Estado: {pedido.status.replace(/_/g, ' ')} · {new Date(pedido.criado_em).toLocaleDateString('pt-PT')}</small>
          {eAgricultor && pedido.status === 'pedido' && <div><Button variant="secondary" type="button" onClick={() => void transicionar(pedido)}>Cancelar pedido</Button></div>}
          {eTransportador && perfilTransporte && pedido.status === 'pedido' && pedido.solicitante_id !== perfil?.id && <div><Button type="button" onClick={() => void transicionar(pedido, 'aceite')}>Aceitar pedido</Button></div>}
          {eTransportador && pedido.transportadora_id && pedido.status === 'aceite' && <div><Button type="button" onClick={() => void transicionar(pedido, 'em_transito')}>Marcar em trânsito</Button></div>}
          {eTransportador && pedido.transportadora_id && pedido.status === 'em_transito' && <div><Button type="button" onClick={() => void transicionar(pedido, 'entregue')}>Marcar entregue</Button></div>}
        </article>)}
      </section>
    </PageContainer>
  );
}
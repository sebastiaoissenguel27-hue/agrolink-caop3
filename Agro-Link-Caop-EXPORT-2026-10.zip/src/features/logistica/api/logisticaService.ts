import { apiGet, apiPatch, apiPost } from '@/shared/lib/apiClient';

export interface PedidoLogistico {
  id: string;
  solicitante_id: string;
  transportadora_id: string | null;
  origem_provincia: string | null;
  destino_provincia: string | null;
  produto_descricao: string;
  quantidade_kg: number;
  status: string;
  criado_em: string;
}

export interface PerfilTransportador {
  utilizador_id: string;
  matricula: string | null;
  tipo_veiculo: string | null;
  capacidade_kg: number | null;
  estado_verificacao: string;
}

export function listarPedidosLogisticos() {
  return apiGet<PedidoLogistico[]>('/api/data/logistica_pedidos?order=criado_em&limit=200');
}

export function criarPedidoLogistico(pedido: Pick<PedidoLogistico, 'origem_provincia' | 'destino_provincia' | 'produto_descricao' | 'quantidade_kg'>) {
  return apiPost<PedidoLogistico>('/api/data/logistica_pedidos', pedido);
}

export function atualizarPedidoLogistico(id: string, status?: string) {
  return apiPatch<PedidoLogistico>(`/api/data/logistica_pedidos?id=${encodeURIComponent(id)}`, status ? { status } : {});
}

export function obterPerfilTransportador() {
  return apiGet<PerfilTransportador[]>('/api/data/transportadores?limit=1');
}

export function listarPerfisTransportadores() {
  return apiGet<PerfilTransportador[]>('/api/data/transportadores?limit=200');
}

export function guardarPerfilTransportador(profile: Pick<PerfilTransportador, 'matricula' | 'tipo_veiculo' | 'capacidade_kg'>) {
  return apiPost<PerfilTransportador>('/api/data/transportadores', profile);
}

export function definirVerificacaoTransportador(utilizador_id: string, estado_verificacao: 'aprovado' | 'rejeitado') {
  return apiPost<PerfilTransportador>('/api/data/transportadores', { utilizador_id, estado_verificacao });
}
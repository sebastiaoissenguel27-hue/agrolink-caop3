
import { useState, type FormEvent } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { login, mensagemSeguraDeRegisto, registar } from '@/features/auth/api/authService';
import { AuthLayout } from '@/features/auth/components/AuthLayout';
import type { TipoPerfilProfissional } from '@/shared/types/database.types';

export function RegisterPage() {
  const navigate = useNavigate();
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [mostrarPassword, setMostrarPassword] = useState(false);
  const [tipoPerfil, setTipoPerfil] = useState<TipoPerfilProfissional>('agricultor');
  const [provincia, setProvincia] = useState('');
  const [municipio, setMunicipio] = useState('');
  const [comuna, setComuna] = useState('');
  const [erro, setErro] = useState<string | null>(null);
  const [sucesso, setSucesso] = useState<string | null>(null);
  const [aEnviar, setAEnviar] = useState(false);

  async function submeter(e: FormEvent) {
    e.preventDefault();
    setErro(null);
    setSucesso(null);
    setAEnviar(true);
    try {
      const resultado = await registar({ nome, email, password, tipo_perfil: tipoPerfil, provincia, municipio, comuna });
      if (resultado.admin_chefe) {
        await login({ email, password });
        navigate('/');
        return;
      }
      setSucesso('Conta criada. Aguarda aprovação antes de aceder às funcionalidades protegidas.');
    } catch (error) {
      setErro(mensagemSeguraDeRegisto(error));
    } finally {
      setAEnviar(false);
    }
  }

  return (
    <AuthLayout titulo="Criar conta">
      {erro && <div className="auth-erro" role="alert">{erro}</div>}
      {sucesso && (
        <div
          role="status"
          style={{
            marginBottom: 16,
            padding: '10px 12px',
            borderRadius: 8,
            background: '#edf7ed',
            border: '1px solid #cde9d3',
            color: '#1f4e2d',
          }}
        >
          {sucesso}
        </div>
      )}
      <form onSubmit={submeter}>
        <div className="auth-campo">
          <label htmlFor="nome">Nome completo</label>
          <input id="nome" required value={nome} onChange={(e) => setNome(e.target.value)} />
        </div>
        <div className="auth-campo">
          <label htmlFor="email">Email</label>
          <input
            id="email"
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            autoComplete="email"
          />
        </div>
        <div className="auth-campo">
          <label htmlFor="password">Palavra-passe</label>
          <div className="auth-password-wrap">
            <input
              id="password"
              type={mostrarPassword ? 'text' : 'password'}
              required
              minLength={8}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="new-password"
            />
            <button
              className="auth-password-toggle"
              type="button"
              onClick={() => setMostrarPassword((visivel) => !visivel)}
              aria-label={mostrarPassword ? 'Ocultar palavra-passe' : 'Mostrar palavra-passe'}
              title={mostrarPassword ? 'Ocultar palavra-passe' : 'Mostrar palavra-passe'}
            >
              {mostrarPassword ? '◉' : '◌'}
            </button>
          </div>
        </div>
        <div className="auth-campo">
          <label htmlFor="tipo-perfil">Sou</label>
          <select
            id="tipo-perfil"
            value={tipoPerfil}
            onChange={(e) => setTipoPerfil(e.target.value as TipoPerfilProfissional)}
          >
            <option value="agricultor">Agricultor</option>
            <option value="tecnico">Técnico</option>
            <option value="administrador">Administrador</option>
          </select>
        </div>
        <div className="auth-campo">
          <label htmlFor="provincia">Província</label>
          <input
            id="provincia"
            value={provincia}
            onChange={(e) => setProvincia(e.target.value)}
            placeholder="Ex: Luanda"
          />
        </div>
        <div className="auth-campo">
          <label htmlFor="municipio">Município</label>
          <input
            id="municipio"
            value={municipio}
            onChange={(e) => setMunicipio(e.target.value)}
            placeholder="Ex: Viana"
          />
        </div>
        <div className="auth-campo">
          <label htmlFor="comuna">Comuna</label>
          <input
            id="comuna"
            value={comuna}
            onChange={(e) => setComuna(e.target.value)}
            placeholder="Ex: Vila de Viana"
          />
        </div>
        <button className="auth-botao" type="submit" disabled={aEnviar}>
          {aEnviar ? 'A criar conta…' : 'Criar conta'}
        </button>
      </form>
      <div className="auth-rodape">
        Já tem conta? <Link to="/entrar">Entrar</Link>
      </div>
    </AuthLayout>
  );
}


import { useState, type FormEvent } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { login } from '@/features/auth/api/authService';
import { AuthLayout } from '@/features/auth/components/AuthLayout';

export function LoginPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [mostrarPassword, setMostrarPassword] = useState(false);
  const [erro, setErro] = useState<string | null>(null);
  const [aEnviar, setAEnviar] = useState(false);

  async function submeter(e: FormEvent) {
    e.preventDefault();
    setErro(null);
    setAEnviar(true);
    try {
      await login({ email, password });
      navigate('/');
    } catch (err) {
      setErro(
        err instanceof Error
          ? 'Não foi possível entrar. Verifique o email e a palavra-passe.'
          : 'Erro desconhecido.'
      );
    } finally {
      setAEnviar(false);
    }
  }

  return (
    <AuthLayout titulo="Entrar na sua conta">
      {erro && <div className="auth-erro" role="alert">{erro}</div>}
      <form onSubmit={submeter}>
        <div className="auth-campo">
          <label htmlFor="email">Email</label>
          <input
            id="email"
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            autoComplete="email"
          />
        </div>
        <div className="auth-campo">
          <label htmlFor="password">Palavra-passe</label>
          <div className="auth-password-wrap">
            <input
              id="password"
              type={mostrarPassword ? 'text' : 'password'}
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
            />
            <button
              className="auth-password-toggle"
              type="button"
              onClick={() => setMostrarPassword((visivel) => !visivel)}
              aria-label={mostrarPassword ? 'Ocultar palavra-passe' : 'Mostrar palavra-passe'}
              title={mostrarPassword ? 'Ocultar palavra-passe' : 'Mostrar palavra-passe'}
            >
              {mostrarPassword ? '◉' : '◌'}
            </button>
          </div>
        </div>
        <button className="auth-botao" type="submit" disabled={aEnviar}>
          {aEnviar ? 'A entrar…' : 'Entrar'}
        </button>
      </form>
      <div style={{ marginTop: 20, display: 'grid', gap: 12 }}>
        <div style={{ border: '1px solid #dce9dc', background: '#f6faf5', borderRadius: 12, padding: 12 }}>
          <strong>Área administrativa</strong>
          <p style={{ margin: '8px 0 0', fontSize: '0.9rem', color: '#4d5d50' }}>
            Acesso reservado a administradores autenticados. Se a sua conta não tiver esse papel, a sua sessão será bloqueada.
          </p>
          <Link to="/admin" style={{ display: 'inline-block', marginTop: 8, fontWeight: 700 }}>
            Entrar como administrador
          </Link>
        </div>
      </div>
      <div className="auth-rodape">
        Ainda não tem conta? <Link to="/registar">Criar conta</Link>
        <br />
        <Link to="/esqueci-password">Esqueci-me da palavra-passe</Link>
      </div>
    </AuthLayout>
  );
}

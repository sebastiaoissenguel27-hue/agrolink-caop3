
import { useState, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { redefinirPassword } from '@/features/auth/api/authService';
import { AuthLayout } from '@/features/auth/components/AuthLayout';

export function ResetPasswordPage() {
  const navigate = useNavigate();
  const [password, setPassword] = useState('');
  const [mostrarPassword, setMostrarPassword] = useState(false);
  const [erro, setErro] = useState<string | null>(null);
  const [aEnviar, setAEnviar] = useState(false);

  async function submeter(e: FormEvent) {
    e.preventDefault();
    setErro(null);
    setAEnviar(true);
    try {
      await redefinirPassword(password);
      navigate('/');
    } catch {
      setErro(
        'Não foi possível redefinir a palavra-passe. O link pode ter expirado — peça um novo.'
      );
    } finally {
      setAEnviar(false);
    }
  }

  return (
    <AuthLayout titulo="Definir nova palavra-passe">
      {erro && <div className="auth-erro" role="alert">{erro}</div>}
      <form onSubmit={submeter}>
        <div className="auth-campo">
          <label htmlFor="password">Nova palavra-passe</label>
          <div className="auth-password-wrap">
            <input
              id="password"
              type={mostrarPassword ? 'text' : 'password'}
              required
              minLength={8}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="new-password"
            />
            <button
              className="auth-password-toggle"
              type="button"
              onClick={() => setMostrarPassword((visivel) => !visivel)}
              aria-label={mostrarPassword ? 'Ocultar palavra-passe' : 'Mostrar palavra-passe'}
              title={mostrarPassword ? 'Ocultar palavra-passe' : 'Mostrar palavra-passe'}
            >
              {mostrarPassword ? '◉' : '◌'}
            </button>
          </div>
        </div>
        <button className="auth-botao" type="submit" disabled={aEnviar}>
          {aEnviar ? 'A guardar…' : 'Guardar nova palavra-passe'}
        </button>
      </form>
    </AuthLayout>
  );
}

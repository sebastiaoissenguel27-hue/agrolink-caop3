
import { useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { pedirRecuperacaoPassword } from '@/features/auth/api/authService';
import { AuthLayout } from '@/features/auth/components/AuthLayout';

export function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [enviado, setEnviado] = useState(false);
  const [erro, setErro] = useState<string | null>(null);
  const [aEnviar, setAEnviar] = useState(false);

  async function submeter(e: FormEvent) {
    e.preventDefault();
    setErro(null);
    setAEnviar(true);
    try {
      await pedirRecuperacaoPassword(email);
      setEnviado(true);
    } catch {
      setErro('Não foi possível enviar o email. Verifique o endereço.');
    } finally {
      setAEnviar(false);
    }
  }

  return (
    <AuthLayout titulo="Recuperar palavra-passe">
      {erro && <div className="auth-erro" role="alert">{erro}</div>}
      {enviado ? (
        <p>
          Se existir uma conta com esse email, enviámos um link para redefinir a palavra-passe.
          Verifique a sua caixa de entrada.
        </p>
      ) : (
        <form onSubmit={submeter}>
          <div className="auth-campo">
            <label htmlFor="email">Email</label>
            <input
              id="email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <button className="auth-botao" type="submit" disabled={aEnviar}>
            {aEnviar ? 'A enviar…' : 'Enviar link de recuperação'}
          </button>
        </form>
      )}
      <div className="auth-rodape">
        <Link to="/entrar">Voltar ao login</Link>
      </div>
    </AuthLayout>
  );
}

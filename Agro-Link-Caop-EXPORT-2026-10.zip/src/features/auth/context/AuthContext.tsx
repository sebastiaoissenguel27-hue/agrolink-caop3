import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import type { PlataformaSession } from '@/features/auth/api/authService';
import { obterPerfilAtual, obterSessao } from '@/features/auth/api/authService';
import { iniciarSyncAutomatico } from '@/offline/syncEngine';
import type { ProfileRow } from '@/shared/types/database.types';
interface AuthContextValue { sessao:PlataformaSession|null; perfil:ProfileRow|null; carregando:boolean; recarregarPerfil:()=>Promise<void>; }
const AuthContext=createContext<AuthContextValue|undefined>(undefined);
export function AuthProvider({children}:{children:ReactNode}){const[sessao,setSessao]=useState<PlataformaSession|null>(null);const[perfil,setPerfil]=useState<ProfileRow|null>(null);const[carregando,setCarregando]=useState(true);async function carregarPerfil(){const p=await obterPerfilAtual();setPerfil(p);} useEffect(()=>{const atualizar=async()=>{try{const {session,profile}=await obterSessao();setSessao(session);setPerfil(profile);}catch{setSessao(null);setPerfil(null);}}; void atualizar().finally(()=>setCarregando(false)); window.addEventListener('agrolink-auth-changed',atualizar); return()=>window.removeEventListener('agrolink-auth-changed',atualizar);},[]);useEffect(()=>{if(!sessao||!perfil)return;return iniciarSyncAutomatico(perfil.id);},[sessao?.user.id,perfil?.id]);return <AuthContext.Provider value={{sessao,perfil,carregando,recarregarPerfil:carregarPerfil}}>{children}</AuthContext.Provider>}
export function useAuth(){const ctx=useContext(AuthContext);if(!ctx)throw new Error('useAuth deve ser usado dentro de <AuthProvider>.');return ctx;}

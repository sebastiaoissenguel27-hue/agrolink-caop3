import { apiGet, apiPatch, apiPost } from '@/shared/lib/apiClient';
import type { ProfileRow, TipoPerfilProfissional } from '@/shared/types/database.types';
export interface RegistoInput { email:string; password:string; nome:string; tipo_perfil:TipoPerfilProfissional; provincia?:string; municipio?:string; comuna?:string; telefone?:string; }
export interface LoginInput { email:string; password:string; }
export interface RegistoResultado { status:'criada'|'confirmacao_pendente'; admin_chefe?:boolean; }
export interface PlataformaSession { user:{id:string; email:string}; }
export function mensagemSeguraDeRegisto(error: unknown): string { if(!(error instanceof Error)) return 'Não foi possível criar a conta. Tente novamente.'; const m=error.message.toLowerCase(); if(m.includes('já está')||m.includes('already')) return 'Este email já está registado. Tente entrar ou recuperar a palavra-passe.'; if(m.includes('password')||m.includes('palavra')) return 'A palavra-passe não cumpre os requisitos do serviço.'; return 'Não foi possível criar a conta. Tente novamente.'; }
export async function registar(input:RegistoInput):Promise<RegistoResultado>{ const tipo_perfil:TipoPerfilProfissional=['agricultor','tecnico','administrador'].includes(input.tipo_perfil)?input.tipo_perfil:'agricultor'; return apiPost('/api/auth/register',{...input,tipo_perfil}); }
export async function login(input:LoginInput){ const r=await apiPost<{session:PlataformaSession;profile:ProfileRow}>('/api/auth/login',input); window.dispatchEvent(new Event('agrolink-auth-changed')); return r; }
export async function terminarSessao(){ await apiPost('/api/auth/logout'); window.dispatchEvent(new Event('agrolink-auth-changed')); }
export function obterUrlSeguraAplicacao(){ return typeof window!=='undefined'?window.location.origin:''; }
export async function pedirRecuperacaoPassword(email:string){ return apiPost<{ok:boolean;message:string;recoveryUrl?:string}>('/api/auth/password/forgot',{email}); }
export async function redefinirPassword(novaPassword:string){ const token=new URLSearchParams(window.location.search).get('token')||''; return apiPost('/api/auth/password/reset',{token,password:novaPassword}); }
export async function obterSessao(){ return apiGet<{session:PlataformaSession|null;profile:ProfileRow|null}>('/api/auth/session'); }
export async function obterPerfilAtual():Promise<ProfileRow|null>{ try{return await apiGet<ProfileRow>('/api/profile');}catch{return null;} }
export async function atualizarPerfilProprio(dados:{nome?:string;provincia?:string|null;municipio?:string|null;comuna?:string|null;telefone?:string|null;}):Promise<ProfileRow>{return apiPatch('/api/profile',dados);}


import type { ReactNode } from 'react';
import { Logo } from '@/shared/components/Logo';
import './auth.css';

export function AuthLayout({ titulo, children }: { titulo: string; children: ReactNode }) {
  return (
    <div className="auth-shell">
      <div className="auth-card">
        <Logo size="md" className="auth-logo" />
        <h2 className="auth-subtitulo">{titulo}</h2>
        {children}
      </div>
    </div>
  );
}

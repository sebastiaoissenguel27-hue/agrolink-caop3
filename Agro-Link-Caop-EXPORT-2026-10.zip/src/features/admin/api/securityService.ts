import { apiGet, apiPatch, apiPost } from '@/shared/lib/apiClient';
export interface SecurityIncident { id:string; titulo:string; tipo:string; nivel:string; estado:string; analise_ia?:string; recomendacao_ia?:string; alvo_ip?:string; utilizador_nome?:string; criado_em:string; }
export async function listarIncidentes(estado?:string):Promise<SecurityIncident[]> { return apiGet(`/api/admin/security/incidents${estado?`?estado=${encodeURIComponent(estado)}`:''}`); }
export async function decidirIncidente(id:string,acao:'encerrar'|'conter_ip'|'libertar_ip'){ return apiPatch('/api/admin/security/incidents/decidir',{id,acao}); }
export async function gerarRelatorioMensal(){ return apiPost('/api/admin/security/report/monthly'); }
export async function listarRelatoriosMensais(){ return apiGet<any[]>('/api/admin/security/report/monthly'); }

export interface SecurityState { modo:'normal'|'alerta'|'emergencia'; funcionalidades_desativadas:string[]; motivo?:string|null; alterado_em?:string|null; }
export async function obterEstadoSeguranca():Promise<SecurityState>{ return apiGet('/api/admin/security/state'); }
export async function alterarEstadoSeguranca(modo:SecurityState['modo'],funcionalidades_desativadas:string[],motivo?:string){ return apiPatch<SecurityState>('/api/admin/security/state',{modo,funcionalidades_desativadas,motivo}); }
export async function criarBackupSeguranca(){ return apiPost('/api/admin/security/backup'); }
export async function verificarBackupsSeguranca(){ return apiGet<any>('/api/admin/security/backup'); }

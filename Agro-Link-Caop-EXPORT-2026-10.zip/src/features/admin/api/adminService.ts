import { apiGet, apiPatch, apiPost } from '@/shared/lib/apiClient';
import type { ProfileRow, PapelUtilizador, StatusConta, StatusVerificacaoTecnico, AuditoriaRow } from '@/shared/types/database.types';
export async function listarUtilizadores(f:{papel?:PapelUtilizador;status?:StatusConta}):Promise<ProfileRow[]>{const q=new URLSearchParams();if(f.papel)q.set('papel',f.papel);if(f.status)q.set('status',f.status);return apiGet(`/api/admin/users?${q}`);}
export async function atualizarStatusConta(id:string,status:StatusConta){await apiPatch(`/api/data/profiles?id=${encodeURIComponent(id)}`,{status});}
export async function suspenderConta(id:string,motivo:string){await apiPost('/api/admin/users/suspender',{id,motivo});}
export async function reativarConta(id:string){await apiPost('/api/admin/users/repor-ativa',{id});}
export async function aprovarConta(id:string){await apiPost('/api/admin/users/approve-account',{id});}
export async function atualizarVerificacaoTecnico(id:string,verification_status:StatusVerificacaoTecnico){await apiPatch(`/api/data/profiles?id=${encodeURIComponent(id)}`,{verification_status});}
export async function aprovarAdministrador(id:string){await apiPost('/api/admin/users/approve',{id});}
export async function promoverAPapel(id:string,papel:'auditor'){await apiPost('/api/admin/users/promote',{id,papel});}
export async function listarAuditoria():Promise<AuditoriaRow[]>{return apiGet('/api/admin/auditoria');}
export interface Estatisticas{total_relatos:number;relatos_pendentes:number;relatos_em_analise:number;relatos_resolvidos:number;total_agricultores:number;total_tecnicos:number;tecnicos_aprovados:number;contas_pendentes:number;}
export async function obterEstatisticas():Promise<Estatisticas>{return apiGet('/api/admin/stats');}

export async function listarDenuncias(estado?: string){const q=estado?`?estado=${encodeURIComponent(estado)}`:'';return apiGet<import('@/shared/types/database.types').DenunciaRow[]>(`/api/admin/denuncias${q}`);}
export async function atualizarDenuncia(input:{id:string;estado?:string;prioridade?:string;decisao?:string;admin_responsavel_id?:string|null}){return apiPatch('/api/admin/denuncias/atualizar',input);}

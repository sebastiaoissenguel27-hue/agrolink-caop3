import { apiGet, apiPost } from '@/shared/lib/apiClient';
import type { EstatisticasIA, IaResumoMensalRow } from '@/shared/types/database.types';
export async function obterEstatisticasIA():Promise<EstatisticasIA>{return apiGet('/api/admin/ia-stats');}
export async function listarResumosMensais():Promise<IaResumoMensalRow[]>{return apiGet('/api/data/ia_resumos_mensais?limit=500');}
export async function gerarResumoMensalAgora():Promise<{gerado:boolean;motivo?:string}>{return apiPost('/api/admin/ia-resumo');}
export async function enviarMensagemAdmin(titulo:string,corpo:string,papel?:string){const r=await apiPost<{destinatarios:number}>('/api/admin/broadcast',{titulo,corpo,papel});return r.destinatarios;}

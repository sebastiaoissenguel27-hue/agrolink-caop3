
import { useEffect, useState, type FormEvent } from 'react';
import { useAuth } from '@/features/auth/context/AuthContext';
import { listarNoticias, criarNoticia, apagarNoticia } from '@/features/noticias/api/noticiasService';
import type { NoticiaRow } from '@/shared/types/database.types';

export function AdminNoticias() {
  const { perfil } = useAuth();
  const [noticias, setNoticias] = useState<NoticiaRow[]>([]);
  const [titulo, setTitulo] = useState('');
  const [resumo, setResumo] = useState('');
  const [conteudo, setConteudo] = useState('');
  const [categoria, setCategoria] = useState('');

  async function carregar() {
    setNoticias(await listarNoticias());
  }

  useEffect(() => {
    carregar();
  }, []);

  async function submeter(e: FormEvent) {
    e.preventDefault();
    await criarNoticia({ titulo, resumo, conteudo, categoria, autor_id: perfil?.id ?? null });
    setTitulo('');
    setResumo('');
    setConteudo('');
    setCategoria('');
    carregar();
  }

  return (
    <div>
      <h2>Notícias</h2>
      <form onSubmit={submeter} style={{ display: 'flex', flexDirection: 'column', gap: 8, maxWidth: 480 }}>
        <input placeholder="Título" required value={titulo} onChange={(e) => setTitulo(e.target.value)} />
        <input placeholder="Resumo" value={resumo} onChange={(e) => setResumo(e.target.value)} />
        <textarea placeholder="Conteúdo completo" required rows={4} value={conteudo} onChange={(e) => setConteudo(e.target.value)} />
        <input placeholder="Categoria" value={categoria} onChange={(e) => setCategoria(e.target.value)} />
        <button type="submit">Publicar notícia</button>
      </form>

      <ul style={{ listStyle: 'none', padding: 0, marginTop: 16 }}>
        {noticias.map((n) => (
          <li key={n.id} style={{ borderBottom: '1px solid #eee', padding: '8px 0' }}>
            <strong>{n.titulo}</strong>{' '}
            <button onClick={() => apagarNoticia(n.id).then(carregar)}>Apagar</button>
          </li>
        ))}
      </ul>
    </div>
  );
}


import { useEffect, useState } from 'react';
import { obterEstatisticas, type Estatisticas } from '@/features/admin/api/adminService';

export function AdminEstatisticas() {
  const [stats, setStats] = useState<Estatisticas | null>(null);

  useEffect(() => {
    obterEstatisticas().then(setStats);
  }, []);

  if (!stats) return <p>A carregar estatísticas…</p>;

  const cartoes: [string, number][] = [
    ['Total de relatos', stats.total_relatos],
    ['Relatos pendentes', stats.relatos_pendentes],
    ['Relatos em análise', stats.relatos_em_analise],
    ['Relatos resolvidos', stats.relatos_resolvidos],
    ['Agricultores', stats.total_agricultores],
    ['Técnicos', stats.total_tecnicos],
    ['Técnicos aprovados', stats.tecnicos_aprovados],
    ['Contas pendentes', stats.contas_pendentes],
  ];

  return (
    <div>
      <h2>Estatísticas iniciais</h2>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 12 }}>
        {cartoes.map(([rotulo, valor]) => (
          <div key={rotulo} style={{ background: '#fff', borderRadius: 8, padding: 16, textAlign: 'center' }}>
            <div style={{ fontSize: '1.8rem', fontWeight: 700, color: 'var(--color-verde-mata)' }}>
              {valor}
            </div>
            <div style={{ fontSize: '0.8rem', color: 'var(--color-terra)' }}>{rotulo}</div>
          </div>
        ))}
      </div>
      <p style={{ marginTop: 16, fontSize: '0.85rem', color: 'var(--color-terra)' }}>
        Séries históricas e cruzamentos mais avançados ficam para o módulo SIE
        (preparado no schema, ainda sem interface própria).
      </p>
    </div>
  );
}


import { useEffect, useState, type FormEvent } from 'react';
import { useAuth } from '@/features/auth/context/AuthContext';
import {
  listarDocumentos,
  criarDocumento,
  apagarDocumento,
  carregarFicheiroBiblioteca,
} from '@/features/biblioteca/api/bibliotecaService';
import type { BibliotecaDocumentoRow, TipoDocumentoBiblioteca } from '@/shared/types/database.types';

export function AdminBiblioteca() {
  const { perfil } = useAuth();
  const [documentos, setDocumentos] = useState<BibliotecaDocumentoRow[]>([]);
  const [titulo, setTitulo] = useState('');
  const [descricao, setDescricao] = useState('');
  const [categoria, setCategoria] = useState('');
  const [tipo, setTipo] = useState<TipoDocumentoBiblioteca>('pdf');
  const [ficheiro, setFicheiro] = useState<File | null>(null);
  const [urlExterno, setUrlExterno] = useState('');
  const [aEnviar, setAEnviar] = useState(false);

  async function carregar() {
    setDocumentos(await listarDocumentos());
  }

  useEffect(() => {
    carregar();
  }, []);

  async function submeter(e: FormEvent) {
    e.preventDefault();
    if (!ficheiro && !urlExterno) {
      alert('Escolha um ficheiro para carregar ou indique um link externo.');
      return;
    }
    setAEnviar(true);
    try {
      const caminho = ficheiro ? await carregarFicheiroBiblioteca(ficheiro) : null;
      await criarDocumento({
        titulo,
        descricao,
        categoria,
        tipo,
        caminho_storage: caminho,
        url_externo: ficheiro ? null : urlExterno,
        autor_id: perfil?.id ?? null,
      });
      setTitulo('');
      setDescricao('');
      setCategoria('');
      setFicheiro(null);
      setUrlExterno('');
      carregar();
    } catch {
      alert('Não foi possível guardar o documento.');
    } finally {
      setAEnviar(false);
    }
  }

  return (
    <div>
      <h2>Biblioteca AgroLink</h2>
      <form onSubmit={submeter} style={{ display: 'flex', flexDirection: 'column', gap: 8, maxWidth: 480 }}>
        <input placeholder="Título" required value={titulo} onChange={(e) => setTitulo(e.target.value)} />
        <textarea placeholder="Descrição" rows={2} value={descricao} onChange={(e) => setDescricao(e.target.value)} />
        <input placeholder="Categoria" value={categoria} onChange={(e) => setCategoria(e.target.value)} />
        <select value={tipo} onChange={(e) => setTipo(e.target.value as TipoDocumentoBiblioteca)}>
          <option value="pdf">PDF</option>
          <option value="guia">Guia</option>
          <option value="manual">Manual</option>
          <option value="outro">Outro</option>
        </select>
        <label>
          Carregar ficheiro (PDF, etc.)
          <input type="file" onChange={(e) => setFicheiro(e.target.files?.[0] ?? null)} />
        </label>
        <span style={{ textAlign: 'center', fontSize: '0.8rem' }}>— ou —</span>
        <input
          placeholder="Link externo (se não carregar ficheiro)"
          value={urlExterno}
          onChange={(e) => setUrlExterno(e.target.value)}
          disabled={!!ficheiro}
        />
        <button type="submit" disabled={aEnviar}>
          {aEnviar ? 'A guardar…' : 'Publicar documento'}
        </button>
      </form>

      <ul style={{ listStyle: 'none', padding: 0, marginTop: 16 }}>
        {documentos.map((d) => (
          <li key={d.id} style={{ borderBottom: '1px solid #eee', padding: '8px 0' }}>
            {d.titulo} <button onClick={() => apagarDocumento(d.id).then(carregar)}>Apagar</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

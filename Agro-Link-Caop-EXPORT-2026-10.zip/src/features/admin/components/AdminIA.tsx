
import { useEffect, useState } from 'react';
import {
  obterEstatisticasIA,
  listarResumosMensais,
  gerarResumoMensalAgora,
} from '@/features/admin/api/iaAdminService';
import type { EstatisticasIA, IaResumoMensalRow } from '@/shared/types/database.types';

function Cartao({ rotulo, valor }: { rotulo: string; valor: number | string }) {
  return (
    <div style={{ background: '#fff', borderRadius: 8, padding: 12, textAlign: 'center' }}>
      <div style={{ fontSize: '1.4rem', fontWeight: 700, color: 'var(--color-verde-mata)' }}>{valor}</div>
      <div style={{ fontSize: '0.75rem', color: 'var(--color-terra)' }}>{rotulo}</div>
    </div>
  );
}

function ListaFrequencia({ titulo, itens }: { titulo: string; itens: { total: number; [k: string]: unknown }[] }) {
  const chave = Object.keys(itens[0] ?? {}).find((k) => k !== 'total');
  return (
    <div>
      <h4>{titulo}</h4>
      {itens.length === 0 && <p style={{ fontSize: '0.8rem' }}>Sem dados ainda.</p>}
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {itens.map((item, i) => (
          <li key={i} style={{ fontSize: '0.85rem' }}>
            {String(item[chave ?? ''])} — {item.total}
          </li>
        ))}
      </ul>
    </div>
  );
}

export function AdminIA() {
  const [stats, setStats] = useState<EstatisticasIA | null>(null);
  const [resumos, setResumos] = useState<IaResumoMensalRow[]>([]);
  const [aGerar, setAGerar] = useState(false);
  const [mensagem, setMensagem] = useState<string | null>(null);

  async function carregar() {
    setStats(await obterEstatisticasIA());
    setResumos(await listarResumosMensais());
  }

  useEffect(() => {
    carregar();
  }, []);

  async function gerarResumo() {
    setAGerar(true);
    setMensagem(null);
    try {
      const r = await gerarResumoMensalAgora();
      setMensagem(r.gerado ? 'Resumo gerado com sucesso.' : r.motivo ?? 'Nada a gerar.');
      carregar();
    } catch {
      setMensagem('Não foi possível gerar o resumo agora.');
    } finally {
      setAGerar(false);
    }
  }

  if (!stats) return <p>A carregar…</p>;

  return (
    <div>
      <h2>IA AgroLink — Analytics</h2>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: 12 }}>
        <Cartao rotulo="Total de perguntas" valor={stats.total_perguntas} />
        <Cartao rotulo="Confiança média" valor={`${stats.confianca_media_pct ?? '—'}%`} />
        <Cartao rotulo="Encaminhadas p/ técnico" valor={stats.total_encaminhados} />
        <Cartao rotulo="Resolvidas só pela IA" valor={stats.total_resolvidas_so_ia} />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 16, marginTop: 16 }}>
        <ListaFrequencia titulo="Temas mais frequentes" itens={stats.temas_frequentes} />
        <ListaFrequencia titulo="Culturas mais mencionadas" itens={stats.culturas_frequentes} />
        <ListaFrequencia titulo="Pragas mais mencionadas" itens={stats.pragas_frequentes} />
        <ListaFrequencia titulo="Perguntas por província" itens={stats.por_provincia} />
      </div>

      <h3 style={{ marginTop: 24 }}>Evolução mensal</h3>
      <ul style={{ listStyle: 'none', padding: 0, fontSize: '0.85rem' }}>
        {stats.por_mes.map((m) => (
          <li key={m.mes}>
            {m.mes}: {m.total} pergunta(s)
          </li>
        ))}
      </ul>

      <h3 style={{ marginTop: 24 }}>Resumo mensal automático</h3>
      <button onClick={gerarResumo} disabled={aGerar}>
        {aGerar ? 'A gerar…' : 'Gerar resumo do mês anterior agora'}
      </button>
      {mensagem && <p role="status">{mensagem}</p>}
      {resumos.map((r) => (
        <details key={r.id} style={{ marginTop: 8, background: '#fff', borderRadius: 8, padding: 12 }}>
          <summary>
            {r.mes}/{r.ano}
          </summary>
          <p style={{ whiteSpace: 'pre-wrap' }}>{r.conteudo}</p>
        </details>
      ))}
    </div>
  );
}

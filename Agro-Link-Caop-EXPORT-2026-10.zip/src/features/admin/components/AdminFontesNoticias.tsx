
import { useEffect, useState, type FormEvent } from 'react';
import {
  listarFontesNoticias,
  criarFonteNoticia,
  alternarFonteAtiva,
  atualizarUrlFonte,
  apagarFonteNoticia,
  sincronizarNoticiasAgora,
  listarSyncLogs,
  type ResultadoSyncNoticias,
} from '@/features/noticias/api/noticiasService';
import type { NoticiaFonteRow, NoticiaSyncLogRow } from '@/shared/types/database.types';

export function AdminFontesNoticias() {
  const [fontes, setFontes] = useState<NoticiaFonteRow[]>([]);
  const [nome, setNome] = useState('');
  const [urlRss, setUrlRss] = useState('');
  const [categoria, setCategoria] = useState('');
  const [ambito, setAmbito] = useState<'nacional' | 'internacional'>('nacional');
  const [aSincronizar, setASincronizar] = useState(false);
  const [resultado, setResultado] = useState<ResultadoSyncNoticias | null>(null);
  const [logs, setLogs] = useState<NoticiaSyncLogRow[]>([]);

  async function carregar() {
    setFontes(await listarFontesNoticias());
    setLogs(await listarSyncLogs());
  }

  useEffect(() => {
    carregar();
  }, []);

  async function submeter(e: FormEvent) {
    e.preventDefault();
    await criarFonteNoticia({ nome, url_rss: urlRss, categoria: categoria || null, ambito });
    setNome('');
    setUrlRss('');
    setCategoria('');
    setAmbito('nacional');
    carregar();
  }

  async function sincronizarAgora() {
    setASincronizar(true);
    setResultado(null);
    try {
      setResultado(await sincronizarNoticiasAgora());
    } catch {
      setResultado({ fontes_processadas: 0, inseridas: 0, ignoradas: 0, erros: ['Falha ao contactar a função de sincronização.'] });
    } finally {
      setASincronizar(false);
    }
  }

  return (
    <div>
      <h2>Fontes de notícias (integração automática)</h2>
      <p style={{ fontSize: '0.85rem', color: 'var(--color-terra)' }}>
        Cada fonte é um feed RSS. A sincronização corre automaticamente segundo o agendamento
        configurado na Edge Function <code>sync-noticias</code>, ou pode ser disparada aqui manualmente.
      </p>

      <button onClick={sincronizarAgora} disabled={aSincronizar}>
        {aSincronizar ? 'A sincronizar…' : 'Sincronizar agora'}
      </button>

      {resultado && (
        <p style={{ fontSize: '0.85rem' }}>
          {resultado.fontes_processadas} fonte(s) processada(s) · {resultado.inseridas} nova(s) ·{' '}
          {resultado.ignoradas} já existente(s)
          {resultado.erros.length > 0 && <> · erros: {resultado.erros.join('; ')}</>}
        </p>
      )}

      <form onSubmit={submeter} style={{ display: 'flex', flexDirection: 'column', gap: 8, maxWidth: 480, marginTop: 16 }}>
        <input placeholder="Nome da fonte" required value={nome} onChange={(e) => setNome(e.target.value)} />
        <input placeholder="URL do feed RSS" required value={urlRss} onChange={(e) => setUrlRss(e.target.value)} />
        <input placeholder="Categoria" value={categoria} onChange={(e) => setCategoria(e.target.value)} />
        <select value={ambito} onChange={(e) => setAmbito(e.target.value as 'nacional' | 'internacional')}>
          <option value="nacional">Fonte nacional</option>
          <option value="internacional">Fonte internacional</option>
        </select>
        <button type="submit">Adicionar fonte</button>
      </form>

      <ul style={{ listStyle: 'none', padding: 0, marginTop: 16 }}>
        {fontes.map((f) => (
          <li key={f.id} style={{ borderBottom: '1px solid #eee', padding: '8px 0' }}>
            <strong>{f.nome}</strong> ({f.ambito}) {f.ativo ? '(ativa)' : '(inativa)'} — {f.url_rss ?? 'sem URL definida'}{' '}
            <button onClick={() => alternarFonteAtiva(f.id, !f.ativo).then(carregar)}>
              {f.ativo ? 'Desativar' : 'Ativar'}
            </button>{' '}
            <button onClick={() => apagarFonteNoticia(f.id).then(carregar)}>Apagar</button>
            {!f.url_rss && (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  const input = (e.target as HTMLFormElement).elements.namedItem('url') as HTMLInputElement;
                  if (input.value) atualizarUrlFonte(f.id, input.value).then(carregar);
                }}
                style={{ display: 'inline-flex', gap: 4, marginLeft: 8 }}
              >
                <input name="url" placeholder="Colar URL do feed RSS" style={{ fontSize: '0.8rem' }} />
                <button type="submit">Guardar URL</button>
              </form>
            )}
          </li>
        ))}
      </ul>

      <h3 style={{ marginTop: 24 }}>Histórico de sincronizações</h3>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.85rem' }}>
        <thead>
          <tr style={{ textAlign: 'left', borderBottom: '2px solid #ddd' }}>
            <th>Data</th>
            <th>Fonte</th>
            <th>Estado</th>
            <th>Inseridas</th>
            <th>Ignoradas</th>
            <th>Erro</th>
          </tr>
        </thead>
        <tbody>
          {logs.map((l) => (
            <tr key={l.id} style={{ borderBottom: '1px solid #eee' }}>
              <td>{new Date(l.executado_em).toLocaleString('pt-PT')}</td>
              <td>{fontes.find((f) => f.id === l.fonte_id)?.nome ?? '—'}</td>
              <td>{l.sucesso ? '✅' : '❌'}</td>
              <td>{l.itens_inseridos}</td>
              <td>{l.itens_ignorados}</td>
              <td>{l.mensagem_erro ?? '—'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}


import { useEffect, useState, type FormEvent } from 'react';
import {
  listarRecursos,
  criarRecurso,
  apagarRecurso,
  listarFAQ,
  criarFAQ,
  apagarFAQ,
} from '@/features/recursos/api/recursosService';
import type { RecursoExternoRow, PerguntaFrequenteRow } from '@/shared/types/database.types';

export function AdminRecursos() {
  const [recursos, setRecursos] = useState<RecursoExternoRow[]>([]);
  const [faq, setFaq] = useState<PerguntaFrequenteRow[]>([]);

  const [titulo, setTitulo] = useState('');
  const [descricao, setDescricao] = useState('');
  const [categoria, setCategoria] = useState('');
  const [url, setUrl] = useState('');
  const [contacto, setContacto] = useState('');

  const [pergunta, setPergunta] = useState('');
  const [resposta, setResposta] = useState('');

  async function carregar() {
    setRecursos(await listarRecursos());
    setFaq(await listarFAQ());
  }

  useEffect(() => {
    carregar();
  }, []);

  async function submeterRecurso(e: FormEvent) {
    e.preventDefault();
    await criarRecurso({ titulo, descricao, categoria, url: url || null, contacto: contacto || null });
    setTitulo('');
    setDescricao('');
    setCategoria('');
    setUrl('');
    setContacto('');
    carregar();
  }

  async function submeterFAQ(e: FormEvent) {
    e.preventDefault();
    await criarFAQ({ pergunta, resposta });
    setPergunta('');
    setResposta('');
    carregar();
  }

  return (
    <div>
      <h2>Centro de Recursos</h2>

      <h3>Recursos externos</h3>
      <form onSubmit={submeterRecurso} style={{ display: 'flex', flexDirection: 'column', gap: 8, maxWidth: 480 }}>
        <input placeholder="Título" required value={titulo} onChange={(e) => setTitulo(e.target.value)} />
        <input placeholder="Descrição" value={descricao} onChange={(e) => setDescricao(e.target.value)} />
        <input placeholder="Categoria" value={categoria} onChange={(e) => setCategoria(e.target.value)} />
        <input placeholder="URL (opcional)" value={url} onChange={(e) => setUrl(e.target.value)} />
        <input placeholder="Contacto (opcional)" value={contacto} onChange={(e) => setContacto(e.target.value)} />
        <button type="submit">Adicionar recurso</button>
      </form>
      <ul style={{ listStyle: 'none', padding: 0, marginTop: 12 }}>
        {recursos.map((r) => (
          <li key={r.id} style={{ borderBottom: '1px solid #eee', padding: '6px 0' }}>
            {r.titulo} <button onClick={() => apagarRecurso(r.id).then(carregar)}>Apagar</button>
          </li>
        ))}
      </ul>

      <h3 style={{ marginTop: 24 }}>Perguntas frequentes</h3>
      <form onSubmit={submeterFAQ} style={{ display: 'flex', flexDirection: 'column', gap: 8, maxWidth: 480 }}>
        <input placeholder="Pergunta" required value={pergunta} onChange={(e) => setPergunta(e.target.value)} />
        <textarea placeholder="Resposta" required rows={3} value={resposta} onChange={(e) => setResposta(e.target.value)} />
        <button type="submit">Adicionar pergunta</button>
      </form>
      <ul style={{ listStyle: 'none', padding: 0, marginTop: 12 }}>
        {faq.map((f) => (
          <li key={f.id} style={{ borderBottom: '1px solid #eee', padding: '6px 0' }}>
            {f.pergunta} <button onClick={() => apagarFAQ(f.id).then(carregar)}>Apagar</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

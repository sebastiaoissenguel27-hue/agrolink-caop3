
import { useState, type FormEvent } from 'react';
import { enviarMensagemAdmin } from '@/features/admin/api/iaAdminService';

export function AdminMensagens() {
  const [titulo, setTitulo] = useState('');
  const [corpo, setCorpo] = useState('');
  const [papel, setPapel] = useState('');
  const [aEnviar, setAEnviar] = useState(false);
  const [resultado, setResultado] = useState<string | null>(null);

  async function submeter(e: FormEvent) {
    e.preventDefault();
    setAEnviar(true);
    setResultado(null);
    try {
      const total = await enviarMensagemAdmin(titulo, corpo, papel || undefined);
      setResultado(`Mensagem enviada a ${total} utilizador(es).`);
      setTitulo('');
      setCorpo('');
    } catch {
      setResultado('Não foi possível enviar a mensagem.');
    } finally {
      setAEnviar(false);
    }
  }

  return (
    <div>
      <h2>Mensagens da administração</h2>
      <p style={{ fontSize: '0.85rem', color: 'var(--color-terra)' }}>
        Envia uma notificação a todos os utilizadores ativos (ou só a um papel específico).
      </p>
      <form onSubmit={submeter} style={{ display: 'flex', flexDirection: 'column', gap: 8, maxWidth: 480 }}>
        <input placeholder="Título" required value={titulo} onChange={(e) => setTitulo(e.target.value)} />
        <textarea placeholder="Mensagem" required rows={3} value={corpo} onChange={(e) => setCorpo(e.target.value)} />
        <select value={papel} onChange={(e) => setPapel(e.target.value)}>
          <option value="">Todos os utilizadores</option>
          <option value="agricultor">Só agricultores</option>
          <option value="tecnico">Só técnicos</option>
          <option value="admin">Só administradores</option>
        </select>
        <button type="submit" disabled={aEnviar}>
          {aEnviar ? 'A enviar…' : 'Enviar mensagem'}
        </button>
      </form>
      {resultado && <p role="status">{resultado}</p>}
    </div>
  );
}

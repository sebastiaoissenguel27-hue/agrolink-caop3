
import { useEffect, useState, type FormEvent } from 'react';
import { useAuth } from '@/features/auth/context/AuthContext';
import { listarAlertas, criarAlerta, apagarAlerta } from '@/features/alertas/api/alertasService';
import type { AlertaRow, NivelAlerta } from '@/shared/types/database.types';

export function AdminAlertas() {
  const { perfil } = useAuth();
  const [alertas, setAlertas] = useState<AlertaRow[]>([]);
  const [titulo, setTitulo] = useState('');
  const [descricao, setDescricao] = useState('');
  const [nivel, setNivel] = useState<NivelAlerta>('info');
  const [provincias, setProvincias] = useState(''); // vazio = nacional

  async function carregar() {
    setAlertas(await listarAlertas(null)); // admin vê todos, sem filtro de província
  }

  useEffect(() => {
    carregar();
  }, []);

  async function submeter(e: FormEvent) {
    e.preventDefault();
    await criarAlerta({
      titulo,
      descricao,
      nivel,
      criado_por: perfil?.id ?? null,
      provincias_alvo: provincias
        ? provincias.split(',').map((p) => p.trim()).filter(Boolean)
        : [],
    });
    setTitulo('');
    setDescricao('');
    setProvincias('');
    setNivel('info');
    carregar();
  }

  return (
    <div>
      <h2>Alertas</h2>
      <form onSubmit={submeter} style={{ display: 'flex', flexDirection: 'column', gap: 8, maxWidth: 480 }}>
        <input placeholder="Título" required value={titulo} onChange={(e) => setTitulo(e.target.value)} />
        <textarea placeholder="Descrição" required rows={3} value={descricao} onChange={(e) => setDescricao(e.target.value)} />
        <select value={nivel} onChange={(e) => setNivel(e.target.value as NivelAlerta)}>
          <option value="info">Informativo</option>
          <option value="atencao">Atenção</option>
          <option value="urgente">Urgente</option>
        </select>
        <input
          placeholder="Províncias-alvo separadas por vírgula (vazio = nacional)"
          value={provincias}
          onChange={(e) => setProvincias(e.target.value)}
        />
        <button type="submit">Publicar alerta</button>
      </form>

      <ul style={{ listStyle: 'none', padding: 0, marginTop: 16 }}>
        {alertas.map((a) => (
          <li key={a.id} style={{ borderBottom: '1px solid #eee', padding: '8px 0' }}>
            <strong>{a.titulo}</strong> ({a.nivel}) —{' '}
            {a.provincias_alvo.length === 0 ? 'Nacional' : a.provincias_alvo.join(', ')}{' '}
            <button onClick={() => apagarAlerta(a.id).then(carregar)}>Apagar</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

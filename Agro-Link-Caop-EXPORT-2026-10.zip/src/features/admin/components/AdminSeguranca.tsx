import { useEffect, useRef, useState } from 'react';
import { alterarEstadoSeguranca, criarBackupSeguranca, decidirIncidente, gerarRelatorioMensal, listarIncidentes, listarRelatoriosMensais, obterEstadoSeguranca, verificarBackupsSeguranca, type SecurityIncident, type SecurityState } from '@/features/admin/api/securityService';

function avisarNavegador(titulo:string, corpo:string){
  try { if(document.visibilityState==='visible' || Notification.permission!=='granted') return; new Notification(titulo,{body:corpo,tag:'agrolink-security'}); } catch {}
}

export function AdminSeguranca(){
  const [incidentes,setIncidentes]=useState<SecurityIncident[]>([]); const [relatorios,setRelatorios]=useState<any[]>([]); const [estado,setEstado]=useState<SecurityState|null>(null); const [erro,setErro]=useState('');
  const knownIds=useRef(new Set<string>());
  async function carregar(silencioso=false){try{if(!silencioso)setErro('');const novos=await listarIncidentes(); for(const i of novos){if(!knownIds.current.has(i.id)&&i.estado!=='resolvido'){avisarNavegador(`AgroLink: ${i.titulo}`,`Risco ${i.nivel}. ${i.recomendacao_ia||'Requer atenção.'}`);}} novos.forEach(i=>knownIds.current.add(i.id)); setIncidentes(novos); setRelatorios(await listarRelatoriosMensais()); setEstado(await obterEstadoSeguranca());}catch(e:any){if(!silencioso)setErro(e?.message||'Não foi possível carregar a segurança.');}}
  useEffect(()=>{carregar(); const timer=window.setInterval(()=>carregar(true),15000); return()=>window.clearInterval(timer);},[]);
  async function permitirAlertas(){try{if('Notification' in window){const p=await Notification.requestPermission(); if(p==='granted')new Notification('AgroLink Security & Trust Layer',{body:'Alertas de segurança ativados neste dispositivo.'});}}catch{setErro('Não foi possível ativar os alertas deste dispositivo.');}}
  async function agir(i:SecurityIncident,acao:'encerrar'|'conter_ip'|'libertar_ip'){try{await decidirIncidente(i.id,acao);await carregar();}catch(e:any){setErro(e?.message||'Ação recusada.');}}
  return <section>
    <h2>Security & Trust Layer</h2>
    <p>Monitorização defensiva com IA, contenção automática reversível e decisão humana para ações administrativas.</p>
    <button onClick={permitirAlertas}>Ativar alertas de segurança neste dispositivo</button>
    {erro&&<p role="alert">{erro}</p>}
    <h3>Modo de Segurança</h3>
    {estado&&<div style={{border:'1px solid currentColor',padding:12,marginBottom:12,borderRadius:8}}>
      <p><b>Estado atual:</b> {estado.modo}</p>
      {estado.motivo&&<p><b>Motivo:</b> {estado.motivo}</p>}
      <p><b>Funcionalidades protegidas:</b> {estado.funcionalidades_desativadas.length?estado.funcionalidades_desativadas.join(', '):'nenhuma'}</p>
      <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
        <button onClick={async()=>{try{setEstado(await alterarEstadoSeguranca('normal',[], 'Regresso ao funcionamento normal.'));}catch(e:any){setErro(e?.message||'Ação recusada.');}}}>Voltar ao normal</button>
        <button onClick={async()=>{try{setEstado(await alterarEstadoSeguranca('alerta',[], 'Monitorização reforçada.'));}catch(e:any){setErro(e?.message||'Ação recusada.');}}}>Modo alerta</button>
        <button onClick={async()=>{try{setEstado(await alterarEstadoSeguranca('emergencia',['registos','uploads','ia','logistica'], 'Contenção preventiva ativada pelo administrador-chefe.'));}catch(e:any){setErro(e?.message||'Ação recusada.');}}}>Ativar emergência</button>
      </div>
    </div>}
    <h3>Backups e integridade</h3>
    <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
      <button onClick={async()=>{try{const r=await verificarBackupsSeguranca();setErro(r.integrity?.ok?'':'A integridade da base requer atenção.');}catch(e:any){setErro(e?.message||'Não foi possível verificar a base.');}}}>Verificar integridade</button>
      <button onClick={async()=>{try{await criarBackupSeguranca();await carregar();}catch(e:any){setErro(e?.message||'Não foi possível criar o backup.');}}}>Criar backup seguro</button>
    </div>
    <h3>Incidentes</h3>
    {!incidentes.length?<p>Nenhum incidente relevante registado.</p>:incidentes.map(i=><article key={i.id} style={{border:'1px solid currentColor',padding:12,marginBottom:10,borderRadius:8}}>
      <strong>{i.titulo}</strong> — {i.nivel} — {i.estado}<br/>
      <small>{new Date(i.criado_em).toLocaleString('pt-PT')} · origem: {i.alvo_ip||'desconhecida'}</small>
      {i.utilizador_nome&&<div>Utilizador relacionado: {i.utilizador_nome}</div>}
      {i.analise_ia&&<p><b>Análise IA:</b> {i.analise_ia}</p>}
      {i.recomendacao_ia&&<p><b>Recomendação:</b> {i.recomendacao_ia}</p>}
      {i.estado!=='resolvido'&&<div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
        {i.alvo_ip&&<button onClick={()=>agir(i,'conter_ip')}>Aprovar contenção</button>}
        {i.alvo_ip&&i.estado==='contido'&&<button onClick={()=>agir(i,'libertar_ip')}>Libertar origem</button>}
        <button onClick={()=>agir(i,'encerrar')}>Encerrar incidente</button>
      </div>}
    </article>)}
    <h3>Relatórios mensais</h3>
    <button onClick={async()=>{await gerarRelatorioMensal();await carregar();}}>Gerar/verificar relatório do mês anterior</button>
    {relatorios.map(r=><pre key={r.id} style={{whiteSpace:'pre-wrap'}}>{r.conteudo}</pre>)}
  </section>;
}

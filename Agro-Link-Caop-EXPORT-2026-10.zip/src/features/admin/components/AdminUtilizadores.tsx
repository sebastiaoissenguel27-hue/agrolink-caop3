
import { useEffect, useState } from 'react';
import { useAuth } from '@/features/auth/context/AuthContext';
import {
  listarUtilizadores,
  aprovarConta,
  atualizarVerificacaoTecnico,
  aprovarAdministrador,
  promoverAPapel,
  suspenderConta,
  reativarConta,
} from '@/features/admin/api/adminService';
import type { ProfileRow, PapelUtilizador, StatusConta } from '@/shared/types/database.types';

export function AdminUtilizadores() {
  const { perfil } = useAuth();
  const meuId = perfil?.id;
  const podeGerir = perfil?.papel === 'admin_chefe' || (perfil?.papel === 'admin' && perfil.nivel_admin !== 'auditor');
  const podePromover = perfil?.papel === 'admin_chefe';
  const [utilizadores, setUtilizadores] = useState<ProfileRow[]>([]);
  const [filtroPapel, setFiltroPapel] = useState<PapelUtilizador | ''>('');
  const [filtroStatus, setFiltroStatus] = useState<StatusConta | ''>('');
  const [aCarregar, setACarregar] = useState(true);

  async function carregar() {
    setACarregar(true);
    try {
      setUtilizadores(
        await listarUtilizadores({
          papel: filtroPapel || undefined,
          status: filtroStatus || undefined,
        })
      );
    } finally {
      setACarregar(false);
    }
  }

  useEffect(() => {
    carregar();
  }, [filtroPapel, filtroStatus]);

  async function suspender(id: string, nome: string) {
    const motivo = window.prompt(`Motivo da suspensão de "${nome}":`);
    if (!motivo || motivo.trim().length < 5) return;
    await suspenderConta(id, motivo.trim());
    carregar();
  }

  async function reativar(id: string) {
    await reativarConta(id);
    carregar();
  }

  async function mudarVerificacao(id: string, verificacao: 'pendente' | 'aprovado' | 'rejeitado') {
    await atualizarVerificacaoTecnico(id, verificacao);
    carregar();
  }

  async function aprovarAdmin(id: string, nome: string) {
    if (!window.confirm(`Aprovar "${nome}" como administrador?`)) {
      return;
    }
    await aprovarAdministrador(id);
    carregar();
  }

  async function aprovarUtilizador(id: string, nome: string) {
    if (!window.confirm(`Aprovar a conta de "${nome}"?`)) return;
    await aprovarConta(id);
    carregar();
  }

  return (
    <div>
      <h2>Utilizadores</h2>
      <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
        <select value={filtroPapel} onChange={(e) => setFiltroPapel(e.target.value as PapelUtilizador | '')}>
          <option value="">Todos os papéis</option>
          <option value="utilizador">Utilizador</option>
          <option value="admin">Admin</option>
          <option value="admin_chefe">Administrador-chefe</option>
        </select>
        <select value={filtroStatus} onChange={(e) => setFiltroStatus(e.target.value as StatusConta | '')}>
          <option value="">Todos os estados</option>
          <option value="ativo">Ativo</option>
          <option value="pendente">Pendente</option>
          <option value="bloqueado">Bloqueado</option>
        </select>
      </div>

      {aCarregar && <p>A carregar…</p>}

      <div style={{ width: '100%', overflowX: 'auto' }}>
      <table style={{ width: '100%', minWidth: 760, borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ textAlign: 'left', borderBottom: '2px solid #ddd' }}>
            <th>Nome</th>
            <th>Autorização</th><th>Perfil profissional</th>
            <th>Estado</th>
            <th>Verificação</th>
            <th>Ações</th>
          </tr>
        </thead>
        <tbody>
          {utilizadores.map((u) => (
            <tr key={u.id} style={{ borderBottom: '1px solid #eee' }}>
              <td>{u.nome}</td>
              <td>{u.papel === 'admin' && u.nivel_admin === 'auditor' ? 'Auditor' : u.papel}</td><td>{u.tipo_perfil ?? '—'}</td>
              <td>{u.status === 'bloqueado' ? 'Suspensa' : u.status === 'ativo' ? 'Ativa' : 'Pendente'}</td>
              <td>{u.tipo_perfil === 'tecnico' ? u.verification_status : '—'}</td>
              <td><div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', minWidth: 210 }}>
                {podePromover && u.id !== meuId && u.status === 'bloqueado' && (
                  <button onClick={() => reativar(u.id)}>Reativar conta</button>
                )}
                {podePromover && u.id !== meuId && u.status !== 'bloqueado' && (
                  <button onClick={() => suspender(u.id, u.nome)}>Suspender conta</button>
                )}
                {podePromover && u.id !== meuId && u.papel === 'utilizador' && u.tipo_perfil === 'administrador' && u.status === 'pendente' && (
                  <button onClick={() => aprovarAdmin(u.id, u.nome)}>Aprovar administrador</button>
                )}
                {podePromover && u.id !== meuId && u.papel === 'utilizador' && ['agricultor','tecnico'].includes(u.tipo_perfil || '') && u.status === 'pendente' && (
                  <button onClick={() => aprovarUtilizador(u.id, u.nome)}>Aprovar conta</button>
                )}
                {podeGerir && u.tipo_perfil === 'tecnico' && u.verification_status !== 'aprovado' && (
                  <button onClick={() => mudarVerificacao(u.id, 'aprovado')}>Aprovar técnico</button>
                )}
                {podeGerir && u.tipo_perfil === 'tecnico' && u.verification_status !== 'rejeitado' && (
                  <button onClick={() => mudarVerificacao(u.id, 'rejeitado')}>Rejeitar</button>
                )}
                {podePromover && u.id !== meuId && u.papel !== 'admin_chefe' && u.nivel_admin !== 'auditor' && (
                  <button onClick={async () => { await promoverAPapel(u.id, 'auditor'); carregar(); }}>Tornar auditor</button>
                )}
              </div></td>
            </tr>
          ))}
        </tbody>
      </table>
      </div>
    </div>
  );
}

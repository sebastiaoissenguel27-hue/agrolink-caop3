import { useEffect, useState } from 'react';
import { useAuth } from '@/features/auth/context/AuthContext';
import { atualizarDenuncia, listarDenuncias, suspenderConta } from '@/features/admin/api/adminService';
import type { DenunciaRow } from '@/shared/types/database.types';
export function AdminDenuncias(){
 const { perfil } = useAuth(); const podeTratar=perfil?.papel==='admin_chefe'||(perfil?.papel==='admin'&&perfil.nivel_admin!=='auditor');
 const [items,setItems]=useState<DenunciaRow[]>([]),[estado,setEstado]=useState(''),[carregando,setCarregando]=useState(true);
 async function carregar(){setCarregando(true);try{setItems(await listarDenuncias(estado||undefined));}finally{setCarregando(false);}} useEffect(()=>{carregar();},[estado]);
 async function alterar(id:string,campo:'estado'|'prioridade',valor:string){await atualizarDenuncia({id,[campo]:valor});await carregar();}
 async function suspenderDenunciado(d:DenunciaRow){
  const nome=d.denunciado_nome||'utilizador';
  const motivo=window.prompt(`Motivo da suspensão de "${nome}":`);
  if(!motivo||motivo.trim().length<5)return;
  await suspenderConta(d.denunciado_id,motivo.trim());
  await carregar();
 }
 async function decidir(d:DenunciaRow){const decisao=window.prompt('Decisão/nota interna (opcional):',d.decisao||'');if(decisao===null)return;await atualizarDenuncia({id:d.id,decisao,estado:'em_analise'});await carregar();}
 return <div><h2>Denúncias</h2><p style={{fontSize:'.85rem',color:'var(--color-terra)'}}>Denúncias recebidas de utilizadores. Auditores podem consultar; administradores podem tratar; o administrador-chefe pode suspender a conta denunciada quando necessário.</p><select value={estado} onChange={e=>setEstado(e.target.value)}><option value="">Todas</option><option value="pendente">Pendentes</option><option value="em_analise">Em análise</option><option value="confirmada">Confirmadas</option><option value="rejeitada">Rejeitadas</option><option value="arquivada">Arquivadas</option></select>{carregando?<p>A carregar…</p>:<div style={{display:'grid',gap:12,marginTop:12}}>{items.map(d=><article key={d.id} style={{border:'1px solid #ddd',padding:12,borderRadius:8}}><strong>{d.categoria}</strong><div><b>Denunciado:</b> {d.denunciado_nome} ({d.denunciado_papel})</div><div><b>Autor:</b> {d.autor_nome} ({d.autor_papel})</div><div><b>Descrição:</b> {d.descricao}</div><div style={{display:'flex',gap:8,flexWrap:'wrap',marginTop:8}}>{podeTratar&&<label>Estado <select value={d.estado} onChange={e=>alterar(d.id,'estado',e.target.value)}><option value="pendente">Pendente</option><option value="em_analise">Em análise</option><option value="confirmada">Confirmada</option><option value="rejeitada">Rejeitada</option><option value="arquivada">Arquivada</option></select></label>}{podeTratar&&<label>Prioridade <select value={d.prioridade} onChange={e=>alterar(d.id,'prioridade',e.target.value)}><option value="baixa">Baixa</option><option value="media">Média</option><option value="alta">Alta</option><option value="urgente">Urgente</option></select></label>} {podeTratar&&<button onClick={()=>decidir(d)}>Adicionar decisão</button>} {perfil?.papel==='admin_chefe'&&<button onClick={()=>suspenderDenunciado(d)}>Suspender denunciado</button>}	</div>{d.decisao&&<div style={{marginTop:8}}><b>Decisão:</b> {d.decisao}</div>}</article>)}</div>}</div>;
}

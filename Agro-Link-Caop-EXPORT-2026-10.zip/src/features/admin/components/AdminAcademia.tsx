
import { useEffect, useState, type FormEvent } from 'react';
import { useAuth } from '@/features/auth/context/AuthContext';
import {
  listarCursos,
  criarCurso,
  apagarCurso,
  listarLicoes,
  criarLicao,
  apagarLicao,
  carregarFicheiroAcademia,
  listarPerguntasAdmin,
  criarPergunta,
  apagarPergunta,
} from '@/features/academia/api/academiaService';
import type { AcademiaCursoRow, AcademiaLicaoRow, AcademiaQuestionarioAdminRow, TipoLicao } from '@/shared/types/database.types';

function GestaoLicoes({ cursoId }: { cursoId: string }) {
  const [licoes, setLicoes] = useState<AcademiaLicaoRow[]>([]);
  const [titulo, setTitulo] = useState('');
  const [tipo, setTipo] = useState<TipoLicao>('texto');
  const [conteudoTexto, setConteudoTexto] = useState('');
  const [ficheiro, setFicheiro] = useState<File | null>(null);
  const [licaoParaQuiz, setLicaoParaQuiz] = useState<string | null>(null);

  async function carregar() {
    setLicoes(await listarLicoes(cursoId));
  }

  useEffect(() => {
    carregar();
  }, [cursoId]);

  async function submeter(e: FormEvent) {
    e.preventDefault();
    const caminho = ficheiro ? await carregarFicheiroAcademia(ficheiro) : null;
    await criarLicao({
      curso_id: cursoId,
      titulo,
      tipo,
      conteudo_texto: tipo === 'texto' ? conteudoTexto : null,
      caminho_storage: caminho,
      ordem: licoes.length,
    });
    setTitulo('');
    setConteudoTexto('');
    setFicheiro(null);
    carregar();
  }

  return (
    <div style={{ marginLeft: 16, borderLeft: '2px solid #eee', paddingLeft: 16, marginTop: 8 }}>
      <form onSubmit={submeter} style={{ display: 'flex', flexDirection: 'column', gap: 6, maxWidth: 420 }}>
        <input placeholder="Título da lição" required value={titulo} onChange={(e) => setTitulo(e.target.value)} />
        <select value={tipo} onChange={(e) => setTipo(e.target.value as TipoLicao)}>
          <option value="texto">Texto</option>
          <option value="imagem">Imagem</option>
          <option value="pdf">PDF</option>
          <option value="video">Vídeo (preparado, sem player nesta versão)</option>
        </select>
        {tipo === 'texto' && (
          <textarea placeholder="Conteúdo" rows={3} value={conteudoTexto} onChange={(e) => setConteudoTexto(e.target.value)} />
        )}
        {(tipo === 'imagem' || tipo === 'pdf') && (
          <input type="file" onChange={(e) => setFicheiro(e.target.files?.[0] ?? null)} />
        )}
        <button type="submit">Adicionar lição</button>
      </form>

      <ul style={{ listStyle: 'none', padding: 0, marginTop: 8 }}>
        {licoes.map((l) => (
          <li key={l.id} style={{ padding: '4px 0' }}>
            {l.titulo} ({l.tipo}){' '}
            <button onClick={() => setLicaoParaQuiz(licaoParaQuiz === l.id ? null : l.id)}>
              {licaoParaQuiz === l.id ? 'Fechar questionário' : 'Gerir questionário'}
            </button>{' '}
            <button onClick={() => apagarLicao(l.id).then(carregar)}>Apagar</button>
            {licaoParaQuiz === l.id && <GestaoQuestionario licaoId={l.id} />}
          </li>
        ))}
      </ul>
    </div>
  );
}

function GestaoQuestionario({ licaoId }: { licaoId: string }) {
  const [perguntas, setPerguntas] = useState<AcademiaQuestionarioAdminRow[]>([]);
  const [pergunta, setPergunta] = useState('');
  const [opcoes, setOpcoes] = useState(['', '']);
  const [respostaCorreta, setRespostaCorreta] = useState(0);

  async function carregar() {
    setPerguntas(await listarPerguntasAdmin(licaoId));
  }

  useEffect(() => {
    carregar();
  }, [licaoId]);

  async function submeter(e: FormEvent) {
    e.preventDefault();
    await criarPergunta({
      licao_id: licaoId,
      pergunta,
      opcoes: opcoes.filter((o) => o.trim()),
      resposta_correta: respostaCorreta,
      ordem: perguntas.length,
    });
    setPergunta('');
    setOpcoes(['', '']);
    setRespostaCorreta(0);
    carregar();
  }

  return (
    <div style={{ marginTop: 8, marginLeft: 16, background: '#f7f2e6', padding: 8, borderRadius: 6 }}>
      <form onSubmit={submeter} style={{ display: 'flex', flexDirection: 'column', gap: 6, maxWidth: 380 }}>
        <input placeholder="Pergunta" required value={pergunta} onChange={(e) => setPergunta(e.target.value)} />
        {opcoes.map((o, i) => (
          <div key={i} style={{ display: 'flex', gap: 4 }}>
            <input
              placeholder={`Opção ${i + 1}`}
              value={o}
              onChange={(e) => setOpcoes((prev) => prev.map((v, idx) => (idx === i ? e.target.value : v)))}
            />
            <label>
              <input type="radio" checked={respostaCorreta === i} onChange={() => setRespostaCorreta(i)} /> Certa
            </label>
          </div>
        ))}
        <button type="button" onClick={() => setOpcoes((prev) => [...prev, ''])}>
          + Opção
        </button>
        <button type="submit">Guardar pergunta</button>
      </form>
      <ul style={{ listStyle: 'none', padding: 0, marginTop: 8 }}>
        {perguntas.map((p) => (
          <li key={p.id}>
            {p.pergunta} <button onClick={() => apagarPergunta(p.id).then(carregar)}>Apagar</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function AdminAcademia() {
  const { perfil } = useAuth();
  const [cursos, setCursos] = useState<AcademiaCursoRow[]>([]);
  const [titulo, setTitulo] = useState('');
  const [descricao, setDescricao] = useState('');
  const [categoria, setCategoria] = useState('');
  const [cursoExpandido, setCursoExpandido] = useState<string | null>(null);

  async function carregar() {
    setCursos(await listarCursos());
  }

  useEffect(() => {
    carregar();
  }, []);

  async function submeter(e: FormEvent) {
    e.preventDefault();
    await criarCurso({ titulo, descricao, categoria, autor_id: perfil?.id ?? null });
    setTitulo('');
    setDescricao('');
    setCategoria('');
    carregar();
  }

  return (
    <div>
      <h2>Academia AgroLink</h2>
      <form onSubmit={submeter} style={{ display: 'flex', flexDirection: 'column', gap: 8, maxWidth: 480 }}>
        <input placeholder="Título do curso" required value={titulo} onChange={(e) => setTitulo(e.target.value)} />
        <textarea placeholder="Descrição" rows={2} value={descricao} onChange={(e) => setDescricao(e.target.value)} />
        <input placeholder="Categoria" value={categoria} onChange={(e) => setCategoria(e.target.value)} />
        <button type="submit">Criar curso</button>
      </form>

      <ul style={{ listStyle: 'none', padding: 0, marginTop: 16 }}>
        {cursos.map((c) => (
          <li key={c.id} style={{ borderBottom: '1px solid #eee', padding: '8px 0' }}>
            <strong>{c.titulo}</strong>{' '}
            <button onClick={() => setCursoExpandido(cursoExpandido === c.id ? null : c.id)}>
              {cursoExpandido === c.id ? 'Fechar' : 'Gerir lições'}
            </button>{' '}
            <button onClick={() => apagarCurso(c.id).then(carregar)}>Apagar curso</button>
            {cursoExpandido === c.id && <GestaoLicoes cursoId={c.id} />}
          </li>
        ))}
      </ul>
    </div>
  );
}


import { useEffect, useState } from 'react';
import { listarAuditoria } from '@/features/admin/api/adminService';
import type { AuditoriaRow } from '@/shared/types/database.types';

export function AdminAuditoria() {
  const [registos, setRegistos] = useState<AuditoriaRow[]>([]);

  useEffect(() => {
    listarAuditoria().then(setRegistos);
  }, []);

  return (
    <div>
      <h2>Auditoria</h2>
      <p style={{ fontSize: '0.85rem', color: 'var(--color-terra)' }}>
        Registo automático de ações sensíveis (mudanças de estado de conta, verificação de
        técnicos, respostas a relatos). Só admins veem esta lista.
      </p>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.85rem' }}>
        <thead>
          <tr style={{ textAlign: 'left', borderBottom: '2px solid #ddd' }}>
            <th>Data</th>
            <th>Ação</th>
            <th>Entidade</th>
            <th>Detalhes</th>
          </tr>
        </thead>
        <tbody>
          {registos.map((r) => (
            <tr key={r.id} style={{ borderBottom: '1px solid #eee' }}>
              <td>{new Date(r.criado_em).toLocaleString('pt-PT')}</td>
              <td>{r.acao}</td>
              <td>{r.entidade}</td>
              <td>{r.detalhes ? JSON.stringify(r.detalhes) : '—'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

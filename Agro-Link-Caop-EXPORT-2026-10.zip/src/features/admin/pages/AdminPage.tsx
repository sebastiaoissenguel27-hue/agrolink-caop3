
import { useState } from 'react';
import { AdminUtilizadores } from '@/features/admin/components/AdminUtilizadores';
import { AdminNoticias } from '@/features/admin/components/AdminNoticias';
import { AdminFontesNoticias } from '@/features/admin/components/AdminFontesNoticias';
import { AdminAlertas } from '@/features/admin/components/AdminAlertas';
import { AdminEstatisticas } from '@/features/admin/components/AdminEstatisticas';
import { AdminAuditoria } from '@/features/admin/components/AdminAuditoria';
import { AdminRecursos } from '@/features/admin/components/AdminRecursos';
import { AdminBiblioteca } from '@/features/admin/components/AdminBiblioteca';
import { AdminAcademia } from '@/features/admin/components/AdminAcademia';
import { AdminIA } from '@/features/admin/components/AdminIA';
import { AdminMensagens } from '@/features/admin/components/AdminMensagens';
import { AdminDenuncias } from '@/features/admin/components/AdminDenuncias';
import { AdminSeguranca } from '@/features/admin/components/AdminSeguranca';

const ABAS = [
  { id: 'utilizadores', rotulo: 'Utilizadores' },
  { id: 'noticias', rotulo: 'Notícias' },
  { id: 'fontes', rotulo: 'Fontes de notícias' },
  { id: 'alertas', rotulo: 'Alertas' },
  { id: 'recursos', rotulo: 'Centro de Recursos' },
  { id: 'biblioteca', rotulo: 'Biblioteca' },
  { id: 'academia', rotulo: 'Academia' },
  { id: 'ia', rotulo: 'IA Analytics' },
  { id: 'mensagens', rotulo: 'Mensagens' },
  { id: 'denuncias', rotulo: 'Denúncias' },
  { id: 'seguranca', rotulo: 'Segurança' },
  { id: 'estatisticas', rotulo: 'Estatísticas' },
  { id: 'auditoria', rotulo: 'Auditoria' },
] as const;

type AbaId = (typeof ABAS)[number]['id'];

export function AdminPage() {
  const [aba, setAba] = useState<AbaId>('utilizadores');

  return (
    <div style={{ maxWidth: 960, margin: '0 auto' }}>
      <h1>Painel administrativo</h1>
      <div style={{ display: 'flex', gap: 8, marginBottom: 20, flexWrap: 'wrap' }}>
        {ABAS.map((a) => (
          <button
            key={a.id}
            onClick={() => setAba(a.id)}
            style={{ fontWeight: aba === a.id ? 700 : 400 }}
          >
            {a.rotulo}
          </button>
        ))}
      </div>

      {aba === 'utilizadores' && <AdminUtilizadores />}
      {aba === 'noticias' && <AdminNoticias />}
      {aba === 'fontes' && <AdminFontesNoticias />}
      {aba === 'alertas' && <AdminAlertas />}
      {aba === 'recursos' && <AdminRecursos />}
      {aba === 'biblioteca' && <AdminBiblioteca />}
      {aba === 'academia' && <AdminAcademia />}
      {aba === 'ia' && <AdminIA />}
      {aba === 'mensagens' && <AdminMensagens />}
      {aba === 'denuncias' && <AdminDenuncias />}
      {aba === 'seguranca' && <AdminSeguranca />}
      {aba === 'estatisticas' && <AdminEstatisticas />}
      {aba === 'auditoria' && <AdminAuditoria />}
    </div>
  );
}

import { apiGet, apiPost } from '@/shared/lib/apiClient';
import type { DenunciaRow } from '@/shared/types/database.types';
export interface AlvoDenuncia { id:string; nome:string; papel:DenunciaRow['denunciado_papel']; status:string; provincia:string|null; }
export async function pesquisarAlvosDenuncia(pesquisa=''):Promise<AlvoDenuncia[]> { const q=pesquisa?`?pesquisa=${encodeURIComponent(pesquisa)}`:''; return apiGet(`/api/denuncias/alvos${q}`); }
export async function enviarDenuncia(input:{denunciado_id:string;categoria:string;descricao:string;prioridade?:string}) { return apiPost('/api/denuncias',input); }

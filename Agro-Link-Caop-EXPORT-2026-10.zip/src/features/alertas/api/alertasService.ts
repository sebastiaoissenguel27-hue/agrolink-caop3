import { apiGet, apiPost, apiDelete } from '@/shared/lib/apiClient';
import { dbLocal } from '@/offline/db';
import type { AlertaRow, AlertaInsert } from '@/shared/types/database.types';
export async function listarAlertas(provincia?:string|null):Promise<AlertaRow[]>{let todos:AlertaRow[];if(!navigator.onLine)todos=await dbLocal.alertasCache.toArray();else{todos=await apiGet('/api/data/alertas?limit=500');dbLocal.alertasCache.bulkPut(todos);}if(!provincia)return todos;return todos.filter(a=>a.provincias_alvo.length===0||a.provincias_alvo.includes(provincia));}
export async function criarAlerta(a:AlertaInsert){await apiPost('/api/data/alertas',a);}
export async function apagarAlerta(id:string){await apiDelete(`/api/data/alertas?id=${encodeURIComponent(id)}`);}

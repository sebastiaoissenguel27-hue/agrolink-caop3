
import { useEffect, useState } from 'react';
import { useAuth } from '@/features/auth/context/AuthContext';
import { listarAlertas } from '@/features/alertas/api/alertasService';
import type { AlertaRow } from '@/shared/types/database.types';

const COR_NIVEL: Record<string, string> = {
  info: 'var(--color-azul-rio)',
  atencao: 'var(--color-ocre)',
  urgente: 'var(--color-erro)',
};

export function AlertasPage() {
  const { perfil } = useAuth();
  const [alertas, setAlertas] = useState<AlertaRow[]>([]);
  const [aCarregar, setACarregar] = useState(true);

  useEffect(() => {
    listarAlertas(perfil?.provincia)
      .then(setAlertas)
      .finally(() => setACarregar(false));
  }, [perfil?.provincia]);

  return (
    <div style={{ maxWidth: 720, margin: '0 auto' }}>
      <h1>Alertas</h1>
      {!navigator.onLine && <p>Está offline — a mostrar alertas guardados no dispositivo.</p>}
      {aCarregar && <p>A carregar…</p>}
      {!aCarregar && alertas.length === 0 && <p>Sem alertas ativos.</p>}

      {alertas.map((a) => (
        <div
          key={a.id}
          style={{
            borderLeft: `4px solid ${COR_NIVEL[a.nivel]}`,
            padding: '8px 12px',
            marginBottom: 12,
            background: '#fff',
          }}
        >
          <strong>{a.titulo}</strong>{' '}
          <span style={{ fontSize: '0.75rem', color: COR_NIVEL[a.nivel] }}>
            {a.nivel.toUpperCase()}
          </span>
          <p style={{ margin: '4px 0' }}>{a.descricao}</p>
          <small>
            {a.provincias_alvo.length === 0 ? 'Nacional' : a.provincias_alvo.join(', ')} ·{' '}
            {new Date(a.criado_em).toLocaleDateString('pt-PT')}
          </small>
        </div>
      ))}
    </div>
  );
}

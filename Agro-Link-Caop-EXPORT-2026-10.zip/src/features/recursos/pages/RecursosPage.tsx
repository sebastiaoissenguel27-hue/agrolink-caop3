
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { listarRecursos, listarFAQ } from '@/features/recursos/api/recursosService';
import type { RecursoExternoRow, PerguntaFrequenteRow } from '@/shared/types/database.types';

export function RecursosPage() {
  const [recursos, setRecursos] = useState<RecursoExternoRow[]>([]);
  const [faq, setFaq] = useState<PerguntaFrequenteRow[]>([]);
  const [aCarregar, setACarregar] = useState(true);

  useEffect(() => {
    Promise.all([listarRecursos(), listarFAQ()])
      .then(([r, f]) => {
        setRecursos(r);
        setFaq(f);
      })
      .finally(() => setACarregar(false));
  }, []);

  return (
    <div style={{ maxWidth: 720, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 24 }}>
      <h1>Centro de Recursos</h1>
      {!navigator.onLine && <p>Está offline — a mostrar dados guardados no dispositivo.</p>}

      <section>
        <h2>Acesso rápido</h2>
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
          <Link to="/ferramentas">🧮 Ferramentas agrícolas</Link>
          <Link to="/biblioteca">📄 Biblioteca AgroLink</Link>
          <Link to="/academia">🎓 Academia AgroLink</Link>
        </div>
      </section>

      <section>
        <h2>Contactos e links úteis</h2>
        {aCarregar && <p>A carregar…</p>}
        {!aCarregar && recursos.length === 0 && <p>Sem recursos disponíveis no momento.</p>}
        {recursos.map((r) => (
          <div key={r.id} style={{ borderBottom: '1px solid #eee', padding: '8px 0' }}>
            <strong>{r.titulo}</strong>
            {r.categoria && <span style={{ fontSize: '0.75rem', color: 'var(--color-terra)' }}> · {r.categoria}</span>}
            {r.descricao && <p style={{ margin: '4px 0' }}>{r.descricao}</p>}
            {r.url && (
              <a href={r.url} target="_blank" rel="noopener noreferrer">
                Aceder →
              </a>
            )}
            {r.contacto && <p style={{ fontSize: '0.85rem' }}>Contacto: {r.contacto}</p>}
          </div>
        ))}
      </section>

      <section>
        <h2>Perguntas frequentes</h2>
        {faq.map((f) => (
          <details key={f.id} style={{ marginBottom: 8 }}>
            <summary>{f.pergunta}</summary>
            <p>{f.resposta}</p>
          </details>
        ))}
      </section>
    </div>
  );
}

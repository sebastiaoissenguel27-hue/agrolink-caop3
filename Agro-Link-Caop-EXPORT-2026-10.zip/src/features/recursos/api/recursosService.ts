import { apiGet, apiPost, apiDelete } from '@/shared/lib/apiClient';
import type { RecursoExternoRow, RecursoExternoInsert, PerguntaFrequenteRow, PerguntaFrequenteInsert } from '@/shared/types/database.types';
export async function listarRecursos():Promise<RecursoExternoRow[]>{return apiGet('/api/data/recursos_externos?limit=500');}
export async function criarRecurso(r:RecursoExternoInsert){await apiPost('/api/data/recursos_externos',r);}
export async function apagarRecurso(id:string){await apiDelete(`/api/data/recursos_externos?id=${encodeURIComponent(id)}`);}
export async function listarFAQ():Promise<PerguntaFrequenteRow[]>{return apiGet('/api/data/perguntas_frequentes?order=ordem&asc=1&limit=500');}
export async function criarFAQ(r:PerguntaFrequenteInsert){await apiPost('/api/data/perguntas_frequentes',r);}
export async function apagarFAQ(id:string){await apiDelete(`/api/data/perguntas_frequentes?id=${encodeURIComponent(id)}`);}

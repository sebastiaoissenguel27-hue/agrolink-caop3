
import { useEffect, useState } from 'react';
import { listarDocumentos, obterUrlDocumento } from '@/features/biblioteca/api/bibliotecaService';
import type { BibliotecaDocumentoRow } from '@/shared/types/database.types';

const ROTULO_TIPO: Record<string, string> = {
  pdf: '📄 PDF',
  guia: '📘 Guia',
  manual: '📗 Manual',
  outro: '📎 Documento',
};

export function BibliotecaPage() {
  const [documentos, setDocumentos] = useState<BibliotecaDocumentoRow[]>([]);
  const [pesquisa, setPesquisa] = useState('');
  const [categoria, setCategoria] = useState('');
  const [aCarregar, setACarregar] = useState(true);
  const [aAbrir, setAAbrir] = useState<string | null>(null);

  async function carregar() {
    setACarregar(true);
    try {
      setDocumentos(await listarDocumentos({ pesquisa: pesquisa || undefined, categoria: categoria || undefined }));
    } finally {
      setACarregar(false);
    }
  }

  useEffect(() => {
    const t = setTimeout(carregar, 300);
    return () => clearTimeout(t);
  }, [pesquisa, categoria]);

  async function abrir(doc: BibliotecaDocumentoRow) {
    setAAbrir(doc.id);
    try {
      const url = await obterUrlDocumento(doc);
      window.open(url, '_blank', 'noopener,noreferrer');
    } catch {
      alert('Não foi possível abrir o documento agora — pode estar sem rede.');
    } finally {
      setAAbrir(null);
    }
  }

  return (
    <div style={{ maxWidth: 720, margin: '0 auto' }}>
      <h1>Biblioteca AgroLink</h1>
      <p style={{ fontSize: '0.85rem', color: 'var(--color-terra)' }}>
        Documentos, guias e manuais para consulta e download.
      </p>
      {!navigator.onLine && (
        <p>Está offline — a mostrar a lista guardada no dispositivo (os ficheiros exigem rede para abrir).</p>
      )}

      <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        <input placeholder="Pesquisar…" value={pesquisa} onChange={(e) => setPesquisa(e.target.value)} />
        <input placeholder="Categoria" value={categoria} onChange={(e) => setCategoria(e.target.value)} />
      </div>

      {aCarregar && <p>A carregar…</p>}
      {!aCarregar && documentos.length === 0 && <p>Sem documentos para mostrar.</p>}

      <ul style={{ listStyle: 'none', padding: 0 }}>
        {documentos.map((d) => (
          <li key={d.id} style={{ borderBottom: '1px solid #eee', padding: '12px 0' }}>
            <strong>{ROTULO_TIPO[d.tipo]} {d.titulo}</strong>
            {d.categoria && <span style={{ fontSize: '0.75rem', color: 'var(--color-terra)' }}> · {d.categoria}</span>}
            {d.descricao && <p style={{ margin: '4px 0' }}>{d.descricao}</p>}
            <button onClick={() => abrir(d)} disabled={aAbrir === d.id}>
              {aAbrir === d.id ? 'A abrir…' : 'Abrir'}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

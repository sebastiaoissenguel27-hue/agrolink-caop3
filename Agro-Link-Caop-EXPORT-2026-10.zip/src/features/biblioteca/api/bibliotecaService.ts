import { apiGet, apiPost, apiDelete, apiUpload } from '@/shared/lib/apiClient';
import type { BibliotecaDocumentoRow, BibliotecaDocumentoInsert } from '@/shared/types/database.types';
export async function listarDocumentos(filtros:{pesquisa?:string;categoria?:string}={}):Promise<BibliotecaDocumentoRow[]>{const q=new URLSearchParams();if(filtros.pesquisa)q.set('pesquisa',filtros.pesquisa);if(filtros.categoria)q.set('categoria',filtros.categoria);return apiGet(`/api/data/biblioteca_documentos?limit=500&${q}`);}
export async function obterUrlDocumento(doc:BibliotecaDocumentoRow):Promise<string>{if(doc.url_externo)return doc.url_externo;if(!doc.caminho_storage)throw new Error('Documento sem ficheiro.');return `/api/media/${encodeURIComponent(doc.caminho_storage)}`;}
export async function carregarFicheiroBiblioteca(ficheiro:File):Promise<string>{const r=await apiUpload('/api/media/upload/biblioteca',ficheiro);return r.caminho;}
export async function criarDocumento(doc:BibliotecaDocumentoInsert){await apiPost('/api/data/biblioteca_documentos',doc);}
export async function apagarDocumento(id:string){await apiDelete(`/api/data/biblioteca_documentos?id=${encodeURIComponent(id)}`);}

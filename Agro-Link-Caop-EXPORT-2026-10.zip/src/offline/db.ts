
import Dexie, { type Table } from 'dexie';
import type {
  TipoRelato,
  TipoMidia,
  NoticiaRow,
  AlertaRow,
  NomeFerramenta,
  RecursoExternoRow,
  PerguntaFrequenteRow,
  BibliotecaDocumentoRow,
  AcademiaCursoRow,
  AcademiaLicaoRow,
  NotificacaoRow,
} from '@/shared/types/database.types';

export interface RelatoPendente {
  localId: string; // UUID gerado no cliente
  autorId: string | null;
  tipo: TipoRelato;
  descricao: string;
  provincia: string | null;
  municipio: string | null;
  comuna: string | null;
  criadoEm: string;
  sincronizado: boolean;
  emSincronizacao?: boolean;
  erroSincronizacao?: string;
  codigoPublicoObtido?: string;
}

export interface MidiaPendente {
  id?: number; // autoincrement
  serverId?: string;
  relatoLocalId: string;
  tipo: TipoMidia;
  blob: Blob;
  nomeFicheiro: string;
}

export interface MensagemIaCache {
  id?: number;
  utilizadorId: string;
  conversaId: string;
  role: 'user' | 'assistant';
  conteudo: string;
  criadoEm: string;
}

export interface CalculoPendente {
  localId: string;
  utilizadorId: string;
  ferramenta: NomeFerramenta;
  entradas: Record<string, unknown>;
  resultado: Record<string, unknown>;
  criadoEm: string;
  sincronizado: boolean;
}

export interface ProgressoLicaoPendente {
  localId: string;
  utilizadorId: string;
  licaoId: string;
  criadoEm: string;
  sincronizado: boolean;
}

export interface LeituraNotificacaoPendente {
  notificacaoId: string; // chave primária — 1 registo por notificação
  utilizadorId: string;
  sincronizado: boolean;
}

export type NotificacaoCacheRow = NotificacaoRow & { cacheUserId: string };

class AgroLinkDB extends Dexie {
  relatosPendentes!: Table<RelatoPendente, string>;
  midiasPendentes!: Table<MidiaPendente, number>;
  noticiasCache!: Table<NoticiaRow, string>;
  alertasCache!: Table<AlertaRow, string>;
  iaHistoricoCache!: Table<MensagemIaCache, number>;
  calculosPendentes!: Table<CalculoPendente, string>;
  recursosCache!: Table<RecursoExternoRow, string>;
  faqCache!: Table<PerguntaFrequenteRow, string>;
  bibliotecaCache!: Table<BibliotecaDocumentoRow, string>;
  academiaCursosCache!: Table<AcademiaCursoRow, string>;
  academiaLicoesCache!: Table<AcademiaLicaoRow, string>;
  progressoPendente!: Table<ProgressoLicaoPendente, string>;
  notificacoesCache!: Table<NotificacaoCacheRow, string>;
  leiturasPendentes!: Table<LeituraNotificacaoPendente, string>;

  constructor() {
    super('agrolink-caop');
    this.version(1).stores({
      relatosPendentes: 'localId, sincronizado',
      midiasPendentes: '++id, relatoLocalId',
    });
    this.version(2).stores({
      relatosPendentes: 'localId, sincronizado',
      midiasPendentes: '++id, relatoLocalId',
      noticiasCache: 'id, publicado_em, categoria',
      alertasCache: 'id, criado_em, nivel',
      iaHistoricoCache: '++id, conversaId',
    });
    // v3: histórico offline das ferramentas agrícolas.
    this.version(3).stores({
      relatosPendentes: 'localId, sincronizado',
      midiasPendentes: '++id, relatoLocalId',
      noticiasCache: 'id, publicado_em, categoria',
      alertasCache: 'id, criado_em, nivel',
      iaHistoricoCache: '++id, conversaId',
      calculosPendentes: 'localId, sincronizado',
    });
    // v4: cache offline do Centro de Recursos (links externos + FAQ).
    this.version(4).stores({
      relatosPendentes: 'localId, sincronizado',
      midiasPendentes: '++id, relatoLocalId',
      noticiasCache: 'id, publicado_em, categoria',
      alertasCache: 'id, criado_em, nivel',
      iaHistoricoCache: '++id, conversaId',
      calculosPendentes: 'localId, sincronizado',
      recursosCache: 'id, categoria',
      faqCache: 'id, categoria, ordem',
    });
    // v5: cache offline dos metadados da Biblioteca AgroLink (não dos
    // ficheiros PDF em si — só título/descrição/categoria para listagem
    // e pesquisa offline; a transferência do ficheiro exige rede).
    this.version(5).stores({
      relatosPendentes: 'localId, sincronizado',
      midiasPendentes: '++id, relatoLocalId',
      noticiasCache: 'id, publicado_em, categoria',
      alertasCache: 'id, criado_em, nivel',
      iaHistoricoCache: '++id, conversaId',
      calculosPendentes: 'localId, sincronizado',
      recursosCache: 'id, categoria',
      faqCache: 'id, categoria, ordem',
      bibliotecaCache: 'id, categoria, tipo',
    });
    // v6: cache offline de cursos/lições da Academia (texto/imagem/pdf
    // lêem-se offline depois da primeira visita online) + fila de
    // progresso de lições concluídas sem quiz (o quiz exige correção
    // no servidor, por isso não é posto em fila offline — ver iaService
    // e academiaService para a justificação completa).
    this.version(6).stores({
      relatosPendentes: 'localId, sincronizado',
      midiasPendentes: '++id, relatoLocalId',
      noticiasCache: 'id, publicado_em, categoria',
      alertasCache: 'id, criado_em, nivel',
      iaHistoricoCache: '++id, conversaId',
      calculosPendentes: 'localId, sincronizado',
      recursosCache: 'id, categoria',
      faqCache: 'id, categoria, ordem',
      bibliotecaCache: 'id, categoria, tipo',
      academiaCursosCache: 'id, categoria',
      academiaLicoesCache: 'id, curso_id, ordem',
      progressoPendente: 'localId, sincronizado',
    });
    // v7: cache offline de notificações — permite ver/ler notificações
    // já recebidas mesmo sem rede (marcar como lida sincroniza depois).
    this.version(7).stores({
      relatosPendentes: 'localId, sincronizado',
      midiasPendentes: '++id, relatoLocalId',
      noticiasCache: 'id, publicado_em, categoria',
      alertasCache: 'id, criado_em, nivel',
      iaHistoricoCache: '++id, conversaId',
      calculosPendentes: 'localId, sincronizado',
      recursosCache: 'id, categoria',
      faqCache: 'id, categoria, ordem',
      bibliotecaCache: 'id, categoria, tipo',
      academiaCursosCache: 'id, categoria',
      academiaLicoesCache: 'id, curso_id, ordem',
      progressoPendente: 'localId, sincronizado',
      notificacoesCache: 'id, criado_em, lida',
    });
    // v8: fila de marcações "lida" feitas offline, para não se perderem.
    this.version(8).stores({
      relatosPendentes: 'localId, sincronizado',
      midiasPendentes: '++id, relatoLocalId',
      noticiasCache: 'id, publicado_em, categoria',
      alertasCache: 'id, criado_em, nivel',
      iaHistoricoCache: '++id, conversaId',
      calculosPendentes: 'localId, sincronizado',
      recursosCache: 'id, categoria',
      faqCache: 'id, categoria, ordem',
      bibliotecaCache: 'id, categoria, tipo',
      academiaCursosCache: 'id, categoria',
      academiaLicoesCache: 'id, curso_id, ordem',
      progressoPendente: 'localId, sincronizado',
      notificacoesCache: 'id, criado_em, lida',
      leiturasPendentes: 'notificacaoId, sincronizado',
    });
    this.version(9).stores({
      relatosPendentes: 'localId, sincronizado, autorId',
      midiasPendentes: '++id, relatoLocalId',
      noticiasCache: 'id, publicado_em, categoria',
      alertasCache: 'id, criado_em, nivel',
      iaHistoricoCache: '++id, utilizadorId, conversaId',
      calculosPendentes: 'localId, sincronizado, utilizadorId',
      recursosCache: 'id, categoria',
      faqCache: 'id, categoria, ordem',
      bibliotecaCache: 'id, categoria, tipo',
      academiaCursosCache: 'id, categoria',
      academiaLicoesCache: 'id, curso_id, ordem',
      progressoPendente: 'localId, utilizadorId, sincronizado',
      notificacoesCache: 'id, cacheUserId, criado_em, lida',
      leiturasPendentes: 'notificacaoId, utilizadorId, sincronizado',
    });
    this.version(10).stores({
      relatosPendentes: 'localId, sincronizado, autorId',
      midiasPendentes: '++id, relatoLocalId',
      noticiasCache: 'id, publicado_em, categoria',
      alertasCache: 'id, criado_em, nivel',
      iaHistoricoCache: '++id, utilizadorId, conversaId, [utilizadorId+conversaId]',
      calculosPendentes: 'localId, sincronizado, utilizadorId',
      recursosCache: 'id, categoria',
      faqCache: 'id, categoria, ordem',
      bibliotecaCache: 'id, categoria, tipo',
      academiaCursosCache: 'id, categoria',
      academiaLicoesCache: 'id, curso_id, ordem',
      progressoPendente: 'localId, utilizadorId, sincronizado',
      notificacoesCache: 'id, cacheUserId, criado_em, lida, [cacheUserId+id]',
      leiturasPendentes: 'notificacaoId, utilizadorId, sincronizado, [utilizadorId+notificacaoId]',
    }).upgrade(async (transaction) => {
      await transaction.table('notificacoesCache').clear();
    });
  }
}

export const dbLocal = new AgroLinkDB();

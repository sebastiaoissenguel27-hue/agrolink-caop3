import { apiPatch, apiPost, apiUploadBlob } from '@/shared/lib/apiClient';
import { dbLocal, type RelatoPendente } from '@/offline/db';

async function enviarRelato(relato: RelatoPendente, utilizadorId: string) {
  if (relato.autorId !== utilizadorId) return;
  await dbLocal.relatosPendentes.update(relato.localId, { emSincronizacao: true, erroSincronizacao: undefined });
  const result = await apiPost<{ codigo_publico: string }>('/api/data/relatos', {
    id: relato.localId,
    tipo: relato.tipo,
    descricao: relato.descricao,
    provincia: relato.provincia,
    municipio: relato.municipio,
    comuna: relato.comuna,
    criado_em: relato.criadoEm,
  });
  const mediaItems = await dbLocal.midiasPendentes.where('relatoLocalId').equals(relato.localId).toArray();
  for (const media of mediaItems) {
    const mediaId = media.serverId || crypto.randomUUID();
    if (media.id !== undefined && !media.serverId) await dbLocal.midiasPendentes.update(media.id, { serverId: mediaId });
    const filename = media.nomeFicheiro.replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 120);
    const caminho = (await apiUploadBlob('/api/media/upload/relatos', media.blob, filename, mediaId)).caminho;
    await apiPost('/api/data/relato_midias', { id: mediaId, relato_id: relato.localId, tipo: media.tipo, caminho_storage: caminho });
    if (media.id !== undefined) await dbLocal.midiasPendentes.delete(media.id);
  }
  await dbLocal.relatosPendentes.update(relato.localId, {
    sincronizado: true,
    emSincronizacao: false,
    codigoPublicoObtido: result.codigo_publico,
  });
}

export async function sincronizar(utilizadorId: string) {
  if (!utilizadorId || !navigator.onLine) return;
  const pendentes = await dbLocal.relatosPendentes.toCollection().filter((item) => !item.sincronizado && item.autorId === utilizadorId).toArray();
  for (const relato of pendentes) {
    try {
      await enviarRelato(relato, utilizadorId);
    } catch (error) {
      await dbLocal.relatosPendentes.update(relato.localId, {
        emSincronizacao: false,
        erroSincronizacao: error instanceof Error ? error.message : 'Erro desconhecido',
      });
    }
  }
}

export async function sincronizarAnonimos(localId?: string) {
  if (!navigator.onLine) return;
  const query = dbLocal.relatosPendentes.toCollection().filter((item) => !item.sincronizado && item.autorId === null && (!localId || item.localId === localId));
  for (const relato of await query.toArray()) {
    const media = await dbLocal.midiasPendentes.where('relatoLocalId').equals(relato.localId).count();
    if (media) {
      await dbLocal.relatosPendentes.update(relato.localId, { erroSincronizacao: 'Relatos anónimos não podem sincronizar anexos; entre na conta para enviar mídia.' });
      continue;
    }
    try {
      await dbLocal.relatosPendentes.update(relato.localId, { emSincronizacao: true, erroSincronizacao: undefined });
      const result = await apiPost<{ codigo_publico: string }>('/api/data/relatos', {
        id: relato.localId, tipo: relato.tipo, descricao: relato.descricao,
        provincia: relato.provincia, municipio: relato.municipio, comuna: relato.comuna,
        criado_em: relato.criadoEm,
      });
      await dbLocal.relatosPendentes.update(relato.localId, { sincronizado: true, emSincronizacao: false, codigoPublicoObtido: result.codigo_publico });
    } catch (error) {
      await dbLocal.relatosPendentes.update(relato.localId, { emSincronizacao: false, erroSincronizacao: error instanceof Error ? error.message : 'Erro desconhecido' });
    }
  }
}

export function iniciarSyncAutomatico(utilizadorId: string) {
  const sync = () => void sincronizarTudo(utilizadorId);
  window.addEventListener('online', sync);
  sync();
  return () => window.removeEventListener('online', sync);
}

export async function sincronizarCalculos(utilizadorId: string) {
  if (!utilizadorId || !navigator.onLine) return;
  const pendentes = await dbLocal.calculosPendentes.toCollection().filter((item) => !item.sincronizado && item.utilizadorId === utilizadorId).toArray();
  for (const calculation of pendentes) {
    try {
      await apiPost('/api/data/ferramenta_calculos', {
        utilizador_id: utilizadorId,
        ferramenta: calculation.ferramenta,
        entradas: calculation.entradas,
        resultado: calculation.resultado,
      });
      await dbLocal.calculosPendentes.update(calculation.localId, { sincronizado: true });
    } catch {}
  }
}

export async function sincronizarProgresso(utilizadorId: string) {
  if (!utilizadorId || !navigator.onLine) return;
  const pendentes = await dbLocal.progressoPendente.toCollection().filter((item) => !item.sincronizado && item.utilizadorId === utilizadorId).toArray();
  for (const item of pendentes) {
    try {
      await apiPost('/api/academia/concluir', { licaoId: item.licaoId });
      await dbLocal.progressoPendente.update(item.localId, { sincronizado: true });
    } catch {}
  }
}

export async function sincronizarLeiturasNotificacoes(utilizadorId: string) {
  if (!utilizadorId || !navigator.onLine) return;
  const pendentes = await dbLocal.leiturasPendentes.toCollection().filter((item) => !item.sincronizado && item.utilizadorId === utilizadorId).toArray();
  for (const item of pendentes) {
    try {
      await apiPatch(`/api/data/notificacoes?id=${encodeURIComponent(item.notificacaoId)}`, { lida: true });
      await dbLocal.leiturasPendentes.update(item.notificacaoId, { sincronizado: true });
    } catch {}
  }
}

export async function sincronizarTudo(utilizadorId: string) {
  await sincronizar(utilizadorId);
  await sincronizarCalculos(utilizadorId);
  await sincronizarProgresso(utilizadorId);
  await sincronizarLeiturasNotificacoes(utilizadorId);
}
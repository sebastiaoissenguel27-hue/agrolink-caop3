
import type { ReactNode } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '@/features/auth/context/AuthContext';
import type { PapelUtilizador, TipoPerfilProfissional } from '@/shared/types/database.types';

interface Props {
  children: ReactNode;
  papeisPermitidos?: PapelUtilizador[];
  tiposPerfilPermitidos?: TipoPerfilProfissional[];
}

export function ProtectedRoute({ children, papeisPermitidos, tiposPerfilPermitidos }: Props) {
  const { sessao, perfil, carregando } = useAuth();

  if (carregando) {
    return <div style={{ padding: 24 }}>A carregar…</div>;
  }

  if (!sessao) {
    return <Navigate to="/entrar" replace />;
  }

  if (perfil?.status === 'bloqueado') {
    return <Navigate to="/conta-bloqueada" replace />;
  }

  if (perfil?.status === 'pendente') {
    return <Navigate to="/conta-pendente" replace />;
  }

  if (papeisPermitidos && perfil && !papeisPermitidos.includes(perfil.papel)) {
    return <Navigate to="/acesso-negado" replace />;
  }
  if (tiposPerfilPermitidos && perfil && (!perfil.tipo_perfil || !tiposPerfilPermitidos.includes(perfil.tipo_perfil))) {
    return <Navigate to="/acesso-negado" replace />;
  }

  return <>{children}</>;
}

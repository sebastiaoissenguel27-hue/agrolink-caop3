
import type { ReactNode } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider, useAuth } from '@/features/auth/context/AuthContext';
import { LanguageProvider } from '@/shared/i18n/LanguageContext';
import { LoginPage } from '@/features/auth/pages/LoginPage';
import { RegisterPage } from '@/features/auth/pages/RegisterPage';
import { ForgotPasswordPage } from '@/features/auth/pages/ForgotPasswordPage';
import { ResetPasswordPage } from '@/features/auth/pages/ResetPasswordPage';
import { ProtectedRoute } from '@/app/ProtectedRoute';
import { AppLayout } from '@/app/components/AppLayout';
import { HomePage } from '@/app/pages/HomePage';
import { PerfilPage } from '@/app/pages/PerfilPage';
import { AcessoNegadoPage } from '@/app/pages/AcessoNegadoPage';
import { ContaPendentePage } from '@/app/pages/ContaPendentePage';
import { ContaBloqueadaPage } from '@/app/pages/ContaBloqueadaPage';
import { RelatosPage } from '@/features/relatos/pages/RelatosPage';
import { RelatoAnonimoPage } from '@/features/relatos/pages/RelatoAnonimoPage';
import { InstitucionalPage } from '@/app/pages/InstitucionalPage';
import { TecnicoPage } from '@/features/tecnico/pages/TecnicoPage';
import { AdminPage } from '@/features/admin/pages/AdminPage';
import { NoticiasPage } from '@/features/noticias/pages/NoticiasPage';
import { MercadoPage } from '@/features/mercado/pages/MercadoPage';
import { LogisticaPage } from '@/features/logistica/pages/LogisticaPage';
import { AlertasPage } from '@/features/alertas/pages/AlertasPage';
import { IAChatPage } from '@/features/ia-agricola/pages/IAChatPage';
import { ConfiguracoesPage } from '@/features/configuracoes/pages/ConfiguracoesPage';
import { FerramentasPage } from '@/features/ferramentas/pages/FerramentasPage';
import { RecursosPage } from '@/features/recursos/pages/RecursosPage';
import { BibliotecaPage } from '@/features/biblioteca/pages/BibliotecaPage';
import { AcademiaPage } from '@/features/academia/pages/AcademiaPage';
import { CursoDetalhePage } from '@/features/academia/pages/CursoDetalhePage';
import { EscolhaPaisPage } from '@/features/pais/pages/EscolhaPaisPage';
import { VisitanteLandingPage } from '@/features/visitante/pages/VisitanteLandingPage';
import { VisitanteOfflinePage } from '@/features/visitante/pages/VisitanteOfflinePage';
import { ManualPage } from '@/features/manual/pages/ManualPage';
import { DenunciaPage } from '@/features/denuncias/pages/DenunciaPage';
import { PaginaNaoEncontradaPage } from '@/app/pages/PaginaNaoEncontradaPage';
import { obterPaisSelecionado } from '@/shared/lib/country';
import { Logo } from '@/shared/components/Logo';
import type { PapelUtilizador } from '@/shared/types/database.types';

function AuthHashErrorState() {
  const rawUrl = typeof window !== 'undefined' ? window.location.href : '';
  const url = new URL(rawUrl);
  const hashParams = new URLSearchParams(url.hash.startsWith('#') ? url.hash.slice(1) : url.hash);
  const queryParams = new URLSearchParams(url.search);

  const error = hashParams.get('error') ?? queryParams.get('error');
  const errorCode = hashParams.get('error_code') ?? queryParams.get('error_code');
  const errorDescription = hashParams.get('error_description') ?? queryParams.get('error_description');

  if (!error && !errorCode && !errorDescription) return null;

  const e = (error ?? errorCode ?? '').toLowerCase();
  const bloqueioConfirmacao =
    e.includes('access_denied') ||
    e.includes('otp_expired') ||
    e.includes('invalid_token') ||
    e.includes('expired') ||
    e.includes('expired_token');

  if (bloqueioConfirmacao) {
    return (
      <div
        style={{
          minHeight: '100vh',
          display: 'grid',
          placeItems: 'center',
          padding: 24,
          fontFamily: 'system-ui, sans-serif',
          color: '#1f3d2b',
          background: '#f7f5ef',
          textAlign: 'center',
        }}
      >
        <div style={{ maxWidth: 520 }}>
          <h1 style={{ margin: 0, fontSize: '1.5rem' }}>Ligação de confirmação inválida ou expirada</h1>
          <p style={{ marginTop: 12, marginBottom: 0, lineHeight: 1.6 }}>
            O link de confirmação expirou, foi usado antes ou foi bloqueado por segurança. Peça um novo email para concluir o registo e tente de novo.
          </p>
          {errorDescription && (
            <p style={{ marginTop: 12, color: '#4d5d50', fontSize: '0.95rem' }}>{errorDescription}</p>
          )}
        </div>
      </div>
    );
  }

  return null;
}

/**
 * Combina ProtectedRoute (autenticação + papel + status da conta) com
 * o AppLayout (navegação, sino de notificações, indicador de sync) —
 * evita repetir os dois em cada rota autenticada.
 */
function Autenticado({
  children,
  papeisPermitidos,
  tiposPerfilPermitidos,
}: {
  children: ReactNode;
  papeisPermitidos?: PapelUtilizador[];
  tiposPerfilPermitidos?: import('@/shared/types/database.types').TipoPerfilProfissional[];
}) {
  return (
    <ProtectedRoute papeisPermitidos={papeisPermitidos} tiposPerfilPermitidos={tiposPerfilPermitidos}>
      <AppLayout>{children}</AppLayout>
    </ProtectedRoute>
  );
}

function RootGate() {
  const { sessao, carregando } = useAuth();

  if (carregando) {
    return <div style={{ minHeight: '100vh', display: 'grid', placeItems: 'center', padding: 24 }}><Logo size="lg" /></div>;
  }

  if (sessao) {
    return <Autenticado><HomePage /></Autenticado>;
  }

  const paisSelecionado = obterPaisSelecionado();
  if (paisSelecionado) {
    return <VisitanteLandingPage />;
  }

  return <EscolhaPaisPage />;
}

export function App() {
  const hashErrorState = AuthHashErrorState();
  if (hashErrorState) {
    return hashErrorState;
  }

  return (
    <AuthProvider>
      <LanguageProvider>
        <BrowserRouter>
        <Routes>
          {/* Público — sem sessão */}
          <Route path="/" element={<RootGate />} />
          <Route path="/pais" element={<EscolhaPaisPage />} />
          <Route path="/visitante" element={<VisitanteLandingPage />} />
          <Route path="/visitante-offline" element={<VisitanteOfflinePage />} />
          <Route path="/manual" element={<ManualPage />} />
          <Route path="/entrar" element={<LoginPage />} />
          <Route path="/registar" element={<RegisterPage />} />
          <Route path="/esqueci-password" element={<ForgotPasswordPage />} />
          <Route path="/redefinir-password" element={<ResetPasswordPage />} />
          <Route path="/relato-anonimo" element={<RelatoAnonimoPage />} />
          <Route path="/sobre" element={<InstitucionalPage />} />

          {/* Destinos de bloqueio do ProtectedRoute — nunca ficam dentro do AppLayout,
              porque são precisamente para onde se vai quando o acesso normal falha. */}
          <Route path="/acesso-negado" element={<AcessoNegadoPage />} />
          <Route path="/conta-pendente" element={<ContaPendentePage />} />
          <Route path="/conta-bloqueada" element={<ContaBloqueadaPage />} />

          {/* Autenticado — qualquer papel */}
          <Route path="/perfil" element={<Autenticado><PerfilPage /></Autenticado>} />
          <Route path="/noticias" element={<Autenticado><NoticiasPage /></Autenticado>} />
          <Route path="/mercado" element={<Autenticado papeisPermitidos={['utilizador','admin','admin_chefe']}><MercadoPage /></Autenticado>} />
          <Route path="/logistica" element={<Autenticado papeisPermitidos={['utilizador','admin','admin_chefe']}><LogisticaPage /></Autenticado>} />
          <Route path="/alertas" element={<Autenticado><AlertasPage /></Autenticado>} />
          <Route path="/assistente" element={<Autenticado><IAChatPage /></Autenticado>} />
          <Route path="/configuracoes" element={<Autenticado><ConfiguracoesPage /></Autenticado>} />
          <Route path="/denunciar" element={<Autenticado><DenunciaPage /></Autenticado>} />
          <Route path="/ferramentas" element={<Autenticado><FerramentasPage /></Autenticado>} />
          <Route path="/recursos" element={<Autenticado><RecursosPage /></Autenticado>} />
          <Route path="/biblioteca" element={<Autenticado><BibliotecaPage /></Autenticado>} />
          <Route path="/academia" element={<Autenticado><AcademiaPage /></Autenticado>} />
          <Route path="/academia/:cursoId" element={<Autenticado><CursoDetalhePage /></Autenticado>} />

          {/* Autenticado — papel específico */}
          <Route
            path="/relatos"
            element={
              <Autenticado papeisPermitidos={['utilizador']} tiposPerfilPermitidos={['agricultor']}>
                <RelatosPage />
              </Autenticado>
            }
          />
          <Route
            path="/tecnico"
            element={
              <Autenticado papeisPermitidos={['utilizador']} tiposPerfilPermitidos={['tecnico']}>
                <TecnicoPage />
              </Autenticado>
            }
          />
          <Route
            path="/admin"
            element={
              <Autenticado papeisPermitidos={['admin','admin_chefe']}>
                <AdminPage />
              </Autenticado>
            }
          />
          <Route path="*" element={<PaginaNaoEncontradaPage />} />
        </Routes>
      </BrowserRouter>
      </LanguageProvider>
    </AuthProvider>
  );
}

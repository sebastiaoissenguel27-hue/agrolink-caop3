
import { useLiveQuery } from 'dexie-react-hooks';
import { dbLocal } from '@/offline/db';
import { sincronizar } from '@/offline/syncEngine';
import { useAuth } from '@/features/auth/context/AuthContext';

export function SyncBadge() {
  const { perfil } = useAuth();
  const pendentes = useLiveQuery(
    () => perfil ? dbLocal.relatosPendentes.toCollection().filter((item) => !item.sincronizado && item.autorId === perfil.id).count() : 0,
    [perfil?.id]
  );

  if (!pendentes) return null;

  return (
    <button
      onClick={() => perfil && sincronizar(perfil.id)}
      title="Clique para tentar sincronizar agora"
      aria-label={`${pendentes} relato${pendentes > 1 ? 's' : ''} por sincronizar — clique para tentar agora`}
    >
      ⏳ {pendentes} por sincronizar
    </button>
  );
}

import { useEffect, useState } from 'react';
import { Button } from '@/shared/components/Button';

export function AtualizacaoDisponivel() {
  const [visivel, setVisivel] = useState(false);

  useEffect(() => {
    const onUpdate = () => setVisivel(true);
    window.addEventListener('agrolink:pwa-update', onUpdate);
    return () => window.removeEventListener('agrolink:pwa-update', onUpdate);
  }, []);

  if (!visivel) return null;

  return (
    <div className="al-update-banner" role="status">
      <span>Há uma atualização disponível.</span>
      <Button
        type="button"
        variant="secondary"
        onClick={() => window.location.reload()}
      >
        Atualizar
      </Button>
      <button type="button" className="al-update-dismiss" onClick={() => setVisivel(false)}>
        Dispensar
      </button>
    </div>
  );
}

import { useEffect, useState } from 'react';
import { useAuth } from '@/features/auth/context/AuthContext';
import {
  listarNotificacoes,
  marcarNotificacaoLida,
  ouvirNovasNotificacoes,
} from '@/shared/api/notificacoesService';
import type { NotificacaoRow } from '@/shared/types/database.types';

export function NotificationBell() {
  const { perfil } = useAuth();
  const [notificacoes, setNotificacoes] = useState<NotificacaoRow[]>([]);
  const [aberto, setAberto] = useState(false);

  async function carregar() {
    if (perfil) setNotificacoes(await listarNotificacoes(perfil.id));
  }

  useEffect(() => {
    if (!perfil) return;
    carregar();
    return ouvirNovasNotificacoes(perfil.id, carregar);
  }, [perfil?.id]);

  const naoLidas = notificacoes.filter((n) => !n.lida).length;

  async function abrir() {
    setAberto((v) => !v);
  }

  async function marcarLida(id: string) {
    if (!perfil) return;
    await marcarNotificacaoLida(perfil.id, id);
    setNotificacoes((prev) => prev.map((n) => (n.id === id ? { ...n, lida: true } : n)));
  }

  return (
    <div style={{ position: 'relative' }}>
      <button onClick={abrir} aria-label={`Notificações${naoLidas > 0 ? `, ${naoLidas} por ler` : ''}`} aria-expanded={aberto}>
        🔔 {naoLidas > 0 && <span aria-hidden="true">({naoLidas})</span>}
      </button>
      {aberto && (
        <div
          style={{
            position: 'absolute',
            right: 0,
            background: 'var(--color-branco)',
            border: '1px solid #ddd',
            borderRadius: 8,
            width: 280,
            maxHeight: 360,
            overflowY: 'auto',
            zIndex: 10,
          }}
        >
          {notificacoes.length === 0 && <p style={{ padding: 12 }}>Sem notificações.</p>}
          {notificacoes.map((n) => (
            <div
              key={n.id}
              onClick={() => marcarLida(n.id)}
              style={{
                padding: 10,
                borderBottom: '1px solid #eee',
                background: n.lida ? 'transparent' : '#f7f2e6',
                cursor: 'pointer',
              }}
            >
              <strong>{n.titulo}</strong>
              <p style={{ margin: '4px 0 0 0', fontSize: '0.85rem' }}>{n.corpo}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

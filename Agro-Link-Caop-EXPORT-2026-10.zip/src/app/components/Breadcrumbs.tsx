import { Link } from 'react-router-dom';

export interface BreadcrumbItem {
  label: string;
  to?: string;
}

export function Breadcrumbs({ itens }: { itens: BreadcrumbItem[] }) {
  return (
    <nav className="al-breadcrumbs" aria-label="Breadcrumb">
      {itens.map((item, index) => (
        <span key={`${item.label}-${index}`}>
          {index > 0 && <span aria-hidden="true"> / </span>}
          {item.to && index < itens.length - 1 ? <Link to={item.to}>{item.label}</Link> : item.label}
        </span>
      ))}
    </nav>
  );
}
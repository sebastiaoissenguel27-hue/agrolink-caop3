import { Button } from '@/shared/components/Button';

interface ConfirmDialogProps {
  aberto: boolean;
  titulo: string;
  mensagem: string;
  confirmarLabel?: string;
  onConfirmar: () => void;
  onCancelar: () => void;
}

export function ConfirmDialog({
  aberto,
  titulo,
  mensagem,
  confirmarLabel = 'Confirmar',
  onConfirmar,
  onCancelar,
}: ConfirmDialogProps) {
  if (!aberto) return null;

  return (
    <div className="al-dialog-backdrop" role="presentation" onClick={onCancelar}>
      <div
        className="al-dialog"
        role="dialog"
        aria-modal="true"
        aria-labelledby="al-dialog-title"
        onClick={(event) => event.stopPropagation()}
      >
        <h2 id="al-dialog-title">{titulo}</h2>
        <p>{mensagem}</p>
        <div className="al-dialog-actions">
          <Button type="button" variant="secondary" onClick={onCancelar}>Cancelar</Button>
          <Button type="button" variant="danger" onClick={onConfirmar}>{confirmarLabel}</Button>
        </div>
      </div>
    </div>
  );
}
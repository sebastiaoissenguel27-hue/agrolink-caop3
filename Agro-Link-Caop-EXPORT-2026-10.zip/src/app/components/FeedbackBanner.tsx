import { useEffect } from 'react';

export function FeedbackBanner({
  mensagem,
  tipo = 'info',
  onFechar,
}: {
  mensagem: string | null;
  tipo?: 'info' | 'sucesso' | 'erro';
  onFechar?: () => void;
}) {
  useEffect(() => {
    if (!mensagem || !onFechar) return;
    const timer = window.setTimeout(onFechar, 5000);
    return () => window.clearTimeout(timer);
  }, [mensagem, onFechar]);

  if (!mensagem) return null;

  return (
    <div className={`al-feedback al-feedback-${tipo}`} role={tipo === 'erro' ? 'alert' : 'status'}>
      <span>{mensagem}</span>
      {onFechar && <button type="button" onClick={onFechar} aria-label="Fechar aviso">×</button>}
    </div>
  );
}
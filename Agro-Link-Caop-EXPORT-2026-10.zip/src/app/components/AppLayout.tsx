
import type { ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/features/auth/context/AuthContext';
import { terminarSessao } from '@/features/auth/api/authService';
import { AppHeader } from '@/app/components/AppHeader';
import { AtualizacaoDisponivel } from '@/app/components/AtualizacaoDisponivel';
import { BottomNav } from '@/shared/components/BottomNav';
import './layout.css';

const NAV_POR_PAPEL: Record<string, { to: string; rotulo: string }[]> = {
  agricultor: [
    { to: '/', rotulo: 'Início' },
    { to: '/relatos', rotulo: 'Meus relatos' },
    { to: '/ferramentas', rotulo: 'Ferramentas' },
    { to: '/recursos', rotulo: 'Recursos' },
    { to: '/biblioteca', rotulo: 'Biblioteca' },
    { to: '/academia', rotulo: 'Academia' },
    { to: '/noticias', rotulo: 'Notícias' },
    { to: '/mercado', rotulo: 'Mercado' },
    { to: '/logistica', rotulo: 'Logística' },
    { to: '/alertas', rotulo: 'Alertas' },
    { to: '/assistente', rotulo: 'Assistente IA' },
    { to: '/configuracoes', rotulo: 'Configurações' },
    { to: '/denunciar', rotulo: 'Denunciar' },
  ],
  tecnico: [
    { to: '/', rotulo: 'Início' },
    { to: '/tecnico', rotulo: 'Relatos de todas as províncias' },
    { to: '/ferramentas', rotulo: 'Ferramentas' },
    { to: '/recursos', rotulo: 'Recursos' },
    { to: '/biblioteca', rotulo: 'Biblioteca' },
    { to: '/academia', rotulo: 'Academia' },
    { to: '/noticias', rotulo: 'Notícias' },
    { to: '/mercado', rotulo: 'Mercado' },
    { to: '/logistica', rotulo: 'Logística' },
    { to: '/alertas', rotulo: 'Alertas' },
    { to: '/assistente', rotulo: 'Assistente IA' },
    { to: '/configuracoes', rotulo: 'Configurações' },
    { to: '/denunciar', rotulo: 'Denunciar' },
  ],
  admin: [
    { to: '/', rotulo: 'Início' },
    { to: '/admin', rotulo: 'Painel administrativo' },
    { to: '/recursos', rotulo: 'Recursos' },
    { to: '/biblioteca', rotulo: 'Biblioteca' },
    { to: '/academia', rotulo: 'Academia' },
    { to: '/noticias', rotulo: 'Notícias' },
    { to: '/mercado', rotulo: 'Mercado' },
    { to: '/logistica', rotulo: 'Logística' },
    { to: '/alertas', rotulo: 'Alertas' },
    { to: '/configuracoes', rotulo: 'Configurações' },
    { to: '/denunciar', rotulo: 'Denunciar' },
  ],
};

NAV_POR_PAPEL.admin_chefe = NAV_POR_PAPEL.admin;

export function AppLayout({ children }: { children: ReactNode }) {
  const { perfil } = useAuth();
  const navigate = useNavigate();
  const chaveNav = perfil?.papel === 'utilizador'
    ? perfil.tipo_perfil === 'tecnico' ? 'tecnico' : 'agricultor'
    : perfil?.papel === 'admin' ? 'admin' : perfil?.papel === 'admin_chefe' ? 'admin_chefe' : '';
  const itensNav = chaveNav ? NAV_POR_PAPEL[chaveNav] ?? [] : [];

  async function sair() {
    await terminarSessao();
    navigate('/entrar');
  }

  return (
    <div className="app-shell">
      <AppHeader itensNav={itensNav} onSair={sair} />
      <main className="app-conteudo">{children}</main>
      <BottomNav
        itens={itensNav.slice(0, 5).map((item) => ({
          to: item.to,
          rotulo: item.rotulo,
        }))}
      />
      <AtualizacaoDisponivel />
    </div>
  );
}

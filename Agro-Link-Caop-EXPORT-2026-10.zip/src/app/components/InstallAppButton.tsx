import { useEffect, useState } from 'react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

export function InstallAppButton() {
  const [evento, setEvento] = useState<BeforeInstallPromptEvent | null>(null);
  const [instalada, setInstalada] = useState(false);
  const [ios, setIos] = useState(false);

  useEffect(() => {
    const apple = /iphone|ipad|ipod/i.test(window.navigator.userAgent);
    const standalone = window.matchMedia('(display-mode: standalone)').matches;
    setIos(apple && !standalone);
    const onBeforeInstall = (event: Event) => {
      event.preventDefault();
      setEvento(event as BeforeInstallPromptEvent);
    };
    const onInstalled = () => {
      setInstalada(true);
      setEvento(null);
    };
    window.addEventListener('beforeinstallprompt', onBeforeInstall);
    window.addEventListener('appinstalled', onInstalled);
    return () => {
      window.removeEventListener('beforeinstallprompt', onBeforeInstall);
      window.removeEventListener('appinstalled', onInstalled);
    };
  }, []);

  if (instalada) return null;

  async function instalar() {
    if (!evento) return;
    await evento.prompt();
    const escolha = await evento.userChoice;
    if (escolha.outcome === 'accepted') setEvento(null);
  }

  if (evento) {
    return <button type="button" onClick={instalar}>Instalar app</button>;
  }

  if (!ios) return null;

  return <span className="app-install-help" title="Use Partilhar e Adicionar ao ecrã principal.">Adicionar ao ecrã</span>;
}

import { useNavigate } from 'react-router-dom';

export function BackButton() {
  const navigate = useNavigate();

  return (
    <button
      type="button"
      onClick={() => navigate(-1)}
      aria-label="Voltar à página anterior"
      style={{
        minHeight: 40,
        border: '1px solid #d7e3d2',
        borderRadius: 10,
        background: '#fff',
        color: '#1f3d2b',
        padding: '0 12px',
        fontSize: 15,
        fontWeight: 700,
        cursor: 'pointer',
      }}
    >
      ← Voltar
    </button>
  );
}

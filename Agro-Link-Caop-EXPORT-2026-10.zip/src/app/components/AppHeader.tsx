import { Link, NavLink } from 'react-router-dom';
import { BackButton } from './BackButton';
import { NotificationBell } from './NotificationBell';
import { SyncBadge } from './SyncBadge';
import { InstallAppButton } from './InstallAppButton';
import { Logo } from '@/shared/components/Logo';

export interface AppHeaderItem {
  to: string;
  rotulo: string;
}

export function AppHeader({
  itensNav,
  onSair,
}: {
  itensNav: AppHeaderItem[];
  onSair: () => void;
}) {
  return (
    <header className="app-header">
      <BackButton />
      <Link to="/" className="app-marca" aria-label="Ir para o início">
        <Logo size="sm" />
      </Link>
      <nav className="app-nav" aria-label="Navegação principal">
        {itensNav.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) => (isActive ? 'is-active' : undefined)}
          >
            {item.rotulo}
          </NavLink>
        ))}
      </nav>
      <div className="app-header-acoes">
        <SyncBadge />
        <NotificationBell />
        <InstallAppButton />
        <Link to="/perfil">Perfil</Link>
        <button type="button" onClick={onSair}>Sair</button>
      </div>
    </header>
  );
}
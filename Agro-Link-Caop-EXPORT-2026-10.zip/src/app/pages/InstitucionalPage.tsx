
import { Link } from 'react-router-dom';
import { Logo } from '@/shared/components/Logo';
import { PageContainer } from '@/shared/components/PageContainer';

/**
 * Site institucional e PWA partilham deliberadamente o mesmo projeto
 * React e o mesmo router — não há uma aplicação separada. Esta página
 * é o ponto de entrada público (sem sessão); tudo o resto da app já
 * funciona no navegador tal como no telemóvel instalado, porque é a
 * mesma PWA em ambos os casos.
 */
export function InstitucionalPage() {
  return (
    <PageContainer className="al-public-page">
      <Logo size="lg" />
      <h1>AgroLink Caop</h1>
      <p>
        Uma plataforma angolana que liga agricultores, técnicos e administradores — relatos
        agrícolas, apoio técnico, notícias, alertas, um assistente de IA especializado em
        agricultura angolana, e recursos de formação.
      </p>
      <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap', marginTop: 24 }}>
        <Link to="/entrar" className="al-btn al-btn-primary">Entrar</Link>
        <Link to="/registar" className="al-btn al-btn-secondary">Criar conta</Link>
        <Link to="/relato-anonimo" className="al-btn al-btn-secondary">Reportar sem criar conta</Link>
      </div>
    </PageContainer>
  );
}

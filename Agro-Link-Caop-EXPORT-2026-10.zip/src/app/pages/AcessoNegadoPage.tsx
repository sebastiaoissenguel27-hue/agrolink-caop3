
export function AcessoNegadoPage() {
  return (
    <div style={{ padding: 24 }}>
      <h1>Acesso negado</h1>
      <p>Não tem permissão para aceder a esta área da plataforma.</p>
    </div>
  );
}

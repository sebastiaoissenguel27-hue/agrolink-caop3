import { useAuth } from '@/features/auth/context/AuthContext';

export function ContaBloqueadaPage() {
  const { perfil } = useAuth();
  return (
    <div style={{ padding: 24, maxWidth: 640, margin: '0 auto' }}>
      <h1>Conta suspensa</h1>
      <p>O acesso a esta conta foi suspenso pelo administrador-chefe do AgroLink Caop.</p>
      {perfil?.motivo_suspensao && (
        <div style={{ border: '1px solid #ddd', borderRadius: 8, padding: 12, marginTop: 12 }}>
          <strong>Motivo informado:</strong>
          <p style={{ whiteSpace: 'pre-wrap' }}>{perfil.motivo_suspensao}</p>
        </div>
      )}
      <p>Se considera que a suspensão foi um engano, contacte a equipa do AgroLink Caop por um canal oficial.</p>
    </div>
  );
}

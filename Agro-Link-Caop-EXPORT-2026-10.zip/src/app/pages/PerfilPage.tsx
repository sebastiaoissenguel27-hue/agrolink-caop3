
import { useState, type FormEvent } from 'react';
import { useAuth } from '@/features/auth/context/AuthContext';
import { atualizarPerfilProprio } from '@/features/auth/api/authService';

const NOME_PAPEL: Record<string, string> = { utilizador: 'Utilizador', admin: 'Administrador', admin_chefe: 'Administrador Chefe' };
const NOME_TIPO: Record<string, string> = { agricultor: 'Agricultor', tecnico: 'Técnico', administrador: 'Administrador' };

export function PerfilPage() {
  const { perfil, recarregarPerfil } = useAuth();
  const [nome, setNome] = useState(perfil?.nome ?? '');
  const [provincia, setProvincia] = useState(perfil?.provincia ?? '');
  const [municipio, setMunicipio] = useState(perfil?.municipio ?? '');
  const [comuna, setComuna] = useState(perfil?.comuna ?? '');
  const [telefone, setTelefone] = useState(perfil?.telefone ?? '');
  const [aGuardar, setAGuardar] = useState(false);
  const [mensagem, setMensagem] = useState<string | null>(null);

  async function submeter(e: FormEvent) {
    e.preventDefault();
    setAGuardar(true);
    setMensagem(null);
    try {
      await atualizarPerfilProprio({ nome, provincia, municipio, comuna, telefone });
      await recarregarPerfil();
      setMensagem('Perfil atualizado.');
    } catch {
      setMensagem('Não foi possível guardar as alterações.');
    } finally {
      setAGuardar(false);
    }
  }

  if (!perfil) return <p>A carregar…</p>;

  return (
    <div style={{ maxWidth: 480, margin: '0 auto' }}>
      <h1>O meu perfil</h1>

      <p>
        Autorização: <strong>{perfil.papel === 'admin' && perfil.nivel_admin === 'auditor' ? 'Auditor' : NOME_PAPEL[perfil.papel]}</strong> · Perfil profissional: <strong>{perfil.tipo_perfil ? NOME_TIPO[perfil.tipo_perfil] : '—'}</strong> · Estado da conta:{' '}
        <strong>{perfil.status}</strong>
        {perfil.tipo_perfil === 'tecnico' && (
          <>
            {' '}
            · Verificação profissional: <strong>{perfil.verification_status}</strong>
          </>
        )}
      </p>

      {mensagem && <div>{mensagem}</div>}

      <form onSubmit={submeter} style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        <label>
          Nome
          <input value={nome} onChange={(e) => setNome(e.target.value)} required />
        </label>
        <label>
          Telefone
          <input value={telefone} onChange={(e) => setTelefone(e.target.value)} />
        </label>
        <label>
          Província
          <input value={provincia} onChange={(e) => setProvincia(e.target.value)} />
        </label>
        <label>
          Município
          <input value={municipio} onChange={(e) => setMunicipio(e.target.value)} />
        </label>
        <label>
          Comuna
          <input value={comuna} onChange={(e) => setComuna(e.target.value)} />
        </label>
        <button type="submit" disabled={aGuardar}>
          {aGuardar ? 'A guardar…' : 'Guardar alterações'}
        </button>
      </form>
    </div>
  );
}

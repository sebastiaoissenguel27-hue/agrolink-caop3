
export function ContaPendentePage() {
  return (
    <div style={{ padding: 24 }}>
      <h1>Conta em análise</h1>
      <p>
        O seu registo foi recebido. Um administrador precisa de ativar a sua
        conta antes de poder aceder à plataforma. Isto costuma demorar pouco
        tempo — tente novamente mais tarde.
      </p>
    </div>
  );
}

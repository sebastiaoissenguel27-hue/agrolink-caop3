import { Link } from 'react-router-dom';
import { Logo } from '@/shared/components/Logo';

export function PaginaNaoEncontradaPage() {
  return (
    <main className="al-not-found">
      <Logo size="md" />
      <p className="al-not-found-code">404</p>
      <h1>Página não encontrada</h1>
      <p>O endereço que procurou não existe ou já não está disponível.</p>
      <Link to="/" className="al-btn al-btn-primary">Voltar ao início</Link>
    </main>
  );
}
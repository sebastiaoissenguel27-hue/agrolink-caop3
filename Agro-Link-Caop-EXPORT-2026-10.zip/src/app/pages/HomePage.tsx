
import { Navigate } from 'react-router-dom';
import { useAuth } from '@/features/auth/context/AuthContext';
import { AgricultorDashboard } from '@/features/agricultor/pages/AgricultorDashboard';
import { Logo } from '@/shared/components/Logo';

/**
 * Ponto de entrada pós-login: cada papel tem o seu painel próprio.
 * O agricultor fica aqui mesmo (dashboard); técnico e admin são
 * encaminhados para as respetivas rotas dedicadas.
 */
export function HomePage() {
  const { perfil } = useAuth();

  if (!perfil) return <div style={{ minHeight: '50vh', display: 'grid', placeItems: 'center', padding: 24 }}><Logo size="lg" /></div>;
  if (perfil.papel === 'utilizador' && perfil.tipo_perfil === 'tecnico') return <Navigate to="/tecnico" replace />;
  if (['admin','admin_chefe'].includes(perfil.papel)) return <Navigate to="/admin" replace />;

  return <AgricultorDashboard />;
}

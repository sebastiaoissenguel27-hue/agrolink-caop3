import type { HTMLAttributes } from 'react';
import logoOficial from '@/shared/assets/agrolink-logo-master.png';

type LogoTamanho = 'sm' | 'md' | 'lg';

const TAMANHOS: Record<LogoTamanho, number> = {
  sm: 32,
  md: 48,
  lg: 72,
};

interface LogoProps extends HTMLAttributes<HTMLDivElement> {
  size?: LogoTamanho;
  mostrarNome?: boolean;
}

export function Logo({ size = 'md', mostrarNome = true, className = '', ...props }: LogoProps) {
  return (
    <div className={`al-logo ${className}`.trim()} {...props}>
      <img src={logoOficial} alt="AgroLink Caop" width={TAMANHOS[size]} height={TAMANHOS[size]} />
      {mostrarNome && <span>AgroLink Caop</span>}
    </div>
  );
}
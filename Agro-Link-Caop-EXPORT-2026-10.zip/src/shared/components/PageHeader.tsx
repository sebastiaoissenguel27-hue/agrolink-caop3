import type { ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from './Button';

interface PageHeaderProps {
  titulo: string;
  subtitulo?: string;
  acoes?: ReactNode;
  comVoltar?: boolean;
}

export function PageHeader({ titulo, subtitulo, acoes, comVoltar = true }: PageHeaderProps) {
  const navigate = useNavigate();

  return (
    <div className="al-page-header">
      <div className="al-page-header-main">
        {comVoltar && (
          <Button type="button" variant="secondary" onClick={() => navigate(-1)}>
            ← Voltar
          </Button>
        )}
        <div>
          <h1>{titulo}</h1>
          {subtitulo && <p>{subtitulo}</p>}
        </div>
      </div>
      {acoes && <div className="al-page-header-actions">{acoes}</div>}
    </div>
  );
}
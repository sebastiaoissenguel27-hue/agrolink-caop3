import type { ReactNode } from 'react';
import { Button } from './Button';

export function EstadoCarregando({ mensagem = 'A carregar…' }: { mensagem?: string }) {
  return <p className="al-state" role="status">{mensagem}</p>;
}

export function EstadoVazio({ mensagem }: { mensagem: string }) {
  return <p className="al-state al-state-empty">{mensagem}</p>;
}

export function EstadoErro({
  mensagem,
  onTentarNovamente,
}: {
  mensagem: string;
  onTentarNovamente?: () => void;
}) {
  return (
    <div className="al-state al-state-error" role="alert">
      <p>{mensagem}</p>
      {onTentarNovamente && (
        <Button type="button" variant="secondary" onClick={onTentarNovamente}>
          Tentar novamente
        </Button>
      )}
    </div>
  );
}

export function EstadoOffline({ children = 'Está offline — a mostrar dados guardados no dispositivo.' }: { children?: ReactNode }) {
  return <div className="al-state al-state-offline" role="status">{children}</div>;
}
import { NavLink } from 'react-router-dom';

export interface ItemBottomNav {
  to: string;
  rotulo: string;
  icone?: string;
}

export function BottomNav({ itens }: { itens: ItemBottomNav[] }) {
  return (
    <nav className="al-bottom-nav" aria-label="Navegação principal">
      {itens.slice(0, 5).map((item) => (
        <NavLink
          key={item.to}
          to={item.to}
          className={({ isActive }) => `al-bottom-nav-item${isActive ? ' is-active' : ''}`}
        >
          {item.icone && <span aria-hidden="true">{item.icone}</span>}
          <span>{item.rotulo}</span>
        </NavLink>
      ))}
    </nav>
  );
}
type StatusVariant = 'info' | 'success' | 'warning' | 'danger' | 'neutral';

const MAPA: Record<string, { label: string; variant: StatusVariant }> = {
  pendente: { label: 'Pendente', variant: 'warning' },
  em_analise: { label: 'Em análise', variant: 'info' },
  respondido: { label: 'Respondido', variant: 'success' },
  resolvido: { label: 'Resolvido', variant: 'success' },
  erro: { label: 'Erro', variant: 'danger' },
  urgente: { label: 'Urgente', variant: 'danger' },
  atencao: { label: 'Atenção', variant: 'warning' },
  info: { label: 'Informação', variant: 'info' },
};

export function StatusBadge({ status, label }: { status: string; label?: string }) {
  const config = MAPA[status] ?? { label: status, variant: 'neutral' as const };
  return <span className={`al-badge al-badge-${config.variant}`}>{label ?? config.label}</span>;
}
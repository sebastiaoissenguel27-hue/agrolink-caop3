import type { KeyboardEvent, ReactNode } from 'react';

interface CardProps {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
  ariaLabel?: string;
}

export function Card({ children, className = '', onClick, ariaLabel }: CardProps) {
  if (!onClick) return <div className={`al-card ${className}`.trim()}>{children}</div>;
  const handleClick = onClick;

  function onKeyDown(event: KeyboardEvent<HTMLDivElement>) {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      handleClick();
    }
  }

  return (
    <div
      className={`al-card al-card-interactive ${className}`.trim()}
      role="button"
      tabIndex={0}
      aria-label={ariaLabel}
      onClick={handleClick}
      onKeyDown={onKeyDown}
    >
      {children}
    </div>
  );
}

export function CardTitle({ children }: { children: ReactNode }) {
  return <h3 className="al-card-title">{children}</h3>;
}

// Português — única tradução completa nesta versão. As restantes línguas
// (kmb/umb/kon/cok) usam este mesmo ficheiro como fallback (ver LanguageContext.tsx)
// até terem tradução própria feita por um falante nativo — nunca inventamos
// traduções automáticas para línguas nacionais angolanas, por respeito e
// por rigor: um erro aqui é pior do que mostrar português por omissão.
export const pt = {
  nav: {
    inicio: 'Início',
    meusRelatos: 'Meus relatos',
    relatosZona: 'Relatos de todas as províncias',
    ferramentas: 'Ferramentas',
    recursos: 'Recursos',
    biblioteca: 'Biblioteca',
    academia: 'Academia',
    noticias: 'Notícias',
    alertas: 'Alertas',
    assistente: 'Assistente IA',
    configuracoes: 'Configurações',
    painelAdmin: 'Painel administrativo',
    perfil: 'Perfil',
    sair: 'Sair',
  },
  auth: {
    entrar: 'Entrar',
    criarConta: 'Criar conta',
    email: 'Email',
    palavraPasse: 'Palavra-passe',
    esqueciPalavraPasse: 'Esqueci-me da palavra-passe',
  },
  comum: {
    aCarregar: 'A carregar…',
    guardar: 'Guardar',
    apagar: 'Apagar',
    cancelar: 'Cancelar',
    semRede: 'Está offline — a mostrar dados guardados no dispositivo.',
  },
} as const;

export type ChaveTraducao = typeof pt;

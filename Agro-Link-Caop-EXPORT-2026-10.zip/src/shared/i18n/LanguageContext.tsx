
import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { pt } from '@/shared/i18n/locales/pt';
import { obterPreferencias, atualizarPreferencias } from '@/features/configuracoes/api/preferenciasService';
import { useAuth } from '@/features/auth/context/AuthContext';
import type { IdiomaApp } from '@/shared/types/database.types';

export const IDIOMAS_DISPONIVEIS: { valor: IdiomaApp; nome: string; traduzido: boolean }[] = [
  { valor: 'pt', nome: 'Português', traduzido: true },
  { valor: 'kmb', nome: 'Kimbundu', traduzido: false },
  { valor: 'umb', nome: 'Umbundu', traduzido: false },
  { valor: 'kon', nome: 'Kikongo', traduzido: false },
  { valor: 'cok', nome: 'Cokwe', traduzido: false },
];

// Todas as línguas apontam para o mesmo dicionário por agora — só "pt"
// tem tradução real. Quando uma língua ganhar o seu próprio ficheiro em
// locales/, troca-se aqui a entrada correspondente neste mapa.
const DICIONARIOS: Record<IdiomaApp, typeof pt> = {
  pt,
  kmb: pt,
  umb: pt,
  kon: pt,
  cok: pt,
};

interface LanguageContextValue {
  idioma: IdiomaApp;
  traducaoDisponivel: boolean;
  textos: typeof pt;
  mudarIdioma: (idioma: IdiomaApp) => Promise<void>;
}

const LanguageContext = createContext<LanguageContextValue | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const { perfil } = useAuth();
  const [idioma, setIdioma] = useState<IdiomaApp>('pt');

  useEffect(() => {
    if (!perfil) return;
    obterPreferencias(perfil.id).then((p) => {
      if (p?.idioma) setIdioma(p.idioma);
    }).catch(() => {});
  }, [perfil?.id]);

  async function mudarIdioma(novoIdioma: IdiomaApp) {
    setIdioma(novoIdioma);
    try {
      if (perfil) await atualizarPreferencias(perfil.id, { idioma: novoIdioma });
    } catch {
      // Sem rede: a escolha fica válida nesta sessão e sincroniza quando possível.
    }
  }

  const traduzido = IDIOMAS_DISPONIVEIS.find((i) => i.valor === idioma)?.traduzido ?? false;

  return (
    <LanguageContext.Provider
      value={{ idioma, traducaoDisponivel: traduzido, textos: DICIONARIOS[idioma], mudarIdioma }}
    >
      {children}
    </LanguageContext.Provider>
  );
}

export function useIdioma() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error('useIdioma deve ser usado dentro de <LanguageProvider>.');
  return ctx;
}

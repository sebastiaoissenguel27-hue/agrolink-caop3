
export const PAISES_PALOP = [
  { countryCode: 'AO', nome: 'Angola', bandeira: '🇦🇴' },
  { countryCode: 'MZ', nome: 'Moçambique', bandeira: '🇲🇿' },
  { countryCode: 'CV', nome: 'Cabo Verde', bandeira: '🇨🇻' },
  { countryCode: 'GW', nome: 'Guiné-Bissau', bandeira: '🇬🇼' },
  { countryCode: 'ST', nome: 'São Tomé e Príncipe', bandeira: '🇸🇹' },
] as const;

export type CountryCode = (typeof PAISES_PALOP)[number]['countryCode'];

export const COUNTRY_STORAGE_KEY = 'agrolink_country_code_v1';
export const COUNTRY_REGION_STORAGE_KEY = 'agrolink_country_region_v1';

export const DEFAULT_REGION_BY_COUNTRY: Record<CountryCode, string> = {
  AO: 'Luanda',
  MZ: 'Maputo',
  CV: 'Praia',
  GW: 'Bissau',
  ST: 'São Tomé',
};

export function obterPaisSelecionado(): { countryCode: CountryCode; nome: string; bandeira: string } | null {
  if (typeof window === 'undefined') return null;
  const raw = window.localStorage.getItem(COUNTRY_STORAGE_KEY);
  if (!raw) return null;
  const pais = PAISES_PALOP.find((item) => item.countryCode === raw);
  if (!pais) return null;
  return { countryCode: pais.countryCode, nome: pais.nome, bandeira: pais.bandeira };
}

export function guardarPaisSelecionado(countryCode: CountryCode) {
  if (typeof window === 'undefined') return;
  window.localStorage.setItem(COUNTRY_STORAGE_KEY, countryCode);
  const regiaoPadrao = DEFAULT_REGION_BY_COUNTRY[countryCode] ?? 'Luanda';
  window.localStorage.setItem(COUNTRY_REGION_STORAGE_KEY, regiaoPadrao);
}

export function limparPaisSelecionado() {
  if (typeof window === 'undefined') return;
  window.localStorage.removeItem(COUNTRY_STORAGE_KEY);
  window.localStorage.removeItem(COUNTRY_REGION_STORAGE_KEY);
}

export function obterContextoIA() {
  const pais = obterPaisSelecionado();
  const countryCode = pais?.countryCode ?? 'AO';
  const region =
    (typeof window !== 'undefined' ? window.localStorage.getItem(COUNTRY_REGION_STORAGE_KEY) : null) ??
    DEFAULT_REGION_BY_COUNTRY[countryCode] ??
    'Luanda';

  return {
    countryCode,
    region,
    idioma: 'pt',
    contextoAgricola: `Uso da plataforma AgroLink Caop para agricultura em ${pais?.nome ?? 'Angola'}; adaptar respostas ao contexto do país, à região e ao idioma do utilizador.`,
  } as const;
}

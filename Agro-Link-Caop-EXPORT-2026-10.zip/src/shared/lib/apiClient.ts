export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) { super(message); this.name='ApiError'; this.status=status; }
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const response = await fetch(path, { credentials: 'include', headers: { 'content-type': 'application/json', ...(init.headers || {}) }, ...init });
  const text = await response.text();
  let payload: any = null;
  try { payload = text ? JSON.parse(text) : null; } catch { payload = null; }
  if (!response.ok) throw new ApiError(response.status, payload?.error || `Pedido falhou (${response.status}).`);
  return payload as T;
}
export function apiGet<T>(path: string) { return request<T>(path); }
export function apiPost<T>(path: string, body?: unknown) { return request<T>(path,{method:'POST',body:JSON.stringify(body ?? {})}); }
export function apiPatch<T>(path: string, body?: unknown) { return request<T>(path,{method:'PATCH',body:JSON.stringify(body ?? {})}); }
export function apiDelete<T>(path: string) { return request<T>(path,{method:'DELETE'}); }
export async function apiUpload(path: string, file: File, _campo='file'): Promise<{ caminho: string }> {
  const bytes = new Uint8Array(await file.arrayBuffer());
  let binary=''; for(let i=0;i<bytes.length;i+=0x8000) binary += String.fromCharCode(...bytes.subarray(i,i+0x8000));
  return apiPost(path,{filename:file.name,mimeType:file.type,data:btoa(binary)});
}
export async function apiUploadBlob(path:string, blob:Blob, filename:string, uploadId?:string):Promise<{caminho:string}>{
  const bytes=new Uint8Array(await blob.arrayBuffer()); let binary=''; for(let i=0;i<bytes.length;i+=0x8000) binary += String.fromCharCode(...bytes.subarray(i,i+0x8000));
  return apiPost(path,{filename,mimeType:blob.type,data:btoa(binary),uploadId});
}

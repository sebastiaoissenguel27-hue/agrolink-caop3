
export type PapelUtilizador = 'utilizador' | 'admin' | 'admin_chefe';
export type TipoPerfilProfissional = 'agricultor' | 'tecnico' | 'administrador';
export type NivelAdmin = 'normal' | 'auditor';

/** Estado geral da conta. Só um admin pode alterar este valor. */
export type StatusConta = 'ativo' | 'pendente' | 'bloqueado';

/**
 * Verificação profissional, exclusiva de técnicos.
 * `null` para agricultores e admins.
 */
export type StatusVerificacaoTecnico = 'pendente' | 'aprovado' | 'rejeitado';

export interface ProfileRow {
  id: string;
  nome: string;
  papel: PapelUtilizador;
  tipo_perfil: TipoPerfilProfissional | null;
  nivel_admin: NivelAdmin;
  status: StatusConta;
  verification_status: StatusVerificacaoTecnico | null;
  provincia: string | null;
  municipio: string | null;
  comuna: string | null;
  telefone: string | null;
  criado_em: string;
  suspenso_em?: string | null;
  suspenso_por?: string | null;
  motivo_suspensao?: string | null;
}

// status e verification_status ficam de fora de propósito: são geridos
// pelo servidor (trigger + valores por omissão), nunca pelo cliente.
export interface ProfileInsert {
  id: string;
  nome: string;
  papel: PapelUtilizador;
  tipo_perfil?: TipoPerfilProfissional | null;
  nivel_admin?: NivelAdmin;
  provincia?: string | null;
  municipio?: string | null;
  comuna?: string | null;
  telefone?: string | null;
}

// papel/status/verification_status entram aqui só para o admin poder
// chamar .update({...}) sem luta com o compilador — a proteção real
// contra utilizadores normais mudarem estes campos está no servidor
// (política RLS "profiles_update_admin" + trigger "proteger_campos_sensiveis"),
// não neste tipo.
export interface ProfileUpdate {
  nome?: string;
  provincia?: string | null;
  municipio?: string | null;
  comuna?: string | null;
  telefone?: string | null;
  papel?: PapelUtilizador;
  tipo_perfil?: TipoPerfilProfissional | null;
  nivel_admin?: NivelAdmin;
  status?: StatusConta;
  verification_status?: StatusVerificacaoTecnico | null;
}

// ── Denúncias ───────────────────────────────────────────────────────
export type EstadoDenuncia = 'pendente' | 'em_analise' | 'confirmada' | 'rejeitada' | 'arquivada';
export type PrioridadeDenuncia = 'baixa' | 'media' | 'alta' | 'urgente';
export interface DenunciaRow {
  id: string; autor_id: string; denunciado_id: string; transporte_id: string | null;
  categoria: string; descricao: string; evidencias: string[]; estado: EstadoDenuncia; prioridade: PrioridadeDenuncia;
  admin_responsavel_id: string | null; decisao: string | null; sugestao_ia: string | null; data_resolucao: string | null; criado_em: string;
  autor_nome?: string; autor_papel?: PapelUtilizador; denunciado_nome?: string; denunciado_papel?: PapelUtilizador; admin_responsavel_nome?: string | null;
}

// ── Relatos ──────────────────────────────────────────────────────────
export type TipoRelato = 'praga' | 'doenca' | 'clima' | 'solo' | 'pedido_apoio' | 'outro';
export type StatusRelato = 'pendente' | 'em_analise' | 'respondido' | 'resolvido';
export type TipoMidia = 'foto' | 'audio';

export interface RelatoRow {
  id: string;
  autor_id: string | null;
  codigo_publico: string | null;
  tipo: TipoRelato;
  descricao: string;
  provincia: string | null;
  municipio: string | null;
  comuna: string | null;
  status: StatusRelato;
  tecnico_atribuido_id: string | null;
  criado_em: string;
}

// codigo_publico nunca é definido pelo cliente — o servidor gera-o.
export interface RelatoInsert {
  autor_id: string | null;
  tipo: TipoRelato;
  descricao: string;
  provincia?: string | null;
  municipio?: string | null;
  comuna?: string | null;
}

export interface RelatoUpdate {
  status?: StatusRelato;
  tecnico_atribuido_id?: string | null;
}

export interface RelatoMidiaRow {
  id: string;
  relato_id: string;
  tipo: TipoMidia;
  caminho_storage: string;
  criado_em: string;
}

export interface RelatoMidiaInsert {
  relato_id: string;
  tipo: TipoMidia;
  caminho_storage: string;
}

export interface RelatoRespostaRow {
  id: string;
  relato_id: string;
  tecnico_id: string;
  comentario: string;
  criado_em: string;
}

export interface RelatoRespostaInsert {
  relato_id: string;
  tecnico_id: string;
  comentario: string;
}

// ── Notícias e alertas ───────────────────────────────────────────────
export type CategoriaNoticia =
  | 'Culturas' | 'Pecuária' | 'Clima' | 'Mercados' | 'Tecnologia'
  | 'Investigação' | 'Políticas Públicas' | 'Pragas e Doenças' | 'Formação' | 'Ambiente';

export interface NoticiaRow {
  id: string;
  titulo: string;
  [key: string]: unknown;
  resumo: string | null;
  conteudo: string;
  imagem_url: string | null;
  autor_id: string | null;
  categoria: string | null;
  categoria_ia: CategoriaNoticia | null;
  pais: string | null;
  relevante: boolean;
  publicado_em: string;
  url_original: string | null;
  fonte_id: string | null;
}

export interface NoticiaInsert {
  titulo: string;
  [key: string]: unknown;
  resumo?: string | null;
  conteudo: string;
  imagem_url?: string | null;
  autor_id?: string | null;
  categoria?: string | null;
  categoria_ia?: CategoriaNoticia | null;
  pais?: string | null;
  relevante?: boolean;
  url_original?: string | null;
  fonte_id?: string | null;
}

export type NivelAlerta = 'info' | 'atencao' | 'urgente';

export interface AlertaRow {
  id: string;
  titulo: string;
  [key: string]: unknown;
  descricao: string;
  tipo: string | null;
  provincias_alvo: string[];
  nivel: NivelAlerta;
  criado_por: string | null;
  criado_em: string;
  expira_em: string | null;
}

export interface AlertaInsert {
  titulo: string;
  descricao: string;
  tipo?: string | null;
  provincias_alvo?: string[];
  nivel?: NivelAlerta;
  criado_por?: string | null;
  expira_em?: string | null;
}

// ── Assistente IA agrícola ───────────────────────────────────────────
export interface IaConversaRow {
  id: string;
  utilizador_id: string;
  criado_em: string;
}

export interface IaMensagemRow {
  id: string;
  conversa_id: string;
  role: 'user' | 'assistant';
  conteudo: string;
  criado_em: string;
}

// Tipos do modelo de dados interno do AgroLink.
// Será ampliada com "relatos", "alertas", etc. nas fases seguintes.
// ── Auditoria e notificações ─────────────────────────────────────────
export interface AuditoriaRow {
  id: string;
  ator_id: string | null;
  acao: string;
  entidade: string;
  entidade_id: string | null;
  detalhes: Record<string, unknown> | null;
  criado_em: string;
}

export interface NotificacaoRow {
  id: string;
  destinatario_id: string;
  titulo: string;
  corpo: string | null;
  tipo: string;
  lida: boolean;
  relacionado_tipo: string | null;
  relacionado_id: string | null;
  criado_em: string;
}

export interface DispositivoPushRow {
  id: string;
  utilizador_id: string;
  token: string;
  plataforma: string;
  criado_em: string;
}

export interface TecnicoDocumentoRow {
  id: string;
  tecnico_id: string;
  caminho_storage: string;
  descricao: string | null;
  criado_em: string;
}

export interface NoticiaFonteRow {
  id: string;
  nome: string;
  url_rss: string | null;
  categoria: string | null;
  ativo: boolean;
  ambito: 'nacional' | 'internacional';
  pais: string | null;
  prioridade: number;
  criado_em: string;
}

export interface NoticiaFonteInsert {
  nome: string;
  url_rss?: string | null;
  categoria?: string | null;
  ativo?: boolean;
  ambito?: 'nacional' | 'internacional';
  pais?: string | null;
  prioridade?: number;
}

// ── Configurações ─────────────────────────────────────────────────────
export type IdiomaApp = 'pt' | 'kmb' | 'umb' | 'kon' | 'cok';

export interface PreferenciasUtilizadorRow {
  utilizador_id: string;
  notif_respostas_relato: boolean;
  notif_noticias: boolean;
  notif_alertas: boolean;
  notif_novos_cursos: boolean;
  notif_progresso_academia: boolean;
  notif_calendario_agricola: boolean;
  idioma: IdiomaApp;
  atualizado_em: string;
}

export type PreferenciasUtilizadorUpdate = Partial<
  Omit<PreferenciasUtilizadorRow, 'utilizador_id' | 'atualizado_em'>
>;

// ── Ferramentas agrícolas ────────────────────────────────────────────
export type NomeFerramenta = 'dose_insumo' | 'calendario_plantio';

export interface FerramentaCalculoRow {
  id: string;
  utilizador_id: string;
  ferramenta: NomeFerramenta;
  entradas: Record<string, unknown>;
  resultado: Record<string, unknown>;
  criado_em: string;
}

// ── Centro de recursos ───────────────────────────────────────────────
export interface RecursoExternoRow {
  id: string;
  titulo: string;
  descricao: string | null;
  categoria: string | null;
  url: string | null;
  contacto: string | null;
  criado_em: string;
}

export interface RecursoExternoInsert {
  titulo: string;
  descricao?: string | null;
  categoria?: string | null;
  url?: string | null;
  contacto?: string | null;
}

export interface PerguntaFrequenteRow {
  id: string;
  pergunta: string;
  [key: string]: unknown;
  resposta: string;
  categoria: string | null;
  ordem: number;
  criado_em: string;
}

export interface PerguntaFrequenteInsert {
  pergunta: string;
  resposta: string;
  categoria?: string | null;
  ordem?: number;
}

// ── Biblioteca AgroLink ──────────────────────────────────────────────
export type TipoDocumentoBiblioteca = 'pdf' | 'guia' | 'manual' | 'outro';

export interface BibliotecaDocumentoRow {
  id: string;
  titulo: string;
  [key: string]: unknown;
  descricao: string | null;
  categoria: string | null;
  tipo: TipoDocumentoBiblioteca;
  caminho_storage: string | null;
  url_externo: string | null;
  autor_id: string | null;
  publicado_em: string;
}

export interface BibliotecaDocumentoInsert {
  titulo: string;
  descricao?: string | null;
  categoria?: string | null;
  tipo?: TipoDocumentoBiblioteca;
  caminho_storage?: string | null;
  url_externo?: string | null;
  autor_id?: string | null;
}

// ── Academia AgroLink ────────────────────────────────────────────────
export type TipoLicao = 'texto' | 'imagem' | 'pdf' | 'video';

export interface AcademiaCursoRow {
  id: string;
  titulo: string;
  descricao: string | null;
  categoria: string | null;
  autor_id: string | null;
  publicado_em: string;
}

export interface AcademiaCursoInsert {
  titulo: string;
  descricao?: string | null;
  categoria?: string | null;
  autor_id?: string | null;
}

export interface AcademiaLicaoRow {
  id: string;
  curso_id: string;
  titulo: string;
  tipo: TipoLicao;
  conteudo_texto: string | null;
  caminho_storage: string | null;
  ordem: number;
  criado_em: string;
}

export interface AcademiaLicaoInsert {
  curso_id: string;
  titulo: string;
  tipo?: TipoLicao;
  conteudo_texto?: string | null;
  caminho_storage?: string | null;
  ordem?: number;
}

/** Forma devolvida pela RPC obter_questionario_licao — nunca inclui a resposta certa. */
export interface QuestionarioPergunta {
  id: string;
  pergunta: string;
  opcoes: string[];
}

export interface AcademiaProgressoRow {
  utilizador_id: string;
  licao_id: string;
  concluida: boolean;
  pontuacao_questionario: number | null;
  atualizado_em: string;
}

/** Linha completa (com resposta_correta) — só o admin consegue fazer SELECT nesta tabela. */
export interface AcademiaQuestionarioAdminRow {
  id: string;
  licao_id: string;
  pergunta: string;
  opcoes: string[];
  resposta_correta: number;
  ordem: number;
}

export interface AcademiaQuestionarioInsert {
  licao_id: string;
  pergunta: string;
  opcoes: string[];
  resposta_correta: number;
  ordem?: number;
}

// ── IA — analytics e resumos mensais (só admin) ──────────────────────
export interface IaPerguntaAnalyticsRow {
  id: string;
  utilizador_id: string | null;
  provincia: string | null;
  tema: string | null;
  culturas: string[];
  pragas: string[];
  confianca: string | null;
  encaminhado: boolean;
  criado_em: string;
}

export interface EstatisticasIA {
  total_perguntas: number;
  por_dia: { dia: string; total: number }[];
  por_mes: { mes: string; total: number }[];
  por_provincia: { provincia: string; total: number }[];
  temas_frequentes: { tema: string; total: number }[];
  culturas_frequentes: { cultura: string; total: number }[];
  pragas_frequentes: { praga: string; total: number }[];
  confianca_media_pct: number | null;
  total_encaminhados: number;
  total_resolvidas_so_ia: number;
}

export interface IaResumoMensalRow {
  id: string;
  mes: number;
  ano: number;
  conteudo: string;
  gerado_em: string;
}

// ── Notícias — logs de sincronização ─────────────────────────────────
export interface NoticiaSyncLogRow {
  id: string;
  fonte_id: string | null;
  sucesso: boolean;
  itens_inseridos: number;
  itens_ignorados: number;
  mensagem_erro: string | null;
  executado_em: string;
}

type TablesWithRelationships<Tables> = {
  [TableName in keyof Tables]: Tables[TableName] extends {
    Row: infer Row;
    Insert: infer Insert;
    Update: infer Update;
  }
    ? {
        Row: Row & Record<string, unknown>;
        Insert: Insert & Record<string, unknown>;
        Update: Update & Record<string, unknown>;
        Relationships: [];
      }
    : never;
};

export interface Database {
  public: {
    Tables: TablesWithRelationships<{
      profiles: {
        Row: ProfileRow;
        Insert: ProfileInsert;
        Update: ProfileUpdate;
      };
      relatos: {
        Row: RelatoRow;
        Insert: RelatoInsert;
        Update: RelatoUpdate;
      };
      relato_midias: {
        Row: RelatoMidiaRow;
        Insert: RelatoMidiaInsert;
        Update: Partial<RelatoMidiaInsert>;
      };
      relato_respostas: {
        Row: RelatoRespostaRow;
        Insert: RelatoRespostaInsert;
        Update: Partial<RelatoRespostaInsert>;
      };
      noticias: {
        Row: NoticiaRow;
        Insert: NoticiaInsert;
        Update: Partial<NoticiaInsert>;
      };
      alertas: {
        Row: AlertaRow;
        Insert: AlertaInsert;
        Update: Partial<AlertaInsert>;
      };
      ia_conversas: {
        Row: IaConversaRow;
        Insert: Pick<IaConversaRow, 'utilizador_id'>;
        Update: never;
      };
      ia_mensagens: {
        Row: IaMensagemRow;
        Insert: Omit<IaMensagemRow, 'id' | 'criado_em'>;
        Update: never;
      };
      auditoria: {
        Row: AuditoriaRow;
        Insert: never; // só via função registar_auditoria()
        Update: never;
      };
      notificacoes: {
        Row: NotificacaoRow;
        Insert: never; // só via função criar_notificacao()
        Update: Pick<NotificacaoRow, 'lida'>;
      };
      dispositivos_push: {
        Row: DispositivoPushRow;
        Insert: Omit<DispositivoPushRow, 'id' | 'criado_em'>;
        Update: never;
      };
      tecnico_documentos: {
        Row: TecnicoDocumentoRow;
        Insert: Omit<TecnicoDocumentoRow, 'id' | 'criado_em'>;
        Update: never;
      };
      noticias_fontes: {
        Row: NoticiaFonteRow;
        Insert: NoticiaFonteInsert;
        Update: Partial<NoticiaFonteInsert>;
      };
      preferencias_utilizador: {
        Row: PreferenciasUtilizadorRow;
        Insert: Pick<PreferenciasUtilizadorRow, 'utilizador_id'>;
        Update: PreferenciasUtilizadorUpdate;
      };
      ferramenta_calculos: {
        Row: FerramentaCalculoRow;
        Insert: Omit<FerramentaCalculoRow, 'id' | 'criado_em'>;
        Update: never;
      };
      recursos_externos: {
        Row: RecursoExternoRow;
        Insert: RecursoExternoInsert;
        Update: Partial<RecursoExternoInsert>;
      };
      perguntas_frequentes: {
        Row: PerguntaFrequenteRow;
        Insert: PerguntaFrequenteInsert;
        Update: Partial<PerguntaFrequenteInsert>;
      };
      biblioteca_documentos: {
        Row: BibliotecaDocumentoRow;
        Insert: BibliotecaDocumentoInsert;
        Update: Partial<BibliotecaDocumentoInsert>;
      };
      academia_cursos: {
        Row: AcademiaCursoRow;
        Insert: AcademiaCursoInsert;
        Update: Partial<AcademiaCursoInsert>;
      };
      academia_licoes: {
        Row: AcademiaLicaoRow;
        Insert: AcademiaLicaoInsert;
        Update: Partial<AcademiaLicaoInsert>;
      };
      academia_questionarios: {
        Row: AcademiaQuestionarioAdminRow;
        Insert: AcademiaQuestionarioInsert;
        Update: Partial<AcademiaQuestionarioInsert>;
      };
      academia_progresso: {
        Row: AcademiaProgressoRow;
        Insert: Pick<AcademiaProgressoRow, 'utilizador_id' | 'licao_id'>;
        Update: never;
      };
      ia_perguntas_analytics: {
        Row: IaPerguntaAnalyticsRow;
        Insert: never; // só via RPC registar_pergunta_ia()
        Update: never;
      };
      ia_resumos_mensais: {
        Row: IaResumoMensalRow;
        Insert: never; // só via Edge Function (service role)
        Update: never;
      };
      noticias_sync_logs: {
        Row: NoticiaSyncLogRow;
        Insert: never; // só via Edge Function (service role)
        Update: never;
      };
    }>;
    Views: Record<string, never>;
    Functions: {
      consultar_relato_por_codigo: {
        Args: { p_codigo: string };
        Returns: RelatoRow | null;
      };
      marcar_licao_concluida: {
        Args: { p_licao_id: string };
        Returns: undefined;
      };
      obter_questionario_licao: {
        Args: { p_licao_id: string };
        Returns: QuestionarioPergunta[];
      };
      submeter_resposta_questionario: {
        Args: { p_questionario_id: string; p_resposta: number };
        Returns: { correto: boolean };
      };
      obter_estatisticas: {
        Args: Record<string, never>;
        Returns: unknown;
      };
      obter_estatisticas_ia: {
        Args: Record<string, never>;
        Returns: EstatisticasIA;
      };
      enviar_mensagem_admin: {
        Args: { p_titulo: string; p_corpo: string; p_papel: string | null };
        Returns: number;
      };
      marcar_pergunta_encaminhada: {
        Args: { p_id: string };
        Returns: undefined;
      };
      registar_pergunta_ia: {
        Args: {
          p_tema: string;
          p_culturas: string[];
          p_pragas: string[];
          p_confianca: string;
        };
        Returns: string;
      };
    };
  };
}

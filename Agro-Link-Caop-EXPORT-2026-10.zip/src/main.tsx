
import { StrictMode, Component, type ReactNode } from 'react';
import { createRoot } from 'react-dom/client';
import { registerSW } from 'virtual:pwa-register';
import { App } from '@/app/App';
import '@/shared/styles/tokens.css';
import '@/shared/components/ui.css';
import '@/app/components/layout.css';

class AppBootstrapErrorBoundary extends Component<
  { children: ReactNode },
  { hasError: boolean }
> {
  constructor(props: { children: ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch() {
    // Sem expor stack traces / chaves / tokens ao utilizador.
    console.error('AgroLink falhou ao iniciar.');
  }

  render() {
    if (this.state.hasError) {
      return (
        <div
          style={{
            minHeight: '100vh',
            display: 'grid',
            placeItems: 'center',
            padding: 24,
            fontFamily: 'system-ui, sans-serif',
            color: '#1f3d2b',
            background: '#f7f5ef',
            textAlign: 'center',
          }}
        >
          <div>
            <h1 style={{ margin: 0, fontSize: '1.5rem' }}>AgroLink Caop</h1>
            <p style={{ marginTop: 12, marginBottom: 0 }}>
              Não foi possível iniciar a aplicação neste momento.
            </p>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

const rootElement = document.getElementById('root');

if (!rootElement) {
  throw new Error('Elemento #root não foi encontrado no HTML do app.');
}

try {
  registerSW({
    immediate: true,
    onNeedRefresh() {
      window.dispatchEvent(new Event('agrolink:pwa-update'));
    },
  });
} catch (error) {
  console.error('Falha ao registar o service worker do AgroLink.', error);
}

createRoot(rootElement).render(
  <StrictMode>
    <AppBootstrapErrorBoundary>
      <App />
    </AppBootstrapErrorBoundary>
  </StrictMode>
);
